fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Seu Servidor'
description 'Empregos Ilegais - Portado para QBCore'
version '2.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    '@qbx_core/modules/lib.lua',
    'ConfigClient.lua',
    'Config.lua',
    'cfg_desmanche/Config.lua'
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client-side/*.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server-side/vrp_compat.lua',
    'server-side/*.lua'
}
