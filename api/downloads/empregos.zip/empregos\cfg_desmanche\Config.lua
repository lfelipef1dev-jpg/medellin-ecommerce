Config_desmanche = {

    permissao = "thelost", -- Permissão para desmanchar
    permissao2 = "bikers", -- Permissão para desmanchar
    permissao3 = "suporte", -- Permissão para desmanchar
    permissao4 = "admin", -- Permissão para desmanchar

    tempo_remover_pecas = 3000, -- Tempo em milisegundos que o player demora para remover a peça do veículo

    coordenadas_locais_desmanche = {
        [1] = { ['x'] = 1035.5291748047, ['y'] = -2512.65234375, ['z'] = 28.31658744812 },
        [2] = { ['x'] = -2209.9191894531, ['y'] = 4230.349609375, ['z'] = 48.32691192627 }
    },

    -- H é a direção para qual o player vai olhar ao entregar a peça.
    coordenadas_locais_guardarPecas = {
        [1] = { ['x'] = 1037.8037109375, ['y'] = -2518.4516601562, ['z'] = 28.298429489136 }, 
        [2] = { ['x'] = -2213.6467285156, ['y'] = 4232.9741210938, ['z'] = 48.311347961426 }
        
    },

    -- Coordenadas dos locais onde o player poderá vender as peças desmontadas.
    -- IMPORTANTE: DEIXAR NA MESMA ORDEM DOS LOCAIS DE DESMANCHE.
    -- Exemplo: No PRIMEIRO local de desmanche o player poderá vender as peças no PRIMEIRO local de venda abaixo.
    coordenadas_locais_venda = {
        [1] = { ['x'] = 1037.3089599609, ['y'] = -2525.4516601562, ['z'] = 28.29843711853 },
        [2] = { ['x'] = -2218.45703125, ['y'] = 4230.3217773438, ['z'] = 48.311363220215 }
    },

    -- Bom, pode ser que no seu servidor os nomes dos itens sejam diferentes. Neste caso terá que mexer aqui:
    itens = {
        ['rodaDeCarro'] = "tires",
        ['portaDeCarro'] = "aluminum",
        ['rodaDeMoto'] = "tires",
    },

    -- Itens recebidos após o término do desmanche
    itens_extra = {
        -- DE 1 À 4 PARA CARROS
        [1] = { ['nome'] = "aluminum", ['qtd'] = 25 },
        [2] = { ['nome'] = "plastic", ['qtd'] = 15 },
        [3] = { ['nome'] = "copper", ['qtd'] = 25 },
        [4] = { ['nome'] = "rubber", ['qtd'] = 40 },
        [5] = { ['nome'] = "aluminum", ['qtd'] = 10 },
        [6] = { ['nome'] = "tires", ['qtd'] = 2 },
    },

    -- ============================================================
    -- ECONOMIA 2026 - Desmanche
    -- Valor reduzido de $35.000 para $6.500 (padrão servidor grande)
    -- Mantém materiais para crafting + dinheiro sujo razoável
    -- Ganho total: ~$6.500 + materiais (valor justo para atividade ilegal de baixo risco)
    -- ============================================================
    dinheirosujo = 6500,

    -- À direita logo abaixo temos os objetos que o player carrega na mão durante o processo de desmanche
    -- Existem diversos modelos de rodas/portas, etc que o player pode pegar.
    -- Se quiser alterar você pode encontrar os objetos em: https://gta-objects.xyz/objects
    -- No site acima pesquise por: door, wheel, etc para encontrar o prop desejado. Escolha o que quiser testar e substitua o nome à direta.
    props = {
        ['portas'] = 'imp_prop_impexp_car_door_04a',
        ['rodas'] = 'prop_tornado_wheel',
    },

}