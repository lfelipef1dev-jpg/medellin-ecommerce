# Empregos Ilegais para FiveM (QBox / QBCore)

Sistema de empregos ilegais com plantio, desmanche de veículos e corridas de rua.

## Empregos Inclusos

| Emprego | Descrição |
|---------|-----------|
| **Plantio (WePlant)** | Plante, cultive e colha drogas em locais configuráveis |
| **Desmanche** | Roube e desmanche veículos por peças |
| **Corridas de Rua** | Crie e participe de corridas ilegais entre jogadores |

## Funcionalidades

- Configuração completa de locais, itens e recompensas
- Integração com `ox_inventory` (itens, peso, etc.)
- Timers de plantio realistas
- Sistema de corridas com seleção de rotas

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)
- `ox_inventory`
- `oxmysql`

## Instalação

1. Coloque a pasta `empregos` dentro de `resources/`
2. Adicione ao `server.cfg`:
   ```
   ensure empregos
   ```
3. Configure locais e recompensas em `Config.lua` e `ConfigClient.lua`

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
