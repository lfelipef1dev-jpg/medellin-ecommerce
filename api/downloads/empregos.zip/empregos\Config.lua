Config_cashmachine = {}

-- Valores por pilha (4 pilhas no total) - idêntico ao vrp_yorkcaixa (Creative)
-- Total possível: $13.600 - $21.600
Config_cashmachine.minValorPilha = 3400
Config_cashmachine.maxValorPilha = 5400

-- Cooldown entre roubos: 1800 seg (30 min)
Config_cashmachine.cooldown = 1800

-- Timer padrão da bomba (usado como fallback, cada ATM tem seu timer próprio)
Config_cashmachine.timeC4 = 25
