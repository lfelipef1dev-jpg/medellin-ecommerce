-- ============================================================
-- Compatibilidade QBox + ox_lib + ox_inventory
-- (substitui VRP Tunnel/Proxy e QBCore antigo)
-- ============================================================

-- Utilidade: parseInt compatível
function parseInt(n) return math.floor(tonumber(n) or 0) end

-- Utilidade: Contar policiais online
function GetOnlinePolice()
    local cops = {}
    local players = exports.qbx_core:GetQBPlayers()
    for _, player in pairs(players) do
        if player and player.PlayerData and player.PlayerData.job then
            local jobName = player.PlayerData.job.name
            if jobName == 'police' or jobName == 'bcso' or jobName == 'sast' or jobName == 'sasp' or jobName == 'lssd' then
                if player.PlayerData.job.onduty then
                    table.insert(cops, player.PlayerData.source)
                end
            end
        end
    end
    return cops
end

-- Utilidade: Verificar se player tem item (ox_inventory)
function HasItem(src, itemName, amount)
    local count = exports.ox_inventory:GetItemCount(src, itemName)
    return count and count >= (amount or 1)
end

-- Utilidade: Remover item do player (ox_inventory)
function RemoveItem(src, itemName, amount)
    if not HasItem(src, itemName, amount) then return false end
    return exports.ox_inventory:RemoveItem(src, itemName, amount or 1)
end

-- Utilidade: Dar item ao player (ox_inventory)
function GiveItem(src, itemName, amount)
    return exports.ox_inventory:AddItem(src, itemName, amount or 1)
end

-- Utilidade: Notificar player (ox_lib)
function Notify(src, msg, nType, duration)
    TriggerClientEvent('ox_lib:notify', src, {
        title = 'Empregos',
        description = msg,
        type = nType or 'inform',
        duration = duration or 5000,
    })
end

-- ============================================================
-- SHIM QBCore para scripts que ainda usam API antiga
-- (cashmachine, desmanche, robberys, minerador, makeraces)
-- ============================================================
QBCore = {
    Functions = {
        GetPlayer = function(src)
            return exports.qbx_core:GetPlayer(src)
        end,
        GetQBPlayers = function()
            local players = {}
            for _, playerId in ipairs(GetPlayers()) do
                local src = tonumber(playerId)
                if src then
                    local player = exports.qbx_core:GetPlayer(src)
                    if player then
                        players[src] = player
                    end
                end
            end
            return players
        end,
        HasPermission = function(src, perm)
            return IsPlayerAceAllowed(src, 'command')
        end,
        CreateCallback = function(name, cb)
            lib.callback.register(name, function(source, ...)
                local retval
                cb(source, function(val)
                    retval = val
                end, ...)
                return retval
            end)
        end,
    },
    Shared = {
        Items = setmetatable({}, {
            __index = function(_, key)
                local ok, item = pcall(exports.ox_inventory.Items, exports.ox_inventory, key)
                return ok and item or nil
            end,
        }),
    },
}
