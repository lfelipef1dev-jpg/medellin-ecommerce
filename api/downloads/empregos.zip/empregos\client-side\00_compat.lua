-- ============================================================
-- Compatibilidade Client QBox + ox_lib
-- Shim para scripts que usam QBCore.Functions.TriggerCallback
-- e QBCore.Functions.Notify (cashmachine, desmanche, etc)
-- ============================================================

-- parseInt global
function parseInt(n) return math.floor(tonumber(n) or 0) end

QBCore = {
    Functions = {
        -- Mapeia QBCore.Functions.TriggerCallback para lib.callback
        TriggerCallback = function(name, cb, ...)
            local args = { ... }
            CreateThread(function()
                local result = lib.callback.await(name, false, table.unpack(args))
                if cb then cb(result) end
            end)
        end,
        -- Mapeia QBCore.Functions.Notify para lib.notify
        Notify = function(msg, nType, duration)
            lib.notify({
                title = 'Empregos',
                description = msg,
                type = nType or 'inform',
                duration = duration or 5000,
            })
        end,
        -- GetPlayerData via qbx_core
        GetPlayerData = function()
            return exports.qbx_core:GetPlayerData()
        end,
    },
}
