-- ============================================================
-- PLANTACOES CLIENT - QBox + ox_lib
-- Igual Portal: progresso 0-300, estagios 40/70/100
-- ============================================================

-- Definir sempre (evita nil em qualquer cenario)
local function parseInt(n) return math.floor(tonumber(n) or 0) end
local function dwText(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if not onScreen then return end
    SetTextFont(4)
    SetTextScale(0.35, 0.35)
    SetTextColour(255, 255, 255, 100)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 400
    DrawRect(_x, _y + 0.0125, 0.01 + factor, 0.03, 0, 0, 0, 100)
end

-- ============================================================
-- VARIAVEIS
-- ============================================================
local wePlants = {}
local weObjects = {}
local isPlanting = false
local isHarvesting = false

local weHashsA = 'bkr_prop_weed_01_small_01c'  -- 0-39
local weHashsB = 'bkr_prop_weed_01_small_01a'  -- 40-69
local weHashsC = 'bkr_prop_weed_med_01a'        -- 70-99
local weHashsD = 'bkr_prop_weed_lrg_01a'        -- 100+

local PLANT_ANIM_DICT = 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@'
local PLANT_ANIM_CLIP = 'machinic_loop_mechandplayer'

-- ============================================================
-- CREATEMODELS (igual Portal)
-- ============================================================
function createModels(id, hash, x, y, z)
    local mHash = GetHashKey(hash)

    RequestModel(mHash)
    while not HasModelLoaded(mHash) do
        RequestModel(mHash)
        Citizen.Wait(10)
    end

    weObjects[id] = CreateObjectNoOffset(mHash, x, y, z, false, true, true)
    SetEntityAsMissionEntity(weObjects[id], true, true)
    PlaceObjectOnGroundProperly(weObjects[id])
    FreezeEntityPosition(weObjects[id], true)
    SetModelAsNoLongerNeeded(mHash)
end

-- ============================================================
-- REMOVEOBJECT
-- ============================================================
function removeObject(id)
    if weObjects[id] and DoesEntityExist(weObjects[id]) then
        SetEntityAsMissionEntity(weObjects[id], false, false)
        DeleteEntity(weObjects[id])
    end
    weObjects[id] = nil
end

-- ============================================================
-- LOOP PRINCIPAL (igual Portal: so cria modelo A no inicio)
-- ============================================================
Citizen.CreateThread(function()
    while true do
        local timeDistance = 500
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        for k, v in pairs(wePlants) do
            local distance = #(coords - vector3(v[1], v[2], v[3]))

            if distance < 35 then
                if weObjects[k] == nil then
                    -- Criar modelo baseado no progresso atual
                    if v[4] <= 39 then
                        createModels(k, weHashsA, v[1], v[2], v[3])
                    elseif v[4] <= 69 then
                        createModels(k, weHashsB, v[1], v[2], v[3])
                    elseif v[4] <= 99 then
                        createModels(k, weHashsC, v[1], v[2], v[3])
                    else
                        createModels(k, weHashsD, v[1], v[2], v[3])
                    end
                else
                    timeDistance = 4

                    if distance <= 2.0 then
                        if parseInt(v[4]) >= 100 then
                            dwText(v[1], v[2], v[3] - 0.5, '~g~E~w~   COLETAR')
                        else
                            local pct = math.floor(v[4] / 100 * 100)
                            dwText(v[1], v[2], v[3] - 0.5, '~y~' .. pct .. '%~w~  PROGRESSO')
                        end
                    end

                    if distance <= 1.2 and not isPlanting and not isHarvesting then
                        if IsControlJustPressed(1, 38) and parseInt(v[4]) >= 100 then
                            harvestPlant(k)
                        end
                    end
                end
            else
                if weObjects[k] then
                    removeObject(k)
                end
            end
        end

        Citizen.Wait(timeDistance)
    end
end)

-- ============================================================
-- PLANTAR (comando /plantar)
-- ============================================================
RegisterCommand('plantar', function()
    CreateThread(function()
        if isPlanting or isHarvesting then
            lib.notify({ title = 'Plantacao', description = 'Voce ja esta ocupado', type = 'error' })
            return
        end

        local ped = PlayerPedId()

        if IsEntityInWater(ped) then
            lib.notify({ title = 'Plantacao', description = 'So pode ser plantado em terra firme', type = 'error' })
            return
        end

        local coords = GetEntityCoords(ped)
        if DoesObjectOfTypeExistAtCoords(coords.x, coords.y, coords.z, 0.6, GetHashKey(weHashsA), true) or
           DoesObjectOfTypeExistAtCoords(coords.x, coords.y, coords.z, 0.6, GetHashKey(weHashsB), true) or
           DoesObjectOfTypeExistAtCoords(coords.x, coords.y, coords.z, 0.6, GetHashKey(weHashsC), true) or
           DoesObjectOfTypeExistAtCoords(coords.x, coords.y, coords.z, 0.6, GetHashKey(weHashsD), true) then
            lib.notify({ title = 'Plantacao', description = 'Ja existe uma planta aqui', type = 'error' })
            return
        end

        local confirm = lib.alertDialog({
            header = 'Plantacao de Cannabis',
            content = 'Plantar aqui?\n\n- **Semente de Maconha** x1\n- **Balde** x1\n- **Adubo** x1\n\nA planta cresce sozinha. Volte para colher quando estiver 100%.',
            centered = true,
            cancel = true,
        })

        if confirm ~= 'confirm' then return end

        isPlanting = true

        lib.requestAnimDict(PLANT_ANIM_DICT)
        ped = PlayerPedId()
        TaskPlayAnim(ped, PLANT_ANIM_DICT, PLANT_ANIM_CLIP, 8.0, -8.0, -1, 1, 0, false, false, false)

        local completed = lib.progressBar({
            duration = 7000,
            label = 'Plantando...',
            useWhileDead = false,
            canCancel = true,
            disable = { car = true, move = true, combat = true },
        })

        isPlanting = false
        ClearPedTasks(PlayerPedId())

        if not completed then
            lib.notify({ title = 'Plantacao', description = 'Plantio cancelado', type = 'error' })
            return
        end

        local x, y, z = table.unpack(GetEntityCoords(PlayerPedId()))
        local result = lib.callback.await('empregos:weplant:plant', false, x, y, z)

        if result and result.success then
            lib.notify({ title = 'Plantacao', description = result.message, type = 'success' })
        else
            lib.notify({ title = 'Plantacao', description = result and result.message or 'Erro ao plantar', type = 'error' })
        end
    end)
end, false)

-- ============================================================
-- COLHER PLANTA
-- ============================================================
function harvestPlant(id)
    if isHarvesting or isPlanting then return end
    isHarvesting = true

    CreateThread(function()
        lib.requestAnimDict(PLANT_ANIM_DICT)

        local ped = PlayerPedId()
        TaskPlayAnim(ped, PLANT_ANIM_DICT, PLANT_ANIM_CLIP, 8.0, -8.0, -1, 1, 0, false, false, false)

        local completed = lib.progressBar({
            duration = 10000,
            label = 'Colhendo planta...',
            useWhileDead = false,
            canCancel = true,
            disable = { car = true, move = true, combat = true },
        })

        if not completed then
            isHarvesting = false
            ClearPedTasks(PlayerPedId())
            lib.notify({ title = 'Plantacao', description = 'Colheita cancelada', type = 'error' })
            return
        end

        ClearPedTasks(PlayerPedId())

        local result = lib.callback.await('empregos:weplant:checkTimers', false, id)

        if result and result.success then
            -- Remover objeto E da tabela local (server tambem manda removeExists)
            removeObject(id)
            wePlants[id] = nil
            lib.notify({ title = 'Plantacao', description = result.message, type = 'success', duration = 5000 })
        else
            lib.notify({ title = 'Plantacao', description = result and result.message or 'Erro ao colher', type = 'error' })
        end

        isHarvesting = false
    end)
end

-- ============================================================
-- TABLEUPDATE - so remove modelo antigo, loop principal recria
-- (evita duplicacao: createModels faz yield, loop recria durante)
-- ============================================================
RegisterNetEvent('empregos:weplant:update', function(status)
    local oldPlants = wePlants
    wePlants = status

    -- Se estagio mudou, so remove o objeto antigo
    -- O loop principal vai recriar com o modelo correto no proximo tick
    for k, v in pairs(wePlants) do
        if weObjects[k] and DoesEntityExist(weObjects[k]) then
            local oldProg = oldPlants[k] and oldPlants[k][4] or 0
            local newProg = v[4]
            -- Calcular estagios
            local oldStage = (oldProg <= 39 and 1) or (oldProg <= 69 and 2) or (oldProg <= 99 and 3) or 4
            local newStage = (newProg <= 39 and 1) or (newProg <= 69 and 2) or (newProg <= 99 and 3) or 4
            if oldStage ~= newStage then
                removeObject(k)
            end
        end
    end

    -- Remover objetos de plantas que nao existem mais
    for k, _ in pairs(weObjects) do
        if not wePlants[k] then
            removeObject(k)
        end
    end
end)

-- ============================================================
-- REMOVEEXISTS (igual Portal: evento separado pra deletar)
-- ============================================================
RegisterNetEvent('empregos:weplant:removeExists', function(id)
    removeObject(id)
    wePlants[id] = nil
end)

-- ============================================================
-- CLEANUP
-- ============================================================
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    for k, _ in pairs(weObjects) do
        removeObject(k)
    end
end)
