-- ============================================================
-- PLANTACOES (WEPLANT) - QBox + ox_lib + ox_inventory
-- Crescimento igual Portal: 3s tick, +2 progresso, max 300
-- ============================================================
local wePlants = {}
local plantId = 0

-- ============================================================
-- PLANTAR (requer: cannabisseed + bucket + compost)
-- ============================================================
lib.callback.register('empregos:weplant:plant', function(source, x, y, z)
    local src = source
    local player = exports.qbx_core:GetPlayer(src)
    if not player then return { success = false, message = 'Jogador nao encontrado' } end

    -- Verificar se tem os 3 itens
    local hasSeed = exports.ox_inventory:GetItemCount(src, 'cannabisseed')
    local hasBucket = exports.ox_inventory:GetItemCount(src, 'bucket')
    local hasCompost = exports.ox_inventory:GetItemCount(src, 'compost')

    if not hasSeed or hasSeed < 1 then
        return { success = false, message = 'Voce precisa de uma Semente de Maconha' }
    end
    if not hasBucket or hasBucket < 1 then
        return { success = false, message = 'Voce precisa de um Balde' }
    end
    if not hasCompost or hasCompost < 1 then
        return { success = false, message = 'Voce precisa de Adubo' }
    end

    -- Verificar se ja tem planta muito perto
    for _, plant in pairs(wePlants) do
        if #(vector3(x, y, z) - vector3(plant[1], plant[2], plant[3])) < 1.0 then
            return { success = false, message = 'Ja existe uma planta muito perto' }
        end
    end

    -- Remover os 3 itens
    local r1 = exports.ox_inventory:RemoveItem(src, 'cannabisseed', 1)
    local r2 = exports.ox_inventory:RemoveItem(src, 'bucket', 1)
    local r3 = exports.ox_inventory:RemoveItem(src, 'compost', 1)

    if not r1 or not r2 or not r3 then
        return { success = false, message = 'Erro ao remover itens' }
    end

    -- Criar planta (igual Portal: progresso 0 de 300)
    plantId = plantId + 1
    local id = tostring(plantId)
    wePlants[id] = {
        math.ceil(x * 100) / 100,
        math.ceil(y * 100) / 100,
        math.ceil(z * 100) / 100,
        0,   -- progresso (0 a 300)
        src, -- quem plantou
    }

    -- Atualizar todos os jogadores
    TriggerClientEvent('empregos:weplant:update', -1, wePlants)

    return { success = true, message = 'Planta cultivada! Aguarde o crescimento.' }
end)

-- ============================================================
-- COLHER (quando progresso >= 100 de 300 = pronta)
-- ============================================================
lib.callback.register('empregos:weplant:checkTimers', function(source, id)
    local src = source
    id = tostring(id)  -- client pode mandar number, server usa string
    if not wePlants[id] then
        return { success = false, message = 'Planta nao encontrada' }
    end

    if parseInt(wePlants[id][4]) < 100 then
        return { success = false, message = 'A planta ainda nao esta pronta' }
    end

    -- Quantidade aleatoria 2-4 de weed
    local qtd = math.random(2, 4)

    -- Dar weed + devolver balde
    local addedWeed = exports.ox_inventory:AddItem(src, 'weed', qtd)
    if not addedWeed then
        return { success = false, message = 'Inventario cheio' }
    end

    exports.ox_inventory:AddItem(src, 'bucket', 1)

    -- Remover planta (igual Portal: removeExists + tableUpdate)
    wePlants[id] = nil
    TriggerClientEvent('empregos:weplant:removeExists', -1, id)
    TriggerClientEvent('empregos:weplant:update', -1, wePlants)

    return { success = true, qtd = qtd, message = 'Voce colheu ' .. qtd .. 'x Cannabis e recuperou o Balde!' }
end)

-- ============================================================
-- CRESCIMENTO (igual Portal: 3s tick, +2 progresso, max 300)
-- ============================================================
CreateThread(function()
    while true do
        Citizen.Wait(3000)

        for id, plant in pairs(wePlants) do
            plant[4] = plant[4] + 2

            -- Planta expira aos 300 (auto-remove)
            if plant[4] >= 300 then
                wePlants[id] = nil
                TriggerClientEvent('empregos:weplant:removeExists', -1, id)
            end
        end

        -- Atualizar todos os jogadores
        TriggerClientEvent('empregos:weplant:update', -1, wePlants)
    end
end)

-- ============================================================
-- SYNC: Enviar plantas ao jogador quando entra (igual Portal)
-- ============================================================
AddEventHandler('QBCore:Server:OnPlayerLoaded', function()
    local src = source
    TriggerClientEvent('empregos:weplant:update', src, wePlants)
end)

AddEventHandler('playerDropped', function()
    -- Plantas permanecem no mundo apos desconectar
end)

-- ============================================================
-- ADMIN: VER PLANTAS
-- ============================================================
lib.addCommand('plantas', {
    help = 'Ver plantas ativas no servidor',
    restricted = 'group.admin',
}, function(source)
    local src = source
    local count = 0
    local msg = 'Plantas ativas:\n'

    for id, plant in pairs(wePlants) do
        msg = msg .. string.format('  #%s - %d/300 - (%.1f, %.1f, %.1f)\n',
            id, plant[4], plant[1], plant[2], plant[3])
        count = count + 1
    end

    if count == 0 then
        msg = 'Nenhuma planta ativa no servidor'
    end

    TriggerClientEvent('chat:addMessage', src, { args = { 'Plantas', msg } })
end)
