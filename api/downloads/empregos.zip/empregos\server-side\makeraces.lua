-- ============================================================
-- CORRIDAS - Portado de VRP para QBCore
-- ============================================================
local races = {}
local playerRaces = {}

RegisterCommand("races", function(source, args)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    if args[1] and tonumber(args[1]) and tonumber(args[1]) > 0 and races[tonumber(args[1])] then
        TriggerClientEvent('empregos:races:select', src, tonumber(args[1]), races)
        playerRaces[src] = tonumber(args[1])
    elseif args[1] == "make" then
        TriggerClientEvent('empregos:races:toggleMake', src)
    end
end)

RegisterNetEvent('empregos:races:input', function(status)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    races[Player.PlayerData.citizenid] = status
    TriggerClientEvent('empregos:races:update', -1, races)
end)

RegisterNetEvent('empregos:races:finish', function(raceSelected)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local name = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
    for k, v in pairs(playerRaces) do
        if parseInt(raceSelected) == parseInt(v) then
            TriggerClientEvent('empregos:races:ended', k, parseInt(raceSelected))
            Notify(k, name .. ' venceu a corrida!', 'success')
        end
    end
end)
