-- ============================================================
-- CORRIDAS CLIENT - Portado de VRP para QBCore
-- ============================================================
-- QBCore shim carregado via 00_compat.lua
local races = {}
local myRaces = {}
local inRace = false
local makeRaces = false
local raceSelect = 0
local checkPoint = 0
local blipRace = {}

-- Criação de corrida
CreateThread(function()
    while true do
        local timeDistance = 500
        if makeRaces then
            timeDistance = 4
            local ped = PlayerPedId()
            if IsPedInAnyVehicle(ped) then
                local x, y, z = table.unpack(GetEntityCoords(ped))
                if IsControlJustPressed(1, 38) then
                    table.insert(myRaces, { x, y, z })
                    QBCore.Functions.Notify('Checkpoint marcado.', 'primary')
                    PlaySoundFrontend(-1, "Event_Message_Purple", "GTAO_FM_Events_Soundset", false)
                elseif IsControlJustPressed(1, 47) then
                    QBCore.Functions.Notify('Final da corrida marcado.', 'success')
                    PlaySoundFrontend(-1, "Event_Message_Purple", "GTAO_FM_Events_Soundset", false)
                    table.insert(myRaces, { x, y, z })
                    TriggerServerEvent('empregos:races:input', myRaces)
                    makeRaces = false
                    myRaces = {}
                end
                dwText2("[ ~g~E~w~ ] NOVO CHECKPOINT   ~m~|~w~   [ ~y~G~w~ ] FINALIZAR CORRIDA")
            end
        end
        Wait(timeDistance)
    end
end)

-- Loop de corrida
CreateThread(function()
    while true do
        local timeDistance = 100
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped) and inRace and races[raceSelect] then
            local coords = GetEntityCoords(ped)
            local distance = #(coords - vector3(races[raceSelect][checkPoint][1], races[raceSelect][checkPoint][2], races[raceSelect][checkPoint][3]))
            if distance <= 200 then
                timeDistance = 4
                if distance <= 10 then
                    if DoesBlipExist(blipRace[checkPoint]) then
                        RemoveBlip(blipRace[checkPoint])
                        blipRace[checkPoint] = nil
                    end
                    if checkPoint >= #races[raceSelect] then
                        inRace = false
                        TriggerServerEvent('empregos:races:finish', raceSelect)
                        PlaySoundFrontend(-1, "RACE_PLACED", "HUD_AWARDS", false)
                    else
                        checkPoint = checkPoint + 1
                        SetNewWaypoint(races[raceSelect][checkPoint][1] + 0.0001, races[raceSelect][checkPoint][2] + 0.0001)
                    end
                end
            end
        end
        Wait(timeDistance)
    end
end)

-- Eventos
RegisterNetEvent('empregos:races:select', function(number, raceData)
    races = raceData
    inRace = true
    checkPoint = 1
    raceSelect = number
    makeBlipMarked(raceSelect)
    SetNewWaypoint(races[raceSelect][checkPoint][1] + 0.0001, races[raceSelect][checkPoint][2] + 0.0001)
end)

RegisterNetEvent('empregos:races:toggleMake', function()
    makeRaces = not makeRaces
    if makeRaces then myRaces = {} end
end)

RegisterNetEvent('empregos:races:update', function(status)
    races = status
end)

RegisterNetEvent('empregos:races:ended', function(race)
    if raceSelect == race then
        inRace = false
        for k, _ in pairs(blipRace) do
            if DoesBlipExist(blipRace[k]) then
                RemoveBlip(blipRace[k])
                blipRace[k] = nil
            end
        end
    end
end)

function makeBlipMarked(number)
    for k, v in pairs(races[number]) do
        blipRace[k] = AddBlipForCoord(v[1], v[2], v[3])
        SetBlipSprite(blipRace[k], 315) -- [FIX] Was sprite 1 (generic), now 315 (flag icon)
        SetBlipColour(blipRace[k], 0)
        SetBlipAsShortRange(blipRace[k], true)
        SetBlipScale(blipRace[k], 0.8)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Checkpoint")
        EndTextCommandSetBlipName(blipRace[k])
        ShowNumberOnBlip(blipRace[k], parseInt(k))
    end
end
