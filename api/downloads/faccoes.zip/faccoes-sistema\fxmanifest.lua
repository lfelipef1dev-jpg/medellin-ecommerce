fx_version 'cerulean'
game 'gta5'

name 'faccoes-sistema'
description 'Sistema completo de facções para FiveM (QBox/QBCore)
author 'Seu Servidor'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    '@qbx_core/modules/lib.lua',
    'config.lua'
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

dependencies {
    'ox_lib',
    'qbx_core',
    'ox_target',
    'oxmysql',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/*.svg',
    'html/*.png'
}

lua54 'yes'
