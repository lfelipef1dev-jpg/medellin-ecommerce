// ============================================================================
// MEDELLIN ROLEPLAY - Painel de Facção
// ============================================================================
let dadosFaccao = null;
let dadosJogador = null;
let listaMembros = [];
let listaCargos = [];
let membroSelecionado = null;

// ============================================================================
// INICIALIZAÇÃO
// ============================================================================
window.addEventListener('message', function(event) {
    const data = event.data;
    switch(data.action) {
        case 'abrir':
            abrirPainel(data);
            break;
        case 'fechar':
            fecharPainel();
            break;
        case 'fecharForcado':
            fecharPainel();
            break;
        case 'setFooterWarn':
            setFooterWarn(data.data);
            break;
        case 'atualizar':
            if (data.membros && Array.isArray(data.membros)) {
                atualizarMembros(data.membros);
            }
            break;
        case 'atualizarDadosExtras':
            if (data.saldo != null) {
                document.getElementById('header-saldo').textContent = formatarDinheiro(data.saldo);
                var elNum = document.getElementById('banco-saldo-num');
                if (elNum) elNum.textContent = Number(data.saldo).toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
            }
            if (data.pontosOrganizacao != null) {
                var elPts = document.getElementById('loja-pontos');
                if (elPts) elPts.textContent = Number(data.pontosOrganizacao).toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
            }
            if (data.mensagemLider != null) {
                var elMsg = document.getElementById('texto-mensagem-lider');
                if (elMsg) elMsg.textContent = data.mensagemLider || 'Nenhuma mensagem.';
            }
            if (data.meta) atualizarMeta(data.meta);
            if (data.transacoes) renderizarTransacoes(data.transacoes);
            if (data.banidos) renderizarBanidos(data.banidos);
            if (data.rankingFarm || data.logEntregas) {
                renderizarFarms(data.rankingFarm || [], data.logEntregas || []);
                var rf = data.rankingFarm || [];
                var elRankFarm = document.getElementById('ranking-farm');
                if (elRankFarm && rf.length > 0) {
                    elRankFarm.innerHTML = rf.slice(0, 5).map(function(r) {
                        return '<div class="rank-item">' + escapeHtml(r.pos) + '° | ' + escapeHtml(r.nome || '—') + ' <span class="rank-num">' + escapeHtml(r.total || r.quantidade || 0) + ' ▲</span></div>';
                    }).join('');
                }
            }
            break;
    }
});

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        fecharPainel();
    }
});

// ============================================================================
// ABRIR / FECHAR PAINEL
// ============================================================================
function isLogoUrl(logo) {
    const l = String(logo || '').trim();
    return /^https?:\/\//i.test(l) || /^data:image\//i.test(l) || /^nui:\/\//i.test(l) || /^https:\/\/cfx-nui-/i.test(l);
}

function resolveLogoSrc(logo) {
    const l = String(logo || '').trim();
    if (!l) return null;
    if (isLogoUrl(l)) return l;
    // Se já veio com pasta (ex: "assets/logos/egito.svg"), respeita.
    if (l.includes('/')) return l;
    // Por padrão, arquivos ficam dentro de /html/ do resource.
    return l;
}

function aplicarLogoFaccaoNoHeader(iconeFallback, logo) {
    const el = document.getElementById('faccao-icone');
    if (!el) return;

    el.classList.remove('has-logo');
    el.innerHTML = '';
    el.textContent = '';

    const src = resolveLogoSrc(logo);
    if (!src) {
        el.textContent = iconeFallback || '★';
        return;
    }

    const img = document.createElement('img');
    img.className = 'faccao-logo-img';
    img.alt = 'Logo da facção';
    img.src = src;
    img.onerror = function() {
        el.classList.remove('has-logo');
        el.innerHTML = '';
        el.textContent = iconeFallback || '★';
    };

    el.appendChild(img);
    el.classList.add('has-logo');
}

function abrirPainel(data) {
    dadosFaccao = data.faccao;
    dadosJogador = data.jogador;
    listaMembros = data.membros || [];
    listaCargos = data.cargos || [];

    document.documentElement.style.setProperty('--faccao-cor', dadosFaccao.cor || '#00FF88');

    // Header - nome e tipo da facção
    aplicarLogoFaccaoNoHeader(dadosFaccao.icone, dadosFaccao.logo);
    document.getElementById('faccao-nome').textContent = dadosFaccao.nome;
    document.getElementById('faccao-tipo').textContent = (dadosFaccao.tipo || '').toUpperCase();
    document.getElementById('jogador-cargo').textContent = dadosJogador.cargoNome;

    // Header - saldo e membros online (dados do servidor ou placeholders)
    const saldo = data.saldo != null ? formatarDinheiro(data.saldo) : '$0.00';
    const online = listaMembros.filter(m => m.online).length;
    document.getElementById('header-saldo').textContent = saldo;
    document.getElementById('header-online').textContent = online + '/' + listaMembros.length;
    document.getElementById('header-avaliacao').textContent = (data.avaliacao != null ? data.avaliacao : '— ★ (0)');

    if (data.discord) {
        const linkDiscord = document.getElementById('link-discord');
        linkDiscord.href = data.discord;
        linkDiscord.target = '_blank';
    }

    // Mensagem do líder e nome do líder
    document.getElementById('texto-mensagem-lider').textContent = data.mensagemLider || 'Nenhuma mensagem.';
    document.getElementById('nome-lider').textContent = data.nomeLider || '—';

    // Regras (pode vir do servidor)
    const listaRegras = document.getElementById('lista-regras');
    if (data.regras && Array.isArray(data.regras)) {
        listaRegras.innerHTML = data.regras.map(r => '<li>' + escapeHtml(r) + '</li>').join('');
    }

    // Ranking entrega de farm
    const rankFarm = data.rankingFarm || [];
    const elRankFarm = document.getElementById('ranking-farm');
    if (rankFarm.length === 0) {
        elRankFarm.innerHTML = '<p class="placeholder">Nenhuma entrega registrada.</p>';
    } else {
        elRankFarm.innerHTML = rankFarm.slice(0, 5).map(function(r) {
            return '<div class="rank-item">' + escapeHtml(r.pos) + '° | ' + escapeHtml(r.nome || '—') + ' <span class="rank-num">' + escapeHtml(r.total || 0) + ' ▲</span></div>';
        }).join('');
    }

    // Ranking tempo jogado
    const rankTempo = data.rankingTempo || [];
    const elRankTempo = document.getElementById('ranking-tempo');
    if (rankTempo.length === 0) {
        elRankTempo.innerHTML = '<p class="placeholder">Nenhum dado.</p>';
    } else {
        elRankTempo.innerHTML = rankTempo.slice(0, 5).map(function(r) {
            return '<div class="rank-item">' + escapeHtml(r.pos) + '° ' + escapeHtml(r.nome || '—') + ' ' + escapeHtml(r.tempo || '0h 0min') + '</div>';
        }).join('');
    }

    setFooterWarn(data.lowRec && data.lowRecMessage ? data.lowRecMessage : null);

    // Meta diária (números + barra)
    atualizarMeta(data.meta || { atual: 0, total: 1000, premio: 200000, valorPorEntrega: 2000 });
    // Botão "Configurar meta" só para 00 (cargo 1)
    const podeConfigurarMeta = dadosJogador.cargo === 1;
    var btnConfigMeta = document.getElementById('btn-configurar-meta');
    if (btnConfigMeta) {
        if (podeConfigurarMeta) {
            btnConfigMeta.classList.remove('hidden');
            btnConfigMeta.onclick = abrirModalConfigurarMeta;
        } else {
            btnConfigMeta.classList.add('hidden');
        }
    }

    // Banco (Santa: número no cartão + nome da facção; Depositar/Sacar só liderança = cargo <= 2)
    const saldoNum = (data.saldo != null ? Number(data.saldo) : 0);
    const elSaldoNum = document.getElementById('banco-saldo-num');
    if (elSaldoNum) elSaldoNum.textContent = saldoNum.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    const elBancoFaccao = document.getElementById('banco-faccao-nome');
    if (elBancoFaccao) elBancoFaccao.textContent = dadosFaccao.nome || 'FACÇÃO';
    const bancoAcaoWrap = document.getElementById('banco-acao-wrap');
    if (bancoAcaoWrap) {
        if (dadosJogador.cargo <= 2) bancoAcaoWrap.classList.remove('hidden'); else bancoAcaoWrap.classList.add('hidden');
    }

    // Loja (pontos)
    renderizarLoja(data.loja || [], data.pontosOrganizacao || 0);
    popularLojaEnviarPara(listaMembros);

    // Transações e banidos
    renderizarTransacoes(data.transacoes || []);
    renderizarBanidos(data.banidos || []);

    // Santa: Recrutar só para quem tem all, gerenciar_membros ou recrutar
    const podeRecrutar = dadosJogador.permissoes && (dadosJogador.permissoes.includes('all') || dadosJogador.permissoes.includes('gerenciar_membros') || dadosJogador.permissoes.includes('recrutar'));
    const recrutamentoBox = document.getElementById('recrutamento-box');
    if (recrutamentoBox) {
        if (podeRecrutar) recrutamentoBox.classList.remove('hidden'); else recrutamentoBox.classList.add('hidden');
    }

    renderizarPermissoes();
    renderizarMembros();
    renderizarHierarquia();
    atualizarEstatisticas();
    renderizarFarms(data.rankingFarm || [], data.logEntregas || []);
    renderizarRecrutamento(data.rankingRecrutamento || [], data.logRecrutamento || []);

    const modalAcoes = document.getElementById('modal-acoes');
    if (modalAcoes) modalAcoes.classList.add('hidden');
    const modalHierarquia = document.getElementById('modal-hierarquia');
    if (modalHierarquia) modalHierarquia.classList.add('hidden');
    const modalMeta = document.getElementById('modal-configurar-meta');
    if (modalMeta) modalMeta.classList.add('hidden');

    document.getElementById('painel-container').classList.remove('hidden');
}

function setFooterWarn(htmlOrNull) {
    const el = document.getElementById('painel-footer-warn');
    if (!el) return;
    if (htmlOrNull) {
        el.innerHTML = htmlOrNull;
        el.classList.remove('hidden');
    } else {
        el.classList.add('hidden');
        el.innerHTML = '';
    }
}

let lastMeta = { atual: 0, total: 1000, premio: 200000, valorPorEntrega: 2000 };

function atualizarMeta(meta) {
    if (!meta) return;
    lastMeta = { atual: Number(meta.atual) || 0, total: Math.max(1, Number(meta.total) || 1000), premio: Number(meta.premio) || 0, valorPorEntrega: Number(meta.valorPorEntrega) || 2000 };
    const elAtual = document.getElementById('meta-atual');
    const elTotal = document.getElementById('meta-total');
    const elPremio = document.getElementById('meta-premio');
    const elBar = document.getElementById('meta-bar');
    if (elAtual) elAtual.textContent = lastMeta.atual;
    if (elTotal) elTotal.textContent = lastMeta.total;
    if (elPremio) elPremio.textContent = formatarDinheiro(lastMeta.premio);
    if (elBar) {
        const pct = lastMeta.total > 0 ? Math.min(100, (lastMeta.atual / lastMeta.total) * 100) : 0;
        elBar.style.width = pct + '%';
    }
}

function abrirModalConfigurarMeta() {
    document.getElementById('input-meta-total').value = lastMeta.total;
    document.getElementById('input-meta-premio').value = lastMeta.premio;
    document.getElementById('input-meta-valor').value = lastMeta.valorPorEntrega;
    document.getElementById('modal-configurar-meta').classList.remove('hidden');
}

function fecharModalConfigurarMeta() {
    document.getElementById('modal-configurar-meta').classList.add('hidden');
}

function salvarConfigurarMeta() {
    const total = parseInt(document.getElementById('input-meta-total').value, 10) || 1000;
    const premio = parseInt(document.getElementById('input-meta-premio').value, 10) || 0;
    const valorPorEntrega = parseInt(document.getElementById('input-meta-valor').value, 10) || 2000;
    if (!dadosFaccao || !dadosFaccao.id) return;
    fetch('https://medellin-faccoes-sistema/configurarMeta', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ faccaoId: dadosFaccao.id, total: total, premio: premio, valorPorEntrega: valorPorEntrega })
    }).then(function() {
        fecharModalConfigurarMeta();
    });
}

function fecharPainel() {
    document.getElementById('painel-container').classList.add('hidden');
    setFooterWarn(null);
    fetch('https://medellin-faccoes-sistema/fechar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
}

function formatarDinheiro(val) {
    if (typeof val !== 'number') val = parseFloat(val) || 0;
    return '$' + val.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function escapeHtml(str) {
    return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function escapeAttr(str) {
    return escapeHtml(str).replace(/`/g, '&#96;');
}

// ============================================================================
// NAVEGAÇÃO (TABS)
// ============================================================================
document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const tabId = this.dataset.tab;
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        this.classList.add('active');
        const el = document.getElementById('tab-' + tabId);
        if (el) el.classList.add('active');
    });
});

// ============================================================================
// RENDERIZAÇÃO - PERMISSÕES (craft, baú, garagem, gerenciar – estilo Santa)
// ============================================================================
var PERM_LABELS = {
    'all': 'Todas',
    'craft': 'Craft',
    'bau_lider': 'Baú Líder',
    'bau_membros': 'Baú Membros',
    'garagem': 'Garagem',
    'gerenciar_membros': 'Gerenciar Membros',
    'recrutar': 'Recrutar'
};
function renderizarPermissoes() {
    var el = document.getElementById('perm-badges');
    if (!el) return;
    var perms = (dadosJogador && dadosJogador.permissoes && Array.isArray(dadosJogador.permissoes)) ? dadosJogador.permissoes : [];
    if (perms.length === 0) {
        el.innerHTML = '<span class="perm-badge">Nenhuma</span>';
        return;
    }
    var html = '';
    perms.forEach(function(p) {
        var label = PERM_LABELS[p] || p;
        html += '<span class="perm-badge">' + escapeHtml(label) + '</span>';
    });
    el.innerHTML = html || '<span class="perm-badge">—</span>';
}

// ============================================================================
// RENDERIZAÇÃO - MEMBROS (tabela com dropdown de cargo, igual P.C.J)
// ============================================================================
function renderizarMembros() {
    const tbody = document.getElementById('membros-tbody');
    if (!tbody) return;
    tbody.innerHTML = '';

    const podeGerenciar = dadosJogador.permissoes.includes('all') ||
        dadosJogador.permissoes.includes('gerenciar_membros');
    const meuCargo = dadosJogador.cargo;

    listaMembros.forEach(membro => {
        const tr = document.createElement('tr');
        tr.dataset.citizenid = membro.citizenid;
        tr.dataset.idExibir = (membro.idExibir != null && membro.idExibir !== '') ? String(membro.idExibir) : (membro.citizenid || '');
        tr.dataset.nome = (membro.nome || '').toLowerCase();
        const idExibir = membro.idExibir || membro.citizenid || '—';
        const idExibirSafe = escapeHtml(idExibir);
        const nomeSafe = escapeHtml(membro.nome || '—');
        const nivelXP = (membro.nivelXP != null ? membro.nivelXP : 0) + ' XP';
        const tempoJogado = membro.playtime != null ? formatarTempo(membro.playtime) : '0h 0min';
        const entrada = membro.entrada || '—';
        const ultimoLogin = membro.ultimoLogin || '—';

        let optionsCargo = '';
        (listaCargos || []).forEach(function(c) {
            const nivel = parseInt(c.nivel, 10);
            const cargoMembro = parseInt(membro.cargo, 10);
            const sel = nivel === cargoMembro ? ' selected' : '';
            const disabled = nivel <= meuCargo ? ' disabled' : '';
            optionsCargo += '<option value="' + escapeAttr(nivel) + '"' + sel + disabled + '>' + escapeHtml(c.nome || ('Cargo ' + nivel)) + '</option>';
        });

        const citizenIdSafe = escapeAttr(membro.citizenid || '');
        const idExibirAttr = escapeAttr(tr.dataset.idExibir || '');
        tr.innerHTML =
            '<td>' + idExibirSafe + '</td>' +
            '<td>' + nomeSafe + '</td>' +
            '<td><span class="badge-xp">' + escapeHtml(nivelXP) + '</span></td>' +
            '<td><span class="status-dot ' + (membro.online ? 'online' : 'offline') + '"></span> ' + (membro.online ? 'Online' : 'Offline') + '</td>' +
            '<td>' + escapeHtml(tempoJogado) + '</td>' +
            '<td>' + escapeHtml(entrada) + '</td>' +
            '<td>' + escapeHtml(ultimoLogin) + '</td>' +
            '<td><select class="cargo-select" data-citizenid="' + citizenIdSafe + '" data-id-exibir="' + idExibirAttr + '" ' + (podeGerenciar && membro.cargo > meuCargo ? '' : 'disabled') + '>' + optionsCargo + '</select></td>' +
            '<td><button type="button" class="btn-editar-membro" data-citizenid="' + citizenIdSafe + '" data-id-exibir="' + idExibirAttr + '" ' + (podeGerenciar && membro.cargo > meuCargo ? '' : 'disabled') + ' title="Editar"><i class="fas fa-wrench"></i></button></td>';
        tbody.appendChild(tr);
    });

    document.querySelectorAll('.cargo-select').forEach(function(sel) {
        if (sel.disabled) return;
        sel.addEventListener('change', function() {
            const memberId = (this.dataset.idExibir && this.dataset.idExibir !== '') ? this.dataset.idExibir : this.dataset.citizenid;
            const novoCargo = parseInt(this.value, 10);
            if (memberId && !isNaN(novoCargo)) alterarCargo(memberId, novoCargo);
        });
    });

    document.querySelectorAll('.btn-editar-membro').forEach(function(btn) {
        if (btn.disabled) return;
        btn.addEventListener('click', function() {
            const citizenid = this.dataset.citizenid;
            if (citizenid) abrirModalGerenciar(citizenid);
        });
    });

    reaplicarFiltro('search-membros');
}

function formatarTempo(minutos) {
    if (typeof minutos !== 'number') minutos = 0;
    const h = Math.floor(minutos / 60);
    const m = minutos % 60;
    return h + 'h ' + m + 'min';
}

function alterarCargo(memberId, novoCargo) {
    fetch('https://medellin-faccoes-sistema/alterarCargo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId: memberId, novoCargo: novoCargo })
    });
}

function renderizarTransacoes(transacoes) {
    const tbody = document.getElementById('transacoes-tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    (transacoes || []).forEach(function(t) {
        const tr = document.createElement('tr');
        tr.innerHTML =
            '<td>' + escapeHtml(t.id || '—') + '</td>' +
            '<td>' + escapeHtml(t.nome || '—') + '</td>' +
            '<td><span class="transacao-status ' + (t.tipo === 'entrada' ? 'entrada' : 'saque') + '">' + (t.tipo === 'entrada' ? 'Entrada' : 'Saque') + '</span></td>' +
            '<td>' + escapeHtml(t.descricao || '—') + '</td>' +
            '<td>' + (t.valor != null ? formatarDinheiro(t.valor) : '—') + '</td>' +
            '<td>' + escapeHtml(t.data || '—') + '</td>';
        tbody.appendChild(tr);
    });

    reaplicarFiltro('search-transacoes');
}

function renderizarBanidos(banidos) {
    const tbody = document.getElementById('banidos-tbody');
    if (!tbody) return;
    const podeRemoverBan = dadosJogador && dadosJogador.permissoes && (dadosJogador.permissoes.includes('all') || dadosJogador.permissoes.includes('gerenciar_membros'));
    tbody.innerHTML = '';
    (banidos || []).forEach(function(b) {
        const tr = document.createElement('tr');
        const banId = escapeAttr(b.id || '');
        const acaoCell = podeRemoverBan
            ? '<td><button type="button" class="btn-remover-ban" data-ban-id="' + banId + '" title="Remover"><i class="fas fa-trash-alt"></i></button></td>'
            : '<td>—</td>';
        tr.innerHTML =
            '<td>' + escapeHtml(b.idLider || '—') + ' ' + escapeHtml(b.nomeLider || '') + '</td>' +
            '<td>' + escapeHtml(b.idMembro || '—') + ' ' + escapeHtml(b.nomeMembro || '') + '</td>' +
            '<td>' + escapeHtml(b.data || '—') + '</td>' +
            '<td>' + escapeHtml(b.motivo || '—') + '</td>' +
            acaoCell;
        tbody.appendChild(tr);
    });

    if (podeRemoverBan) {
        tbody.querySelectorAll('[data-ban-id]').forEach(function(btn) {
            btn.addEventListener('click', function() {
                const idBanido = this.getAttribute('data-ban-id');
                if (idBanido) removerBanido(idBanido);
            });
        });
    }

    reaplicarFiltro('search-banidos');
}

function removerBanido(idBanido) {
    if (!idBanido) return;
    fetch('https://medellin-faccoes-sistema/removerBanido', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: idBanido })
    });
}

function renderizarFarms(rankingFarm, logEntregas) {
    const tbodyFarms = document.getElementById('farms-tbody');
    if (tbodyFarms) {
        const rows = [];
        (rankingFarm || []).forEach(function(r, i) {
            const pos = (i + 1) + '°';
            const seg = (r.seg ? 'ok' : 'pendente');
            const ter = (r.ter ? 'ok' : 'pendente');
            const qua = (r.qua ? 'ok' : 'pendente');
            const qui = (r.qui ? 'ok' : 'pendente');
            const sex = (r.sex ? 'ok' : 'pendente');
            const sab = (r.sab ? 'ok' : 'pendente');
            const dom = (r.dom ? 'ok' : 'pendente');
            rows.push('<tr><td>' + escapeHtml(pos) + '</td><td>' + escapeHtml(r.nome || '—') + '</td><td>' + escapeHtml(r.quantidade || 0) + '</td><td class="dia-status ' + seg + '"></td><td class="dia-status ' + ter + '"></td><td class="dia-status ' + qua + '"></td><td class="dia-status ' + qui + '"></td><td class="dia-status ' + sex + '"></td><td class="dia-status ' + sab + '"></td><td class="dia-status ' + dom + '"></td></tr>');
        });
        tbodyFarms.innerHTML = rows.join('');
    }
    const tbodyLog = document.getElementById('log-tbody');
    if (tbodyLog) {
        const rows = (logEntregas || []).map(function(l) {
            return '<tr><td>' + escapeHtml(l.data || '—') + '</td><td>' + escapeHtml(l.player || '—') + '</td><td>' + escapeHtml(l.itens || '—') + '</td></tr>';
        });
        tbodyLog.innerHTML = rows.join('');
    }

    reaplicarFiltro('search-farms');
    reaplicarFiltro('search-log');
}

function renderizarRecrutamento(rankingRecrutamento, logRecrutamento) {
    const tbodyRec = document.getElementById('recrutadores-tbody');
    if (tbodyRec) {
        const rows = [];
        (rankingRecrutamento || []).forEach(function(r, i) {
            const pos = (i + 1) + '°';
            rows.push('<tr><td>' + escapeHtml(pos) + '</td><td>' + escapeHtml(r.recrutador || '—') + '</td><td>' + escapeHtml(r.total || 0) + '</td><td>' + escapeHtml(r.umDia || 0) + '</td><td>' + escapeHtml(r.tresDias || 0) + '</td></tr>');
        });
        tbodyRec.innerHTML = rows.join('');
    }
    const tbodyLogRec = document.getElementById('recrutamento-log-tbody');
    if (tbodyLogRec) {
        const rows = (logRecrutamento || []).map(function(l) {
            return '<tr><td>' + escapeHtml(l.data || '—') + '</td><td>' + escapeHtml(l.recrutador || '—') + '</td><td>' + escapeHtml(l.recrutado || '—') + '</td></tr>';
        });
        tbodyLogRec.innerHTML = rows.join('');
    }

    reaplicarFiltro('search-recrutadores');
    reaplicarFiltro('search-recrutamento-log');
}

// ============================================================================
// RENDERIZAÇÃO - HIERARQUIA
// ============================================================================
function renderizarHierarquia() {
    const container = document.getElementById('hierarquia-lista');
    if (!container) return;
    container.innerHTML = '';
    (listaCargos || []).slice().sort(function(a, b) {
        return (parseInt(a.nivel, 10) || 0) - (parseInt(b.nivel, 10) || 0);
    }).forEach(cargo => {
        const item = document.createElement('div');
        item.className = 'cargo-item';
        item.innerHTML =
            '<div class="cargo-nivel">' + escapeHtml(cargo.nivel) + '</div>' +
            '<span class="cargo-nome-hierarquia">' + escapeHtml(cargo.nome) + '</span>';
        container.appendChild(item);
    });
}

function renderizarHierarquiaModal() {
    const container = document.getElementById('hierarquia-modal-lista');
    if (!container) return;
    container.innerHTML = '';
    (listaCargos || []).slice().sort(function(a, b) {
        return (parseInt(a.nivel, 10) || 0) - (parseInt(b.nivel, 10) || 0);
    }).forEach(function(cargo) {
        const item = document.createElement('div');
        item.className = 'cargo-item';
        item.innerHTML =
            '<div class="cargo-nivel">' + escapeHtml(String(cargo.nivel).padStart(2, '0')) + '</div>' +
            '<span class="cargo-nome-hierarquia">' + escapeHtml(cargo.nome) + '</span>';
        container.appendChild(item);
    });
}

function abrirHierarquiaModal() {
    const modal = document.getElementById('modal-hierarquia');
    if (!modal) return;
    renderizarHierarquiaModal();
    modal.classList.remove('hidden');
}

function fecharHierarquiaModal() {
    const modal = document.getElementById('modal-hierarquia');
    if (!modal) return;
    modal.classList.add('hidden');
}

// ============================================================================
// ESTATÍSTICAS
// ============================================================================
function atualizarEstatisticas() {
    const total = listaMembros.length;
    const online = listaMembros.filter(m => m.online).length;
    const lideres = listaMembros.filter(m => m.cargo <= 3).length;
    const novatos = listaMembros.filter(m => m.cargo >= 15).length;

    const elTotal = document.getElementById('stat-total');
    if (elTotal) elTotal.textContent = total;
    const elOnline = document.getElementById('stat-online');
    if (elOnline) elOnline.textContent = online;
    const elLideres = document.getElementById('stat-lideres');
    if (elLideres) elLideres.textContent = lideres;
    const elNovatos = document.getElementById('stat-novatos');
    if (elNovatos) elNovatos.textContent = novatos;
}

function atualizarMembros(membros) {
    listaMembros = membros || [];
    renderizarMembros();
    atualizarEstatisticas();
    const online = listaMembros.filter(m => m.online).length;
    document.getElementById('header-online').textContent = online + '/' + listaMembros.length;
}

// ============================================================================
// BUSCAS (filtra linhas das tabelas)
// ============================================================================
function debounce(fn, waitMs) {
    let t = null;
    return function() {
        const ctx = this;
        const args = arguments;
        clearTimeout(t);
        t = setTimeout(function() {
            fn.apply(ctx, args);
        }, waitMs);
    };
}

function bindRowFilter(inputId, rowsSelector) {
    const input = document.getElementById(inputId);
    if (!input) return;

    const apply = function() {
        const termo = String(input.value || '').toLowerCase().trim();
        document.querySelectorAll(rowsSelector).forEach(function(row) {
            const texto = String(row.textContent || '').toLowerCase();
            row.style.display = (!termo || texto.indexOf(termo) !== -1) ? '' : 'none';
        });
    };

    input.addEventListener('input', debounce(apply, 80));
}

function reaplicarFiltro(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return;
    if (!String(input.value || '').trim()) return;
    input.dispatchEvent(new Event('input'));
}

bindRowFilter('search-membros', '#membros-tbody tr');
bindRowFilter('search-farms', '#farms-tbody tr');
bindRowFilter('search-log', '#log-tbody tr');
bindRowFilter('search-recrutadores', '#recrutadores-tbody tr');
bindRowFilter('search-recrutamento-log', '#recrutamento-log-tbody tr');
bindRowFilter('search-transacoes', '#transacoes-tbody tr');
bindRowFilter('search-banidos', '#banidos-tbody tr');

// ============================================================================
// HIERARQUIA (modal dentro de MEMBROS)
// ============================================================================
const btnHierarquia = document.getElementById('btn-hierarquia');
if (btnHierarquia) {
    btnHierarquia.addEventListener('click', function() {
        abrirHierarquiaModal();
    });
}

const btnCloseHierarquia = document.querySelector('[data-close-hierarquia]');
if (btnCloseHierarquia) {
    btnCloseHierarquia.addEventListener('click', function() {
        fecharHierarquiaModal();
    });
}

const modalHierarquia = document.getElementById('modal-hierarquia');
if (modalHierarquia) {
    modalHierarquia.addEventListener('click', function(e) {
        if (e.target === modalHierarquia) fecharHierarquiaModal();
    });
}

var btnFecharModalMeta = document.getElementById('btn-fechar-modal-meta');
if (btnFecharModalMeta) btnFecharModalMeta.addEventListener('click', fecharModalConfigurarMeta);
var btnSalvarMeta = document.getElementById('btn-salvar-meta');
if (btnSalvarMeta) btnSalvarMeta.addEventListener('click', salvarConfigurarMeta);
var modalConfigurarMeta = document.getElementById('modal-configurar-meta');
if (modalConfigurarMeta) {
    modalConfigurarMeta.addEventListener('click', function(e) {
        if (e.target === modalConfigurarMeta) fecharModalConfigurarMeta();
    });
}

// ============================================================================
// RECRUTAR POR ID (ID/Passport da tabela de membros ou Citizen ID; jogador precisa estar online)
// ============================================================================
function recrutarPorId() {
    const input = document.getElementById('input-recrutar-id');
    const id = (input && input.value) ? String(input.value).trim() : '';
    if (!id) return;
    fetch('https://medellin-faccoes-sistema/recrutarPorId', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
    }).catch(function() {});
    if (input) input.value = '';
}

// ============================================================================
// AVALIAR CIDADE (botão no header)
// ============================================================================
function avaliarCidade() {
    fetch('https://medellin-faccoes-sistema/avaliarCidade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
}

// ============================================================================
// MODAL GERENCIAR MEMBRO
// ============================================================================
function abrirModalGerenciar(citizenid) {
    membroSelecionado = listaMembros.find(m => m.citizenid === citizenid);
    if (!membroSelecionado) return;

    document.getElementById('modal-membro-nome').textContent = membroSelecionado.nome;
    document.getElementById('modal-membro-cargo').textContent = membroSelecionado.cargoNome;

    const select = document.getElementById('select-cargo');
    select.innerHTML = '';
    listaCargos.forEach(cargo => {
        if (cargo.nivel > dadosJogador.cargo && cargo.nivel < membroSelecionado.cargo) {
            const option = document.createElement('option');
            option.value = cargo.nivel;
            option.textContent = cargo.nivel + '. ' + cargo.nome;
            select.appendChild(option);
        }
    });

    var motivoBan = document.getElementById('modal-motivo-ban');
    if (motivoBan) motivoBan.value = '';
    document.getElementById('modal-acoes').classList.remove('hidden');
}

function fecharModal() {
    document.getElementById('modal-acoes').classList.add('hidden');
    var motivoBan = document.getElementById('modal-motivo-ban');
    if (motivoBan) motivoBan.value = '';
    membroSelecionado = null;
}

// ============================================================================
// AÇÕES - PROMOVER / REBAIXAR / EXPULSAR
// ============================================================================
function promoverMembro() {
    if (!membroSelecionado) return;
    const novoCargo = parseInt(document.getElementById('select-cargo').value, 10);
    if (!novoCargo) return;
    const memberId = (membroSelecionado.idExibir != null && membroSelecionado.idExibir !== '') ? String(membroSelecionado.idExibir) : membroSelecionado.citizenid;
    fetch('https://medellin-faccoes-sistema/promoverMembro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId: memberId, novoCargo: novoCargo })
    });
    fecharModal();
}

function rebaixarMembro() {
    if (!membroSelecionado) return;
    const memberId = (membroSelecionado.idExibir != null && membroSelecionado.idExibir !== '') ? String(membroSelecionado.idExibir) : membroSelecionado.citizenid;
    fetch('https://medellin-faccoes-sistema/rebaixarMembro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId: memberId })
    });
    fecharModal();
}

function expulsarMembro() {
    if (!membroSelecionado) return;
    if (!confirm('Tem certeza que deseja expulsar ' + membroSelecionado.nome + '?')) return;
    const memberId = (membroSelecionado.idExibir != null && membroSelecionado.idExibir !== '') ? String(membroSelecionado.idExibir) : membroSelecionado.citizenid;
    fetch('https://medellin-faccoes-sistema/expulsarMembro', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId: memberId })
    });
    fecharModal();
}

function expulsarEBanir() {
    if (!membroSelecionado) return;
    const motivoEl = document.getElementById('modal-motivo-ban');
    const motivo = (motivoEl && motivoEl.value) ? String(motivoEl.value).trim() : '';
    if (motivo.length < 4) {
        alert('O motivo do banimento é obrigatório e deve ter pelo menos 4 caracteres.');
        return;
    }
    if (!confirm('Você tem certeza que deseja remover e banir este membro?')) return;
    const memberId = (membroSelecionado.idExibir != null && membroSelecionado.idExibir !== '') ? String(membroSelecionado.idExibir) : membroSelecionado.citizenid;
    fetch('https://medellin-faccoes-sistema/expulsarEBanir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberId: memberId, citizenid: membroSelecionado.citizenid, motivo: motivo })
    });
    if (motivoEl) motivoEl.value = '';
    fecharModal();
}

// ============================================================================
// AÇÕES RÁPIDAS - RADIO / LOCALIZAÇÃO / UNIFORME
// ============================================================================
function enviarAcao(acao) {
    fetch('https://medellin-faccoes-sistema/acaoRapida', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ acao: acao })
    });
}

document.querySelectorAll('.acao-card').forEach(card => {
    const acao = card.getAttribute('data-acao');
    const botao = card.querySelector('[data-acao-btn]');
    if (botao && acao) {
        botao.addEventListener('click', function(e) {
            e.stopPropagation();
            enviarAcao(acao);
        });
    }
});

// ============================================================================
// ENTREGAR RECOMPENSA (quantidade = valor do range, valor = quantidade * valorPorEntrega)
// ============================================================================
function entregarRecompensa() {
    const quantidade = parseInt(document.getElementById('range-recompensa').value, 10) || 0;
    if (quantidade <= 0) return;
    const valorStr = document.getElementById('valor-recompensa').textContent;
    fetch('https://medellin-faccoes-sistema/entregarRecompensa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quantidade: quantidade, valor: valorStr })
    });
}

// Range recompensa (visual) - 1 a 100 unidades, valor = quantidade * 2000
const rangeRec = document.getElementById('range-recompensa');
if (rangeRec) {
    rangeRec.min = 1;
    rangeRec.max = 100;
    rangeRec.value = 10;
    rangeRec.addEventListener('input', function() {
        const v = parseInt(this.value, 10) || 0;
        document.getElementById('valor-recompensa').textContent = formatarDinheiro(v * 2000);
    });
    document.getElementById('valor-recompensa').textContent = formatarDinheiro(10 * 2000);
}

// ============================================================================
// BANCO - DEPOSITAR / SACAR (campo único "Preencher valor" estilo Santa)
// ============================================================================
function getValorBancoInput() {
    const input = document.getElementById('input-valor-banco');
    const v = (input && input.value) ? String(input.value).replace(/\D/g, '') : '0';
    return parseInt(v, 10) || 0;
}

function depositarBanco() {
    const amount = getValorBancoInput();
    if (amount <= 0) return;
    fetch('https://medellin-faccoes-sistema/depositarBanco', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ faccaoId: dadosFaccao.id, amount: amount })
    });
    document.getElementById('input-valor-banco').value = '';
}

function sacarBanco() {
    const amount = getValorBancoInput();
    if (amount <= 0) return;
    fetch('https://medellin-faccoes-sistema/sacarBanco', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ faccaoId: dadosFaccao.id, amount: amount })
    });
    document.getElementById('input-valor-banco').value = '';
}

// ============================================================================
// LOJA (compra com pontos)
// ============================================================================
function renderizarLoja(itens, pontos) {
    const elPts = document.getElementById('loja-pontos');
    if (elPts) elPts.textContent = Number(pontos || 0).toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

    const container = document.getElementById('loja-itens');
    if (!container) return;

    const list = Array.isArray(itens) ? itens : [];
    if (list.length === 0) {
        container.innerHTML = '<p class="placeholder">Loja não configurada.</p>';
        return;
    }

    const permissoes = (dadosJogador && dadosJogador.permissoes) ? dadosJogador.permissoes : [];
    const podeComprar = permissoes.includes('all');

    container.innerHTML = list.map(function(it) {
        const item = String(it.item || '');
        const label = escapeHtml(it.label || it.nome || item || 'Item');
        const price = Number(it.price || 0);
        const amount = Number(it.amount || 1);
        const disabled = podeComprar ? '' : 'disabled';
        return (
            '<div class="loja-item">' +
                '<div class="loja-item-info">' +
                    '<div class="loja-item-nome">' + label + '</div>' +
                    '<div class="loja-item-preco"><i class="fas fa-coins"></i> ' + price + ' pts • x' + amount + '</div>' +
                '</div>' +
                '<button type="button" class="loja-btn" data-loja-buy data-item="' + escapeAttr(item) + '" data-amount="' + amount + '" ' + disabled + '>Comprar</button>' +
            '</div>'
        );
    }).join('');

    container.querySelectorAll('[data-loja-buy]').forEach(function(btn) {
        if (btn.disabled) return;
        btn.addEventListener('click', function() {
            comprarLoja(this.getAttribute('data-item'), parseInt(this.getAttribute('data-amount'), 10) || 1);
        });
    });
}

function popularLojaEnviarPara(membros) {
    const sel = document.getElementById('loja-enviar-para');
    if (!sel) return;
    sel.innerHTML = '<option value="">Eu mesmo</option>';
    (membros || []).forEach(function(m) {
        const cid = (m.citizenid != null && m.citizenid !== '') ? String(m.citizenid) : '';
        const nome = (m.nome != null && m.nome !== '') ? String(m.nome) : (m.charinfo && m.charinfo.firstname) ? (m.charinfo.firstname + ' ' + (m.charinfo.lastname || '')) : cid || 'Membro';
        if (cid) {
            const opt = document.createElement('option');
            opt.value = cid;
            opt.textContent = nome;
            sel.appendChild(opt);
        }
    });
}

function comprarLoja(item, amount) {
    if (!dadosFaccao || !dadosFaccao.id || !item) return;
    const sel = document.getElementById('loja-enviar-para');
    const sendToMember = (sel && sel.value) ? String(sel.value).trim() : '';
    const payload = { faccaoId: dadosFaccao.id, item: item, amount: amount || 1 };
    if (sendToMember) payload.sendToMember = sendToMember;
    fetch('https://medellin-faccoes-sistema/comprarLoja', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
}
