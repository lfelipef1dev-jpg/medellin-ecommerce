-- Cria só as tabelas do BANCO DA FACÇÃO (faccoes_bank e transações)
-- Rode no banco qbcore se a tabela faccoes_bank não existir.

CREATE TABLE IF NOT EXISTS `faccoes_bank` (
    `faccao` VARCHAR(50) NOT NULL,
    `balance` BIGINT(20) NOT NULL DEFAULT 0,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`faccao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `faccoes_bank_transactions` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `faccao` VARCHAR(50) NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL,
    `nome` VARCHAR(128) DEFAULT NULL,
    `tipo` ENUM('entrada','saque') NOT NULL,
    `descricao` VARCHAR(128) DEFAULT NULL,
    `valor` BIGINT(20) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_faccao` (`faccao`),
    KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
