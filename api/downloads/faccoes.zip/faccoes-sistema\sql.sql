-- ============================================================================
-- SQL PARA O SISTEMA DE FACÇÕES MEDELLÍN
-- Execute este arquivo no seu banco de dados MySQL/MariaDB
-- ============================================================================

-- Tabela para logs de ações das facções (opcional, para auditoria)
CREATE TABLE IF NOT EXISTS `faccoes_logs` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `faccao` VARCHAR(50) NOT NULL,
    `acao` VARCHAR(50) NOT NULL,
    `executado_por` VARCHAR(50) NOT NULL,
    `alvo` VARCHAR(50) DEFAULT NULL,
    `detalhes` TEXT DEFAULT NULL,
    `data` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_faccao` (`faccao`),
    KEY `idx_data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Nota: O sistema de membros usa a coluna 'gang' da tabela 'players' do QBCore
-- Não é necessário criar tabela adicional para membros

-- Exemplo de query para listar membros de uma facção:
-- SELECT citizenid, charinfo, gang 
-- FROM players 
-- WHERE JSON_EXTRACT(gang, "$.name") = 'egito';

-- Exemplo de query para promover um membro:
-- UPDATE players 
-- SET gang = JSON_SET(gang, "$.grade.level", 5, "$.grade.name", "Guardião") 
-- WHERE citizenid = 'ABC12345';

-- ============================================================================
-- BANCO DA FACÇÃO (saldo por facção)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `faccoes_bank` (
    `faccao` VARCHAR(50) NOT NULL,
    `balance` BIGINT(20) NOT NULL DEFAULT 0,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`faccao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- MENSAGENS DO LÍDER (anúncios/regras por facção)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `faccoes_messages` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `faccao` VARCHAR(50) NOT NULL,
    `author_citizenid` VARCHAR(50) NOT NULL,
    `content` TEXT NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_faccao` (`faccao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- META DIÁRIA POR FACÇÃO (Santa: líder configura meta, premio e valor por entrega)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `faccoes_meta` (
    `faccao` VARCHAR(50) NOT NULL,
    `total` INT(11) NOT NULL DEFAULT 1000,
    `premio` INT(11) NOT NULL DEFAULT 200000,
    `valor_por_entrega` INT(11) NOT NULL DEFAULT 2000,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`faccao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- ENTREGAS DE FARM (para ranking e meta diária)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `faccoes_entregas` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `faccao` VARCHAR(50) NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL,
    `quantidade` INT(11) NOT NULL DEFAULT 0,
    `valor_recebido` INT(11) NOT NULL DEFAULT 0,
    `dia` DATE NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_faccao_dia` (`faccao`, `dia`),
    KEY `idx_citizenid` (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- BANIDOS DA FACÇÃO (quem foi banido, por quem, motivo)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `faccoes_banidos` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `faccao` VARCHAR(50) NOT NULL,
    `id_lider` INT(11) NOT NULL,
    `nome_lider` VARCHAR(128) DEFAULT NULL,
    `citizenid_membro` VARCHAR(50) NOT NULL,
    `nome_membro` VARCHAR(128) DEFAULT NULL,
    `motivo` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_faccao` (`faccao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- TRANSAÇÕES DO BANCO DA FACÇÃO (entrada/saída)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `faccoes_bank_transactions` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `faccao` VARCHAR(50) NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL,
    `nome` VARCHAR(128) DEFAULT NULL,
    `tipo` ENUM('entrada','saque') NOT NULL,
    `descricao` VARCHAR(128) DEFAULT NULL,
    `valor` BIGINT(20) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_faccao` (`faccao`),
    KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
