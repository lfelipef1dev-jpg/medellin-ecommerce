local QBCore = exports['qb-core']:GetCoreObject()
local PlayerData = {}
local painelAberto = false

-- [FASE 3] Lazy loading por gang — threads so rodam se player tem uma gang
local isActiveGang = false

-- ============================================================================
-- INICIALIZAÇÃO
-- ============================================================================
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    -- Retry: aguardar gang carregar (evita race condition após crash/reconexão)
    local attempts = 0
    while attempts < 20 do
        PlayerData = QBCore.Functions.GetPlayerData()
        if PlayerData and PlayerData.gang and PlayerData.gang.name and PlayerData.gang.name ~= "none" then
            break
        end
        attempts = attempts + 1
        Wait(500)
    end
    PlayerData = QBCore.Functions.GetPlayerData()
    isActiveGang = (PlayerData.gang and PlayerData.gang.name and PlayerData.gang.name ~= "none")
end)

RegisterNetEvent('QBCore:Player:SetPlayerData', function(val)
    PlayerData = val
    isActiveGang = (PlayerData.gang and PlayerData.gang.name and PlayerData.gang.name ~= "none")
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    PlayerData = {}
    isActiveGang = false -- [FASE 3] Lazy loading
end)

RegisterNetEvent('QBCore:Client:OnGangUpdate', function(gang)
    PlayerData.gang = gang
    isActiveGang = (gang and gang.name and gang.name ~= "none") -- [FASE 3] Lazy loading
end)

AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    PlayerData = QBCore.Functions.GetPlayerData()
    isActiveGang = (PlayerData.gang and PlayerData.gang.name and PlayerData.gang.name ~= "none") -- [FASE 3] Lazy loading
end)

-- ============================================================================
-- FUNÇÕES AUXILIARES
-- ============================================================================
local function GetPlayerFaccao()
    if not PlayerData.gang then
        local pd = QBCore.Functions.GetPlayerData()
        if pd and pd.gang then
            PlayerData = pd
        else
            return nil
        end
    end
    local gangName = PlayerData.gang.name
    if gangName and Config.Faccoes[gangName] then
        return gangName, Config.Faccoes[gangName]
    end
    return nil
end

local function GetGangGradeLevel(gang)
    if not gang then return 99 end
    local grade = gang.grade
    if type(grade) == 'table' then
        return tonumber(grade.level) or tonumber(grade.grade) or 99
    end
    return tonumber(grade) or 99
end

local function GetMaxCargoForFaccao(faccao)
    local max = 0
    if faccao and faccao.cargos then
        for nivel in pairs(faccao.cargos) do
            local n = tonumber(nivel)
            if n and n > max then max = n end
        end
    end
    if max <= 0 then
        max = (Config and tonumber(Config.MaxCargos)) or 20
    end
    return max
end

local function GetPlayerCargo()
    if not PlayerData.gang then return 99 end
    return GetGangGradeLevel(PlayerData.gang)
end

local function HasBauPermissaoNumerica(playerGrade, permissao)
    playerGrade = tonumber(playerGrade) or 99
    permissao = tonumber(permissao) or 99
    -- Se o sistema usa escala Medellín (1..Config.MaxCargos), menor = mais alto
    if Config and Config.MaxCargos and Config.MaxCargos > 3 then
        return playerGrade <= permissao
    end
    -- Fallback QBCore (0..3), maior = mais alto
    if playerGrade <= 3 and permissao <= 3 then
        return playerGrade >= permissao
    end
    return playerGrade <= permissao
end

local function HasBauPermissao(faccao, playerGrade, tipoBau, permissaoFallback)
    local maxCargo = GetMaxCargoForFaccao(faccao)
    playerGrade = tonumber(playerGrade) or maxCargo
    if playerGrade < 1 then playerGrade = maxCargo end
    if playerGrade > maxCargo then playerGrade = maxCargo end
    local cargoData = faccao and faccao.cargos and faccao.cargos[playerGrade]
    if cargoData and cargoData.permissoes then
        local permNecessaria = (tipoBau == 'lider') and 'bau_lider' or 'bau_membros'
        for _, perm in ipairs(cargoData.permissoes) do
            if perm == 'all' or perm == permNecessaria then
                return true
            end
        end
    end
    return HasBauPermissaoNumerica(playerGrade, permissaoFallback)
end

local function HasPermissao(permissao)
    local faccaoId, faccao = GetPlayerFaccao()
    if not faccao then return false end
    
    local cargo = GetPlayerCargo()
    local maxCargo = GetMaxCargoForFaccao(faccao)
    if cargo < 1 then cargo = maxCargo end
    if cargo > maxCargo then cargo = maxCargo end
    local cargoData = faccao.cargos[cargo] or faccao.cargos[maxCargo]
    if not cargoData then return false end
    
    for _, perm in ipairs(cargoData.permissoes or {}) do
        if perm == 'all' or perm == permissao then
            return true
        end
    end
    return false
end

local function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextDropshadow(0, 0, 0, 0, 255)
    SetTextEdge(2, 0, 0, 0, 150)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

-- ============================================================================
-- BAÚS - INTERAÇÃO POR TECLA E (fallback ao qb-target)
-- ============================================================================
local EInteractionRadius = 2.5
local ETextDistance = 3.5
local ECooldownMs = 600

local function IsEPressed()
    return IsControlJustReleased(0, 38) or IsControlJustReleased(0, 51)
end

CreateThread(function()
    Wait(2000)
    local lastUse = 0

    while true do
        -- [FASE 3] Lazy loading: dormindo se player nao tem gang
        if not isActiveGang then
            Wait(5000)
            goto continue_bau
        end
        local sleep = 800
        local ped = PlayerPedId()
        if ped and ped ~= 0 then
            local coords = GetEntityCoords(ped)
            local faccaoId, faccao = GetPlayerFaccao()

            if faccaoId and faccao and faccao.baus then
                for tipoBau, bau in pairs(faccao.baus) do
                    if bau and bau.coords then
                        local dist = #(coords - bau.coords)
                        if dist <= ETextDistance then
                            sleep = 0
                            if dist <= EInteractionRadius and IsEPressed() then
                                local now = GetGameTimer()
                                if now - lastUse > ECooldownMs then
                                    TriggerServerEvent('faccoes:server:abrirBau', faccaoId, tipoBau)
                                    lastUse = now
                                end
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
        ::continue_bau::
    end
end)

-- ============================================================================
-- BAÚS - CRIAÇÃO DOS PONTOS DE INTERAÇÃO
-- ============================================================================
CreateThread(function()
    Wait(2000) -- Esperar recursos carregarem
    
    for faccaoId, faccao in pairs(Config.Faccoes) do
        if faccao.baus then
            -- Baú Líder (ox_target com onSelect)
            if faccao.baus.lider then
                local lid = faccaoId -- closure
                exports.ox_target:addSphereZone({
                    coords = faccao.baus.lider.coords,
                    radius = 1.5,
                    debug = Config.Debug,
                    options = {
                        {
                            icon = 'fas fa-box',
                            label = faccao.baus.lider.label,
                            distance = 2.0,
                            onSelect = function()
                                local pf = GetPlayerFaccao()
                                if pf ~= lid then
                                    QBCore.Functions.Notify('Você não pertence a esta facção!', 'error')
                                    return
                                end
                                TriggerServerEvent('faccoes:server:abrirBau', lid, 'lider')
                            end,
                        }
                    }
                })
            end

            -- Baú Membros (ox_target com onSelect)
            if faccao.baus.membros then
                local mid = faccaoId -- closure
                exports.ox_target:addSphereZone({
                    coords = faccao.baus.membros.coords,
                    radius = 1.5,
                    debug = Config.Debug,
                    options = {
                        {
                            icon = 'fas fa-box-open',
                            label = faccao.baus.membros.label,
                            distance = 2.0,
                            onSelect = function()
                                local pf = GetPlayerFaccao()
                                if pf ~= mid then
                                    QBCore.Functions.Notify('Você não pertence a esta facção!', 'error')
                                    return
                                end
                                TriggerServerEvent('faccoes:server:abrirBau', mid, 'membros')
                            end,
                        }
                    }
                })
            end
        end
        
        -- Garagem da Facção (REMOVIDO - qb-garages já gerencia)
        -- As garagens de facção estão configuradas no qb-garages/config.lua
    end
    
    if Config.Debug then
    end
end)

-- ============================================================================
-- BAÚS - EVENTOS
-- ============================================================================
RegisterNetEvent('faccoes:abrirBau')
AddEventHandler('faccoes:abrirBau', function(data)
    local faccaoId = data and (data.faccao or (data.args and data.args.faccao)) or nil
    local tipoBau = data and (data.tipoBau or (data.args and data.args.tipoBau)) or nil
    local playerFaccao = GetPlayerFaccao()
    
    if not faccaoId or not tipoBau then
        QBCore.Functions.Notify('Erro ao abrir baú. Dados inválidos.', 'error')
        return
    end

    -- Verificar se é da facção
    if playerFaccao ~= faccaoId then
        QBCore.Functions.Notify('Você não pertence a esta facção!', 'error')
        return
    end
    
    -- Abrir o baú via server (permissão validada no server)
    TriggerServerEvent('faccoes:server:abrirBau', faccaoId, tipoBau)
end)

-- ============================================================================
-- GARAGEM - EVENTOS
-- ============================================================================
RegisterNetEvent('faccoes:abrirGaragem', function(data)
    local faccaoId = data.faccao
    local playerFaccao = GetPlayerFaccao()
    
    -- Verificar se é da facção
    if playerFaccao ~= faccaoId then
        QBCore.Functions.Notify('Você não pertence a esta facção!', 'error')
        return
    end
    
    -- Verificar permissão
    if not HasPermissao('garagem') then
        QBCore.Functions.Notify('Você não tem permissão para usar a garagem!', 'error')
        return
    end
    
    -- Abrir menu de garagem
    TriggerServerEvent('faccoes:server:getVeiculosFaccao', faccaoId)
end)

RegisterNetEvent('faccoes:client:menuGaragem', function(faccaoId, veiculos)
    local faccao = Config.Faccoes[faccaoId]
    local options = {}

    for _, veiculo in ipairs(veiculos) do
        table.insert(options, {
            title = veiculo.label,
            description = 'Spawnar ' .. veiculo.label,
            event = 'faccoes:client:spawnarVeiculo',
            args = {
                faccao = faccaoId,
                modelo = veiculo.model
            }
        })
    end

    lib.registerContext({
        id = 'faccoes_garagem_' .. faccaoId,
        title = 'Garagem da Faccao',
        options = options
    })
    lib.showContext('faccoes_garagem_' .. faccaoId)
end)

-- ============================================================================
-- GHOST SPAWN — veículo spawna no ponto exato, transparente e sem colisão
-- Depois de 5 segundos volta ao normal
-- ============================================================================
local function ApplyGhostMode(veiculo)
    SetEntityAlpha(veiculo, 150, false) -- transparente
    SetTimeout(5000, function()
        if DoesEntityExist(veiculo) then
            ResetEntityAlpha(veiculo) -- opaco
        end
    end)
end

RegisterNetEvent('faccoes:client:spawnarVeiculo', function(data)
    local faccaoId = data.faccao
    local modelo = data.modelo
    local faccao = Config.Faccoes[faccaoId]

    if not faccao or not faccao.garagem then return end

    local spawnPoint = faccao.garagem.spawn
    local hash = GetHashKey(modelo)

    RequestModel(hash)
    while not HasModelLoaded(hash) do
        Wait(100)
    end

    local veiculo = CreateVehicle(hash, spawnPoint.x, spawnPoint.y, spawnPoint.z, spawnPoint.w, true, false)
    SetEntityAsMissionEntity(veiculo, true, true)
    SetVehicleNumberPlateText(veiculo, 'FAC-' .. string.upper(string.sub(faccaoId, 1, 4)))
    ApplyGhostMode(veiculo)
    SetPedIntoVehicle(PlayerPedId(), veiculo, -1)
    SetVehicleEngineOn(veiculo, true, true, false)

    -- Dar chave do veículo
    TriggerEvent('vehiclekeys:client:SetOwner', QBCore.Functions.GetPlate(veiculo))

    SetModelAsNoLongerNeeded(hash)

    QBCore.Functions.Notify('Veículo spawnado com sucesso!', 'success')
end)

-- ============================================================================
-- PAINEL DE FACÇÃO - NUI
-- ============================================================================
RegisterNetEvent('faccoes:abrirPainel', function()
    local faccaoId, faccao = GetPlayerFaccao()
    
    if not faccao then
        QBCore.Functions.Notify('Você não pertence a nenhuma facção!', 'error')
        return
    end
    
    -- Buscar membros do servidor
    TriggerServerEvent('faccoes:server:getMembros', faccaoId)
end)

RegisterNetEvent('faccoes:client:abrirPainelNUI', function(faccaoId, membros, dadosExtras)
    local faccao = Config.Faccoes[faccaoId]
    if not faccao then return end

    local maxCargo = GetMaxCargoForFaccao(faccao)
    local cargo = GetPlayerCargo()
    if cargo < 1 then cargo = maxCargo end
    if cargo > maxCargo then cargo = maxCargo end
    local cargoData = faccao.cargos[cargo] or faccao.cargos[maxCargo] or { nome = ('Cargo ' .. tostring(cargo)), permissoes = {} }
    
    -- Preparar dados dos cargos
    local cargosLista = {}
    for i, c in pairs(faccao.cargos) do
        table.insert(cargosLista, {
            nivel = i,
            nome = c.nome
        })
    end
    table.sort(cargosLista, function(a, b) return a.nivel < b.nivel end)
    
    -- Nome do líder (cargo 1)
    local nomeLider = nil
    for _, m in ipairs(membros) do
        if m.cargo == 1 then
            nomeLider = m.nome
            break
        end
    end
    
    SetNuiFocus(true, true)
    painelAberto = true
    
    local payload = {
        action = 'abrir',
        faccao = {
            id = faccaoId,
            nome = faccao.nome,
            tipo = faccao.tipo,
            cor = faccao.cor,
            icone = faccao.icone,
            logo = faccao.logo
        },
        jogador = {
            cargo = cargo,
            cargoNome = cargoData.nome,
            permissoes = cargoData.permissoes
        },
        membros = membros,
        cargos = cargosLista,
        nomeLider = nomeLider,
        discord = faccao.discord or (dadosExtras and dadosExtras.discord),
        mensagemLider = (dadosExtras and dadosExtras.mensagemLider) or faccao.mensagemLider,
        saldo = dadosExtras and dadosExtras.saldo,
        regras = faccao.regras or (dadosExtras and dadosExtras.regras),
        rankingFarm = dadosExtras and dadosExtras.rankingFarm or {},
        rankingTempo = dadosExtras and dadosExtras.rankingTempo or {},
        meta = dadosExtras and dadosExtras.meta or { atual = 0, total = 1000, premio = 200000 },
        pontosOrganizacao = dadosExtras and dadosExtras.pontosOrganizacao or 0,
        loja = (dadosExtras and dadosExtras.loja) or faccao.loja or ((Config.LojaFaccao and Config.LojaFaccao.itensPadrao) or {})
    }
    SendNUIMessage(payload)
end)

RegisterNUICallback('fechar', function(_, cb)
    SetNuiFocus(false, false)
    painelAberto = false
    cb('ok')
end)

RegisterNUICallback('promoverMembro', function(data, cb)
    TriggerServerEvent('faccoes:server:promoverMembro', data.citizenid, data.novoCargo)
    cb('ok')
end)

RegisterNUICallback('rebaixarMembro', function(data, cb)
    TriggerServerEvent('faccoes:server:rebaixarMembro', data.citizenid)
    cb('ok')
end)

RegisterNUICallback('expulsarMembro', function(data, cb)
    TriggerServerEvent('faccoes:server:expulsarMembro', data.citizenid)
    cb('ok')
end)

RegisterNUICallback('expulsarEBanir', function(data, cb)
    if data and data.citizenid then
        TriggerServerEvent('faccoes:server:expulsarEBanir', data.citizenid, data.motivo)
    end
    cb('ok')
end)

RegisterNUICallback('alterarCargo', function(data, cb)
    if data and data.citizenid and data.novoCargo ~= nil then
        TriggerServerEvent('faccoes:server:alterarCargo', data.citizenid, data.novoCargo)
    end
    cb('ok')
end)

RegisterNUICallback('recrutarPorId', function(data, cb)
    if data and data.id ~= nil then
        TriggerServerEvent('faccoes:server:recrutarPorId', data.id)
    end
    cb('ok')
end)

RegisterNUICallback('removerBanido', function(data, cb)
    if data and data.id ~= nil then
        TriggerServerEvent('faccoes:server:removerBanido', data.id)
    end
    cb('ok')
end)

RegisterNUICallback('avaliarCidade', function(_, cb)
    -- Opcional: integrar com sistema de avaliação (ex: promoter_score)
    QBCore.Functions.Notify('Avaliação em breve.', 'primary')
    cb('ok')
end)

RegisterNUICallback('acaoRapida', function(data, cb)
    local acao = data and data.acao
    local faccaoId, faccao = GetPlayerFaccao()
    if not faccao then cb('ok') return end
    
    if acao == 'radio' then
        local canal = faccao.radioChannel or Config.RadioCanalPadrao or 10
        local success = pcall(function()
            exports['pma-voice']:addPlayerToRadio(canal)
        end)
        if success then
            QBCore.Functions.Notify('Entrou no rádio da facção (canal ' .. canal .. ').', 'success')
        else
            QBCore.Functions.Notify('Use o item rádio ou o recurso de voz está indisponível.', 'error')
        end
    elseif acao == 'localizacao' then
        local coords = (faccao.waypointCoords and faccao.waypointCoords) or
            (faccao.baus and faccao.baus.lider and faccao.baus.lider.coords) or
            (faccao.garagem and faccao.garagem.coords)
        if coords and coords.x and coords.y then
            SetNewWaypoint(coords.x, coords.y)
            QBCore.Functions.Notify('Localização da facção marcada no mapa.', 'success')
        else
            QBCore.Functions.Notify('Nenhuma coordenada configurada para esta facção.', 'error')
        end
    elseif acao == 'uniforme' then
        if faccao.uniforme then
            TriggerEvent('qb-clothing:client:loadOutfit', faccao.uniforme)
            QBCore.Functions.Notify('Uniforme da facção aplicado.', 'success')
        else
            QBCore.Functions.Notify('Esta facção não possui uniforme configurado.', 'primary')
        end
    end
    cb('ok')
end)

RegisterNUICallback('entregarRecompensa', function(data, cb)
    local quantidade = tonumber(data and data.quantidade) or 0
    local valorStr = data and data.valor
    TriggerServerEvent('faccoes:server:entregarRecompensa', quantidade, valorStr)
    cb('ok')
end)

RegisterNUICallback('depositarBanco', function(data, cb)
    if data and data.faccaoId and data.amount then
        TriggerServerEvent('faccoes:server:depositarBanco', data.faccaoId, data.amount)
    end
    cb('ok')
end)

RegisterNUICallback('sacarBanco', function(data, cb)
    if data and data.faccaoId and data.amount then
        TriggerServerEvent('faccoes:server:sacarBanco', data.faccaoId, data.amount)
    end
    cb('ok')
end)

RegisterNUICallback('comprarLoja', function(data, cb)
    if data and data.faccaoId and data.item then
        TriggerServerEvent('faccoes:server:comprarLoja', data.faccaoId, data.item, data.amount)
    end
    cb('ok')
end)

RegisterNUICallback('configurarMeta', function(data, cb)
    if data and data.faccaoId then
        TriggerServerEvent('faccoes:server:configurarMeta', data.faccaoId, data.total, data.premio, data.valorPorEntrega)
    end
    cb('ok')
end)

-- Comando /painel: abre o painel de facção (chamado pelo Hub via ExecuteCommand).
RegisterCommand("painel", function()
    TriggerEvent('faccoes:abrirPainel')
end, false)
-- O Hub chama ExecuteCommand("painel") ao clicar em "Painel da Organização".

-- ============================================================================
-- COMANDO PARA TESTAR BAÚ (DEBUG)
-- ============================================================================
RegisterCommand('testebau', function(source, args)
    local tipoBau = args[1] or 'lider'
    local faccaoId, faccao = GetPlayerFaccao()
    
    if not faccao then
        QBCore.Functions.Notify('Você não pertence a nenhuma facção!', 'error')
        return
    end
    
    if Config.Debug then print('[DEBUG] Tentando abrir baú: ' .. tipoBau .. ' da facção: ' .. faccaoId) end
    TriggerServerEvent('faccoes:server:abrirBau', faccaoId, tipoBau)
end, false)

-- ============================================================================
-- MARKERS 3D (opcional - visual) — SPLIT THREAD [FASE 3]
-- ============================================================================
local nearAnyBau = false

-- Thread de DADOS: verifica proximidade dos baus a cada 1s
CreateThread(function()
    while true do
        if not isActiveGang then
            nearAnyBau = false
            Wait(5000)
        else
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local found = false
            for _, faccao in pairs(Config.Faccoes) do
                if faccao.baus then
                    if faccao.baus.lider and #(playerCoords - faccao.baus.lider.coords) < 20.0 then
                        found = true
                        break
                    end
                    if faccao.baus.membros and #(playerCoords - faccao.baus.membros.coords) < 20.0 then
                        found = true
                        break
                    end
                end
            end
            nearAnyBau = found
            Wait(1000)
        end
    end
end)

-- Thread de RENDER: só roda quando nearAnyBau == true
CreateThread(function()
    while true do
        if nearAnyBau and isActiveGang then
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)

            for faccaoId, faccao in pairs(Config.Faccoes) do
                -- Markers nos baús
                if faccao.baus then
                    if faccao.baus.lider then
                        local dist = #(playerCoords - faccao.baus.lider.coords)
                        if dist < 20.0 then
                            DrawMarker(2, faccao.baus.lider.coords.x, faccao.baus.lider.coords.y, faccao.baus.lider.coords.z + 0.5,
                                0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 255, 136, 150, true, true, 2, nil, nil, false)
                        end
                        if dist < 6.0 then
                            DrawText3D(faccao.baus.lider.coords.x, faccao.baus.lider.coords.y, faccao.baus.lider.coords.z + 1.0, '~g~[E] ' .. (faccao.baus.lider.label or 'Baú Líder'))
                        end
                    end

                    if faccao.baus.membros then
                        local b = faccao.baus.membros
                        local mz = (b.markerZOffset ~= nil) and b.markerZOffset or 0.5
                        local tz = (b.textZOffset ~= nil) and b.textZOffset or 1.0
                        local dist = #(playerCoords - b.coords)
                        if dist < 20.0 then
                            DrawMarker(2, b.coords.x, b.coords.y, b.coords.z + mz,
                                0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 255, 136, 150, true, true, 2, nil, nil, false)
                        end
                        if dist < 6.0 then
                            DrawText3D(b.coords.x, b.coords.y, b.coords.z + tz, '~g~[E] ' .. (b.label or 'Baú Membros'))
                        end
                    end
                end

                -- Marker na garagem (REMOVIDO - qb-garages já gerencia)
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- ============================================================================
-- EVENTOS DE NOTIFICAÇÃO
-- ============================================================================
RegisterNetEvent('faccoes:client:notify', function(msg, tipo)
    QBCore.Functions.Notify(msg, tipo)
end)

RegisterNetEvent('faccoes:client:atualizarPainel', function()
    if painelAberto then
        local faccaoId = GetPlayerFaccao()
        if faccaoId then
            TriggerServerEvent('faccoes:server:getMembros', faccaoId)
        end
    end
end)

RegisterNetEvent('faccoes:client:atualizarDadosExtras', function(dados)
    if not painelAberto or not dados then return end
    SendNUIMessage({
        action = 'atualizarDadosExtras',
        saldo = dados.saldo,
        transacoes = dados.transacoes or {},
        banidos = dados.banidos or {},
        pontosOrganizacao = dados.pontosOrganizacao or 0,
        mensagemLider = dados.mensagemLider
    })
end)
