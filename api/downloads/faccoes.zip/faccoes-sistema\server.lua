local QBCore = exports['qb-core']:GetCoreObject()
local DEBUG = false

-- Log centralizado (opcional)
local function FaccaoLog(src, titulo, descricao, campos)
    pcall(function()
        -- -- exports['logs']:LogPlayer('faccoes', titulo, src, descricao, campos)
    end)
end

-- Rate limiting para eventos financeiros (previne spam/exploit)
local rateLimits = {}
local function IsRateLimited(src, eventName, cooldownMs)
    cooldownMs = cooldownMs or 30000 -- 30 segundos padrão
    local key = tostring(src) .. ':' .. eventName
    local now = GetGameTimer()
    if rateLimits[key] and (now - rateLimits[key]) < cooldownMs then
        return true
    end
    rateLimits[key] = now
    return false
end
-- Limpar rate limits de jogadores desconectados
AddEventHandler('playerDropped', function()
    local src = tostring(source)
    for k, _ in pairs(rateLimits) do
        if k:find('^' .. src .. ':') then
            rateLimits[k] = nil
        end
    end
end)

-- ============================================================================
-- REGRAS SANTA (painel) – mesma lógica em todas as funções
-- ============================================================================
-- INÍCIO: qualquer membro da facção pode abrir; tipo da facção = Config.Painel.apenasTipo.
-- MEMBROS: alterar cargo / promover / rebaixar / expulsar = HasCargoPermissao(..., 'gerenciar_membros').
-- RECRUTAMENTO: enviar convite = HasCargoPermissaoAny(..., {'all','gerenciar_membros','recrutar'}); aceitar/recusar no client; pontos por iniciante = Config.PontosFaccao.
-- BANIDOS: remover ban = HasCargoPermissao(..., 'gerenciar_membros').
-- BANCO: depositar/sacar = grade <= Config.BancoFaccao.cargosPodeMover (só liderança).
-- MENSAGEM LÍDER: postar = grade <= cargosPodeMover (só liderança).
-- LOJA: comprar com pontos = grade <= Config.LojaFaccao.cargosPodeComprar (só liderança).
-- FARM: entregar recompensa = qualquer membro da facção.
-- ============================================================================

-- Facção do jogador via QBCore PlayerData (gang.name)
local function GetPlayerFaction(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return nil end
    local gang = Player.PlayerData.gang
    if not gang or not gang.name or gang.name == '' or gang.name == 'none' then
        return nil
    end
    return gang.name
end

-- ============================================================================
-- FORWARD DECLARATIONS (evita problema de escopo em callbacks)
-- ============================================================================
local GetOrCreateBankBalance
local GetOrCreateOrgPoints
local AddOrgPoints
local RemoveOrgPoints

-- Convites pendentes (Santa: enviar convite, alvo aceita/recusa). [targetSource] = { faccaoId, recruiterSrc, recruiterNome, expiresAt }
local ConvitesPendentes = {}
local CONVITE_EXPIRA_SEG = 60

-- ============================================================================
-- DB - GARANTIR TABELAS (points + messages) - criação síncrona para existir antes de qualquer query
-- ============================================================================
MySQL.ready(function()
    pcall(function()
            MySQL.query.await([[
                CREATE TABLE IF NOT EXISTS faccoes_points (
                    faccao VARCHAR(64) NOT NULL,
                    points INT NOT NULL DEFAULT 0,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (faccao)
                )
            ]])
            MySQL.query.await([[
                CREATE TABLE IF NOT EXISTS faccoes_messages (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    faccao VARCHAR(50) NOT NULL,
                    author_citizenid VARCHAR(50) NOT NULL,
                    content TEXT NOT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    KEY idx_faccao (faccao)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ]])
            MySQL.query.await([[
                CREATE TABLE IF NOT EXISTS faccoes_banidos (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    faccao VARCHAR(50) NOT NULL,
                    id_lider INT(11) NOT NULL,
                    nome_lider VARCHAR(128) NOT NULL DEFAULT '',
                    citizenid_membro VARCHAR(50) NOT NULL,
                    nome_membro VARCHAR(128) NOT NULL DEFAULT '',
                    motivo TEXT,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    KEY idx_faccao (faccao)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ]])
            MySQL.query.await([[
                CREATE TABLE IF NOT EXISTS faccoes_recrutamentos (
                    id INT(11) NOT NULL AUTO_INCREMENT,
                    faccao VARCHAR(50) NOT NULL,
                    recruiter_citizenid VARCHAR(50) NOT NULL,
                    recruiter_nome VARCHAR(128) NOT NULL DEFAULT '',
                    recruited_citizenid VARCHAR(50) NOT NULL,
                    recruited_nome VARCHAR(128) NOT NULL DEFAULT '',
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    KEY idx_faccao (faccao),
                    KEY idx_recruiter (recruiter_citizenid)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ]])
            MySQL.query.await([[
                CREATE TABLE IF NOT EXISTS faccoes_meta (
                    faccao VARCHAR(50) NOT NULL PRIMARY KEY,
                    total INT(11) NOT NULL DEFAULT 1000,
                    premio INT(11) NOT NULL DEFAULT 200000,
                    valor_por_entrega INT(11) NOT NULL DEFAULT 2000,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ]])
    end)
end)

-- ============================================================================
-- UTILITÁRIOS
-- ============================================================================
local function GetGangGradeLevel(gang)
    if not gang then return 99 end
    local grade = gang.grade
    if type(grade) == 'table' then
        return tonumber(grade.level) or tonumber(grade.grade) or 99
    end
    return tonumber(grade) or 99
end

local function IsGangBoss(gang)
    if not gang then return false end
    if gang.isboss ~= nil then return gang.isboss == true end
    local grade = gang.grade
    if type(grade) == 'table' and grade.isboss ~= nil then
        return grade.isboss == true
    end
    return false
end

local function GetMaxCargoForFaccao(faccao)
    local max = 0
    if faccao and faccao.cargos then
        for nivel in pairs(faccao.cargos) do
            local n = tonumber(nivel)
            if n and n > max then max = n end
        end
    end
    if max <= 0 then
        max = (Config and tonumber(Config.MaxCargos)) or 20
    end
    return max
end

local function NormalizarCargo(faccao, cargo)
    local max = GetMaxCargoForFaccao(faccao)
    cargo = tonumber(cargo) or max
    if cargo < 1 then cargo = max end
    if cargo > max then cargo = max end
    if faccao and faccao.cargos and not faccao.cargos[cargo] then
        cargo = max
    end
    return cargo, max
end

-- Santa: verificar se cargo tem permissão (ex: 'craft', 'bau_membros', 'gerenciar_membros'). Usado por faccoes-armas e painel.
local function HasCargoPermissao(faccaoId, gradeLevel, permissao)
    if not faccaoId or not permissao or permissao == '' then return false end
    local faccao = Config.Faccoes[faccaoId]
    if not faccao or not faccao.cargos then return false end
    local cargoNorm, _ = NormalizarCargo(faccao, gradeLevel)
    local cargoData = faccao.cargos[cargoNorm]
    if not cargoData or not cargoData.permissoes then return false end
    for _, perm in ipairs(cargoData.permissoes) do
        if perm == 'all' or perm == permissao then return true end
    end
    return false
end
-- Santa: verificar se cargo tem alguma das permissões (ex: recrutar = all OU gerenciar_membros OU recrutar)
local function HasCargoPermissaoAny(faccaoId, gradeLevel, listaPermissoes)
    if not listaPermissoes or type(listaPermissoes) ~= 'table' then return false end
    for _, p in ipairs(listaPermissoes) do
        if HasCargoPermissao(faccaoId, gradeLevel, p) then return true end
    end
    return false
end
exports('HasCargoPermissao', function(faccaoId, gradeLevel, permissao) return HasCargoPermissao(faccaoId, gradeLevel, permissao) end)

-- ============================================================================
-- SANTA: regras de hierarquia idênticas (Chefe=1, Sub-Chefe=2, Supervisor=3, Membro=4, Novato=5+)
-- promote = 1,2,3; alvo ~= 1; Sub-Chefe/Supervisor não podem promover a cargo 2
-- demote/fire = 1,2; fire: não a si mesmo; Sub-Chefe não pode expulsar Chefe
-- banco/mensagem = cargo <= 2; loja = cargo == 1 (só líder); recrutar = cargo <= 4
-- ============================================================================
local function SantaPodePromover(playerGrade, targetGrade, novoCargo)
    playerGrade = tonumber(playerGrade) or 99
    targetGrade = tonumber(targetGrade) or 99
    novoCargo = tonumber(novoCargo) or 99
    if playerGrade > 3 then return false end
    if targetGrade <= 1 then return false end
    if playerGrade >= 2 and novoCargo <= 2 then return false end
    return true
end
local function SantaPodeRebaixar(playerGrade)
    return (tonumber(playerGrade) or 99) <= 2
end
local function SantaPodeExpulsar(playerGrade, targetGrade, playerCid, targetCid)
    playerGrade = tonumber(playerGrade) or 99
    targetGrade = tonumber(targetGrade) or 99
    if playerGrade > 2 then return false end
    if playerCid == targetCid then return false end
    if playerGrade == 2 and targetGrade <= 1 then return false end
    return true
end
local function SantaPodeBanco(playerGrade)
    return (tonumber(playerGrade) or 99) <= 2
end
local function SantaPodeLoja(playerGrade)
    return (tonumber(playerGrade) or 99) == 1
end
local function SantaPodeRecrutar(playerGrade)
    return (tonumber(playerGrade) or 99) <= 4
end

-- Lista de facções para o menu de recrutamento do agente (id + nome)
exports('GetFaccoesParaRecrutamento', function()
    local list = {}
    for id, f in pairs(Config.Faccoes or {}) do
        list[#list + 1] = { id = id, nome = (f and f.nome) and tostring(f.nome) or id }
    end
    return list
end)

local function PersistirGangNoDB(citizenid, gangData, cb)
    if not citizenid then
        if cb then cb(false) end
        return
    end
    MySQL.Async.execute('UPDATE players SET gang = ? WHERE citizenid = ?', { json.encode(gangData), citizenid }, function(_)
        if cb then cb(true) end
    end)
end

local function HasBauPermissaoNumerica(playerGrade, permissao)
    playerGrade = tonumber(playerGrade) or 99
    permissao = tonumber(permissao) or 99
    -- QBCore (0..3): maior = mais alto
    if playerGrade <= 3 and permissao <= 3 then
        return playerGrade >= permissao
    end
    -- Medellín (1..20): menor = mais alto
    return playerGrade <= permissao
end

local function HasBauPermissao(faccao, playerGrade, tipoBau, permissaoFallback, isBoss)
    playerGrade = select(1, NormalizarCargo(faccao, playerGrade))
    local cargoData = faccao and faccao.cargos and faccao.cargos[playerGrade]
    if cargoData and cargoData.permissoes then
        local permNecessaria = (tipoBau == 'lider') and 'bau_lider' or 'bau_membros'
        for _, perm in ipairs(cargoData.permissoes) do
            if perm == 'all' or perm == permNecessaria then
                return true
            end
        end
        return false
    else
        -- Sem mapeamento de cargos: fallback QBCore
        if tipoBau == 'membros' then
            return true
        end
        if tipoBau == 'lider' then
            if isBoss then
                return true
            end
            if tonumber(playerGrade) and tonumber(playerGrade) <= 3 then
                return tonumber(playerGrade) >= 2
            end
        end
    end
    return HasBauPermissaoNumerica(playerGrade, permissaoFallback)
end

-- ============================================================================
-- CALLBACK: obter facção do jogador (para clientes evitarem PlayerData direto)
-- ============================================================================
-- Painel: fonte da verdade é o servidor. Se a memória (GetPlayerFaction) disser que não está em facção,
-- consultar o DB — em alguns clientes a gang é zerada no load (CheckPlayerData) e outros usuários aparecem "sem organização".
QBCore.Functions.CreateCallback('faccoes:server:getPlayerFaction', function(source, cb)
    local faction = GetPlayerFaction(source)
    if faction and faction ~= '' and faction ~= 'none' and Config.Faccoes[faction] then
        cb(faction)
        return
    end
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player or not Player.PlayerData.citizenid then
        cb(faction or 'none')
        return
    end
    MySQL.Async.fetchScalar('SELECT gang FROM players WHERE citizenid = ?', { Player.PlayerData.citizenid }, function(gangJson)
        if not gangJson or gangJson == '' then
            cb(faction or 'none')
            return
        end
        local ok, gang = pcall(json.decode, gangJson)
        local name = (ok and gang and gang.name) and string.lower(tostring(gang.name):match('^%s*(.-)%s*$') or '') or nil
        if name and name ~= '' and name ~= 'none' and Config.Faccoes[name] then
            -- Sincronizar gang em memória para este jogador (evita "sem organização" em aberturas seguintes)
            local lvl = nil
            if gang.grade then
                if type(gang.grade) == 'table' and gang.grade.level ~= nil then
                    lvl = tonumber(gang.grade.level) or tonumber(gang.grade.grade)
                else
                    lvl = tonumber(gang.grade)
                end
            end
            local shared = QBCore.Shared and QBCore.Shared.Gangs and QBCore.Shared.Gangs[name]
            local grade = (shared and shared.grades and lvl and shared.grades[tostring(lvl)]) and lvl or nil
            if not grade and shared and shared.grades then
                local maxG = 0
                for k in pairs(shared.grades) do local n = tonumber(k); if n and n > maxG then maxG = n end end
                grade = maxG
            end
            local P = QBCore.Functions.GetPlayer(source)
            if P and grade ~= nil then
                pcall(function() P.Functions.SetGang(name, grade) end)
            end
            cb(name)
            return
        end
        cb(faction or 'none')
    end)
end)

-- ============================================================================
-- ATUALIZAÇÃO DO QBCORE
-- ============================================================================
RegisterNetEvent('QBCore:Server:UpdateObject', function()
    if source ~= '' then return end
    QBCore = exports['qb-core']:GetCoreObject()
end)

-- ============================================================================
-- SANTA: quando a gang é alterada (QB Admin Menu ou painel), painel atualiza
-- na hora. Disparamos refresh imediato e persistimos no DB em background.
-- ============================================================================
AddEventHandler('QBCore:Server:OnGangUpdate', function(playerSource, gangData)
    if not playerSource or not gangData then return end
    local Player = QBCore.Functions.GetPlayer(playerSource)
    if not Player or not Player.PlayerData.citizenid then return end
    local citizenid = Player.PlayerData.citizenid
    -- Atualizar painel do próprio jogador na hora
    TriggerClientEvent('faccoes:client:atualizarPainel', playerSource)
    local faccaoId = (gangData.name and tostring(gangData.name):lower():match('^%s*(.-)%s*$')) or ''
    if faccaoId ~= '' and faccaoId ~= 'none' and Config.Faccoes[faccaoId] then
        -- Nova facção: notificar todos da mesma facção para a lista atualizar
        local players = QBCore.Functions.GetQBPlayers()
        for _, p in pairs(players) do
            if p and p.PlayerData and p.PlayerData.source ~= playerSource then
                local g = p.PlayerData.gang and (p.PlayerData.gang.name or '')
                if g == faccaoId then
                    TriggerClientEvent('faccoes:client:atualizarPainel', p.PlayerData.source)
                end
            end
        end
    elseif faccaoId == 'none' then
        -- Remoção: notificar jogadores da facção antiga (DB ainda tem o gang antigo antes do persist)
        MySQL.Async.fetchScalar('SELECT gang FROM players WHERE citizenid = ?', {citizenid}, function(gangJson)
            if gangJson then
                local ok, decoded = pcall(json.decode, gangJson)
                local oldName = (ok and decoded and decoded.name) and tostring(decoded.name):lower():match('^%s*(.-)%s*$') or ''
                if oldName ~= '' and oldName ~= 'none' and Config.Faccoes[oldName] then
                    local players = QBCore.Functions.GetQBPlayers()
                    for _, p in pairs(players) do
                        if p and p.PlayerData then
                            local g = p.PlayerData.gang and (p.PlayerData.gang.name or '')
                            if g == oldName then
                                TriggerClientEvent('faccoes:client:atualizarPainel', p.PlayerData.source)
                            end
                        end
                    end
                end
            end
        end)
    end
    -- Persistir no DB em background (não bloqueia o refresh)
    PersistirGangNoDB(citizenid, gangData, function() end)
end)

-- ============================================================================
-- BAÚS - ABRIR INVENTÁRIO
-- ============================================================================
RegisterNetEvent('faccoes:server:abrirBau', function(faccaoId, tipoBau)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if DEBUG then print(string.format('[FACCOES-DEBUG] Evento recebido - Faccao: %s, TipoBau: %s, Source: %s',
        tostring(faccaoId), tostring(tipoBau), tostring(src))) end
    
    if not Player then
        if DEBUG then print('[FACCOES-DEBUG] Player não encontrado!') end
        return
    end
    
    local faccao = Config.Faccoes[faccaoId]
    if not faccao then
        if DEBUG then print('[FACCOES-DEBUG] Facção não encontrada no config: ' .. tostring(faccaoId)) end
        return
    end
    
    local playerFaction = GetPlayerFaction(src)
    local playerGrade = GetGangGradeLevel(Player.PlayerData.gang)
    local isBoss = IsGangBoss(Player.PlayerData.gang)
    
    if DEBUG then print(string.format('[FACCAO CHECK] abrirBau src=%s faction=%s grade=%s', tostring(src), tostring(playerFaction), tostring(playerGrade))) end
    
    -- Verificar se é da facção
    if playerFaction ~= faccaoId then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não pertence a esta facção!', 'error')
        if DEBUG then print('[FACCOES-DEBUG] Jogador não pertence à facção!') end
        return
    end
    
    local bauConfig = faccao.baus[tipoBau]
    if not bauConfig then
        if DEBUG then print('[FACCOES-DEBUG] Baú não encontrado: ' .. tostring(tipoBau)) end
        return
    end
    
    if DEBUG then print(string.format('[FACCOES-DEBUG] BauConfig permissao: %s', tostring(bauConfig.permissao))) end
    
    -- Verificar cargo
    if not HasBauPermissao(faccao, playerGrade, tipoBau, bauConfig.permissao, isBoss) then
        TriggerClientEvent('faccoes:client:notify', src, 'Cargo insuficiente para acessar este baú!', 'error')
        if DEBUG then print('[FACCOES-DEBUG] Cargo insuficiente!') end
        return
    end
    
    -- Criar identificador único do baú
    local stashId = 'faccao_' .. faccaoId .. '_' .. tipoBau
    
    if DEBUG then print('[FACCOES-DEBUG] Abrindo stash: ' .. stashId) end
    
    -- Abrir inventário via ox_inventory
    local invRes = GetResourceState('ox_inventory')
    if invRes ~= 'started' then
        TriggerClientEvent('faccoes:client:notify', src, 'Inventário não está disponível. Tente novamente.', 'error')
        return
    end
    
    print('^3[BAU SERVER] Tentando abrir stash: ' .. stashId .. ' para src=' .. tostring(src) .. '^7')

    -- Registrar stash se não existir
    local okReg, errReg = pcall(function()
        exports.ox_inventory:RegisterStash(stashId, bauConfig.label, bauConfig.slots, bauConfig.maxweight)
    end)
    print('^3[BAU SERVER] RegisterStash: ok=' .. tostring(okReg) .. ' err=' .. tostring(errReg) .. '^7')

    -- Abrir o inventário
    local ok, err = pcall(function()
        exports.ox_inventory:forceOpenInventory(src, 'stash', stashId)
    end)
    print('^3[BAU SERVER] forceOpenInventory: ok=' .. tostring(ok) .. ' err=' .. tostring(err) .. '^7')

    if not ok then
        -- Fallback: tentar OpenInventory
        print('^1[BAU SERVER] forceOpen falhou, tentando OpenInventory...^7')
        local ok2, err2 = pcall(function()
            TriggerClientEvent('ox_inventory:openInventory', src, 'stash', stashId)
        end)
        print('^3[BAU SERVER] OpenInventory via event: ok=' .. tostring(ok2) .. ' err=' .. tostring(err2) .. '^7')
    end
    
    if DEBUG then print(string.format('[FACCOES] %s abriu o baú %s da facção %s',
        Player.PlayerData.charinfo.firstname, tipoBau, faccaoId)) end
end)

-- ============================================================================
-- GARAGEM - OBTER VEÍCULOS (Santa: membro = só lista membros; gerente = todos = membros + VIP)
-- ============================================================================
RegisterNetEvent('faccoes:server:getVeiculosFaccao', function(faccaoId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local playerFaction = GetPlayerFaction(src)
    if playerFaction ~= faccaoId then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não pertence a esta facção!', 'error')
        return
    end

    local playerGrade = GetGangGradeLevel(Player.PlayerData.gang)
    local temGaragemVIP = HasCargoPermissao(faccaoId, playerGrade, 'bau_lider') or HasCargoPermissao(faccaoId, playerGrade, 'all')

    local raw = Config.VeiculosFaccao[faccaoId]
    local listMembros = {}
    local listVIP = {}

    if type(raw) == 'table' and not raw[1] and (raw.membros or raw.vip) then
        listMembros = raw.membros or {}
        listVIP = raw.vip or {}
    else
        local flat = type(raw) == 'table' and raw or {}
        listMembros = flat
        listVIP = {}
    end

    local modelos = {}
    local seen = {}
    for _, modelo in ipairs(listMembros) do
        if type(modelo) == 'string' and modelo ~= '' and not seen[modelo] then
            seen[modelo] = true
            table.insert(modelos, modelo)
        end
    end
    if temGaragemVIP then
        for _, modelo in ipairs(listVIP) do
            if type(modelo) == 'string' and modelo ~= '' and not seen[modelo] then
                seen[modelo] = true
                table.insert(modelos, modelo)
            end
        end
    end

    local veiculos = {}
    for _, modelo in ipairs(modelos) do
        table.insert(veiculos, {
            model = modelo,
            label = string.upper(modelo)
        })
    end

    TriggerClientEvent('faccoes:client:menuGaragem', src, faccaoId, veiculos)
end)

-- ============================================================================
-- PAINEL - OBTER MEMBROS DA FACÇÃO + DADOS EXTRAS (banco, mensagens, rankings, meta)
-- ============================================================================
RegisterNetEvent('faccoes:server:getMembros', function(faccaoId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    
    local playerFaction = GetPlayerFaction(src)
    local citizenid = Player.PlayerData.citizenid

    local function doGetMembros()
        local faccao = Config.Faccoes[faccaoId]
        if not faccao then return end
    local maxCargo = GetMaxCargoForFaccao(faccao)

    -- Opcional: painel somente para um tipo específico (ex: 'armas')
    local apenasTipo = Config.Painel and Config.Painel.apenasTipo
    if apenasTipo and faccao.tipo ~= apenasTipo then
        TriggerClientEvent('faccoes:client:notify', src, 'Este painel é exclusivo para facções de ' .. tostring(apenasTipo) .. '.', 'error')
        return
    end
    
    -- Só colunas que existem em todo QBCore (evita erro se não tiver metadata)
    MySQL.Async.fetchAll('SELECT citizenid, charinfo, gang, license FROM players WHERE JSON_EXTRACT(gang, "$.name") = ?', {faccaoId}, function(result)
        if not result then
            TriggerClientEvent('faccoes:client:notify', src, 'Erro ao carregar membros.', 'error')
            return
        end
        
        local membros = {}
        for _, row in ipairs(result) do
            local charinfo = json.decode(row.charinfo) or {}
            local gang = json.decode(row.gang) or {}
            local cargoRaw = nil
            if gang.grade ~= nil then
                if type(gang.grade) == 'table' then
                    cargoRaw = gang.grade.level or gang.grade.grade
                else
                    cargoRaw = gang.grade
                end
            end
            local cargo = tonumber(cargoRaw) or maxCargo
            if cargo < 1 then cargo = maxCargo end
            if cargo > maxCargo then cargo = maxCargo end
            if not faccao.cargos[cargo] then cargo = maxCargo end
            local cargoNome = faccao.cargos[cargo] and faccao.cargos[cargo].nome or ('Cargo ' .. tostring(cargo))
            
            local isOnline = false
            local players = QBCore.Functions.GetQBPlayers()
            for _, p in pairs(players) do
                if p.PlayerData.citizenid == row.citizenid then
                    isOnline = true
                    break
                end
            end
            
            -- Santa: ID exibido = fixed_id (ordem de entrada por license) em todo lugar
            local idExibir = row.citizenid
            if GetResourceState('fixed-ids') == 'started' and row.license and row.license ~= '' then
                local ok, fixedId = pcall(function()
                    return exports['fixed-ids']:GetFixedIDFromLicense(row.license)
                end)
                if ok and fixedId and tonumber(fixedId) then
                    idExibir = tostring(fixedId)
                end
            end
            table.insert(membros, {
                citizenid = row.citizenid,
                nome = (charinfo.firstname or '') .. ' ' .. (charinfo.lastname or ''),
                cargo = cargo,
                cargoNome = cargoNome,
                online = isOnline,
                playtime = 0,
                idExibir = idExibir
            })
        end

        -- Santa: mesclar jogadores online da memória (QB) para painel atualizar na hora ao setar/remover pelo Admin
        local seen = {}
        for _, m in ipairs(membros) do seen[m.citizenid] = true end
        local qbPlayers = QBCore.Functions.GetQBPlayers()
        for _, p in pairs(qbPlayers) do
            if not p or not p.PlayerData then goto continue end
            local g = p.PlayerData.gang and (p.PlayerData.gang.name or '')
            if g ~= faccaoId then goto continue end
            local cid = p.PlayerData.citizenid
            local grade = (p.PlayerData.gang.grade and (p.PlayerData.gang.grade.level or p.PlayerData.gang.grade.grade)) or maxCargo
            grade = tonumber(grade) or maxCargo
            if grade < 1 then grade = maxCargo end
            if grade > maxCargo then grade = maxCargo end
            local cargoNome = faccao.cargos[grade] and faccao.cargos[grade].nome or ('Cargo ' .. tostring(grade))
            local charinfo = p.PlayerData.charinfo or {}
            local nome = (charinfo.firstname or '') .. ' ' .. (charinfo.lastname or '')
            local idExibir = cid
            if GetResourceState('fixed-ids') == 'started' then
                local lic
                for _, id in ipairs(GetPlayerIdentifiers(p.PlayerData.source) or {}) do
                    if id:sub(1, 8) == 'license:' then lic = id break end
                end
                if lic and lic ~= '' then
                    local ok, fixedId = pcall(function() return exports['fixed-ids']:GetFixedIDFromLicense(lic) end)
                    if ok and fixedId and tonumber(fixedId) then idExibir = tostring(fixedId) end
                end
            end
            if seen[cid] then
                for _, m in ipairs(membros) do
                    if m.citizenid == cid then m.cargo = grade; m.cargoNome = cargoNome; m.online = true; break end
                end
            else
                seen[cid] = true
                table.insert(membros, { citizenid = cid, nome = nome, cargo = grade, cargoNome = cargoNome, online = true, playtime = 0, idExibir = idExibir })
            end
            ::continue::
        end

        -- Santa: ordenação idêntica (compareMembers – online primeiro, depois cargo crescente)
        local function compareMembers(a, b)
            if a.online ~= b.online then
                return a.online and not b.online
            else
                return (tonumber(a.cargo) or 99) < (tonumber(b.cargo) or 99)
            end
        end
        table.sort(membros, compareMembers)
        for i, m in ipairs(membros) do
            if not m.idExibir or m.idExibir == '' then m.idExibir = m.citizenid or ('#' .. tostring(i)) end
        end

        -- Santa: paginação 20 por página
        local MEMBROS_POR_PAGINA = 20
        local totalPages = math.ceil(#membros / MEMBROS_POR_PAGINA)
        if totalPages < 1 then totalPages = 1 end

        -- LowRec (Santa: facção abaixo da média de online)
        local currentOnline = 0
        for _, m in ipairs(membros) do if m.online then currentOnline = currentOnline + 1 end end
        local factionOnlineCounts = {}
        local players = QBCore.Functions.GetQBPlayers()
        for _, p in pairs(players) do
            local g = p and p.PlayerData and p.PlayerData.gang and p.PlayerData.gang.name
            if g and Config.Faccoes[g] then
                factionOnlineCounts[g] = (factionOnlineCounts[g] or 0) + 1
            end
        end
        local totalOnline = 0
        local nFac = 0
        for _, c in pairs(factionOnlineCounts) do totalOnline = totalOnline + c; nFac = nFac + 1 end
        local avgOnline = (nFac > 0) and (totalOnline / nFac) or 0
        local lowRec = (avgOnline > 0 and currentOnline < avgOnline)
        local lowRecMessage = lowRec and 'Sua facção está com a média de players <b>abaixo da média</b>' or nil
        
        -- Dados extras padrão (painel abre mesmo sem as tabelas faccoes_*)
        local metaTotal = (Config.MetaDiaria and Config.MetaDiaria.total) or 1000
        local metaPremio = (Config.MetaDiaria and Config.MetaDiaria.premio) or 200000
        local rankingTempo = {}
        for i, m in ipairs(membros) do
            if i <= 10 then
                table.insert(rankingTempo, { pos = i, nome = m.nome, tempo = '0h 0min', playtime = 0 })
            end
        end
        
        local dadosExtras = {
            saldo = 0,
            mensagemLider = faccao.mensagemLider or 'Nenhuma mensagem.',
            discord = faccao.discord,
            regras = faccao.regras,
            rankingFarm = {},
            rankingTempo = rankingTempo,
            meta = { atual = 0, total = metaTotal, premio = metaPremio },
            transacoes = {},
            banidos = {},
            pontosOrganizacao = 0,
            loja = faccao.loja or ((Config.LojaFaccao and Config.LojaFaccao.itensPadrao) or {}),
            lowRec = lowRec,
            lowRecMessage = lowRecMessage,
            analyticsRecrutamento = { ranking = {}, ultimos = {} },
            totalPages = totalPages,
            logEntregas = {}
        }

        -- Santa: enviar cargo do jogador (fonte da verdade no servidor)
        local playerGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
        TriggerClientEvent('faccoes:client:abrirPainelNUI', src, faccaoId, membros, dadosExtras, playerGrade)

        -- Buscar saldo, pontos, mensagem e logs (não bloqueia; se tabelas não existirem, mantém padrão)
        pcall(function()
            GetOrCreateBankBalance(faccaoId, function(bal)
                dadosExtras.saldo = bal

                GetOrCreateOrgPoints(faccaoId, function(pts)
                    dadosExtras.pontosOrganizacao = pts

                    -- Santa: meta diária por facção (total, premio, valor por entrega) + meta atual = soma entregas do dia
                    MySQL.Async.fetchAll('SELECT total, premio, valor_por_entrega FROM faccoes_meta WHERE faccao = ?', {faccaoId}, function(metaRow)
                        local metaTotal = (Config.MetaDiaria and Config.MetaDiaria.total) or 1000
                        local metaPremio = (Config.MetaDiaria and Config.MetaDiaria.premio) or 200000
                        local valorPorEntrega = (Config.MetaDiaria and Config.MetaDiaria.valorPorEntrega) or 2000
                        if metaRow and metaRow[1] then
                            metaTotal = tonumber(metaRow[1].total) or metaTotal
                            metaPremio = tonumber(metaRow[1].premio) or metaPremio
                            valorPorEntrega = tonumber(metaRow[1].valor_por_entrega) or valorPorEntrega
                        end
                        MySQL.Async.fetchScalar('SELECT COALESCE(SUM(quantidade), 0) FROM faccoes_entregas WHERE faccao = ? AND dia = CURDATE()', {faccaoId}, function(metaAtual)
                            dadosExtras.meta = {
                                atual = tonumber(metaAtual) or 0,
                                total = metaTotal,
                                premio = metaPremio,
                                valorPorEntrega = valorPorEntrega
                            }
                            local function carregarLogsBancoEBanidos()
                        MySQL.Async.fetchAll('SELECT id, citizenid, nome, tipo, descricao, valor, created_at FROM faccoes_bank_transactions WHERE faccao = ? ORDER BY created_at DESC LIMIT 30', {faccaoId}, function(transResult)
                            if transResult then
                                for _, row in ipairs(transResult) do
                                    local dataStr = '—'
                                    if row.created_at then
                                        if type(row.created_at) == 'string' then
                                            dataStr = row.created_at:sub(1, 16):gsub('(%d+)-(%d+)-(%d+)', '%3/%2/%1'):gsub('T', ' – ')
                                        else
                                            dataStr = os.date('%d/%m – %Hh:%M', row.created_at)
                                        end
                                    end
                                    table.insert(dadosExtras.transacoes, {
                                        id = row.id,
                                        nome = row.nome,
                                        tipo = row.tipo,
                                        descricao = row.descricao or (row.tipo == 'entrada' and 'Depósito' or 'Saque'),
                                        valor = row.valor,
                                        data = dataStr
                                    })
                                end
                            end
                            local banResult = {}
                            pcall(function()
                                if MySQL and MySQL.query and MySQL.query.await then
                                    banResult = MySQL.query.await('SELECT id, id_lider, nome_lider, citizenid_membro, nome_membro, motivo, created_at FROM faccoes_banidos WHERE faccao = ? ORDER BY created_at DESC LIMIT 100', {faccaoId}) or {}
                                end
                            end)
                            if banResult then
                                for _, row in ipairs(banResult) do
                                    local created = row.created_at
                                    if type(created) == 'string' then created = created:sub(1, 16):gsub('T', ' ') else created = '—' end
                                    table.insert(dadosExtras.banidos, {
                                        id = row.id,
                                        idLider = tostring(row.id_lider),
                                        nomeLider = row.nome_lider,
                                        idMembro = row.citizenid_membro,
                                        nomeMembro = row.nome_membro,
                                        data = created,
                                        motivo = row.motivo
                                    })
                                end
                            end
                            -- Ranking e log de entregas de farm (Santa: quando entregam, aparece no painel)
                            MySQL.Async.fetchAll([[
                                SELECT e.citizenid, SUM(e.quantidade) as total
                                FROM faccoes_entregas e
                                WHERE e.faccao = ?
                                GROUP BY e.citizenid
                                ORDER BY total DESC
                                LIMIT 30
                            ]], {faccaoId}, function(rankResult)
                                if rankResult and #rankResult > 0 then
                                    for i, row in ipairs(rankResult) do
                                        local nome = '—'
                                        for _, m in ipairs(membros) do
                                            if m.citizenid == row.citizenid then nome = m.nome break end
                                        end
                                        table.insert(dadosExtras.rankingFarm, {
                                            pos = i,
                                            nome = nome,
                                            quantidade = tonumber(row.total) or 0,
                                            total = tonumber(row.total) or 0
                                        })
                                    end
                                end
                                MySQL.Async.fetchAll('SELECT e.citizenid, e.quantidade, e.created_at FROM faccoes_entregas e WHERE e.faccao = ? ORDER BY e.created_at DESC LIMIT 50', {faccaoId}, function(logResult)
                                    if logResult then
                                        for _, row in ipairs(logResult) do
                                            local nome = '—'
                                            for _, m in ipairs(membros) do
                                                if m.citizenid == row.citizenid then nome = m.nome break end
                                            end
                                            local dataStr = '—'
                                            if row.created_at then
                                                if type(row.created_at) == 'string' then
                                                    dataStr = row.created_at:sub(1, 16):gsub('T', ' ')
                                                else
                                                    dataStr = os.date('%d/%m %H:%M', row.created_at)
                                                end
                                            end
                                            table.insert(dadosExtras.logEntregas, { data = dataStr, player = nome, itens = tostring(row.quantidade or 0) })
                                        end
                                    end
                                    -- Analytics de recrutamento (prioridade 3)
                                    MySQL.Async.fetchAll('SELECT recruiter_nome, recruited_nome, created_at FROM faccoes_recrutamentos WHERE faccao = ? ORDER BY created_at DESC LIMIT 100', {faccaoId}, function(recResult)
                                if recResult and #recResult > 0 then
                                    local now = os.time()
                                    local oneDay = 24 * 60 * 60
                                    local threeDays = 3 * oneDay
                                    local byRecruiter = {}
                                    for _, row in ipairs(recResult) do
                                        local rec = row.recruiter_nome or '—'
                                        if not byRecruiter[rec] then
                                            byRecruiter[rec] = { total = 0, umDia = 0, tresDias = 0 }
                                        end
                                        byRecruiter[rec].total = byRecruiter[rec].total + 1
                                        local ts = row.created_at
                                        if type(ts) == 'string' then
                                            ts = os.time({ year = tonumber(ts:sub(1,4)) or 0, month = tonumber(ts:sub(6,7)) or 0, day = tonumber(ts:sub(9,10)) or 0, hour = tonumber(ts:sub(12,13)) or 0, min = tonumber(ts:sub(15,16)) or 0, sec = tonumber(ts:sub(18,19)) or 0 })
                                        end
                                        if ts and (now - ts) <= oneDay then byRecruiter[rec].umDia = byRecruiter[rec].umDia + 1 end
                                        if ts and (now - ts) <= threeDays then byRecruiter[rec].tresDias = byRecruiter[rec].tresDias + 1 end
                                    end
                                    local ranking = {}
                                    for nome, t in pairs(byRecruiter) do
                                        table.insert(ranking, { recrutador = nome, total = t.total, umDia = t.umDia, tresDias = t.tresDias })
                                    end
                                    table.sort(ranking, function(a, b) return (a.total or 0) > (b.total or 0) end)
                                    dadosExtras.analyticsRecrutamento.ranking = ranking
                                    local ultimos = {}
                                    for i = 1, math.min(10, #recResult) do
                                        local row = recResult[i]
                                        local dataStr = '—'
                                        if row.created_at then
                                            if type(row.created_at) == 'string' then
                                                dataStr = row.created_at:sub(1, 16):gsub('(%d+)-(%d+)-(%d+)', '%3/%2/%1'):gsub('T', ' ')
                                            else
                                                dataStr = os.date('%d/%m %H:%M', row.created_at)
                                            end
                                        end
                                        table.insert(ultimos, { data = dataStr, recrutador = row.recruiter_nome or '—', recrutado = row.recruited_nome or '—' })
                                    end
                                    dadosExtras.analyticsRecrutamento.ultimos = ultimos
                                end
                                TriggerClientEvent('faccoes:client:atualizarDadosExtras', src, dadosExtras)
                            end)
                                    end)
                                end)
                            end)
                        end
                        carregarLogsBancoEBanidos()
                        end)
                    end)

                    -- Mensagem do líder (última no banco; falha silenciosa se tabela ainda não existir)
                    local content = nil
                    pcall(function()
                        if MySQL and MySQL.scalar and MySQL.scalar.await then
                            content = MySQL.scalar.await('SELECT content FROM faccoes_messages WHERE faccao = ? ORDER BY id DESC LIMIT 1', {faccaoId})
                        end
                    end)
                    if content and content ~= '' then
                        dadosExtras.mensagemLider = content
                    end
                end)
            end)
        end)
    end)
    end

    if playerFaction == faccaoId then
        doGetMembros()
        return
    end
    MySQL.Async.fetchScalar('SELECT gang FROM players WHERE citizenid = ?', { citizenid }, function(gangJson)
        local ok, gang = pcall(json.decode, gangJson or '{}')
        local name = (ok and gang and gang.name) and string.lower(tostring(gang.name)) or nil
        if name == faccaoId and Config.Faccoes[name] then
            doGetMembros()
            return
        end
        TriggerClientEvent('faccoes:client:notify', src, 'Você não pertence a esta facção!', 'error')
    end)
end)

-- Envia só a lista de membros para o cliente atualizar o painel na hora (Santa: atualização instantânea)
local function EnviarListaMembrosParaCliente(src, faccaoId)
    local faccao = Config.Faccoes[faccaoId]
    if not faccao then return end
    local maxCargo = GetMaxCargoForFaccao(faccao)
    MySQL.Async.fetchAll('SELECT citizenid, charinfo, gang, license FROM players WHERE JSON_EXTRACT(gang, "$.name") = ?', {faccaoId}, function(result)
        if not result then return end
        local membros = {}
        for _, row in ipairs(result) do
            local charinfo = json.decode(row.charinfo) or {}
            local gang = json.decode(row.gang) or {}
            local cargoRaw = nil
            if gang.grade ~= nil then
                if type(gang.grade) == 'table' then
                    cargoRaw = gang.grade.level or gang.grade.grade
                else
                    cargoRaw = gang.grade
                end
            end
            local cargo = tonumber(cargoRaw) or maxCargo
            if cargo < 1 then cargo = maxCargo end
            if cargo > maxCargo then cargo = maxCargo end
            if not faccao.cargos[cargo] then cargo = maxCargo end
            local cargoNome = faccao.cargos[cargo] and faccao.cargos[cargo].nome or ('Cargo ' .. tostring(cargo))
            local isOnline = false
            local players = QBCore.Functions.GetQBPlayers()
            for _, p in pairs(players) do
                if p.PlayerData.citizenid == row.citizenid then isOnline = true break end
            end
            local idExibir = row.citizenid
            if GetResourceState('fixed-ids') == 'started' and row.license and row.license ~= '' then
                local ok, fixedId = pcall(function() return exports['fixed-ids']:GetFixedIDFromLicense(row.license) end)
                if ok and fixedId and tonumber(fixedId) then idExibir = tostring(fixedId) end
            end
            table.insert(membros, {
                citizenid = row.citizenid,
                nome = (charinfo.firstname or '') .. ' ' .. (charinfo.lastname or ''),
                cargo = cargo,
                cargoNome = cargoNome,
                online = isOnline,
                playtime = 0,
                idExibir = idExibir
            })
        end
        -- Incluir jogadores online com essa gang que ainda não estão no DB (ex: recém recrutado)
        local seen = {}
        for _, m in ipairs(membros) do seen[m.citizenid] = true end
        local players = QBCore.Functions.GetQBPlayers()
        for _, p in pairs(players) do
            if p and p.PlayerData and p.PlayerData.gang and (p.PlayerData.gang.name or '') == faccaoId and not seen[p.PlayerData.citizenid] then
                seen[p.PlayerData.citizenid] = true
                local grade = (p.PlayerData.gang.grade and p.PlayerData.gang.grade.level) or maxCargo
                grade = tonumber(grade) or maxCargo
                if grade < 1 then grade = maxCargo end
                if grade > maxCargo then grade = maxCargo end
                local cargoNome = faccao.cargos[grade] and faccao.cargos[grade].nome or ('Cargo ' .. tostring(grade))
                local charinfo = p.PlayerData.charinfo or {}
                local nome = (charinfo.firstname or '') .. ' ' .. (charinfo.lastname or '')
                local idExibir = p.PlayerData.citizenid
                if GetResourceState('fixed-ids') == 'started' then
                    local lic = nil
                    for _, id in ipairs(GetPlayerIdentifiers(p.PlayerData.source) or {}) do
                        if id:sub(1, 8) == 'license:' then lic = id break end
                    end
                    if lic and lic ~= '' then
                        local ok, fixedId = pcall(function() return exports['fixed-ids']:GetFixedIDFromLicense(lic) end)
                        if ok and fixedId and tonumber(fixedId) then idExibir = tostring(fixedId) end
                    end
                end
                table.insert(membros, {
                    citizenid = p.PlayerData.citizenid,
                    nome = nome,
                    cargo = grade,
                    cargoNome = cargoNome,
                    online = true,
                    playtime = 0,
                    idExibir = idExibir
                })
            end
        end
        table.sort(membros, function(a, b) return a.cargo < b.cargo end)
        for i, m in ipairs(membros) do
            if not m.idExibir or m.idExibir == '' then m.idExibir = m.citizenid or ('#' .. tostring(i)) end
        end
        TriggerClientEvent('faccoes:client:atualizarListaMembros', src, membros)
    end)
end

-- Resolve ID do membro (ID fixo/Passport ou citizenid) para citizenid (para ações do painel)
local function ResolverIdMembroParaCitizenId(memberId)
    if memberId == nil then return nil end
    local s = (type(memberId) == 'string') and memberId:match('^%s*(.-)%s*$') or tostring(memberId)
    if s == '' then return nil end
    local num = tonumber(s)
    if num and num > 0 and GetResourceState('fixed-ids') == 'started' then
        local ok, cid = pcall(function() return exports['fixed-ids']:GetCitizenIdFromPassportId(num) end)
        if ok and cid and cid ~= '' then return cid end
    end
    return s
end

-- ============================================================================
-- PAINEL - ALTERAR CARGO (dropdown na tabela de membros)
-- ============================================================================
RegisterNetEvent('faccoes:server:alterarCargo', function(targetCitizenId, novoCargo)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local playerFaction = GetPlayerFaction(src)
    local faccao = Config.Faccoes[playerFaction]
    if not faccao then return end

    targetCitizenId = ResolverIdMembroParaCitizenId(targetCitizenId)
    if not targetCitizenId or targetCitizenId == '' then
        TriggerClientEvent('faccoes:client:notify', src, 'Membro não encontrado.', 'error')
        return
    end

    local playerGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
    local maxCargo = GetMaxCargoForFaccao(faccao)
    if not HasCargoPermissao(playerFaction, playerGrade, 'gerenciar_membros') then
        TriggerClientEvent('faccoes:client:notify', src, 'Sem permissão para alterar cargos.', 'error')
        return
    end

    novoCargo = tonumber(novoCargo)
    if not novoCargo or novoCargo < 1 or novoCargo > maxCargo then return end
    if novoCargo <= playerGrade then
        TriggerClientEvent('faccoes:client:notify', src, 'Não pode definir cargo igual ou superior ao seu.', 'error')
        return
    end

    local TargetPlayer = QBCore.Functions.GetPlayerByCitizenId(targetCitizenId)
    if TargetPlayer then
        TargetPlayer.Functions.SetGang(playerFaction, novoCargo)
        PersistirGangNoDB(TargetPlayer.PlayerData.citizenid, TargetPlayer.PlayerData.gang, function()
            TriggerClientEvent('faccoes:client:notify', TargetPlayer.PlayerData.source, 'Seu cargo foi alterado para ' .. (faccao.cargos[novoCargo] and faccao.cargos[novoCargo].nome or novoCargo) .. '.', 'success')
            TriggerClientEvent('faccoes:client:notify', src, 'Cargo alterado.', 'success')
            EnviarListaMembrosParaCliente(src, playerFaction)
        end)
    else
        MySQL.Async.execute('UPDATE players SET gang = JSON_SET(gang, "$.grade.level", ?, "$.grade.name", ?) WHERE citizenid = ? AND JSON_EXTRACT(gang, "$.name") = ?',
            {novoCargo, (faccao.cargos[novoCargo] and faccao.cargos[novoCargo].nome or 'Cargo'), targetCitizenId, playerFaction}, function()
                TriggerClientEvent('faccoes:client:notify', src, 'Cargo alterado.', 'success')
                EnviarListaMembrosParaCliente(src, playerFaction)
            end)
    end
end)

-- ============================================================================
-- PAINEL - PROMOVER MEMBRO
-- ============================================================================
RegisterNetEvent('faccoes:server:promoverMembro', function(targetCitizenId, novoCargo)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local playerFaction = GetPlayerFaction(src)
    local faccao = Config.Faccoes[playerFaction]
    if not faccao then return end

    targetCitizenId = ResolverIdMembroParaCitizenId(targetCitizenId)
    if not targetCitizenId or targetCitizenId == '' then
        TriggerClientEvent('faccoes:client:notify', src, 'Membro não encontrado.', 'error')
        return
    end

    local playerGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
    local maxCargo = GetMaxCargoForFaccao(faccao)
    if not HasCargoPermissao(playerFaction, playerGrade, 'gerenciar_membros') then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não tem permissão para gerenciar membros!', 'error')
        return
    end

    novoCargo = tonumber(novoCargo)
    if not novoCargo or novoCargo < 1 or novoCargo > maxCargo then
        TriggerClientEvent('faccoes:client:notify', src, 'Cargo inválido.', 'error')
        return
    end

    if novoCargo <= playerGrade then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não pode promover alguém para um cargo igual ou superior ao seu!', 'error')
        return
    end

    local TargetPlayer = QBCore.Functions.GetPlayerByCitizenId(targetCitizenId)
    local targetGrade = maxCargo
    if TargetPlayer and TargetPlayer.PlayerData.gang then
        targetGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(TargetPlayer.PlayerData.gang)))
    end
    if not SantaPodePromover(playerGrade, targetGrade, novoCargo) then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não pode promover este membro a esse cargo (regras da organização).', 'error')
        return
    end
    
    if TargetPlayer then
        -- Jogador online
        TargetPlayer.Functions.SetGang(playerFaction, novoCargo)
        PersistirGangNoDB(TargetPlayer.PlayerData.citizenid, TargetPlayer.PlayerData.gang, function()
            TriggerClientEvent('faccoes:client:notify', TargetPlayer.PlayerData.source, 'Você foi promovido para ' .. faccao.cargos[novoCargo].nome .. '!', 'success')
            TriggerClientEvent('faccoes:client:notify', src, 'Membro promovido com sucesso!', 'success')
            EnviarListaMembrosParaCliente(src, playerFaction)
            if DEBUG then print(string.format('[FACCOES] %s promoveu %s para cargo %d na facção %s',
                Player.PlayerData.charinfo.firstname, targetCitizenId, novoCargo, playerFaction)) end
        end)
    else
        -- Jogador offline - atualizar no banco
        MySQL.Async.execute('UPDATE players SET gang = JSON_SET(gang, "$.grade.level", ?, "$.grade.name", ?) WHERE citizenid = ?',
            {novoCargo, faccao.cargos[novoCargo].nome, targetCitizenId}, function()
                TriggerClientEvent('faccoes:client:notify', src, 'Membro promovido com sucesso!', 'success')
                EnviarListaMembrosParaCliente(src, playerFaction)
                if DEBUG then print(string.format('[FACCOES] %s promoveu %s para cargo %d na facção %s',
                    Player.PlayerData.charinfo.firstname, targetCitizenId, novoCargo, playerFaction)) end
            end)
    end
end)

-- ============================================================================
-- PAINEL - REBAIXAR MEMBRO
-- ============================================================================
RegisterNetEvent('faccoes:server:rebaixarMembro', function(targetCitizenId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local playerFaction = GetPlayerFaction(src)
    local faccao = Config.Faccoes[playerFaction]
    if not faccao then return end

    targetCitizenId = ResolverIdMembroParaCitizenId(targetCitizenId)
    if not targetCitizenId or targetCitizenId == '' then
        TriggerClientEvent('faccoes:client:notify', src, 'Membro não encontrado.', 'error')
        return
    end

    local maxCargo = GetMaxCargoForFaccao(faccao)
    local playerGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
    if not HasCargoPermissao(playerFaction, playerGrade, 'gerenciar_membros') then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não tem permissão para gerenciar membros!', 'error')
        return
    end
    if not SantaPodeRebaixar(playerGrade) then
        TriggerClientEvent('faccoes:client:notify', src, 'Apenas Chefe ou Sub-Chefe podem rebaixar.', 'error')
        return
    end

    MySQL.Async.fetchScalar('SELECT gang FROM players WHERE citizenid = ?', {targetCitizenId}, function(gangData)
        if not gangData then return end
        
        local gang = json.decode(gangData)
        local cargoAtualRaw = nil
        if gang and gang.grade ~= nil then
            if type(gang.grade) == 'table' then
                cargoAtualRaw = gang.grade.level or gang.grade.grade
            else
                cargoAtualRaw = gang.grade
            end
        end
        local cargoAtual = tonumber(cargoAtualRaw) or maxCargo
        if cargoAtual < 1 then cargoAtual = maxCargo end
        if cargoAtual > maxCargo then cargoAtual = maxCargo end
        if not faccao.cargos[cargoAtual] then cargoAtual = maxCargo end
        
        -- Não pode rebaixar alguém de cargo igual ou superior
        if cargoAtual <= playerGrade then
            TriggerClientEvent('faccoes:client:notify', src, 'Você não pode rebaixar alguém de cargo igual ou superior!', 'error')
            return
        end
        
        local novoCargo = math.min(cargoAtual + 1, maxCargo)
        
        local TargetPlayer = QBCore.Functions.GetPlayerByCitizenId(targetCitizenId)
        
        if TargetPlayer then
            TargetPlayer.Functions.SetGang(playerFaction, novoCargo)
            PersistirGangNoDB(TargetPlayer.PlayerData.citizenid, TargetPlayer.PlayerData.gang, function()
                TriggerClientEvent('faccoes:client:notify', TargetPlayer.PlayerData.source, 'Você foi rebaixado para ' .. faccao.cargos[novoCargo].nome .. '!', 'error')
                TriggerClientEvent('faccoes:client:notify', src, 'Membro rebaixado com sucesso!', 'success')
                EnviarListaMembrosParaCliente(src, playerFaction)
                if DEBUG then print(string.format('[FACCOES] %s rebaixou %s para cargo %d na facção %s',
                    Player.PlayerData.charinfo.firstname, targetCitizenId, novoCargo, playerFaction)) end
            end)
        else
            MySQL.Async.execute('UPDATE players SET gang = JSON_SET(gang, "$.grade.level", ?, "$.grade.name", ?) WHERE citizenid = ?',
                {novoCargo, faccao.cargos[novoCargo].nome, targetCitizenId}, function()
                    TriggerClientEvent('faccoes:client:notify', src, 'Membro rebaixado com sucesso!', 'success')
                    EnviarListaMembrosParaCliente(src, playerFaction)
                    if DEBUG then print(string.format('[FACCOES] %s rebaixou %s para cargo %d na facção %s',
                        Player.PlayerData.charinfo.firstname, targetCitizenId, novoCargo, playerFaction)) end
                end)
        end
    end)
end)

-- ============================================================================
-- PAINEL - EXPULSAR MEMBRO
-- ============================================================================
-- ============================================================================
-- PAINEL - RECRUTAR POR ID (SANTA: Passport numérico ou citizenid)
-- ============================================================================
RegisterNetEvent('faccoes:server:recrutarPorId', function(targetCitizenId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    
    local playerFaction = GetPlayerFaction(src)
    local faccao = Config.Faccoes[playerFaction]
    if not faccao then return end

    local playerGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
    local maxCargo = GetMaxCargoForFaccao(faccao)
    if not HasCargoPermissaoAny(playerFaction, playerGrade, {'all', 'gerenciar_membros', 'recrutar'}) then
        TriggerClientEvent('faccoes:client:notify', src, 'Sem permissão para recrutar.', 'error')
        return
    end
    if not SantaPodeRecrutar(playerGrade) then
        TriggerClientEvent('faccoes:client:notify', src, 'Apenas até cargo 4 (Membro) pode recrutar.', 'error')
        return
    end
    
    local id = (type(targetCitizenId) == 'string') and targetCitizenId:match('^%s*(.-)%s*$') or tostring(targetCitizenId or '')
    if id == '' then
        TriggerClientEvent('faccoes:client:notify', src, 'Informe o ID (Passport/Server ID) ou Citizen ID do jogador.', 'error')
        return
    end
    
    local numId = tonumber(id)
    local TargetPlayer = nil

    -- Painel da organização: ID da tabela é Passport (ID fixo). Número alto = Passport primeiro; número baixo = pode ser Server ID.
    if numId and numId > 0 then
        -- 1) Se for número alto (típico Passport/ID fixo): tentar Passport primeiro
        if numId > 32 and GetResourceState('fixed-ids') == 'started' then
            local ok, cid = pcall(function()
                return exports['fixed-ids']:GetCitizenIdFromPassportId(numId)
            end)
            if ok and cid and cid ~= '' then
                TargetPlayer = QBCore.Functions.GetPlayerByCitizenId(cid)
            end
        end
        -- 2) Se não achou: tentar como Server ID (source 1-32 etc.)
        if not TargetPlayer then
            TargetPlayer = QBCore.Functions.GetPlayer(numId)
        end
        -- 3) Se ainda não achou e é número: tentar Passport (para numId <= 32)
        if not TargetPlayer and GetResourceState('fixed-ids') == 'started' then
            local ok, cid = pcall(function()
                return exports['fixed-ids']:GetCitizenIdFromPassportId(numId)
            end)
            if ok and cid and cid ~= '' then
                TargetPlayer = QBCore.Functions.GetPlayerByCitizenId(cid)
            end
        end
    end

    -- 4) Tentar como Citizen ID (string)
    if not TargetPlayer then
        TargetPlayer = QBCore.Functions.GetPlayerByCitizenId(id)
    end

    if not TargetPlayer then
        TriggerClientEvent('faccoes:client:notify', src, 'Jogador não encontrado. Digite o Passport/ID do jogador (ele precisa estar online e sem facção).', 'error')
        return
    end

    -- Santa: considerar "sem facção" = gang none / no gang / vazio / ou não está em Config.Faccoes
    local targetGangName = (TargetPlayer.PlayerData.gang and TargetPlayer.PlayerData.gang.name) and string.lower(tostring(TargetPlayer.PlayerData.gang.name):match('^%s*(.-)%s*$')) or ''
    local semFaccao = (targetGangName == '' or targetGangName == 'none' or targetGangName == 'no gang' or targetGangName == 'no gang affiliation')
        or not Config.Faccoes[targetGangName]
    if not semFaccao then
        TriggerClientEvent('faccoes:client:notify', src, 'O jogador precisa estar sem facção para ser recrutado.', 'error')
        return
    end

    if not faccao.cargos[maxCargo] then return end

    -- Santa: enviar convite; só recruta quando o alvo aceitar
    local nomeRecrutador = (Player.PlayerData.charinfo and (Player.PlayerData.charinfo.firstname or '') .. ' ' .. (Player.PlayerData.charinfo.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    if nomeRecrutador == '' then nomeRecrutador = 'Facção' end

    local targetSrc = TargetPlayer.PlayerData.source
    ConvitesPendentes[targetSrc] = {
        faccaoId = playerFaction,
        recruiterSrc = src,
        recruiterNome = nomeRecrutador,
        expiresAt = os.time() + CONVITE_EXPIRA_SEG
    }
    TriggerClientEvent('faccoes:client:receberConvite', targetSrc, faccao.nome, nomeRecrutador)
    TriggerClientEvent('faccoes:client:notify', src, 'Convite enviado! O jogador pode aceitar ou recusar.', 'success')
end)

-- ============================================================================
-- RECRUTAR POR ID (AGENTE/ADMIN) – mesma lógica Santa: enviar convite
-- ============================================================================
RegisterNetEvent('faccoes:server:recrutarPorIdAgente', function(targetSource, faccaoId)
    local src = source
    local okAdmin = false
    pcall(function()
        if GetResourceState('admin-system') == 'started' and exports['admin-system'] and exports['admin-system'].HasAdminLevel then
            okAdmin = exports['admin-system']:HasAdminLevel(src, 1)
        end
    end)
    if not okAdmin then
        TriggerClientEvent('faccoes:client:notify', src, 'Sem permissão para recrutar como agente.', 'error')
        return
    end

    local faccao = Config.Faccoes[faccaoId]
    if not faccao then
        TriggerClientEvent('faccoes:client:notify', src, 'Facção inválida.', 'error')
        return
    end

    local targetId = tonumber(targetSource)
    local TargetPlayer = targetId and QBCore.Functions.GetPlayer(targetId) or nil
    if not TargetPlayer then
        TriggerClientEvent('faccoes:client:notify', src, 'Jogador não encontrado (precisa estar online).', 'error')
        return
    end

    local targetFaction = GetPlayerFaction(TargetPlayer.PlayerData.source)
    if targetFaction ~= 'none' then
        TriggerClientEvent('faccoes:client:notify', src, 'O jogador precisa estar sem facção para ser recrutado.', 'error')
        return
    end

    local maxCargo = GetMaxCargoForFaccao(faccao)
    if not faccao.cargos[maxCargo] then return end

    -- Santa: enviar convite; só recruta quando o alvo aceitar
    local AdminPlayer = QBCore.Functions.GetPlayer(src)
    local nomeRecrutador = 'Administração'
    if AdminPlayer and AdminPlayer.PlayerData and AdminPlayer.PlayerData.charinfo then
        nomeRecrutador = (AdminPlayer.PlayerData.charinfo.firstname or '') .. ' ' .. (AdminPlayer.PlayerData.charinfo.lastname or '')
        nomeRecrutador = nomeRecrutador:gsub('^%s+', ''):gsub('%s+$', '')
        if nomeRecrutador == '' then nomeRecrutador = 'Administração' end
    end

    local targetSrc = TargetPlayer.PlayerData.source
    ConvitesPendentes[targetSrc] = {
        faccaoId = faccaoId,
        recruiterSrc = src,
        recruiterNome = nomeRecrutador,
        expiresAt = os.time() + CONVITE_EXPIRA_SEG
    }
    TriggerClientEvent('faccoes:client:receberConvite', targetSrc, faccao.nome, nomeRecrutador)
    TriggerClientEvent('faccoes:client:notify', src, 'Convite enviado! O jogador pode aceitar ou recusar.', 'success')
end)

-- ============================================================================
-- SANTA: ACEITAR CONVITE (alvo aceitou; aplicar recrutamento + notificações + pontos)
-- ============================================================================
RegisterNetEvent('faccoes:server:aceitarConvite', function()
    local src = source
    local convite = ConvitesPendentes[src]
    if not convite or os.time() > convite.expiresAt then
        ConvitesPendentes[src] = nil
        TriggerClientEvent('faccoes:client:notify', src, 'Convite expirado ou inválido.', 'error')
        return
    end

    local faccaoId = convite.faccaoId
    local recruiterSrc = convite.recruiterSrc
    local faccao = Config.Faccoes[faccaoId]
    ConvitesPendentes[src] = nil

    if not faccao then
        TriggerClientEvent('faccoes:client:notify', src, 'Facção não encontrada.', 'error')
        return
    end

    local TargetPlayer = QBCore.Functions.GetPlayer(src)
    if not TargetPlayer then return end
    -- Santa: checar GANG apenas (não GetPlayerFaction, que retorna job quando não tem gang)
    local gangName = (TargetPlayer.PlayerData.gang and TargetPlayer.PlayerData.gang.name) and string.lower(tostring(TargetPlayer.PlayerData.gang.name)) or 'none'
    if gangName ~= '' and gangName ~= 'none' and Config.Faccoes[gangName] then
        TriggerClientEvent('faccoes:client:notify', src, 'Você já pertence a uma facção.', 'error')
        return
    end

    local maxCargo = GetMaxCargoForFaccao(faccao)
    if not faccao.cargos[maxCargo] then return end

    -- Usar cargo que existe em QBCore.Shared.Gangs (igual qb-adminmenu) para não conflitar
    local gradeParaSetGang = maxCargo
    if QBCore.Shared and QBCore.Shared.Gangs and QBCore.Shared.Gangs[faccaoId] and QBCore.Shared.Gangs[faccaoId].grades then
        if not QBCore.Shared.Gangs[faccaoId].grades[tostring(maxCargo)] then
            local maxShared = 0
            for k in pairs(QBCore.Shared.Gangs[faccaoId].grades) do
                local n = tonumber(k)
                if n and n > maxShared then maxShared = n end
            end
            gradeParaSetGang = (maxShared > 0) and maxShared or 0
        end
    end

    local ok = TargetPlayer.Functions.SetGang(faccaoId, gradeParaSetGang)
    if not ok then
        TriggerClientEvent('faccoes:client:notify', src, 'Erro ao entrar na facção. Tente novamente.', 'error')
        return
    end
    TriggerClientEvent('faccoes:client:notify', src, 'Você entrou em ' .. faccao.nome .. '!', 'success')
    if recruiterSrc and GetPlayerPing(recruiterSrc) > 0 then
        TriggerClientEvent('faccoes:client:notify', recruiterSrc, 'O jogador aceitou o convite!', 'success')
        EnviarListaMembrosParaCliente(recruiterSrc, faccaoId)
    end

    -- Popup estilo Santa (convite aceito)
    if GetResourceState('notify') == 'started' then
        TriggerClientEvent('notify:CustomRecruit', src,
            'Convite aceito',
            'Você foi convidado para ' .. faccao.nome .. ' por ' .. (convite.recruiterNome or '') .. '. Bem-vindo!',
            convite.recruiterNome or faccao.nome,
            5000,
            vector3(0, 0, 0),
            faccao.nome,
            convite.recruiterNome or ''
        )
    end

    local pts = (Config.PontosFaccao and tonumber(Config.PontosFaccao.pontosPorRecrutamentoIniciante)) or 0
    if (Config.PontosFaccao and Config.PontosFaccao.habilitado) and pts > 0 then
        AddOrgPoints(faccaoId, pts)
        if recruiterSrc and GetPlayerPing(recruiterSrc) > 0 then
            TriggerClientEvent('faccoes:client:notify', recruiterSrc, 'Sua organização ganhou +' .. pts .. ' pontos por recrutar um iniciante.', 'success')
        end
    end

    -- Analytics de recrutamento: registrar na tabela faccoes_recrutamentos
    local recruiterCitizenid = ''
    local recruiterNome = convite.recruiterNome or 'Recrutador'
    if recruiterSrc and GetPlayerPing(recruiterSrc) > 0 then
        local RecruiterPlayer = QBCore.Functions.GetPlayer(recruiterSrc)
        if RecruiterPlayer and RecruiterPlayer.PlayerData then
            recruiterCitizenid = RecruiterPlayer.PlayerData.citizenid or ''
            local ci = RecruiterPlayer.PlayerData.charinfo or {}
            recruiterNome = (ci.firstname or '') .. ' ' .. (ci.lastname or '')
            if recruiterNome:match('^%s*$') then recruiterNome = convite.recruiterNome or 'Recrutador' end
        end
    end
    local recruitedNome = (TargetPlayer.PlayerData.charinfo and (TargetPlayer.PlayerData.charinfo.firstname or '') .. ' ' .. (TargetPlayer.PlayerData.charinfo.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    if recruitedNome == '' then recruitedNome = TargetPlayer.PlayerData.citizenid or '' end
    MySQL.Async.execute('INSERT INTO faccoes_recrutamentos (faccao, recruiter_citizenid, recruiter_nome, recruited_citizenid, recruited_nome) VALUES (?, ?, ?, ?, ?)', {
        faccaoId, recruiterCitizenid, recruiterNome, TargetPlayer.PlayerData.citizenid, recruitedNome
    }, function() end)

    PersistirGangNoDB(TargetPlayer.PlayerData.citizenid, TargetPlayer.PlayerData.gang, function() end)
end)

-- ============================================================================
-- SANTA: RECUSAR CONVITE
-- ============================================================================
RegisterNetEvent('faccoes:server:recusarConvite', function()
    local src = source
    local convite = ConvitesPendentes[src]
    ConvitesPendentes[src] = nil
    if convite and convite.recruiterSrc and GetPlayerPing(convite.recruiterSrc) > 0 then
        TriggerClientEvent('faccoes:client:notify', convite.recruiterSrc, 'O jogador recusou o convite.', 'error')
    end
    TriggerClientEvent('faccoes:client:notify', src, 'Você recusou o convite.', 'primary')
end)

AddEventHandler('playerDropped', function()
    local src = source
    ConvitesPendentes[src] = nil
end)

-- ============================================================================
-- PAINEL - REMOVER BANIDO (desbanir)
-- ============================================================================
RegisterNetEvent('faccoes:server:removerBanido', function(idBanido)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    
    local playerFaction = GetPlayerFaction(src)
    local faccao = Config.Faccoes[playerFaction]
    if not faccao then return end
    
    local playerGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
    if not HasCargoPermissao(playerFaction, playerGrade, 'gerenciar_membros') then
        TriggerClientEvent('faccoes:client:notify', src, 'Sem permissão para remover ban.', 'error')
        return
    end
    
    local id = tonumber(idBanido)
    if not id then return end
    
    MySQL.Async.execute('DELETE FROM faccoes_banidos WHERE id = ? AND faccao = ?', {id, playerFaction}, function(affected)
        if affected and affected > 0 then
            TriggerClientEvent('faccoes:client:notify', src, 'Ban removido.', 'success')
            TriggerClientEvent('faccoes:client:atualizarPainel', src)
        end
    end)
end)

RegisterNetEvent('faccoes:server:expulsarMembro', function(targetCitizenId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local playerFaction = GetPlayerFaction(src)
    local faccao = Config.Faccoes[playerFaction]
    if not faccao then return end

    targetCitizenId = ResolverIdMembroParaCitizenId(targetCitizenId)
    if not targetCitizenId or targetCitizenId == '' then
        TriggerClientEvent('faccoes:client:notify', src, 'Membro não encontrado.', 'error')
        return
    end

    local playerGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
    local maxCargo = GetMaxCargoForFaccao(faccao)
    if not HasCargoPermissao(playerFaction, playerGrade, 'gerenciar_membros') then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não tem permissão para expulsar membros!', 'error')
        return
    end
    if not SantaPodeExpulsar(playerGrade, 99, Player.PlayerData.citizenid, targetCitizenId) then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não pode expulsar este membro (regras da organização).', 'error')
        return
    end

    MySQL.Async.fetchScalar('SELECT gang FROM players WHERE citizenid = ?', {targetCitizenId}, function(gangData)
        if not gangData then return end
        
        local gang = json.decode(gangData)
        local cargoAtualRaw = nil
        if gang and gang.grade ~= nil then
            if type(gang.grade) == 'table' then
                cargoAtualRaw = gang.grade.level or gang.grade.grade
            else
                cargoAtualRaw = gang.grade
            end
        end
        local cargoAtual = tonumber(cargoAtualRaw) or maxCargo
        if cargoAtual < 1 then cargoAtual = maxCargo end
        if cargoAtual > maxCargo then cargoAtual = maxCargo end
        if not faccao.cargos[cargoAtual] then cargoAtual = maxCargo end
        
        if not SantaPodeExpulsar(playerGrade, cargoAtual, Player.PlayerData.citizenid, targetCitizenId) then
            TriggerClientEvent('faccoes:client:notify', src, 'Você não pode expulsar alguém de cargo igual ou superior (Sub-Chefe não pode expulsar Chefe).', 'error')
            return
        end
        
        local TargetPlayer = QBCore.Functions.GetPlayerByCitizenId(targetCitizenId)
        
        if TargetPlayer then
            TargetPlayer.Functions.SetGang('none', 0)
            PersistirGangNoDB(TargetPlayer.PlayerData.citizenid, TargetPlayer.PlayerData.gang, function()
                TriggerClientEvent('faccoes:client:notify', TargetPlayer.PlayerData.source, 'Você foi expulso da facção!', 'error')
                TriggerClientEvent('faccoes:client:notify', src, 'Membro expulso com sucesso!', 'success')
                EnviarListaMembrosParaCliente(src, playerFaction)
                if DEBUG then print(string.format('[FACCOES] %s expulsou %s da facção %s',
                    Player.PlayerData.charinfo.firstname, targetCitizenId, playerFaction)) end
            end)
        else
            MySQL.Async.execute('UPDATE players SET gang = ? WHERE citizenid = ?',
                {json.encode({name = 'none', label = 'No Gang', isboss = false, grade = {name = 'none', level = 0}}), targetCitizenId}, function()
                    TriggerClientEvent('faccoes:client:notify', src, 'Membro expulso com sucesso!', 'success')
                    EnviarListaMembrosParaCliente(src, playerFaction)
                    if DEBUG then print(string.format('[FACCOES] %s expulsou %s da facção %s',
                        Player.PlayerData.charinfo.firstname, targetCitizenId, playerFaction)) end
                end)
        end
    end)
end)

-- ============================================================================
-- PAINEL - EXPULSAR E BANIR (Remover + Banir em uma ação – prioridade 1)
-- Evento: faccoes:server:expulsarEBanir
-- Params: targetCitizenId (string), motivo (string, opcional)
-- ============================================================================
RegisterNetEvent('faccoes:server:expulsarEBanir', function(targetCitizenId, motivo)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local playerFaction = GetPlayerFaction(src)
    local faccao = Config.Faccoes[playerFaction]
    if not faccao then return end

    targetCitizenId = ResolverIdMembroParaCitizenId(targetCitizenId)
    if not targetCitizenId or targetCitizenId == '' then
        TriggerClientEvent('faccoes:client:notify', src, 'Membro não encontrado.', 'error')
        return
    end

    local playerGrade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
    local maxCargo = GetMaxCargoForFaccao(faccao)
    if not HasCargoPermissao(playerFaction, playerGrade, 'gerenciar_membros') then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não tem permissão para expulsar/banir membros!', 'error')
        return
    end

    motivo = (type(motivo) == 'string' and motivo:match('^%s*(.-)%s*$')) or ''
    if motivo == '' then motivo = 'Expulsão e banimento pelo painel' end
    if #motivo > 0 and #motivo < 4 then
        TriggerClientEvent('faccoes:client:notify', src, 'O motivo deve ter pelo menos 4 caracteres.', 'error')
        return
    end

    local nomeLider = (Player.PlayerData.charinfo and (Player.PlayerData.charinfo.firstname or '') .. ' ' .. (Player.PlayerData.charinfo.lastname or '')):gsub('^%s+', ''):gsub('%s+$', '')
    if nomeLider == '' then nomeLider = 'Líder' end
    local citizenidLider = Player.PlayerData.citizenid or ''

    MySQL.Async.fetchAll('SELECT gang, charinfo FROM players WHERE citizenid = ?', {targetCitizenId}, function(result)
        if not result or not result[1] then return end
        local gang = json.decode(result[1].gang or '{}')
        local charinfo = json.decode(result[1].charinfo or '{}') or {}
        local nomeMembro = (charinfo.firstname or '') .. ' ' .. (charinfo.lastname or '')
        if nomeMembro:match('^%s*$') then nomeMembro = targetCitizenId end

        local cargoAtualRaw = nil
        if gang and gang.grade ~= nil then
            if type(gang.grade) == 'table' then
                cargoAtualRaw = gang.grade.level or gang.grade.grade
            else
                cargoAtualRaw = gang.grade
            end
        end
        local cargoAtual = tonumber(cargoAtualRaw) or maxCargo
        if cargoAtual < 1 then cargoAtual = maxCargo end
        if cargoAtual > maxCargo then cargoAtual = maxCargo end
        if not faccao.cargos[cargoAtual] then cargoAtual = maxCargo end

        if not SantaPodeExpulsar(playerGrade, cargoAtual, Player.PlayerData.citizenid, targetCitizenId) then
            TriggerClientEvent('faccoes:client:notify', src, 'Você não pode expulsar este membro (regras da organização).', 'error')
            return
        end

        local TargetPlayer = QBCore.Functions.GetPlayerByCitizenId(targetCitizenId)

        if TargetPlayer then
            TargetPlayer.Functions.SetGang('none', 0)
            PersistirGangNoDB(TargetPlayer.PlayerData.citizenid, TargetPlayer.PlayerData.gang, function()
                MySQL.Async.execute('INSERT INTO faccoes_banidos (faccao, id_lider, nome_lider, citizenid_membro, nome_membro, motivo) VALUES (?, ?, ?, ?, ?, ?)', {
                    playerFaction, 0, nomeLider, targetCitizenId, nomeMembro, motivo
                }, function()
                    TriggerClientEvent('faccoes:client:notify', TargetPlayer.PlayerData.source, 'Você foi expulso e banido da facção.', 'error')
                    TriggerClientEvent('faccoes:client:notify', src, 'Membro expulso e banido com sucesso!', 'success')
                    EnviarListaMembrosParaCliente(src, playerFaction)
                    TriggerClientEvent('faccoes:client:atualizarPainel', src)
                end)
            end)
        else
            MySQL.Async.execute('UPDATE players SET gang = ? WHERE citizenid = ?',
                {json.encode({name = 'none', label = 'No Gang', isboss = false, grade = {name = 'none', level = 0}}), targetCitizenId}, function()
                    MySQL.Async.execute('INSERT INTO faccoes_banidos (faccao, id_lider, nome_lider, citizenid_membro, nome_membro, motivo) VALUES (?, ?, ?, ?, ?, ?)', {
                        playerFaction, 0, nomeLider, targetCitizenId, nomeMembro, motivo
                    }, function()
                        TriggerClientEvent('faccoes:client:notify', src, 'Membro expulso e banido com sucesso!', 'success')
                        EnviarListaMembrosParaCliente(src, playerFaction)
                        TriggerClientEvent('faccoes:client:atualizarPainel', src)
                    end)
                end)
        end
    end)
end)

-- ============================================================================
-- ENTREGAR RECOMPENSA (entrega de farm - lógica Santa)
-- ============================================================================
RegisterNetEvent('faccoes:server:entregarRecompensa', function(quantidade, valorStr)
    local src = source
    -- Rate limiting: máximo 1 entrega a cada 30 segundos
    if IsRateLimited(src, 'entregarRecompensa', 30000) then
        TriggerClientEvent('faccoes:client:notify', src, 'Aguarde antes de entregar novamente.', 'error')
        return
    end

    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local faccaoId = GetPlayerFaction(src)
    if not faccaoId or not Config.Faccoes[faccaoId] then return end

    quantidade = tonumber(quantidade) or 0
    if quantidade <= 0 or quantidade > 100 then
        TriggerClientEvent('faccoes:client:notify', src, 'Quantidade inválida.', 'error')
        return
    end

    local citizenid = Player.PlayerData.citizenid
    local hoje = os.date('%Y-%m-%d')
    local valorPorEntregaPadrao = (Config.MetaDiaria and Config.MetaDiaria.valorPorEntrega) or 2000

    -- Santa: valor por entrega vem da meta da facção (DB) ou config
    MySQL.Async.fetchAll('SELECT valor_por_entrega FROM faccoes_meta WHERE faccao = ?', {faccaoId}, function(metaRow)
        local valorPorEntrega = valorPorEntregaPadrao
        if metaRow and metaRow[1] and metaRow[1].valor_por_entrega then
            valorPorEntrega = tonumber(metaRow[1].valor_por_entrega) or valorPorEntregaPadrao
        end
        local valor = math.floor(quantidade * valorPorEntrega)
        if valor <= 0 then return end

        MySQL.Async.execute('INSERT INTO faccoes_entregas (faccao, citizenid, quantidade, valor_recebido, dia) VALUES (?, ?, ?, ?, ?)', {
            faccaoId, citizenid, quantidade, valor, hoje
        }, function(affected)
            Player.Functions.AddMoney('cash', valor)
            TriggerClientEvent('faccoes:client:notify', src, 'Você entregou ' .. quantidade .. ' e recebeu $' .. valor .. '.', 'success')
            TriggerClientEvent('faccoes:client:atualizarPainel', src)
            FaccaoLog(src, 'Entrega Recompensa', 'Entregou ' .. quantidade .. ' itens e recebeu $' .. valor .. ' (faccao: ' .. faccaoId .. ')')
        end)
    end)
end)

-- ============================================================================
-- MENSAGEM DO LÍDER (só cargo 1 ou 2)
-- ============================================================================
RegisterNetEvent('faccoes:server:postarMensagemLider', function(faccaoId, conteudo)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    
    if GetPlayerFaction(src) ~= faccaoId then return end
    -- Santa: só liderança pode postar (mesmo limite do banco = cargosPodeMover)
    local grade = GetGangGradeLevel(Player.PlayerData.gang)
    local cargosPodeMover = (Config.BancoFaccao and tonumber(Config.BancoFaccao.cargosPodeMover)) or 2
    if grade > cargosPodeMover then
        TriggerClientEvent('faccoes:client:notify', src, 'Apenas líderes podem postar mensagens.', 'error')
        return
    end
    
    if not conteudo or #conteudo < 2 then
        TriggerClientEvent('faccoes:client:notify', src, 'Mensagem muito curta.', 'error')
        return
    end
    
    local citizenid = Player.PlayerData.citizenid
    local ok = pcall(function()
        if MySQL and MySQL.query and MySQL.query.await then
            MySQL.query.await('INSERT INTO faccoes_messages (faccao, author_citizenid, content) VALUES (?, ?, ?)', {faccaoId, citizenid, conteudo})
        else
            MySQL.Async.execute('INSERT INTO faccoes_messages (faccao, author_citizenid, content) VALUES (?, ?, ?)', {faccaoId, citizenid, conteudo})
        end
    end)
    if ok then
        TriggerClientEvent('faccoes:client:notify', src, 'Mensagem publicada.', 'success')
        TriggerClientEvent('faccoes:client:atualizarPainel', src)
    else
        TriggerClientEvent('faccoes:client:notify', src, 'Erro ao salvar mensagem. Tente de novo em instantes.', 'error')
    end
end)

-- ============================================================================
-- CONFIGURAR META DIÁRIA (só 00 – total, premio, valor por entrega)
-- ============================================================================
RegisterNetEvent('faccoes:server:configurarMeta', function(faccaoId, total, premio, valorPorEntrega)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    if GetPlayerFaction(src) ~= faccaoId then return end
    local grade = GetGangGradeLevel(Player.PlayerData.gang)
    if grade ~= 1 then
        TriggerClientEvent('faccoes:client:notify', src, 'Apenas o líder 00 pode configurar a meta.', 'error')
        return
    end

    total = math.max(1, tonumber(total) or 1000)
    premio = math.max(0, tonumber(premio) or 0)
    valorPorEntrega = math.max(0, tonumber(valorPorEntrega) or 2000)

    MySQL.Async.execute([[
        INSERT INTO faccoes_meta (faccao, total, premio, valor_por_entrega)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE total = VALUES(total), premio = VALUES(premio), valor_por_entrega = VALUES(valor_por_entrega)
    ]], {faccaoId, total, premio, valorPorEntrega}, function()
        TriggerClientEvent('faccoes:client:notify', src, 'Meta diária atualizada.', 'success')
        TriggerClientEvent('faccoes:client:atualizarPainel', src)
    end)
end)

-- ============================================================================
-- BANCO DA FACÇÃO - DEPOSITAR / SACAR
-- ============================================================================
GetOrCreateBankBalance = function(faccaoId, cb)
    MySQL.Async.fetchScalar('SELECT balance FROM faccoes_bank WHERE faccao = ?', {faccaoId}, function(bal)
        if bal == nil then
            MySQL.Async.execute('INSERT IGNORE INTO faccoes_bank (faccao, balance) VALUES (?, 0)', {faccaoId}, function()
                cb(0)
            end)
        else
            cb(tonumber(bal) or 0)
        end
    end)
end

-- ============================================================================
-- PONTOS DA ORGANIZAÇÃO (estilo Santa)
-- ============================================================================
GetOrCreateOrgPoints = function(faccaoId, cb)
    if not (Config.PontosFaccao and Config.PontosFaccao.habilitado) then
        cb(0)
        return
    end

    local ok = pcall(function()
        MySQL.Async.fetchScalar('SELECT points FROM faccoes_points WHERE faccao = ?', {faccaoId}, function(pts)
            if pts == nil then
                MySQL.Async.execute('INSERT IGNORE INTO faccoes_points (faccao, points) VALUES (?, 0)', {faccaoId}, function()
                    cb(0)
                end)
            else
                cb(tonumber(pts) or 0)
            end
        end)
    end)

    if not ok then cb(0) end
end

AddOrgPoints = function(faccaoId, amount, cb)
    if not (Config.PontosFaccao and Config.PontosFaccao.habilitado) then
        if cb then cb(false, 0) end
        return
    end

    amount = math.floor(tonumber(amount) or 0)
    if amount == 0 then
        if cb then cb(false, 0) end
        return
    end

    local ok = pcall(function()
        MySQL.Async.execute(
            'INSERT INTO faccoes_points (faccao, points) VALUES (?, ?) ON DUPLICATE KEY UPDATE points = points + ?',
            {faccaoId, amount, amount},
            function()
                if cb then
                    GetOrCreateOrgPoints(faccaoId, function(pts) cb(true, pts) end)
                end
            end
        )
    end)

    if not ok and cb then cb(false, 0) end
end

RemoveOrgPoints = function(faccaoId, amount, cb)
    if not (Config.PontosFaccao and Config.PontosFaccao.habilitado) then
        if cb then cb(false, 0) end
        return
    end

    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then
        if cb then cb(false, 0) end
        return
    end

    local ok = pcall(function()
        MySQL.Async.fetchScalar('SELECT points FROM faccoes_points WHERE faccao = ?', {faccaoId}, function(pts)
            pts = tonumber(pts) or 0
            if pts < amount then
                if cb then cb(false, pts) end
                return
            end
            MySQL.Async.execute('UPDATE faccoes_points SET points = points - ? WHERE faccao = ?', {amount, faccaoId}, function()
                if cb then cb(true, pts - amount) end
            end)
        end)
    end)

    if not ok and cb then cb(false, 0) end
end

RegisterNetEvent('faccoes:server:depositarBanco', function(faccaoId, amount)
    local src = source
    if IsRateLimited(src, 'depositarBanco', 5000) then
        TriggerClientEvent('faccoes:client:notify', src, 'Aguarde antes de depositar novamente.', 'error')
        return
    end
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or GetPlayerFaction(src) ~= faccaoId then return end

    -- Santa-like: só liderança movimenta banco
    local grade = GetGangGradeLevel(Player.PlayerData.gang)
    local cargosPodeMover = (Config.BancoFaccao and tonumber(Config.BancoFaccao.cargosPodeMover)) or 2
    if grade > cargosPodeMover then
        TriggerClientEvent('faccoes:client:notify', src, 'Apenas a liderança pode movimentar o banco.', 'error')
        return
    end
    
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 or amount > 10000000 then
        TriggerClientEvent('faccoes:client:notify', src, 'Valor inválido.', 'error')
        return
    end

    -- Re-verificar saldo atualizado do player
    local Player2 = QBCore.Functions.GetPlayer(src)
    local bank = Player2 and Player2.PlayerData.money.bank or 0
    if bank < amount then
        TriggerClientEvent('faccoes:client:notify', src, 'Saldo bancário insuficiente.', 'error')
        return
    end

    local taxa = (Config.BancoFaccao and tonumber(Config.BancoFaccao.taxaDeposito)) or 0
    if taxa < 0 then taxa = 0 end
    if taxa > 0.99 then taxa = 0.99 end

    local recebido = amount
    if taxa > 0 then
        recebido = math.floor(amount * (1 - taxa))
    end
    if recebido <= 0 then
        TriggerClientEvent('faccoes:client:notify', src, 'Valor muito baixo para depósito.', 'error')
        return
    end
    local taxaValor = amount - recebido

    Player.Functions.RemoveMoney('bank', amount)
    local citizenid = Player.PlayerData.citizenid
    local nome = (Player.PlayerData.charinfo.firstname or '') .. ' ' .. (Player.PlayerData.charinfo.lastname or '')
    MySQL.Async.execute('INSERT INTO faccoes_bank (faccao, balance) VALUES (?, ?) ON DUPLICATE KEY UPDATE balance = balance + ?', {faccaoId, recebido, recebido})
    MySQL.Async.execute('INSERT INTO faccoes_bank_transactions (faccao, citizenid, nome, tipo, descricao, valor) VALUES (?, ?, ?, ?, ?, ?)', {
        faccaoId, citizenid, nome, 'entrada', (taxaValor > 0 and ('Depósito (taxa ' .. tostring(math.floor(taxa * 100 + 0.5)) .. '%)') or 'Depósito'), recebido
    })
    if taxaValor > 0 then
        TriggerClientEvent('faccoes:client:notify', src, 'Depositou $' .. recebido .. ' (taxa: -$' .. taxaValor .. ').', 'success')
    else
        TriggerClientEvent('faccoes:client:notify', src, 'Depositou $' .. recebido .. ' no banco da facção.', 'success')
    end
    TriggerClientEvent('faccoes:client:atualizarPainel', src)
    FaccaoLog(src, 'Deposito Banco Faccao', 'Depositou $' .. recebido .. ' no banco da faccao ' .. faccaoId .. (taxaValor > 0 and (' (taxa: $' .. taxaValor .. ')') or ''))
end)

RegisterNetEvent('faccoes:server:sacarBanco', function(faccaoId, amount)
    local src = source
    if IsRateLimited(src, 'sacarBanco', 5000) then
        TriggerClientEvent('faccoes:client:notify', src, 'Aguarde antes de sacar novamente.', 'error')
        return
    end
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or GetPlayerFaction(src) ~= faccaoId then return end

    local grade = GetGangGradeLevel(Player.PlayerData.gang)
    local cargosPodeMover = (Config.BancoFaccao and tonumber(Config.BancoFaccao.cargosPodeMover)) or 2
    if grade > cargosPodeMover then
        TriggerClientEvent('faccoes:client:notify', src, 'Apenas líderes podem sacar.', 'error')
        return
    end

    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 or amount > 10000000 then
        TriggerClientEvent('faccoes:client:notify', src, 'Valor inválido.', 'error')
        return
    end

    -- UPDATE atômico: só subtrai se saldo >= amount (previne race condition)
    local affectedRows = MySQL.update.await(
        'UPDATE faccoes_bank SET balance = balance - ? WHERE faccao = ? AND balance >= ?',
        { amount, faccaoId, amount }
    )

    if not affectedRows or affectedRows == 0 then
        TriggerClientEvent('faccoes:client:notify', src, 'Saldo da facção insuficiente.', 'error')
        return
    end

    Player.Functions.AddMoney('bank', amount)
    local citizenid = Player.PlayerData.citizenid
    local nome = (Player.PlayerData.charinfo.firstname or '') .. ' ' .. (Player.PlayerData.charinfo.lastname or '')
    MySQL.Async.execute('INSERT INTO faccoes_bank_transactions (faccao, citizenid, nome, tipo, descricao, valor) VALUES (?, ?, ?, ?, ?, ?)', {
        faccaoId, citizenid, nome, 'saque', 'Saque', amount
    })
    TriggerClientEvent('faccoes:client:notify', src, 'Sacou $' .. amount .. ' do banco da facção.', 'success')
    TriggerClientEvent('faccoes:client:atualizarPainel', src)
    FaccaoLog(src, 'Saque Banco Faccao', 'Sacou $' .. amount .. ' do banco da faccao ' .. faccaoId)
end)

-- ============================================================================
-- LOJA DA ORGANIZAÇÃO (compra com pontos)
-- ============================================================================
RegisterNetEvent('faccoes:server:comprarLoja', function(faccaoId, itemName, amount, targetCitizenid)
    local src = source
    if IsRateLimited(src, 'comprarLoja', 5000) then
        TriggerClientEvent('faccoes:client:notify', src, 'Aguarde antes de comprar novamente.', 'error')
        return
    end
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    if not (Config.LojaFaccao and Config.LojaFaccao.habilitado) then
        TriggerClientEvent('faccoes:client:notify', src, 'Loja desativada.', 'error')
        return
    end

    if GetPlayerFaction(src) ~= faccaoId then
        TriggerClientEvent('faccoes:client:notify', src, 'Você não pertence a esta facção.', 'error')
        return
    end

    local faccao = Config.Faccoes[faccaoId]
    if not faccao then return end
    local grade = select(1, NormalizarCargo(faccao, GetGangGradeLevel(Player.PlayerData.gang)))
    -- Santa: só líder (cargo 1) compra na loja; pode presentear (targetCitizenid)
    if not SantaPodeLoja(grade) then
        TriggerClientEvent('faccoes:client:notify', src, 'Apenas o líder pode comprar na loja da organização.', 'error')
        return
    end

    local loja = faccao.loja or Config.LojaFaccao.itensPadrao or {}
    itemName = tostring(itemName or ''):lower():gsub('%s+', '')
    if itemName == '' then return end

    local entry = nil
    for _, it in ipairs(loja) do
        if it and it.item and tostring(it.item):lower() == itemName then
            entry = it
            break
        end
    end
    if not entry then
        TriggerClientEvent('faccoes:client:notify', src, 'Item indisponível na loja.', 'error')
        return
    end

    local itemData = QBCore.Shared.Items[itemName]
    if not itemData then
        TriggerClientEvent('faccoes:client:notify', src, 'Item não existe no servidor: ' .. itemName, 'error')
        return
    end

    local buyAmount = math.floor(tonumber(amount) or (entry.amount or 1))
    if buyAmount <= 0 then buyAmount = (entry.amount or 1) end

    local priceUnit = math.floor(tonumber(entry.price) or 0)
    local totalPrice = priceUnit * buyAmount
    if totalPrice <= 0 then
        TriggerClientEvent('faccoes:client:notify', src, 'Preço inválido.', 'error')
        return
    end

    RemoveOrgPoints(faccaoId, totalPrice, function(ok, remaining)
        if not ok then
            TriggerClientEvent('faccoes:client:notify', src, 'Pontos insuficientes. Você tem: ' .. tostring(remaining or 0), 'error')
            return
        end

        -- Santa: presentear = enviar item para outro membro (targetCitizenid)
        local destPlayer = Player
        local destCid = Player.PlayerData.citizenid
        if targetCitizenid and type(targetCitizenid) == 'string' and targetCitizenid ~= '' and targetCitizenid ~= destCid then
            local TargetP = QBCore.Functions.GetPlayerByCitizenId(targetCitizenid)
            if TargetP and GetPlayerFaction(TargetP.PlayerData.source) == faccaoId then
                destPlayer = TargetP
                destCid = targetCitizenid
            end
        end

        local added = destPlayer.Functions.AddItem(itemName, buyAmount)
        if not added then
            AddOrgPoints(faccaoId, totalPrice)
            TriggerClientEvent('faccoes:client:notify', src, (destCid ~= Player.PlayerData.citizenid and 'Inventário do membro cheio.' or 'Inventário cheio. Compra cancelada.'), 'error')
            return
        end

        if destCid ~= Player.PlayerData.citizenid then
            TriggerClientEvent('faccoes:client:notify', src, 'Enviou ' .. buyAmount .. 'x ' .. (entry.label or itemData.label or itemName) .. ' para o membro (' .. totalPrice .. ' pontos).', 'success')
            if destPlayer.PlayerData.source then
                TriggerClientEvent('faccoes:client:notify', destPlayer.PlayerData.source, 'O líder enviou ' .. buyAmount .. 'x ' .. (entry.label or itemData.label or itemName) .. ' para você.', 'success')
            end
        else
            TriggerClientEvent('faccoes:client:notify', src, 'Comprou ' .. buyAmount .. 'x ' .. (entry.label or itemData.label or itemName) .. ' por ' .. totalPrice .. ' pontos.', 'success')
        end
        TriggerClientEvent('faccoes:client:atualizarPainel', src)
    end)
end)

-- ============================================================================
-- COMANDOS ADMIN
-- ============================================================================
QBCore.Commands.Add('setfaccao', 'Definir facção de um jogador (Admin)', {
    {name = 'id', help = 'ID do jogador'},
    {name = 'faccao', help = 'Nome da facção'},
    {name = 'cargo', help = 'Nível do cargo (1..máximo da facção)'}
}, true, function(source, args)
    local targetId = tonumber(args[1])
    local faccaoId = args[2]
    local faccao = Config.Faccoes[faccaoId]
    local maxCargo = GetMaxCargoForFaccao(faccao)
    local cargo = tonumber(args[3]) or maxCargo
    if cargo < 1 then cargo = 1 end
    if cargo > maxCargo then cargo = maxCargo end
    
    if not faccao then
        TriggerClientEvent('faccoes:client:notify', source, 'Facção não encontrada!', 'error')
        return
    end
    
    local TargetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not TargetPlayer then
        TriggerClientEvent('faccoes:client:notify', source, 'Jogador não encontrado!', 'error')
        return
    end
    
    local ok = TargetPlayer.Functions.SetGang(faccaoId, cargo)
    if not ok then
        TriggerClientEvent('faccoes:client:notify', source, 'Gang não registrada no qb-core (shared/gangs.lua).', 'error')
        return
    end
    PersistirGangNoDB(TargetPlayer.PlayerData.citizenid, TargetPlayer.PlayerData.gang)
    TriggerClientEvent('faccoes:client:atualizarPainel', targetId)

    local cargoNome = (faccao.cargos[cargo] and faccao.cargos[cargo].nome) or tostring(cargo)
    TriggerClientEvent('faccoes:client:notify', targetId, 'Você foi adicionado à facção ' .. faccao.nome .. ' como ' .. cargoNome, 'success')
    TriggerClientEvent('faccoes:client:notify', source, 'Jogador adicionado à facção com sucesso!', 'success')

    if DEBUG then print(string.format('[FACCOES] Admin definiu jogador %d na facção %s cargo %d', targetId, faccaoId, cargo)) end
end, 'admin')

QBCore.Commands.Add('removerfaccao', 'Remover jogador da facção (Admin)', {
    {name = 'id', help = 'ID do jogador'}
}, true, function(source, args)
    local targetId = tonumber(args[1])
    
    local TargetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not TargetPlayer then
        TriggerClientEvent('faccoes:client:notify', source, 'Jogador não encontrado!', 'error')
        return
    end
    
    TargetPlayer.Functions.SetGang('none', 0)
    PersistirGangNoDB(TargetPlayer.PlayerData.citizenid, TargetPlayer.PlayerData.gang)
    
    TriggerClientEvent('faccoes:client:notify', targetId, 'Você foi removido da sua facção!', 'error')
    TriggerClientEvent('faccoes:client:notify', source, 'Jogador removido da facção com sucesso!', 'success')
    
    if DEBUG then print(string.format('[FACCOES] Admin removeu jogador %d da facção', targetId)) end
end, 'admin')

QBCore.Commands.Add('setarpontosfac', 'Adicionar pontos da facção (Admin)', {
    {name = 'faccao', help = 'Nome da facção (ex: egito)'},
    {name = 'pontos', help = 'Quantidade de pontos'}
}, true, function(source, args)
    local faccaoId = args[1]
    local pontos = tonumber(args[2]) or 0

    if not faccaoId or not Config.Faccoes[faccaoId] then
        TriggerClientEvent('faccoes:client:notify', source, 'Facção não encontrada.', 'error')
        return
    end

    if pontos == 0 then
        TriggerClientEvent('faccoes:client:notify', source, 'Quantidade inválida.', 'error')
        return
    end

    AddOrgPoints(faccaoId, pontos, function(ok, novoTotal)
        if ok then
            TriggerClientEvent('faccoes:client:notify', source, 'Pontos adicionados. Total agora: ' .. tostring(novoTotal), 'success')
        else
            TriggerClientEvent('faccoes:client:notify', source, 'Falha ao adicionar pontos.', 'error')
        end
    end)
end, 'admin')

-- ============================================================================
-- LOGS
-- ============================================================================
local function ContarFaccoes()
    local count = 0
    for _ in pairs(Config.Faccoes) do
        count = count + 1
    end
    return count
end

if DEBUG then
end
