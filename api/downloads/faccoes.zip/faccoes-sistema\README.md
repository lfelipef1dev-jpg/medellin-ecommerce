# Sistema de Facções para FiveM (QBox / QBCore)

Sistema completo de facções com hierarquia, baús, garagens, mensagens internas, recrutamento e painel de gestão.

## Funcionalidades

### Gestão de Membros
- Hierarquia configurável (cargos 1-20, menor = mais alto)
- Promover / rebaixar membros por cargo
- Expulsar membros com registro em log
- Recrutamento via código de convite
- Lista de banidos por facção

### Baús de Facção
- Múltiplos tipos de baú por facção (membros, liderança, cofre)
- Controle de permissão por cargo
- Integração com `ox_inventory`

### Garagens
- Garagens exclusivas por facção
- Controle de acesso por cargo mínimo

### Painel Web
- Interface visual para liderança gerir membros, cargos e pontos
- Ver mensagens internas da facção
- Ranking de pontos

### Comunicação
- Mensagens internas (chat privado da facção)
- Notificações para todos os membros online

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)
- `ox_target`
- `ox_inventory`
- `oxmysql`

## Instalação

1. Coloque a pasta `faccoes-sistema` dentro de `resources/`
2. Execute os SQLs:
   - `sql.sql` — tabelas principais
   - `sql_criar_banco_faccao.sql` — estrutura de pontos e mensagens
3. Adicione ao `server.cfg`:
   ```
   ensure faccoes-sistema
   ```
4. Configure as facções em `config.lua`

## Configuração Básica (config.lua)

```lua
Config.Faccoes = {
    ['grove'] = {
        label = 'Grove Street',
        cargos = {
            [1] = { nome = 'Líder', permissoes = {'tudo'} },
            [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider'} },
            [5] = { nome = 'Membro', permissoes = {'bau_membros'} },
        },
        baus = {
            membros = { coords = vector3(0,0,0) },
            lider = { coords = vector3(0,0,0), permissao = 'bau_lider' },
        },
    },
    -- adicione mais facções aqui
}
```

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
