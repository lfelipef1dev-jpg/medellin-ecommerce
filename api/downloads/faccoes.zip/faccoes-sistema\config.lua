Config = {}

-- ============================================================================
-- CONFIGURAÇÃO GERAL
-- ============================================================================
Config.Debug = false
Config.MaxCargos = 20 -- Número máximo de cargos por facção

-- Meta diária do painel (entrega de farm)
Config.MetaDiaria = {
    total = 1000,        -- Meta em quantidade de entregas
    premio = 200000,     -- Prêmio em $ ao completar
    valorPorEntrega = 2000 -- Valor base por entrega (slider no painel)
}

-- Canal de rádio padrão por facção (pma-voice). Defina por facção em cada entrada abaixo.
Config.RadioCanalPadrao = 10

-- ============================================================================
-- PAINEL (LÓGICA ESTILO SANTA)
-- ============================================================================
Config.Painel = {
    -- Se definido, só abre painel para facções desse tipo (ex: 'armas').
    -- Coloque nil para permitir todos os tipos.
    apenasTipo = nil,

    -- Cooldown simples (ms) para ações sensíveis (evita spam).
    cooldownAcaoMs = 1500
}

Config.BancoFaccao = {
    -- Taxa cobrada no depósito (ex: 0.05 = 5%).
    taxaDeposito = 0.05,

    -- Cargo máximo que pode mover o banco (1 = líder, 2 = sublíder, ...).
    cargosPodeMover = 2
}

Config.PontosFaccao = {
    habilitado = true,

    -- Pontos de organização ganhos ao recrutar alguém "sem facção" (iniciante).
    pontosPorRecrutamentoIniciante = 75
}

Config.LojaFaccao = {
    habilitado = true,

    -- Cargo máximo que pode comprar na loja com pontos da organização.
    cargosPodeComprar = 1,

    -- Lista padrão (pode sobrescrever por facção em Config.Faccoes[faccaoId].loja).
    itensPadrao = {
        { item = 'radio', label = 'Rádio', amount = 1, price = 25 },
        { item = 'lockpick', label = 'Lockpick', amount = 1, price = 10 },
        { item = 'armor', label = 'Colete', amount = 1, price = 35 }
    }
}

-- ============================================================================
-- FACÇÕES REGISTRADAS
-- ============================================================================
Config.Faccoes = {
    -- ========================================================================
    -- FACÇÃO EGITO (Armas)
    -- ========================================================================
    egito = {
        nome = 'Tropa do Egito',
        tipo = 'armas',
        cor = '#00FF88', -- Verde Servidor (ou use a cor da facção)
        icone = '🏺',
        logo = 'egito.svg',
        discord = '', -- Link do Discord da facção (opcional)
        mensagemLider = '', -- Mensagem fixa do líder (opcional)
        regras = { 'Respeite todos os membros', 'Entre no Discord da facção', 'Sem zaralho e sem matar dentro da FAC', 'Guie os novatos' },
        radioChannel = 10, -- Canal do rádio da facção (pma-voice)
        raioInteracaoBau = 3.0,       -- [E] baú membros (3m)
        raioInteracaoBauLider = 1.5,  -- [E] só baú líder (1.5m)
        raioTextoBau = 3.0,       -- texto [E] baú membros
        raioTextoBauLider = 1.5,  -- texto [E] baú líder
        -- waypointCoords = vector2(799.64, -293.67), -- Opcional: marcar no mapa. Se nil, usa baus.lider.coords
        
        -- Baús
        baus = {
            lider = {
                coords = vector3(799.64, -293.67, 69.47),
                label = 'Baú Líder Egito',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 5 -- Cargo mínimo para acessar (1 = líder, 2 = sublíder, etc.)
            },
            membros = {
                coords = vector3(798.55, -294.04, 66.52),
                label = 'Baú Membros Egito',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 14 -- Todos os membros
            }
        },
        
        -- Garagem da Facção (coordenadas corretas)
        garagem = {
            coords = vector3(787.60, -296.62, 60.20),
            spawn = vector4(785.49, -302.23, 58.98, 120.18),
            label = 'Garagem Facção Egito',
            blipColor = 46 -- Dourado
        },
        
        -- Hierarquia (cargos) – Santa: 00 = tudo; Gerente = baú líder + craft; Membro = só baú membros
        cargos = {
            [1] = { nome = 'Líder 00', permissoes = {'all'} },
            [2] = { nome = 'Líder 01', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [3] = { nome = 'Líder 02', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [4] = { nome = 'Líder 03', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Gerente Geral', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [6] = { nome = 'Gerente de Farm', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [7] = { nome = 'Gerente de Pista', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [8] = { nome = 'Gerente de Recrutamento', permissoes = {'recrutar', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [9] = { nome = 'Supervisor', permissoes = {'recrutar', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [10] = { nome = 'Recrutador', permissoes = {'recrutar', 'bau_membros'} },
            [11] = { nome = 'Elite', permissoes = {'bau_membros'} },
            [12] = { nome = 'Membro Verificado', permissoes = {'bau_membros'} },
            [13] = { nome = 'Membro', permissoes = {'bau_membros'} },
            [14] = { nome = 'Novato', permissoes = {'bau_membros'} }
        }
    },

    -- ========================================================================
    -- FACÇÃO BROOKLYN (Armas)
    -- ========================================================================
    brooklyn = {
        nome = 'Brooklyn',
        tipo = 'armas',
        cor = '#FF4500',
        icone = '🔫',
        logo = 'brooklyn.png',
        
        baus = {
            lider = {
                coords = vector3(-188.0, -1660.0, 33.0),
                label = 'Baú Líder Brooklyn',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 5
            },
            membros = {
                coords = vector3(-190.0, -1660.0, 33.0),
                label = 'Baú Membros Brooklyn',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 14
            }
        },
        
        garagem = {
            coords = vector3(-195.0, -1665.0, 33.0),
            spawn = vector4(-200.0, -1670.0, 33.0, 180.0),
            label = 'Garagem Brooklyn',
            blipColor = 1
        },
        
        cargos = {
            [1] = { nome = 'Líder 00', permissoes = {'all'} },
            [2] = { nome = 'Líder 01', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [3] = { nome = 'Líder 02', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [4] = { nome = 'Líder 03', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Gerente Geral', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [6] = { nome = 'Gerente de Farm', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [7] = { nome = 'Gerente de Pista', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [8] = { nome = 'Gerente de Recrutamento', permissoes = {'recrutar', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [9] = { nome = 'Supervisor', permissoes = {'recrutar', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [10] = { nome = 'Recrutador', permissoes = {'recrutar', 'bau_membros'} },
            [11] = { nome = 'Elite', permissoes = {'bau_membros'} },
            [12] = { nome = 'Membro Verificado', permissoes = {'bau_membros'} },
            [13] = { nome = 'Membro', permissoes = {'bau_membros'} },
            [14] = { nome = 'Novato', permissoes = {'bau_membros'} }
        }
    },

    -- ========================================================================
    -- FACÇÃO TURQUIA (Munição)
    -- ========================================================================
    turquia = {
        nome = 'Tropa da Turquia',
        tipo = 'municao',
        cor = '#E30A17',
        icone = '🎯',
        logo = 'turquia.png',
        
        baus = {
            lider = {
                coords = vector3(1289.67, -712.95, 64.07),
                label = 'Baú Líder Turquia',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(1287.0, -712.0, 64.07),
                label = 'Baú Membros Turquia',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(1295.0, -710.0, 64.07),
            spawn = vector4(1300.0, -705.0, 64.07, 0.0),
            label = 'Garagem Turquia',
            blipColor = 1
        },
        
        cargos = {
            [1] = { nome = 'Sultão', permissoes = {'all'} },
            [2] = { nome = 'Vizir', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem', 'craft'} },
            [3] = { nome = 'Paxá', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Bey', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Aga', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Guerreiro VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Guerreiro V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Guerreiro IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Guerreiro III', permissoes = {'craft'} },
            [10] = { nome = 'Guerreiro II', permissoes = {'craft'} },
            [11] = { nome = 'Guerreiro I', permissoes = {'craft'} },
            [12] = { nome = 'Aprendiz V', permissoes = {'craft'} },
            [13] = { nome = 'Aprendiz IV', permissoes = {'craft'} },
            [14] = { nome = 'Aprendiz III', permissoes = {'craft'} },
            [15] = { nome = 'Aprendiz II', permissoes = {} },
            [16] = { nome = 'Aprendiz I', permissoes = {} },
            [17] = { nome = 'Novato IV', permissoes = {} },
            [18] = { nome = 'Novato III', permissoes = {} },
            [19] = { nome = 'Novato II', permissoes = {} },
            [20] = { nome = 'Novato I', permissoes = {} }
        }
    },

    -- ========================================================================
    -- FACÇÃO CUPULA (Munição)
    -- ========================================================================
    cupula = {
        nome = 'Cúpula',
        tipo = 'municao',
        cor = '#800080',
        icone = '🏛️',
        logo = 'cupula.png',
        
        baus = {
            lider = {
                coords = vector3(-103.42, 852.90, 235.61),
                label = 'Baú Líder Cúpula',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(-105.0, 852.0, 235.61),
                label = 'Baú Membros Cúpula',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(-100.0, 855.0, 235.61),
            spawn = vector4(-95.0, 860.0, 235.61, 90.0),
            label = 'Garagem Cúpula',
            blipColor = 27
        },
        
        cargos = {
            [1] = { nome = 'Supremo', permissoes = {'all'} },
            [2] = { nome = 'Vice-Supremo', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem', 'craft'} },
            [3] = { nome = 'Conselheiro', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Executor', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Guardião', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Membro VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Membro V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Membro IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Membro III', permissoes = {'craft'} },
            [10] = { nome = 'Membro II', permissoes = {'craft'} },
            [11] = { nome = 'Membro I', permissoes = {'craft'} },
            [12] = { nome = 'Recruta V', permissoes = {'craft'} },
            [13] = { nome = 'Recruta IV', permissoes = {'craft'} },
            [14] = { nome = 'Recruta III', permissoes = {'craft'} },
            [15] = { nome = 'Recruta II', permissoes = {} },
            [16] = { nome = 'Recruta I', permissoes = {} },
            [17] = { nome = 'Novato IV', permissoes = {} },
            [18] = { nome = 'Novato III', permissoes = {} },
            [19] = { nome = 'Novato II', permissoes = {} },
            [20] = { nome = 'Novato I', permissoes = {} }
        }
    },

    -- ========================================================================
    -- FACÇÃO RHINOS (Munição)
    -- ========================================================================
    rhinos = {
        nome = 'Rhinos',
        tipo = 'municao',
        cor = '#808080',
        icone = '🦏',
        logo = 'rhinos.png',
        
        baus = {
            lider = {
                coords = vector3(-2638.28, 1306.97, 145.36),
                label = 'Baú Líder Rhinos',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(-2640.0, 1306.0, 145.36),
                label = 'Baú Membros Rhinos',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(-2635.0, 1310.0, 145.36),
            spawn = vector4(-2630.0, 1315.0, 145.36, 270.0),
            label = 'Garagem Rhinos',
            blipColor = 0
        },
        
        cargos = {
            [1] = { nome = 'Alpha', permissoes = {'all'} },
            [2] = { nome = 'Beta', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem', 'craft'} },
            [3] = { nome = 'Gamma', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Delta', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Epsilon', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Membro VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Membro V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Membro IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Membro III', permissoes = {'craft'} },
            [10] = { nome = 'Membro II', permissoes = {'craft'} },
            [11] = { nome = 'Membro I', permissoes = {'craft'} },
            [12] = { nome = 'Recruta V', permissoes = {'craft'} },
            [13] = { nome = 'Recruta IV', permissoes = {'craft'} },
            [14] = { nome = 'Recruta III', permissoes = {'craft'} },
            [15] = { nome = 'Recruta II', permissoes = {} },
            [16] = { nome = 'Recruta I', permissoes = {} },
            [17] = { nome = 'Novato IV', permissoes = {} },
            [18] = { nome = 'Novato III', permissoes = {} },
            [19] = { nome = 'Novato II', permissoes = {} },
            [20] = { nome = 'Novato I', permissoes = {} }
        }
    },

    -- ========================================================================
    -- FACÇÃO PELICANS (Armas) – CONFIG FECHADA – não alterar (ver .cursor/rules/pelicans-bloqueado.mdc)
    -- ========================================================================
    pelicans = {
        nome = 'Pelicans',
        tipo = 'armas',
        cor = '#00CED1',
        icone = '🐦',
        logo = 'pelicans.png',
        
        baus = {
            lider = {
                coords = vector3(-1876.17, 2062.69, 145.57),
                label = 'Baú Líder Pelicans',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 5
            },
            membros = {
                coords = vector3(-1880.59, 2054.86, 140.98),
                label = 'Baú Membros Pelicans',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 14
            }
        },
        
        garagem = {
            coords = vector3(-1883.95, 2039.52, 140.92),
            spawn = vector4(-1883.95, 2039.52, 140.92, 170.99),
            label = 'Garagem Pelicans',
            blipColor = 26
        },
        
        cargos = {
            [1] = { nome = 'Líder 00', permissoes = {'all'} },
            [2] = { nome = 'Líder 01', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [3] = { nome = 'Líder 02', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [4] = { nome = 'Líder 03', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Gerente Geral', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [6] = { nome = 'Gerente de Farm', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [7] = { nome = 'Gerente de Pista', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [8] = { nome = 'Gerente de Recrutamento', permissoes = {'recrutar', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [9] = { nome = 'Supervisor', permissoes = {'recrutar', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [10] = { nome = 'Recrutador', permissoes = {'recrutar', 'bau_membros'} },
            [11] = { nome = 'Elite', permissoes = {'bau_membros'} },
            [12] = { nome = 'Membro Verificado', permissoes = {'bau_membros'} },
            [13] = { nome = 'Membro', permissoes = {'bau_membros'} },
            [14] = { nome = 'Novato', permissoes = {'bau_membros'} }
        }
    },

    -- ========================================================================
    -- FACÇÃO SYNDICATO (Armas)
    -- ========================================================================
    syndicato = {
        nome = 'Syndicato',
        tipo = 'armas',
        cor = '#4B0082',
        icone = '⚔️',
        logo = 'syndicato.png',
        
        baus = {
            lider = {
                coords = vector3(1399.56, 1132.20, 117.49),
                label = 'Baú Líder Syndicato',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 5
            },
            membros = {
                coords = vector3(1401.97, 1132.16, 114.34),
                label = 'Baú Membros Syndicato',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 14,
                markerZOffset = 0.0,   -- marcador mais baixo (no chão)
                textZOffset = 0.85    -- notificação um pouco mais alta que o marcador
            }
        },
        
        garagem = {
            coords = vector3(1373.19, 1151.37, 113.76),
            spawn = vector4(1373.19, 1151.37, 113.76, 88.45),
            label = 'Garagem Syndicato',
            blipColor = 19
        },
        
        cargos = {
            [1] = { nome = 'Líder 00', permissoes = {'all'} },
            [2] = { nome = 'Líder 01', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [3] = { nome = 'Líder 02', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [4] = { nome = 'Líder 03', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Gerente Geral', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [6] = { nome = 'Gerente de Farm', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [7] = { nome = 'Gerente de Pista', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [8] = { nome = 'Gerente de Recrutamento', permissoes = {'recrutar', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [9] = { nome = 'Supervisor', permissoes = {'recrutar', 'bau_lider', 'bau_membros', 'garagem', 'craft'} },
            [10] = { nome = 'Recrutador', permissoes = {'recrutar', 'bau_membros'} },
            [11] = { nome = 'Elite', permissoes = {'bau_membros'} },
            [12] = { nome = 'Membro Verificado', permissoes = {'bau_membros'} },
            [13] = { nome = 'Membro', permissoes = {'bau_membros'} },
            [14] = { nome = 'Novato', permissoes = {'bau_membros'} }
        }
    },

    -- ========================================================================
    -- FACÇÃO VANILLA (Lavagem)
    -- ========================================================================
    vanilla = {
        nome = 'Vanilla',
        tipo = 'lavagem',
        cor = '#FFD700',
        icone = '💰',
        logo = 'vanilla.png',
        
        baus = {
            lider = {
                coords = vector3(132.51, -1304.79, 29.20),
                label = 'Baú Líder Vanilla',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(130.0, -1304.0, 29.20),
                label = 'Baú Membros Vanilla',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(135.0, -1310.0, 29.20),
            spawn = vector4(140.0, -1315.0, 29.20, 180.0),
            label = 'Garagem Vanilla',
            blipColor = 46
        },
        
        cargos = {
            [1] = { nome = 'CEO', permissoes = {'all'} },
            [2] = { nome = 'Diretor', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem'} },
            [3] = { nome = 'Gerente', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Supervisor', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Coordenador', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Funcionário VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Funcionário V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Funcionário IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Funcionário III', permissoes = {'craft'} },
            [10] = { nome = 'Funcionário II', permissoes = {'craft'} },
            [11] = { nome = 'Funcionário I', permissoes = {'craft'} },
            [12] = { nome = 'Estagiário V', permissoes = {'craft'} },
            [13] = { nome = 'Estagiário IV', permissoes = {'craft'} },
            [14] = { nome = 'Estagiário III', permissoes = {'craft'} },
            [15] = { nome = 'Estagiário II', permissoes = {} },
            [16] = { nome = 'Estagiário I', permissoes = {} },
            [17] = { nome = 'Trainee IV', permissoes = {} },
            [18] = { nome = 'Trainee III', permissoes = {} },
            [19] = { nome = 'Trainee II', permissoes = {} },
            [20] = { nome = 'Trainee I', permissoes = {} }
        }
    },

    -- ========================================================================
    -- FACÇÃO TEQUILA (Lavagem)
    -- ========================================================================
    tequila = {
        nome = 'Tequila',
        tipo = 'lavagem',
        cor = '#228B22',
        icone = '🍹',
        logo = 'tequila.png',
        
        baus = {
            lider = {
                coords = vector3(-565.0, 276.0, 83.0),
                label = 'Baú Líder Tequila',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(-567.0, 276.0, 83.0),
                label = 'Baú Membros Tequila',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(-560.0, 280.0, 83.0),
            spawn = vector4(-555.0, 285.0, 83.0, 270.0),
            label = 'Garagem Tequila',
            blipColor = 2
        },
        
        cargos = {
            [1] = { nome = 'El Jefe', permissoes = {'all'} },
            [2] = { nome = 'Segundo', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem'} },
            [3] = { nome = 'Capo', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Sicario', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Membro VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Membro V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Membro IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Membro III', permissoes = {'craft'} },
            [10] = { nome = 'Membro II', permissoes = {'craft'} },
            [11] = { nome = 'Membro I', permissoes = {'craft'} },
            [12] = { nome = 'Recruta V', permissoes = {'craft'} },
            [13] = { nome = 'Recruta IV', permissoes = {'craft'} },
            [14] = { nome = 'Recruta III', permissoes = {'craft'} },
            [15] = { nome = 'Recruta II', permissoes = {} },
            [16] = { nome = 'Recruta I', permissoes = {} },
            [17] = { nome = 'Novato IV', permissoes = {} },
            [18] = { nome = 'Novato III', permissoes = {} },
            [19] = { nome = 'Novato II', permissoes = {} },
            [20] = { nome = 'Novato I', permissoes = {} }
        }
    },

    -- ========================================================================
    -- FACÇÃO BAHAMAS (Lavagem)
    -- ========================================================================
    bahamas = {
        nome = 'Bahamas',
        tipo = 'lavagem',
        cor = '#00BFFF',
        icone = '🏝️',
        logo = 'bahamas.png',
        
        baus = {
            lider = {
                coords = vector3(-1388.0, -586.0, 30.0),
                label = 'Baú Líder Bahamas',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(-1390.0, -586.0, 30.0),
                label = 'Baú Membros Bahamas',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(-1385.0, -590.0, 30.0),
            spawn = vector4(-1380.0, -595.0, 30.0, 0.0),
            label = 'Garagem Bahamas',
            blipColor = 26
        },
        
        cargos = {
            [1] = { nome = 'Magnata', permissoes = {'all'} },
            [2] = { nome = 'Investidor', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem'} },
            [3] = { nome = 'Gestor', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Contador', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Analista', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Funcionário VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Funcionário V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Funcionário IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Funcionário III', permissoes = {'craft'} },
            [10] = { nome = 'Funcionário II', permissoes = {'craft'} },
            [11] = { nome = 'Funcionário I', permissoes = {'craft'} },
            [12] = { nome = 'Estagiário V', permissoes = {'craft'} },
            [13] = { nome = 'Estagiário IV', permissoes = {'craft'} },
            [14] = { nome = 'Estagiário III', permissoes = {'craft'} },
            [15] = { nome = 'Estagiário II', permissoes = {} },
            [16] = { nome = 'Estagiário I', permissoes = {} },
            [17] = { nome = 'Trainee IV', permissoes = {} },
            [18] = { nome = 'Trainee III', permissoes = {} },
            [19] = { nome = 'Trainee II', permissoes = {} },
            [20] = { nome = 'Trainee I', permissoes = {} }
        }
    },

    -- ========================================================================
    -- FACÇÃO INCAS (Muambas)
    -- ========================================================================
    incas = {
        nome = 'Incas',
        tipo = 'muambas',
        cor = '#DAA520',
        icone = '📦',
        logo = 'incas.png',
        
        baus = {
            lider = {
                coords = vector3(-850.0, 165.0, 65.0),
                label = 'Baú Líder Incas',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(-852.0, 165.0, 65.0),
                label = 'Baú Membros Incas',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(-845.0, 170.0, 65.0),
            spawn = vector4(-840.0, 175.0, 65.0, 180.0),
            label = 'Garagem Incas',
            blipColor = 47
        },
        
        cargos = {
            [1] = { nome = 'Imperador', permissoes = {'all'} },
            [2] = { nome = 'Príncipe', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem'} },
            [3] = { nome = 'General', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Comandante', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Capitão', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Guerreiro VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Guerreiro V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Guerreiro IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Guerreiro III', permissoes = {'craft'} },
            [10] = { nome = 'Guerreiro II', permissoes = {'craft'} },
            [11] = { nome = 'Guerreiro I', permissoes = {'craft'} },
            [12] = { nome = 'Aprendiz V', permissoes = {'craft'} },
            [13] = { nome = 'Aprendiz IV', permissoes = {'craft'} },
            [14] = { nome = 'Aprendiz III', permissoes = {'craft'} },
            [15] = { nome = 'Aprendiz II', permissoes = {} },
            [16] = { nome = 'Aprendiz I', permissoes = {} },
            [17] = { nome = 'Novato IV', permissoes = {} },
            [18] = { nome = 'Novato III', permissoes = {} },
            [19] = { nome = 'Novato II', permissoes = {} },
            [20] = { nome = 'Novato I', permissoes = {} }
        }
    },

    -- ========================================================================
    -- FACÇÃO MAFIA (Desmanche)
    -- ========================================================================
    mafia = {
        nome = 'Máfia',
        tipo = 'desmanche',
        cor = '#2F4F4F',
        icone = '🔧',
        logo = 'mafia.png',
        
        baus = {
            lider = {
                coords = vector3(473.81, -1313.64, 29.21),
                label = 'Baú Líder Máfia',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(487.11, -1322.03, 29.20),
                label = 'Baú Membros Máfia',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(480.0, -1305.0, 29.0),
            spawn = vector4(485.0, -1300.0, 29.0, 90.0),
            label = 'Garagem Máfia',
            blipColor = 0
        },
        
        cargos = {
            [1] = { nome = 'Don', permissoes = {'all'} },
            [2] = { nome = 'Underboss', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem'} },
            [3] = { nome = 'Consigliere', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Caporegime', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Soldato', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Associato VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Associato V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Associato IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Associato III', permissoes = {'craft'} },
            [10] = { nome = 'Associato II', permissoes = {'craft'} },
            [11] = { nome = 'Associato I', permissoes = {'craft'} },
            [12] = { nome = 'Picciotto V', permissoes = {'craft'} },
            [13] = { nome = 'Picciotto IV', permissoes = {'craft'} },
            [14] = { nome = 'Picciotto III', permissoes = {'craft'} },
            [15] = { nome = 'Picciotto II', permissoes = {} },
            [16] = { nome = 'Picciotto I', permissoes = {} },
            [17] = { nome = 'Giovane IV', permissoes = {} },
            [18] = { nome = 'Giovane III', permissoes = {} },
            [19] = { nome = 'Giovane II', permissoes = {} },
            [20] = { nome = 'Giovane I', permissoes = {} }
        }
    },

    -- ========================================================================
    -- FACÇÃO HACKERS (Cartões)
    -- ========================================================================
    hackers = {
        nome = 'Hackers',
        tipo = 'cartoes',
        cor = '#00FF00',
        icone = '💳',
        logo = 'hackers.png',
        
        baus = {
            lider = {
                coords = vector3(712.0, -967.0, 30.0),
                label = 'Baú Líder Hackers',
                slots = 100,
                maxweight = 25000000, -- 25000 kg
                permissao = 2
            },
            membros = {
                coords = vector3(710.0, -967.0, 30.0),
                label = 'Baú Membros Hackers',
                slots = 50,
                maxweight = 15000000, -- 15000 kg
                permissao = 20
            }
        },
        
        garagem = {
            coords = vector3(715.0, -962.0, 30.0),
            spawn = vector4(720.0, -957.0, 30.0, 270.0),
            label = 'Garagem Hackers',
            blipColor = 2
        },
        
        cargos = {
            [1] = { nome = 'Admin Root', permissoes = {'all'} },
            [2] = { nome = 'Sysadmin', permissoes = {'gerenciar_membros', 'bau_lider', 'garagem'} },
            [3] = { nome = 'Developer', permissoes = {'bau_lider', 'garagem', 'craft'} },
            [4] = { nome = 'Hacker Elite', permissoes = {'bau_membros', 'garagem', 'craft'} },
            [5] = { nome = 'Hacker', permissoes = {'bau_membros', 'craft'} },
            [6] = { nome = 'Cracker VI', permissoes = {'bau_membros', 'craft'} },
            [7] = { nome = 'Cracker V', permissoes = {'bau_membros', 'craft'} },
            [8] = { nome = 'Cracker IV', permissoes = {'bau_membros', 'craft'} },
            [9] = { nome = 'Cracker III', permissoes = {'craft'} },
            [10] = { nome = 'Cracker II', permissoes = {'craft'} },
            [11] = { nome = 'Cracker I', permissoes = {'craft'} },
            [12] = { nome = 'Script Kiddie V', permissoes = {'craft'} },
            [13] = { nome = 'Script Kiddie IV', permissoes = {'craft'} },
            [14] = { nome = 'Script Kiddie III', permissoes = {'craft'} },
            [15] = { nome = 'Script Kiddie II', permissoes = {} },
            [16] = { nome = 'Script Kiddie I', permissoes = {} },
            [17] = { nome = 'Noob IV', permissoes = {} },
            [18] = { nome = 'Noob III', permissoes = {} },
            [19] = { nome = 'Noob II', permissoes = {} },
            [20] = { nome = 'Noob I', permissoes = {} }
        }
    },

    -- ============================================================================
    -- FACÇÕES ADICIONAIS (completadas automaticamente)
    -- ============================================================================
    lostmc = {
        nome = 'The Lost MC', tipo = 'desmanche', cor = '#8B4513', icone = '🔧', logo = 'lostmc.png',
        radioChannel = 30,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(1036.10, -2546.74, 32.29), label = 'Baú Líder Lost MC', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(1001.24, -2550.04, 28.29), label = 'Baú Membros Lost MC', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(1030.27, -2488.31, 28.53), spawn = vector4(1030.27, -2488.31, 28.53, 152.25), label = 'Garagem Lost MC', blipColor = 1 },
        cargos = { [1] = { nome = 'Presidente', permissoes = {'all'} }, [2] = { nome = 'Vice-Presidente', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Sargento', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Membro', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Prospect', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Hangaround', permissoes = {'bau_membros'} } }
    },
    bikers = {
        nome = 'Bikers', tipo = 'desmanche', cor = '#2C3E50', icone = '🔧', logo = 'bikers.png',
        radioChannel = 31,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-2184.27, 4299.41, 53.58), label = 'Baú Líder Bikers', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-2185.09, 4281.05, 49.18), label = 'Baú Membros Bikers', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-2209.49, 4280.71, 48.06), spawn = vector4(-2209.49, 4283.71, 48.06, 180.0), label = 'Garagem Bikers', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    obsidians = {
        nome = 'Obsidians', tipo = 'cartoes', cor = '#9B59B6', icone = '💳', logo = 'obsidians.png',
        radioChannel = 32,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-1616.94, 75.77, 61.47), label = 'Baú Líder Obsidians', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-1612.94, 75.77, 61.47), label = 'Baú Membros Obsidians', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-1614.94, 80.77, 61.47), spawn = vector4(-1614.94, 83.77, 61.47, 180.0), label = 'Garagem Obsidians', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    orcs = {
        nome = 'Orcs', tipo = 'cartoes', cor = '#9B59B6', icone = '💳', logo = 'orcs.png',
        radioChannel = 33,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-963.05, -1480.73, 5.17), label = 'Baú Líder Orcs', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-959.05, -1480.73, 5.17), label = 'Baú Membros Orcs', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-961.05, -1475.73, 5.17), spawn = vector4(-961.05, -1472.73, 5.17, 180.0), label = 'Garagem Orcs', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    raptors = {
        nome = 'Raptors', tipo = 'cartoes', cor = '#9B59B6', icone = '💳', logo = 'raptors.png',
        radioChannel = 34,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-3126.46, 803.19, 17.77), label = 'Baú Líder Raptors', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-3122.46, 803.19, 17.77), label = 'Baú Membros Raptors', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-3124.46, 808.19, 17.77), spawn = vector4(-3124.46, 811.19, 17.77, 180.0), label = 'Garagem Raptors', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    crocodile = {
        nome = 'Crocodile', tipo = 'muambas', cor = '#F39C12', icone = '📦', logo = 'crocodile.png',
        radioChannel = 35,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-1798.75, 475.31, 133.83), label = 'Baú Líder Crocodile', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-1794.75, 475.31, 133.83), label = 'Baú Membros Crocodile', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-1796.75, 480.31, 133.83), spawn = vector4(-1796.75, 483.31, 133.83, 180.0), label = 'Garagem Crocodile', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    hydra = {
        nome = 'Hydra', tipo = 'muambas', cor = '#F39C12', icone = '📦', logo = 'hydra.png',
        radioChannel = 36,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(13.55, 549.94, 176.10), label = 'Baú Líder Hydra', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(9.55, 549.94, 176.10), label = 'Baú Membros Hydra', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(11.55, 554.94, 176.10), spawn = vector4(11.55, 557.94, 176.10, 180.0), label = 'Garagem Hydra', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    brasil = {
        nome = 'Tropa do Brasil', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'brasil.png',
        radioChannel = 37,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(1291.66, -714.23, 64.67), label = 'Baú Líder Brasil', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(1287.66, -714.23, 64.67), label = 'Baú Membros Brasil', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(1289.66, -709.23, 64.67), spawn = vector4(1289.66, -706.23, 64.67, 180.0), label = 'Garagem Brasil', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    portugal = {
        nome = 'Tropa de Portugal', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'portugal.png',
        radioChannel = 38,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(2391.47, 3799.90, 37.97), label = 'Baú Líder Portugal', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(2387.47, 3799.90, 37.97), label = 'Baú Membros Portugal', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(2389.47, 3804.90, 37.97), spawn = vector4(2389.47, 3807.90, 37.97, 180.0), label = 'Garagem Portugal', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    argentina = {
        nome = 'Tropa da Argentina', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'argentina.png',
        radioChannel = 39,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(1256.23, -1291.83, 35.32), label = 'Baú Líder Argentina', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(1252.23, -1291.83, 35.32), label = 'Baú Membros Argentina', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(1254.23, -1286.83, 35.32), spawn = vector4(1254.23, -1283.83, 35.32, 180.0), label = 'Garagem Argentina', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    colombia = {
        nome = 'Tropa da Colômbia', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'colombia.png',
        radioChannel = 40,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(1013.13, 904.86, 211.22), label = 'Baú Líder Colômbia', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(1009.13, 904.86, 211.22), label = 'Baú Membros Colômbia', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(1011.13, 909.86, 211.22), spawn = vector4(1011.13, 912.86, 211.22, 180.0), label = 'Garagem Colômbia', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    franca = {
        nome = 'Tropa da França', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'franca.png',
        radioChannel = 41,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-2540.71, 1886.33, 167.11), label = 'Baú Líder França', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-2536.71, 1886.33, 167.11), label = 'Baú Membros França', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-2538.71, 1891.33, 167.11), spawn = vector4(-2538.71, 1894.33, 167.11, 180.0), label = 'Garagem França', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    grecia = {
        nome = 'Tropa da Grécia', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'grecia.png',
        radioChannel = 42,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(3045.88, 2868.79, 84.19), label = 'Baú Líder Grécia', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(3041.88, 2868.79, 84.19), label = 'Baú Membros Grécia', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(3043.88, 2873.79, 84.19), spawn = vector4(3043.88, 2876.79, 84.19, 180.0), label = 'Garagem Grécia', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    canada = {
        nome = 'Tropa do Canadá', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'canada.png',
        radioChannel = 43,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(1312.82, -2586.52, 47.23), label = 'Baú Líder Canadá', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(1308.82, -2586.52, 47.23), label = 'Baú Membros Canadá', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(1310.82, -2581.52, 47.23), spawn = vector4(1310.82, -2578.52, 47.23, 180.0), label = 'Garagem Canadá', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    chile = {
        nome = 'Tropa do Chile', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'chile.png',
        radioChannel = 44,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(1884.49, 466.44, 171.15), label = 'Baú Líder Chile', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(1880.49, 466.44, 171.15), label = 'Baú Membros Chile', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(1882.49, 471.44, 171.15), spawn = vector4(1882.49, 474.44, 171.15, 180.0), label = 'Garagem Chile', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    japao = {
        nome = 'Tropa do Japão', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'japao.png',
        radioChannel = 45,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-3112.71, 1324.68, 20.20), label = 'Baú Líder Japão', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-3108.71, 1324.68, 20.20), label = 'Baú Membros Japão', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-3110.71, 1329.68, 20.20), spawn = vector4(-3110.71, 1332.68, 20.20, 180.0), label = 'Garagem Japão', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    jamaica = {
        nome = 'Tropa da Jamaica', tipo = 'drogas', cor = '#1ABC9C', icone = '🌿', logo = 'jamaica.png',
        radioChannel = 46,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-286.48, 1501.68, 336.67), label = 'Baú Líder Jamaica', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-282.48, 1501.68, 336.67), label = 'Baú Membros Jamaica', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-284.48, 1506.68, 336.67), spawn = vector4(-284.48, 1509.68, 336.67, 180.0), label = 'Garagem Jamaica', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    ballas = {
        nome = 'Ballas', tipo = 'armas', cor = '#8E44AD', icone = '🔫', logo = 'ballas.png',
        radioChannel = 47,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(91.78, -1959.64, 20.75), label = 'Baú Líder Ballas', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(87.78, -1959.64, 20.75), label = 'Baú Membros Ballas', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(89.78, -1954.64, 20.75), spawn = vector4(89.78, -1951.64, 20.75, 180.0), label = 'Garagem Ballas', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    vagos = {
        nome = 'Vagos', tipo = 'armas', cor = '#F1C40F', icone = '🔫', logo = 'vagos.png',
        radioChannel = 48,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(339.36, -2043.75, 20.99), label = 'Baú Líder Vagos', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(335.36, -2043.75, 20.99), label = 'Baú Membros Vagos', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(337.36, -2038.75, 20.99), spawn = vector4(337.36, -2035.75, 20.99, 180.0), label = 'Garagem Vagos', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    cartel = {
        nome = 'Cartel', tipo = 'desmanche', cor = '#C0392B', icone = '🔧', logo = 'cartel.png',
        radioChannel = 49,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(1395.85, 3612.28, 38.94), label = 'Baú Líder Cartel', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(1391.85, 3612.28, 38.94), label = 'Baú Membros Cartel', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(1393.85, 3617.28, 38.94), spawn = vector4(1393.85, 3620.28, 38.94, 180.0), label = 'Garagem Cartel', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    families = {
        nome = 'Families', tipo = 'armas', cor = '#27AE60', icone = '🔫', logo = 'families.png',
        radioChannel = 50,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-153.17, -1641.76, 33.58), label = 'Baú Líder Families', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-149.17, -1641.76, 33.58), label = 'Baú Membros Families', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-151.17, -1636.76, 33.58), spawn = vector4(-151.17, -1633.76, 33.58, 180.0), label = 'Garagem Families', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
    triads = {
        nome = 'Triads', tipo = 'muambas', cor = '#E67E22', icone = '📦', logo = 'triads.png',
        radioChannel = 51,
        raioInteracaoBau = 3.0, raioInteracaoBauLider = 3.0, raioTextoBau = 5.0, raioTextoBauLider = 5.0,
        baus = {
            lider = { coords = vector3(-831.38, -705.06, 27.30), label = 'Baú Líder Triads', slots = 50, maxweight = 500000, permissao = 2 },
            membros = { coords = vector3(-827.38, -705.06, 27.30), label = 'Baú Membros Triads', slots = 100, maxweight = 1000000, permissao = 0 },
        },
        garagem = { coords = vector3(-829.38, -700.06, 27.30), spawn = vector4(-829.38, -697.06, 27.30, 180.0), label = 'Garagem Triads', blipColor = 1 },
        cargos = { [1] = { nome = 'Líder', permissoes = {'all'} }, [2] = { nome = 'Sub-Líder', permissoes = {'gerenciar_membros', 'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [3] = { nome = 'Capitão', permissoes = {'bau_lider', 'bau_membros', 'garagem', 'craft'} }, [4] = { nome = 'Soldado', permissoes = {'bau_membros', 'garagem', 'craft'} }, [5] = { nome = 'Recruta', permissoes = {'bau_membros', 'craft'} }, [6] = { nome = 'Novato', permissoes = {'bau_membros'} } }
    },
}

-- ============================================================================
-- VEÍCULOS DAS FACÇÕES (Santa: membro = só lista membros; gerente = membros + VIP)
-- ============================================================================
-- Por facção: membros = veículos que quem tem só "membro" pode pegar; vip = extras para quem tem bau_lider (gerente/00).
-- Gerente vê membros + vip. Membro vê só membros.
Config.VeiculosFaccao = {
    egito = {
        membros = {'sultan', 'kuruma'},
        vip = {'schafter2', 'zentorno', 'adder'}
    },
    brooklyn = {
        membros = {'baller', 'dubsta'},
        vip = {'cavalcade', 'baller2', 'cognoscenti'}
    },
    turquia = {
        membros = {'sultan', 'elegy'},
        vip = {'jester', 'ninef', 'paragon'}
    },
    cupula = {
        membros = {'sultan', 'elegy'},
        vip = {'zentorno', 'adder', 't20'}
    },
    rhinos = {
        membros = {'insurgent', 'nightshark'},
        vip = {'insurgent2', 'menacer', 'technical'}
    },
    pelicans = {
        membros = {'baller2', 'xls'},
        vip = {'baller3', 'schafter2', 'cognoscenti'}
    },
    syndicato = {
        membros = {'schafter3', 'cognoscenti'},
        vip = {'schafter4', 'schafter5', 'superd'}
    },
    vanilla = {
        membros = {'windsor', 'superd'},
        vip = {'windsor2', 'ztype', 'viseris'}
    },
    tequila = {
        membros = {'dubsta2', 'mesa'},
        vip = {'brawler', 'dubsta', 'granger'}
    },
    bahamas = {
        membros = {'toros', 'novak'},
        vip = {'rebla', 'sugoi', 'jugular'}
    },
    incas = {
        membros = {'mule', 'boxville'},
        vip = {'mule2', 'pounder', 'phantom'}
    },
    mafia = {
        membros = {'zion', 'exemplar'},
        vip = {'feltzer3', 'sentinel2', 'oracle2'}
    },
    hackers = {
        membros = {'neon', 'voltic'},
        vip = {'cyclone', 'tezeract', 'neon'}
    },
    lostmc = { membros = {'daemon', 'hexer'}, vip = {'nightblade', 'wolfsbane', 'ratbike'} },
    bikers = { membros = {'avarus', 'daemon'}, vip = {'sanctus', 'zombiea', 'zombieb'} },
    obsidians = { membros = {'sultan', 'kuruma'}, vip = {'jester', 'elegy2', 'comet2'} },
    orcs = { membros = {'baller', 'dubsta'}, vip = {'insurgent', 'nightshark', 'menacer'} },
    raptors = { membros = {'sultan', 'elegy'}, vip = {'zentorno', 't20', 'osiris'} },
    crocodile = { membros = {'baller2', 'xls'}, vip = {'toros', 'novak', 'rebla'} },
    hydra = { membros = {'schafter3', 'cognoscenti'}, vip = {'schafter4', 'superd', 'windsor'} },
    brasil = { membros = {'sultan', 'kuruma'}, vip = {'jester', 'elegy2', 'zentorno'} },
    portugal = { membros = {'sultan', 'elegy'}, vip = {'comet2', 'jester2', 'ninef'} },
    argentina = { membros = {'baller', 'dubsta'}, vip = {'toros', 'novak', 'jugular'} },
    colombia = { membros = {'sultan', 'kuruma'}, vip = {'zentorno', 't20', 'entityxf'} },
    franca = { membros = {'schafter3', 'cognoscenti'}, vip = {'windsor2', 'superd', 'ztype'} },
    grecia = { membros = {'sultan', 'elegy'}, vip = {'jester', 'comet2', 'ninef'} },
    canada = { membros = {'baller', 'dubsta'}, vip = {'insurgent', 'nightshark', 'barrage'} },
    chile = { membros = {'sultan', 'kuruma'}, vip = {'zentorno', 'adder', 't20'} },
    japao = { membros = {'sultan', 'elegy'}, vip = {'jester2', 'comet5', 'pariah'} },
    jamaica = { membros = {'baller', 'dubsta'}, vip = {'toros', 'novak', 'rebla'} },
    ballas = { membros = {'sultan', 'kuruma'}, vip = {'zentorno', 'adder', 'entityxf'} },
    vagos = { membros = {'sultan', 'elegy'}, vip = {'jester', 't20', 'osiris'} },
    cartel = { membros = {'insurgent', 'nightshark'}, vip = {'insurgent2', 'menacer', 'barrage'} },
    families = { membros = {'sultan', 'kuruma'}, vip = {'zentorno', 'jester', 'comet2'} },
    triads = { membros = {'schafter3', 'cognoscenti'}, vip = {'schafter4', 'superd', 'windsor'} },
}
