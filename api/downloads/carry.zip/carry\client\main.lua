-- ============================================================
-- Medellin ROLEPLAY — Sistema de Segurar/Carregar Pessoas
-- Tecla H — Funciona para TODOS os jogadores
-- ============================================================

-- ======================== STATE ========================

local isCarrying = false       -- estou carregando/segurando alguem
local isBeingCarried = false   -- estou sendo carregado/segurado
local carriedBy = nil          -- serverId de quem me carrega
local carryingPlayer = nil     -- serverId de quem estou carregando
local carryMode = nil          -- 'hostage' | 'carry' | 'escort'

-- ======================== CONFIG ========================

local MAX_DIST = 2.5

-- ======================== KEYBIND ========================

RegisterKeyMapping('segurar', 'Segurar/Carregar Pessoa', 'keyboard', 'H')

RegisterCommand('segurar', function()
    if isBeingCarried then return end
    if IsPedInAnyVehicle(PlayerPedId(), false) then return end

    if isCarrying then
        -- Soltar pessoa
        TriggerServerEvent('medellin-carry:server:release', carryingPlayer)
        return
    end

    -- Encontrar jogador mais proximo
    local closestPlayer, closestPed, closestDist = getClosestPlayer()
    if not closestPlayer then
        lib.notify({ title = 'Segurar', description = 'Nenhum jogador proximo', type = 'error' })
        return
    end

    local targetServerId = GetPlayerServerId(closestPlayer)

    -- Determinar modo baseado no estado do alvo
    TriggerServerEvent('medellin-carry:server:requestCarry', targetServerId)
end, false)

-- ======================== UTILS ========================

function getClosestPlayer()
    local myPed = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)
    local closestPlayer = nil
    local closestPed = nil
    local closestDist = MAX_DIST + 1

    local activePlayers = GetActivePlayers()
    for _, player in ipairs(activePlayers) do
        if player ~= PlayerId() then
            local ped = GetPlayerPed(player)
            if DoesEntityExist(ped) then
                local pedCoords = GetEntityCoords(ped)
                local dist = #(myCoords - pedCoords)
                if dist < closestDist then
                    closestDist = dist
                    closestPlayer = player
                    closestPed = ped
                end
            end
        end
    end

    if closestDist <= MAX_DIST then
        return closestPlayer, closestPed, closestDist
    end
    return nil, nil, nil
end

-- ======================== SERVER RESPONSES ========================

-- Servidor determinou o modo e aprovou
RegisterNetEvent('medellin-carry:client:startCarrying', function(targetId, mode)
    local targetPlayer = GetPlayerFromServerId(targetId)
    if targetPlayer == -1 then return end

    local targetPed = GetPlayerPed(targetPlayer)
    if not DoesEntityExist(targetPed) then return end

    isCarrying = true
    carryingPlayer = targetId
    carryMode = mode

    if mode == 'hostage' then
        startHostageCarrier(targetPed)
    elseif mode == 'carry' then
        startFiremanCarrier(targetPed)
    elseif mode == 'escort' then
        startEscortCarrier(targetPed)
    -- piggyback movido pra medellin-piggyback
    elseif mode == 'bridal' then
        startBridalCarrier(targetPed)
    end

    -- Thread de seguranca: se eu morrer ou o alvo sumir, soltar
    CreateThread(function()
        while isCarrying do
            Wait(500)
            local myPed = PlayerPedId()
            local tp = GetPlayerFromServerId(carryingPlayer)

            if IsEntityDead(myPed) or tp == -1 or not DoesEntityExist(GetPlayerPed(tp)) then
                TriggerServerEvent('medellin-carry:server:release', carryingPlayer)
                break
            end
        end
    end)
end)

-- Eu estou sendo carregado/segurado
RegisterNetEvent('medellin-carry:client:beingCarried', function(carrierId, mode)
    local carrierPlayer = GetPlayerFromServerId(carrierId)
    if carrierPlayer == -1 then return end

    local carrierPed = GetPlayerPed(carrierPlayer)
    if not DoesEntityExist(carrierPed) then return end

    isBeingCarried = true
    carriedBy = carrierId
    carryMode = mode

    if mode == 'hostage' then
        startHostageVictim(carrierPed)
    elseif mode == 'carry' then
        startFiremanVictim(carrierPed)
    elseif mode == 'escort' then
        startEscortVictim(carrierPed)
    -- piggyback movido pra medellin-piggyback
    elseif mode == 'bridal' then
        startBridalVictim(carrierPed)
    end

    -- Thread: bloquear controles enquanto sendo carregado
    CreateThread(function()
        while isBeingCarried do
            Wait(1)
            DisableAllControlActions(0)
            EnableControlAction(0, 1, true)   -- Camera
            EnableControlAction(0, 2, true)   -- Camera
            EnableControlAction(0, 245, true) -- Chat
            EnableControlAction(0, 249, true) -- Push to talk
        end
    end)

    -- Thread de seguranca: se o carregador sumir, soltar
    CreateThread(function()
        while isBeingCarried do
            Wait(500)
            local cp = GetPlayerFromServerId(carriedBy)
            if cp == -1 or not DoesEntityExist(GetPlayerPed(cp)) then
                releaseMe()
                break
            end
        end
    end)
end)

-- Soltar
RegisterNetEvent('medellin-carry:client:released', function()
    if isCarrying then
        releaseCarrying()
    end
    if isBeingCarried then
        releaseMe()
    end
end)

-- ======================== HOSTAGE (Segurar como Refem) ========================

function startHostageCarrier(targetPed)
    -- Sem animacao, anda normal
end

function startHostageVictim(carrierPed)
    local myPed = PlayerPedId()
    -- Sem animacao, so gruda do lado
    AttachEntityToEntity(myPed, carrierPed, 11816, 0.55, 0.0, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, false)
end

-- ======================== FIREMAN CARRY (Carregar nas Costas) ========================

function startFiremanCarrier(targetPed)
    local myPed = PlayerPedId()
    lib.requestAnimDict('missfinale_c2mcs_1')
    TaskPlayAnim(myPed, 'missfinale_c2mcs_1', 'fin_c2_mcs_1_camman', 8.0, -8.0, -1, 49, 0, false, false, false)
end

function startFiremanVictim(carrierPed)
    local myPed = PlayerPedId()

    lib.requestAnimDict('nm')
    TaskPlayAnim(myPed, 'nm', 'firemans_carry', 8.0, -8.0, -1, 33, 0, false, false, false)

    -- Attach nas costas — rotZ=180 corrigido (rubbertoe98)
    AttachEntityToEntity(myPed, carrierPed, 0, 0.27, 0.15, 0.63, 0.5, 0.5, 180.0, false, false, false, false, 2, false)
end

-- ======================== ESCORT (Escortar Algemado) ========================

function startEscortCarrier(targetPed)
    -- Carregador nao precisa de animacao especial no escort, so anda normalmente
end

function startEscortVictim(carrierPed)
    local myPed = PlayerPedId()

    lib.requestAnimDict('mp_arresting')
    TaskPlayAnim(myPed, 'mp_arresting', 'idle', 8.0, -8.0, -1, 49, 0, false, false, false)

    -- Attach ao lado do carregador
    AttachEntityToEntity(myPed, carrierPed, 11816, 0.45, 0.45, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
end

-- ======================== RELEASE ========================

function releaseCarrying()
    if not isCarrying then return end

    local myPed = PlayerPedId()
    ClearPedTasks(myPed)
    ClearPedSecondaryTask(myPed)

    isCarrying = false
    carryingPlayer = nil
    carryMode = nil
end

function releaseMe()
    if not isBeingCarried then return end

    local myPed = PlayerPedId()
    DetachEntity(myPed, true, false)
    ClearPedTasks(myPed)
    ClearPedTasksImmediately(myPed)

    isBeingCarried = false
    carriedBy = nil
    carryMode = nil
end

-- ======================== /CARREGAR (qualquer jogador) ========================
-- /carregar = fireman carry (costas deitado)
-- /carregar 4 = cavalinho (piggyback)
-- /carregar 2 = bridal carry (colo)

RegisterCommand('carregar', function(source, args)
    if isBeingCarried then return end

    -- Cavalinho DESATIVADO temporariamente
    -- if args[1] == '4' then
    --     doPiggyback()
    --     return
    -- end

    if isCarrying then
        TriggerServerEvent('medellin-carry:server:release', carryingPlayer)
        return
    end

    local myPed = PlayerPedId()
    if IsPedInAnyVehicle(myPed, false) then
        lib.notify({ title = 'Carregar', description = 'Saia do veiculo primeiro', type = 'error' })
        return
    end

    local closestPlayer, closestPed, closestDist = getClosestPlayer()
    if not closestPlayer then
        lib.notify({ title = 'Carregar', description = 'Nenhum jogador proximo', type = 'error' })
        return
    end

    local targetServerId = GetPlayerServerId(closestPlayer)
    TriggerServerEvent('medellin-carry:server:requestCarregar', targetServerId)
end, false)

TriggerEvent('chat:addSuggestion', '/carregar', 'Carregar jogador | /carregar 4 = cavalinho')

-- Resposta do pedido de permissao (fireman carry)
RegisterNetEvent('medellin-carry:client:pedirPermissaoCarregar', function(carrierId, carrierName)
    local accepted = lib.alertDialog({
        header = 'Carregar',
        content = carrierName .. ' quer te carregar. Aceitar?',
        centered = true,
        cancel = true,
    })

    if accepted == 'confirm' then
        TriggerServerEvent('medellin-carry:server:carregarAceito', carrierId)
    else
        TriggerServerEvent('medellin-carry:server:carregarRecusado', carrierId)
    end
end)

-- ======================== CAVALINHO (piggyback) via /carregar 4 ========================

local piggybackData = {
    InProgress = false,
    targetSrc = -1,
    type = "",
    carrier = { animDict = "anim@arena@celeb@flat@paired@no_props@", anim = "piggyback_c_player_a", flag = 49 },
    carried = { animDict = "anim@gangops@hostage@", anim = "victim_idle", flag = 49 },
}

function doPiggyback()
    if piggybackData.InProgress then
        -- Soltar
        piggybackData.InProgress = false
        ClearPedSecondaryTask(PlayerPedId())
        DetachEntity(PlayerPedId(), true, false)
        TriggerServerEvent('medellin-carry:server:piggybackStop', piggybackData.targetSrc)
        piggybackData.targetSrc = -1
        return
    end

    local closestPlayer, closestPed = getClosestPlayer()
    if not closestPlayer then
        lib.notify({ title = 'Cavalinho', description = 'Ninguem perto', type = 'error' })
        return
    end

    local targetSrc = GetPlayerServerId(closestPlayer)
    piggybackData.targetSrc = targetSrc

    -- Morto/caido = direto
    if IsEntityDead(closestPed) or GetEntityHealth(closestPed) <= 100 then
        piggybackData.InProgress = true
        piggybackData.type = "carrier"
        TriggerServerEvent('medellin-carry:server:piggybackDirect', targetSrc)
        return
    end

    -- Vivo = pedir permissao
    TriggerServerEvent('medellin-carry:server:piggybackRequest', targetSrc)
    lib.notify({ title = 'Cavalinho', description = 'Aguardando aceitar...', type = 'inform' })
end

-- Alvo recebe pedido
RegisterNetEvent('medellin-carry:client:piggybackAsk', function(carrierSrc)
    local input = lib.alertDialog({
        header = 'Cavalinho',
        content = 'Um jogador quer te carregar no cavalinho. Aceitar?',
        centered = true,
        cancel = true,
    })
    if input == 'confirm' then
        TriggerServerEvent('medellin-carry:server:piggybackAccepted', carrierSrc)
    else
        TriggerServerEvent('medellin-carry:server:piggybackDeclined', carrierSrc)
    end
end)

-- Carrier: alvo aceitou
RegisterNetEvent('medellin-carry:client:piggybackStart', function()
    piggybackData.InProgress = true
    piggybackData.type = "carrier"
    -- Sem animacao no carrier, anda normal
end)

-- Alvo: attach no carrier
RegisterNetEvent('medellin-carry:client:piggybackAttach', function(carrierSrc)
    local carrierPed = GetPlayerPed(GetPlayerFromServerId(carrierSrc))
    piggybackData.InProgress = true
    piggybackData.type = "carried"
    -- Attach + animacao do carried (sentado com joelho dobrado)
    lib.requestAnimDict(piggybackData.carried.animDict)
    AttachEntityToEntity(PlayerPedId(), carrierPed, 11816, 0.0, -0.09, 0.0, 0.0, 0.0, -90.0, false, false, false, false, 2, false)
    TaskPlayAnim(PlayerPedId(), piggybackData.carried.animDict, piggybackData.carried.anim, 8.0, -8.0, -1, piggybackData.carried.flag, 0, false, false, false)
end)

-- Carrier: recusado
RegisterNetEvent('medellin-carry:client:piggybackDeclined', function()
    lib.notify({ title = 'Cavalinho', description = 'Jogador recusou', type = 'error' })
    piggybackData.targetSrc = -1
end)

-- Carrier: timeout
RegisterNetEvent('medellin-carry:client:piggybackTimeout', function()
    lib.notify({ title = 'Cavalinho', description = 'Jogador nao respondeu', type = 'error' })
    piggybackData.targetSrc = -1
end)

-- Parar cavalinho
RegisterNetEvent('medellin-carry:client:piggybackStop', function()
    piggybackData.InProgress = false
    ClearPedSecondaryTask(PlayerPedId())
    DetachEntity(PlayerPedId(), true, false)
end)

-- Anim loop do cavalinho
CreateThread(function()
    while true do
        if piggybackData.InProgress then
            local ped = PlayerPedId()
            if piggybackData.type == "carried" then
                if not IsEntityPlayingAnim(ped, piggybackData.carried.animDict, piggybackData.carried.anim, 3) then
                    TaskPlayAnim(ped, piggybackData.carried.animDict, piggybackData.carried.anim, 8.0, -8.0, -1, piggybackData.carried.flag, 0, false, false, false)
                end
            elseif piggybackData.type == "carrier" then
                -- Sem animacao, anda normal
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- ======================== /CARREGAR2 (bridal carry / colo / princesa) ========================

RegisterCommand('carregar2', function()
    if isBeingCarried then return end
    if isCarrying then
        TriggerServerEvent('medellin-carry:server:release', carryingPlayer)
        return
    end

    local myPed = PlayerPedId()
    if IsPedInAnyVehicle(myPed, false) then
        lib.notify({ title = 'Carregar', description = 'Saia do veiculo primeiro', type = 'error' })
        return
    end

    local closestPlayer, closestPed = getClosestPlayer()
    if not closestPlayer then
        lib.notify({ title = 'Carregar', description = 'Nenhum jogador proximo', type = 'error' })
        return
    end

    TriggerServerEvent('medellin-carry:server:requestBridal', GetPlayerServerId(closestPlayer))
end, false)

TriggerEvent('chat:addSuggestion', '/carregar2', 'Carregar jogador no colo (bridal carry)')

RegisterNetEvent('medellin-carry:client:pedirPermissaoBridal', function(carrierId, carrierName)
    local accepted = lib.alertDialog({
        header = 'Carregar no Colo',
        content = carrierName .. ' quer te carregar no colo. Aceitar?',
        centered = true,
        cancel = true,
    })
    if accepted == 'confirm' then
        TriggerServerEvent('medellin-carry:server:bridalAceito', carrierId)
    else
        TriggerServerEvent('medellin-carry:server:bridalRecusado', carrierId)
    end
end)

function startBridalCarrier(targetPed)
    local myPed = PlayerPedId()
    lib.requestAnimDict('anim@heists@box_carry@')
    TaskPlayAnim(myPed, 'anim@heists@box_carry@', 'idle', 8.0, -8.0, -1, 49, 0, false, false, false)
end

function startBridalVictim(carrierPed)
    local myPed = PlayerPedId()
    lib.requestAnimDict('amb@code_human_in_car_idles@generic@ps@base')
    TaskPlayAnim(myPed, 'amb@code_human_in_car_idles@generic@ps@base', 'base', 8.0, -8.0, -1, 33, 0, false, false, false)
    AttachEntityToEntity(myPed, carrierPed, 0, 0.27, 0.15, 0.63, 0.5, 0.5, 0.0, false, false, false, false, 2, true)
end

-- ======================== /CARREGARALGEMADO (fireman carry so algemado) ========================

RegisterCommand('carregaralgemado', function()
    if isBeingCarried then return end
    if isCarrying then
        TriggerServerEvent('medellin-carry:server:release', carryingPlayer)
        return
    end

    local myPed = PlayerPedId()
    if IsPedInAnyVehicle(myPed, false) then
        lib.notify({ title = 'Carregar', description = 'Saia do veiculo primeiro', type = 'error' })
        return
    end

    local closestPlayer, closestPed = getClosestPlayer()
    if not closestPlayer then
        lib.notify({ title = 'Carregar', description = 'Nenhum jogador proximo', type = 'error' })
        return
    end

    TriggerServerEvent('medellin-carry:server:requestCarryAlgemado', GetPlayerServerId(closestPlayer))
end, false)

TriggerEvent('chat:addSuggestion', '/carregaralgemado', 'Carregar jogador algemado nas costas')

-- ======================== /COLOCARNOVEICULO (policia — algemado pro banco de tras) ========================

RegisterCommand('colocarnoveiculo', function()
    local myPed = PlayerPedId()

    local closestPlayer, closestPed = getClosestPlayer()
    if not closestPlayer then
        lib.notify({ title = 'Veiculo', description = 'Nenhum jogador proximo', type = 'error' })
        return
    end

    -- Encontrar veiculo proximo
    local veh = lib.getClosestVehicle(GetEntityCoords(myPed), 5.0, true)
    if not veh or veh == 0 then
        lib.notify({ title = 'Veiculo', description = 'Nenhum veiculo proximo', type = 'error' })
        return
    end

    TriggerServerEvent('medellin-carry:server:colocarNoVeiculo', GetPlayerServerId(closestPlayer), NetworkGetNetworkIdFromEntity(veh))
end, false)

TriggerEvent('chat:addSuggestion', '/colocarnoveiculo', 'Colocar algemado no banco de tras (policia)')

RegisterNetEvent('medellin-carry:client:entrarVeiculo', function(vehNetId, seat)
    local veh = NetworkGetEntityFromNetworkId(vehNetId)
    if not veh or not DoesEntityExist(veh) then return end

    local myPed = PlayerPedId()
    ClearPedTasks(myPed)
    DetachEntity(myPed, true, false)
    Wait(200)
    TaskWarpPedIntoVehicle(myPed, veh, seat)
end)

-- ======================== /TIRARDOVEICULO (policia — tirar do veiculo) ========================

RegisterCommand('tirardoveiculo', function()
    local closestPlayer, closestPed = getClosestPlayer()
    if not closestPlayer then
        lib.notify({ title = 'Veiculo', description = 'Nenhum jogador proximo', type = 'error' })
        return
    end

    TriggerServerEvent('medellin-carry:server:tirarDoVeiculo', GetPlayerServerId(closestPlayer))
end, false)

TriggerEvent('chat:addSuggestion', '/tirardoveiculo', 'Tirar jogador do veiculo (policia)')

RegisterNetEvent('medellin-carry:client:sairVeiculo', function()
    local myPed = PlayerPedId()
    if IsPedInAnyVehicle(myPed, false) then
        local veh = GetVehiclePedIsIn(myPed, false)
        TaskLeaveVehicle(myPed, veh, 0)
    end
end)

-- ======================== /AJOELHAR (policia — forcar ajoelhar) ========================

local isKneeling = false

RegisterCommand('ajoelhar', function()
    local closestPlayer, closestPed = getClosestPlayer()
    if not closestPlayer then
        lib.notify({ title = 'Ajoelhar', description = 'Nenhum jogador proximo', type = 'error' })
        return
    end

    TriggerServerEvent('medellin-carry:server:ajoelhar', GetPlayerServerId(closestPlayer))
end, false)

TriggerEvent('chat:addSuggestion', '/ajoelhar', 'Forcar jogador a ajoelhar (policia)')

RegisterNetEvent('medellin-carry:client:ajoelhar', function(toggle)
    local myPed = PlayerPedId()

    if toggle then
        isKneeling = true
        lib.requestAnimDict('random@arrests')
        TaskPlayAnim(myPed, 'random@arrests', 'kneeling_arrest_idle', 8.0, -8.0, -1, 49, 0, false, false, false)

        CreateThread(function()
            while isKneeling do
                Wait(0)
                DisableAllControlActions(0)
                EnableControlAction(0, 1, true)
                EnableControlAction(0, 2, true)
                EnableControlAction(0, 245, true)
                EnableControlAction(0, 249, true)

                if not IsEntityPlayingAnim(myPed, 'random@arrests', 'kneeling_arrest_idle', 3) then
                    TaskPlayAnim(myPed, 'random@arrests', 'kneeling_arrest_idle', 8.0, -8.0, -1, 49, 0, false, false, false)
                end
            end
        end)
    else
        isKneeling = false
        ClearPedTasks(myPed)
    end
end)

-- ======================== BRIDAL/CARREGAR2 ANIMATIONS ========================
-- (startBridalCarrier e startBridalVictim ja definidos acima)
-- Adicionar modo 'bridal' no handler de startCarrying/beingCarried:

-- ======================== CLEANUP ========================

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    if isCarrying then releaseCarrying() end
    if isBeingCarried then releaseMe() end
    isKneeling = false
end)
