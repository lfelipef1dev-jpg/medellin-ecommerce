-- ============================================================
-- Medellin ROLEPLAY — Sistema de Segurar/Carregar Pessoas
-- Server-side: validacao e roteamento de eventos
-- ============================================================

local QBCore = exports['qb-core']:GetCoreObject()

-- Rastrear quem esta carregando quem
local carryPairs = {} -- carryPairs[carrierId] = targetId
local beingCarried = {} -- beingCarried[targetId] = carrierId

-- Jobs/grupos com permissao para carregar (igual Santa Group)
local CarryPermission = {
    -- Jobs
    ['police'] = true,
    ['ambulance'] = true,
    -- Grupos ACE
    ['admin'] = true,
    ['god'] = true,
}

local function hasCarryPermission(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end

    -- Verificar job
    local job = Player.PlayerData.job
    if job and job.name and CarryPermission[job.name] then
        return true
    end

    -- Verificar job type (leo = policia, ems = medico)
    if job and job.type then
        if job.type == 'leo' or job.type == 'ems' then
            return true
        end
    end

    -- Verificar permissao admin
    if QBCore.Functions.HasPermission(src, 'admin') or QBCore.Functions.HasPermission(src, 'god') then
        return true
    end

    return false
end

-- ======================== REQUEST ========================

RegisterNetEvent('medellin-carry:server:requestCarry', function(targetId)
    local src = source

    -- Verificar permissao (igual Santa Group: so policia, medico, admin)
    if not hasCarryPermission(src) then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Segurar',
            description = 'Apenas policia, medicos e admins podem carregar pessoas',
            type = 'error'
        })
        return
    end

    -- Validacoes basicas
    if src == targetId then return end
    if carryPairs[src] then return end
    if beingCarried[targetId] then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Segurar',
            description = 'Esta pessoa ja esta sendo segurada',
            type = 'error'
        })
        return
    end
    if beingCarried[src] then return end

    -- Verificar distancia
    local srcPed = GetPlayerPed(src)
    local targetPed = GetPlayerPed(targetId)
    if not srcPed or not targetPed then return end
    if srcPed == 0 or targetPed == 0 then return end

    local srcCoords = GetEntityCoords(srcPed)
    local targetCoords = GetEntityCoords(targetPed)
    local dist = #(srcCoords - targetCoords)

    if dist > 3.0 then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Segurar',
            description = 'Jogador muito longe',
            type = 'error'
        })
        return
    end

    -- Determinar modo
    local targetPlayer = exports['qb-core']:GetPlayer(targetId)
    if not targetPlayer then return end

    local mode = 'hostage'

    local metadata = targetPlayer.PlayerData.metadata
    if metadata.isdead or metadata.inlaststand then
        mode = 'carry'
    elseif metadata.ishandcuffed then
        mode = 'escort'
    end

    -- Registrar o par
    carryPairs[src] = targetId
    beingCarried[targetId] = src

    -- Notificar ambos os lados
    TriggerClientEvent('medellin-carry:client:startCarrying', src, targetId, mode)
    TriggerClientEvent('medellin-carry:client:beingCarried', targetId, src, mode)

    -- Log
    local srcName = GetPlayerName(src) or 'Desconhecido'
    local targetName = GetPlayerName(targetId) or 'Desconhecido'
    -- print(('[medellin-carry] %s (ID:%d) modo: %s -> %s (ID:%d)'):format(srcName, src, mode, targetName, targetId))
end)

-- ======================== RELEASE ========================

RegisterNetEvent('medellin-carry:server:release', function(targetId)
    local src = source
    if not targetId then return end

    -- Verificar se realmente esta carregando essa pessoa
    if carryPairs[src] ~= targetId then
        return
    end

    -- Limpar registros
    carryPairs[src] = nil
    beingCarried[targetId] = nil

    -- Notificar ambos
    TriggerClientEvent('medellin-carry:client:released', src)
    TriggerClientEvent('medellin-carry:client:released', targetId)

    local srcName = GetPlayerName(src) or 'Desconhecido'
    local targetName = GetPlayerName(targetId) or 'Desconhecido'
    -- print(('[medellin-carry] %s (ID:%d) soltou %s (ID:%d)'):format(srcName, src, targetName, targetId))
end)

-- ======================== /CARREGAR (qualquer jogador) ========================

local carregarCooldown = {} -- carregarCooldown[src] = os.time()
local pendingCarregar = {}  -- pendingCarregar[targetId] = carrierId

RegisterNetEvent('medellin-carry:server:requestCarregar', function(targetId)
    local src = source
    if src == targetId then return end
    if carryPairs[src] then return end
    if beingCarried[targetId] then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Essa pessoa ja esta sendo carregada', type = 'error' })
        return
    end
    if beingCarried[src] then return end

    -- Cooldown 5 segundos
    if carregarCooldown[src] and os.time() < carregarCooldown[src] then
        local restante = carregarCooldown[src] - os.time()
        TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = ('Aguarde %d segundos'):format(restante), type = 'error' })
        return
    end
    carregarCooldown[src] = os.time() + 5

    -- Verificar distancia
    local srcPed = GetPlayerPed(src)
    local targetPed = GetPlayerPed(targetId)
    if not srcPed or srcPed == 0 or not targetPed or targetPed == 0 then return end

    local dist = #(GetEntityCoords(srcPed) - GetEntityCoords(targetPed))
    if dist > 3.0 then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Jogador muito longe', type = 'error' })
        return
    end

    local targetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not targetPlayer then return end

    local metadata = targetPlayer.PlayerData.metadata
    local targetDead = metadata.isdead or metadata.inlaststand

    -- Nome do carregador
    local srcPlayer = QBCore.Functions.GetPlayer(src)
    local charName = GetPlayerName(src) or 'Alguem'
    if srcPlayer and srcPlayer.PlayerData.charinfo then
        charName = (srcPlayer.PlayerData.charinfo.firstname or '') .. ' ' .. (srcPlayer.PlayerData.charinfo.lastname or '')
    end

    if targetDead then
        -- Caido/morto: carrega direto sem pedir permissao
        carryPairs[src] = targetId
        beingCarried[targetId] = src
        TriggerClientEvent('medellin-carry:client:startCarrying', src, targetId, 'carry')
        TriggerClientEvent('medellin-carry:client:beingCarried', targetId, src, 'carry')
        TriggerClientEvent('ox_lib:notify', targetId, { title = 'Carregar', description = charName .. ' te carregou', type = 'inform' })
    else
        -- De pe: pedir permissao
        pendingCarregar[targetId] = src
        TriggerClientEvent('medellin-carry:client:pedirPermissaoCarregar', targetId, src, charName)
        TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Aguardando jogador aceitar...', type = 'inform' })

        -- Timeout 15 segundos
        SetTimeout(15000, function()
            if pendingCarregar[targetId] == src then
                pendingCarregar[targetId] = nil
                TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Jogador nao respondeu', type = 'error' })
            end
        end)
    end
end)

RegisterNetEvent('medellin-carry:server:carregarAceito', function(carrierId)
    local targetId = source
    if pendingCarregar[targetId] ~= carrierId then return end
    pendingCarregar[targetId] = nil

    if carryPairs[carrierId] or beingCarried[targetId] then return end

    carryPairs[carrierId] = targetId
    beingCarried[targetId] = carrierId
    TriggerClientEvent('medellin-carry:client:startCarrying', carrierId, targetId, 'carry')
    TriggerClientEvent('medellin-carry:client:beingCarried', targetId, carrierId, 'carry')
end)

RegisterNetEvent('medellin-carry:server:carregarRecusado', function(carrierId)
    local targetId = source
    if pendingCarregar[targetId] ~= carrierId then return end
    pendingCarregar[targetId] = nil
    TriggerClientEvent('ox_lib:notify', carrierId, { title = 'Carregar', description = 'Jogador recusou ser carregado', type = 'error' })
end)

-- ======================== CAVALINHO (piggyback) via /carregar 4 ========================

local pendingPiggyback = {}

RegisterNetEvent('medellin-carry:server:piggybackRequest', function(targetId)
    local src = source
    if src == targetId then return end

    local srcPed = GetPlayerPed(src)
    local targetPed = GetPlayerPed(targetId)
    if not srcPed or srcPed == 0 or not targetPed or targetPed == 0 then return end
    if #(GetEntityCoords(srcPed) - GetEntityCoords(targetPed)) > 3.0 then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Cavalinho', description = 'Jogador muito longe', type = 'error' })
        return
    end

    pendingPiggyback[targetId] = src
    TriggerClientEvent('medellin-carry:client:piggybackAsk', targetId, src)

    SetTimeout(10000, function()
        if pendingPiggyback[targetId] == src then
            pendingPiggyback[targetId] = nil
            TriggerClientEvent('medellin-carry:client:piggybackTimeout', src)
        end
    end)
end)

RegisterNetEvent('medellin-carry:server:piggybackDirect', function(targetId)
    local src = source
    TriggerClientEvent('medellin-carry:client:piggybackAttach', targetId, src)
    TriggerClientEvent('medellin-carry:client:piggybackStart', src)
end)

RegisterNetEvent('medellin-carry:server:piggybackAccepted', function(carrierSrc)
    local targetId = source
    if pendingPiggyback[targetId] ~= carrierSrc then return end
    pendingPiggyback[targetId] = nil
    TriggerClientEvent('medellin-carry:client:piggybackAttach', targetId, carrierSrc)
    TriggerClientEvent('medellin-carry:client:piggybackStart', carrierSrc)
end)

RegisterNetEvent('medellin-carry:server:piggybackDeclined', function(carrierSrc)
    local targetId = source
    if pendingPiggyback[targetId] ~= carrierSrc then return end
    pendingPiggyback[targetId] = nil
    TriggerClientEvent('medellin-carry:client:piggybackDeclined', carrierSrc)
end)

RegisterNetEvent('medellin-carry:server:piggybackStop', function(targetSrc)
    TriggerClientEvent('medellin-carry:client:piggybackStop', targetSrc)
end)

-- ======================== /CARREGAR2 (bridal carry / colo) ========================

local pendingBridal = {}

RegisterNetEvent('medellin-carry:server:requestBridal', function(targetId)
    local src = source
    if src == targetId then return end
    if carryPairs[src] or beingCarried[targetId] or beingCarried[src] then return end

    if carregarCooldown[src] and os.time() < carregarCooldown[src] then return end
    carregarCooldown[src] = os.time() + 5

    local srcPed = GetPlayerPed(src)
    local targetPed = GetPlayerPed(targetId)
    if not srcPed or srcPed == 0 or not targetPed or targetPed == 0 then return end
    if #(GetEntityCoords(srcPed) - GetEntityCoords(targetPed)) > 3.0 then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Jogador muito longe', type = 'error' })
        return
    end

    local targetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not targetPlayer then return end
    local metadata = targetPlayer.PlayerData.metadata

    -- Se algemado, rendido ou morto: direto sem pedir
    if metadata.ishandcuffed or metadata.isdead or metadata.inlaststand then
        carryPairs[src] = targetId
        beingCarried[targetId] = src
        TriggerClientEvent('medellin-carry:client:startCarrying', src, targetId, 'bridal')
        TriggerClientEvent('medellin-carry:client:beingCarried', targetId, src, 'bridal')
        return
    end

    -- Pedir permissao
    local srcPlayer = QBCore.Functions.GetPlayer(src)
    local charName = GetPlayerName(src) or 'Alguem'
    if srcPlayer and srcPlayer.PlayerData.charinfo then
        charName = (srcPlayer.PlayerData.charinfo.firstname or '') .. ' ' .. (srcPlayer.PlayerData.charinfo.lastname or '')
    end

    pendingBridal[targetId] = src
    TriggerClientEvent('medellin-carry:client:pedirPermissaoBridal', targetId, src, charName)
    TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Aguardando aceitar...', type = 'inform' })

    SetTimeout(15000, function()
        if pendingBridal[targetId] == src then
            pendingBridal[targetId] = nil
            TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Jogador nao respondeu', type = 'error' })
        end
    end)
end)

RegisterNetEvent('medellin-carry:server:bridalAceito', function(carrierId)
    local targetId = source
    if pendingBridal[targetId] ~= carrierId then return end
    pendingBridal[targetId] = nil
    if carryPairs[carrierId] or beingCarried[targetId] then return end

    carryPairs[carrierId] = targetId
    beingCarried[targetId] = carrierId
    TriggerClientEvent('medellin-carry:client:startCarrying', carrierId, targetId, 'bridal')
    TriggerClientEvent('medellin-carry:client:beingCarried', targetId, carrierId, 'bridal')
end)

RegisterNetEvent('medellin-carry:server:bridalRecusado', function(carrierId)
    local targetId = source
    if pendingBridal[targetId] ~= carrierId then return end
    pendingBridal[targetId] = nil
    TriggerClientEvent('ox_lib:notify', carrierId, { title = 'Carregar', description = 'Jogador recusou', type = 'error' })
end)

-- ======================== /CARREGARALGEMADO (fireman so se algemado) ========================

RegisterNetEvent('medellin-carry:server:requestCarryAlgemado', function(targetId)
    local src = source
    if src == targetId then return end
    if carryPairs[src] or beingCarried[targetId] or beingCarried[src] then return end

    local srcPed = GetPlayerPed(src)
    local targetPed = GetPlayerPed(targetId)
    if not srcPed or srcPed == 0 or not targetPed or targetPed == 0 then return end
    if #(GetEntityCoords(srcPed) - GetEntityCoords(targetPed)) > 3.0 then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Jogador muito longe', type = 'error' })
        return
    end

    local targetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not targetPlayer then return end

    if not targetPlayer.PlayerData.metadata.ishandcuffed then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Carregar', description = 'Jogador nao esta algemado', type = 'error' })
        return
    end

    carryPairs[src] = targetId
    beingCarried[targetId] = src
    TriggerClientEvent('medellin-carry:client:startCarrying', src, targetId, 'carry')
    TriggerClientEvent('medellin-carry:client:beingCarried', targetId, src, 'carry')
end)

-- ======================== /COLOCARNOVEICULO (policia) ========================

RegisterNetEvent('medellin-carry:server:colocarNoVeiculo', function(targetId, vehNetId)
    local src = source
    if not hasCarryPermission(src) then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Veiculo', description = 'Apenas policia pode usar', type = 'error' })
        return
    end

    local targetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not targetPlayer then return end

    if not targetPlayer.PlayerData.metadata.ishandcuffed then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Veiculo', description = 'Jogador nao esta algemado', type = 'error' })
        return
    end

    -- Soltar carry se estiver carregando
    if carryPairs[src] == targetId then
        carryPairs[src] = nil
        beingCarried[targetId] = nil
        TriggerClientEvent('medellin-carry:client:released', src)
        TriggerClientEvent('medellin-carry:client:released', targetId)
    end

    -- Encontrar assento livre (1=tras esq, 2=tras dir)
    local seat = 1
    TriggerClientEvent('medellin-carry:client:entrarVeiculo', targetId, vehNetId, seat)
    TriggerClientEvent('ox_lib:notify', src, { title = 'Veiculo', description = 'Jogador colocado no banco de tras', type = 'success' })
end)

-- ======================== /TIRARDOVEICULO (policia) ========================

RegisterNetEvent('medellin-carry:server:tirarDoVeiculo', function(targetId)
    local src = source
    if not hasCarryPermission(src) then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Veiculo', description = 'Apenas policia pode usar', type = 'error' })
        return
    end

    local targetPed = GetPlayerPed(targetId)
    if not targetPed or targetPed == 0 then return end

    if not IsPedInAnyVehicle(targetPed, false) then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Veiculo', description = 'Jogador nao esta em veiculo', type = 'error' })
        return
    end

    TriggerClientEvent('medellin-carry:client:sairVeiculo', targetId)
    TriggerClientEvent('ox_lib:notify', src, { title = 'Veiculo', description = 'Jogador retirado do veiculo', type = 'success' })
end)

-- ======================== /AJOELHAR (policia) ========================

local kneelingPlayers = {} -- kneelingPlayers[targetId] = true

RegisterNetEvent('medellin-carry:server:ajoelhar', function(targetId)
    local src = source
    if not hasCarryPermission(src) then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Ajoelhar', description = 'Apenas policia pode usar', type = 'error' })
        return
    end

    local targetPlayer = QBCore.Functions.GetPlayer(targetId)
    if not targetPlayer then return end

    local metadata = targetPlayer.PlayerData.metadata
    if not metadata.ishandcuffed then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Ajoelhar', description = 'Jogador precisa estar algemado', type = 'error' })
        return
    end

    if kneelingPlayers[targetId] then
        kneelingPlayers[targetId] = nil
        TriggerClientEvent('medellin-carry:client:ajoelhar', targetId, false)
        TriggerClientEvent('ox_lib:notify', src, { title = 'Ajoelhar', description = 'Jogador pode levantar', type = 'inform' })
    else
        kneelingPlayers[targetId] = true
        TriggerClientEvent('medellin-carry:client:ajoelhar', targetId, true)
        TriggerClientEvent('ox_lib:notify', src, { title = 'Ajoelhar', description = 'Jogador forcado a ajoelhar', type = 'success' })
    end
end)

-- ======================== CLEANUP ON DISCONNECT ========================

AddEventHandler('playerDropped', function(reason)
    local src = source

    -- Se eu estava carregando alguem, soltar
    if carryPairs[src] then
        local targetId = carryPairs[src]
        beingCarried[targetId] = nil
        TriggerClientEvent('medellin-carry:client:released', targetId)
        carryPairs[src] = nil
    end

    -- Se eu estava sendo carregado, soltar o carregador
    if beingCarried[src] then
        local carrierId = beingCarried[src]
        carryPairs[carrierId] = nil
        TriggerClientEvent('medellin-carry:client:released', carrierId)
        beingCarried[src] = nil
    end
end)

-- ======================== CLEANUP ON RESOURCE STOP ========================

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end

    -- Soltar todos
    for carrierId, targetId in pairs(carryPairs) do
        TriggerClientEvent('medellin-carry:client:released', carrierId)
        TriggerClientEvent('medellin-carry:client:released', targetId)
    end

    carryPairs = {}
    beingCarried = {}
end)
