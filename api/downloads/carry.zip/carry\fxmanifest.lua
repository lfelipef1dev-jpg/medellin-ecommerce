fx_version 'cerulean'
game 'gta5'

description 'Medellin ROLEPLAY - Sistema de Segurar/Carregar Pessoas (Tecla H)'
author 'Medellin RP'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

lua54 'yes'

dependencies {
    'ox_lib',
    'qbx_core',
}
