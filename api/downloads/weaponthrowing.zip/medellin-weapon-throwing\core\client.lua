function CreateProp(modelHash, ...)
    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do Wait(0) end
    local obj = CreateObject(modelHash, ...)
    SetModelAsNoLongerNeeded(modelHash)
    return obj
end

function PlayAnim(ped, dict, ...)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(0) end
    TaskPlayAnim(ped, dict, ...)
end

local interactTick = 0
local interactCheck = false
local interactText = nil

function ShowInteractText(text, cds)
    local timer = GetGameTimer()
    interactTick = timer
    DrawText3D(cds[1],cds[2],cds[3]+0.2, text,400)
  --  lib.showTextUI(text)
    -- if interactCheck then return end
    -- interactCheck = true
    -- CreateThread(function()
    --     Wait(150)
    --     local timer = GetGameTimer()
    --     interactCheck = false
    --     if timer ~= interactTick then 
    --    --     lib.hideTextUI()
    --         interactText = nil
    --         interactTick = 0
    --     end
    -- end)
end

function DrawText3D(x,y,z,text)
	SetTextFont(4)
	SetTextCentre(1)
	SetTextEntry("STRING")
	SetTextScale(0.35,0.35)
	SetTextColour(30,30,30,255)
	AddTextComponentString(text)
	SetDrawOrigin(x,y,z,0)
	DrawText(0.0,0.0)
	local factor = (string.len(text) / 375) + 0.01
	DrawRect(0.0,0.0125,factor,0.03,38,42,56,200)
	ClearDrawOrigin()
end