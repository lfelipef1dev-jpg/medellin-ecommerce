fx_version 'cerulean'
lua54 'yes'
game 'gta5'

name         'medellin-weapon-throwing'
version      '1.1.1'
description  'Script para arremessar armas.'
author       'Pickle Mods'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    -- 'core/shared.lua', -- REMOVIDO: arquivo não existe (só core/client.lua)
    "locales/locale.lua",
    "locales/translations/*.lua",
    -- 'modules/**/shared.lua', -- REMOVIDO: arquivo não existe
}

server_scripts {
    'bridge/**/server.lua',
    'modules/**/server.lua',
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'core/client.lua',
    'bridge/**/client.lua',
    'modules/**/client.lua',
}
