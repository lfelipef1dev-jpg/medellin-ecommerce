-- Bridge de inventario para weapon-throwing
-- Com ox_inventory: GetCurrentWeapon e usado server-side, nao precisa de evento client
-- Este handler existe apenas como fallback caso algum resource dispare o evento
RegisterNetEvent('inventory:client:UseWeapon', function(weaponData, shootbool)
    TriggerServerEvent("pickle_weaponthrowing:SetCurrentWeapon", weaponData)
end)
