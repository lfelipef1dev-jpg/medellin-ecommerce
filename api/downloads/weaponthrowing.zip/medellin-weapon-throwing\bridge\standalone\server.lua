-- Guard: não carregar bridge standalone se QBCore estiver ativo
if GetResourceState('qb-core') == 'started' then return end

-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP (só carrega se QBCore NÃO estiver ativo)
-----------------------------------------------------------------------------------------------------------------------------------------
local Proxy = module("vrp","lib/Proxy")
local Tunnel = module("vrp","lib/Tunnel")
vRP = Proxy.getInterface("vRP")

-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
SjR = {}
Tunnel.bindInterface("pickle_weaponthrowing", SjR)


function GetWeapon(source, name)
    local user_id = vRP.Passport(source)
    if user_id then
        return vRP.InventoryItemAmount(user_id,name)[1]
    end
end

function AddWeapon(source, data) 
    local user_id = vRP.Passport(source)
    if user_id then
        vRP.GenerateItem(user_id, data.weapon, 1, true)
        return true
    end
end

function RemoveWeapon(source, data) 
    local user_id = vRP.Passport(source)
    if user_id then
        local Inventory = vRP.Inventory(user_id)
        local realname = ''
        for k,v in pairs(Inventory) do
            if splitString(v.item, "-")[1] == data.weapon then
                realname = v.item
            end
        end
        return vRP.TakeItem(user_id, realname,1,true)
    end
end

function CreateWeaponData(source, data, weaponData)
    return data
end