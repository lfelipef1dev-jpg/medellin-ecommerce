RegisterNetEvent('medellin-skate:removeItem', function()
    exports.ox_inventory:RemoveItem(source, 'skate', 1)
end)

RegisterNetEvent('medellin-skate:returnItem', function()
    exports.ox_inventory:AddItem(source, 'skate', 1)
end)
