local RCCar = {}
local Attached = false

-- Limpa entidades ao reiniciar o resource
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    if DoesEntityExist(RCCar.Skate) then DeleteEntity(RCCar.Skate) end
    if DoesEntityExist(RCCar.Entity) then DeleteVehicle(RCCar.Entity) end
    if DoesEntityExist(RCCar.Driver) then DeleteEntity(RCCar.Driver) end
    if Attached then
        DetachEntity(PlayerPedId(), false, false)
        Attached = false
    end
end)

local function DrawText3Ds(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 215)
    BeginTextCommandDisplayText("STRING")
    SetTextCentre(true)
    AddTextComponentSubstringPlayerName(text)
    SetDrawOrigin(x, y, z, 0)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

RegisterNetEvent('medellin-skate:use', function()
    local ped = PlayerPedId()
    if DoesEntityExist(RCCar.Entity) then return end
    TriggerServerEvent('medellin-skate:removeItem')
    RCCar.Spawn()
    while DoesEntityExist(RCCar.Entity) and DoesEntityExist(RCCar.Driver) do
        Citizen.Wait(5)
        local distanceCheck = GetDistanceBetweenCoords(GetEntityCoords(ped), GetEntityCoords(RCCar.Entity), true)
        RCCar.HandleKeys(distanceCheck)
        -- Sincroniza posição do prop visual com o veículo invisível
        if DoesEntityExist(RCCar.Skate) then
            local vCoords = GetEntityCoords(RCCar.Entity)
            SetEntityCoords(RCCar.Skate, vCoords.x, vCoords.y, vCoords.z - 0.15, false, false, false)
            SetEntityHeading(RCCar.Skate, GetEntityHeading(RCCar.Entity) + 90.0)
        end
        if distanceCheck <= 3 then
            if not NetworkHasControlOfEntity(RCCar.Driver) then
                NetworkRequestControlOfEntity(RCCar.Driver)
            elseif not NetworkHasControlOfEntity(RCCar.Entity) then
                NetworkRequestControlOfEntity(RCCar.Entity)
            end
            if not Attached then
                TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 6, 500)
            end
        else
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 6, 2500)
        end
    end
end)

function RCCar.HandleKeys(distanceCheck)
    local ped = PlayerPedId()
    if distanceCheck <= 1.5 then
        if IsControlJustPressed(0, 38) and not Attached then
            RCCar.Attach("pick")
        end
        if IsControlJustReleased(0, 244) then
            if Attached then
                RCCar.AttachPlayer(false)
            else
                RCCar.AttachPlayer(true)
            end
        end
        if not Attached then
            DrawText3Ds(GetEntityCoords(RCCar.Entity).x, GetEntityCoords(RCCar.Entity).y, GetEntityCoords(RCCar.Entity).z + 0.5, "~r~E ~w~ PEGAR      ~g~M ~w~ SUBIR")
        end
    end
    if distanceCheck <= 1.5 and Attached then
        if IsControlPressed(0, 32) and not IsControlPressed(0, 33) then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 9, 1)
        end
        if IsControlJustReleased(0, 22) and Attached then
            local vel = GetEntityVelocity(RCCar.Entity)
            if not IsEntityInAir(RCCar.Entity) then
                SetEntityVelocity(RCCar.Entity, vel.x, vel.y, vel.z + 5.0)
                Citizen.Wait(20)
            end
        end
        if IsControlJustReleased(0, 32) or IsControlJustReleased(0, 33) then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 6, 2500)
        end
        if IsControlPressed(0, 33) and not IsControlPressed(0, 32) then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 22, 1)
        end
        if IsControlPressed(0, 34) and IsControlPressed(0, 33) then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 13, 1)
        end
        if IsControlPressed(0, 35) and IsControlPressed(0, 33) then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 14, 1)
        end
        if IsControlPressed(0, 32) and IsControlPressed(0, 33) then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 30, 100)
        end
        if IsControlPressed(0, 34) and IsControlPressed(0, 32) and true then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 7, 1)
        end
        if IsControlPressed(0, 35) and IsControlPressed(0, 32) and true then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 8, 1)
        end
        if IsControlPressed(0, 34) and not IsControlPressed(0, 32) and not IsControlPressed(0, 33) and true then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 4, 1)
        end
        if IsControlPressed(0, 35) and not IsControlPressed(0, 32) and not IsControlPressed(0, 33) and true then
            TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 5, 1)
        end
    end
    if Attached then
        local ped2 = PlayerPedId()
        local x = GetEntityRotation(RCCar.Entity).x
        local y = GetEntityRotation(RCCar.Entity).y
        if (x < -60.0 or x > 60.0) or (y < -60.0 or y > 60.0) or (HasEntityCollidedWithAnything(RCCar.Entity) and GetEntitySpeed(RCCar.Entity) > 12.6) then
            RCCar.AttachPlayer(false)
            SetPedToRagdoll(ped2, 4000, 4000, 0, true, true, false)
        elseif IsPedArmed(ped2, 7) or IsEntityInWater(RCCar.Entity) or GetEntityHealth(ped2) <= 101 then
            RCCar.AttachPlayer(false)
            DetachEntity(RCCar.Entity)
        end
    end
end

function RCCar.Spawn()
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped) then return end

    local hVeh = GetHashKey("rcbandito")
    RequestModel(hVeh)
    local t = 0
    while not HasModelLoaded(hVeh) and t < 100 do Citizen.Wait(10); t = t + 1 end

    RequestAnimDict("pickup_object")
    while not HasAnimDictLoaded("pickup_object") do Citizen.Wait(10) end
    RequestAnimDict("move_strafe@stealth")
    while not HasAnimDictLoaded("move_strafe@stealth") do Citizen.Wait(10) end

    local hPed = 68070371
    RequestModel(hPed)
    t = 0
    while not HasModelLoaded(hPed) and t < 100 do Citizen.Wait(10); t = t + 1 end

    local hSkate = GetHashKey("v_res_skateboard")
    RequestModel(hSkate)
    t = 0
    while not HasModelLoaded(hSkate) and t < 100 do Citizen.Wait(10); t = t + 1 end

    local spawnCoords = GetEntityCoords(ped) + GetEntityForwardVector(ped) * 2.0
    local spawnHeading = GetEntityHeading(ped)

    RCCar.Entity = CreateVehicle(hVeh, spawnCoords, spawnHeading, true)
    while not DoesEntityExist(RCCar.Entity) do Citizen.Wait(5) end

    SetVehicleHandlingFloat(RCCar.Entity, "CHandlingData", "fSuspensionForce", 1.5)
    SetVehicleEngineTorqueMultiplier(RCCar.Entity, 0.1)
    SetEntityNoCollisionEntity(RCCar.Entity, ped, false)
    SetEntityVisible(RCCar.Entity, false)
    SetAllVehiclesSpawn(RCCar.Entity, true, true, true, true)

    local spawnPos = GetEntityCoords(RCCar.Entity)
    RCCar.Skate = CreateObject(hSkate, spawnPos.x, spawnPos.y, spawnPos.z, true, true, true)
    while not DoesEntityExist(RCCar.Skate) do Citizen.Wait(5) end
    SetEntityCollision(RCCar.Skate, false, false)
    FreezeEntityPosition(RCCar.Skate, false)

    RCCar.Driver = CreatePed(5, hPed, spawnCoords, spawnHeading, true)
    SetEntityInvincible(RCCar.Driver, true)
    SetEntityAlpha(RCCar.Driver, 0, false)
    SetEntityVisible(RCCar.Driver, false)
    SetBlockingOfNonTemporaryEvents(RCCar.Driver, true)
    SetPedAlertness(RCCar.Driver, 0.0)
    TaskWarpPedIntoVehicle(RCCar.Driver, RCCar.Entity, -1)
    local tw = 0
    while not IsPedInVehicle(RCCar.Driver, RCCar.Entity) and tw < 200 do
        Citizen.Wait(0)
        tw = tw + 1
    end
    SetEntityAlpha(RCCar.Driver, 0, false)
    SetEntityVisible(RCCar.Driver, false)
    SetVehicleEngineOn(RCCar.Entity, false, true, false)
    TaskVehicleTempAction(RCCar.Driver, RCCar.Entity, 6, 99999)
    RCCar.Attach("place")
end

function RCCar.Attach(param)
    local ped = PlayerPedId()
    if not DoesEntityExist(RCCar.Entity) or GetEntityHealth(ped) <= 101 then
        return
    end
    if param == "place" then
        AttachEntityToEntity(RCCar.Entity, ped, GetPedBoneIndex(ped, 28422), -0.1, 0.0, -0.2, 70.0, 0.0, 270.0, 1, 1, 0, 0, 2, 1)
        TaskPlayAnim(ped, "pickup_object", "pickup_low", 8.0, -8.0, -1, 0, 0, false, false, false)
        Citizen.Wait(800)
        DetachEntity(RCCar.Entity, false, true)
        PlaceObjectOnGroundProperly(RCCar.Entity)
    elseif param == "pick" then
        Citizen.Wait(100)
        TaskPlayAnim(ped, "pickup_object", "pickup_low", 8.0, -8.0, -1, 0, 0, false, false, false)
        Citizen.Wait(600)
        AttachEntityToEntity(RCCar.Entity, ped, GetPedBoneIndex(ped, 28422), -0.1, 0.0, -0.2, 70.0, 0.0, 270.0, 1, 1, 0, 0, 2, 1)
        Citizen.Wait(900)
        DetachEntity(RCCar.Entity)
        if DoesEntityExist(RCCar.Skate) then DeleteEntity(RCCar.Skate) end
        DeleteVehicle(RCCar.Entity)
        DeleteEntity(RCCar.Driver)
        TriggerServerEvent('medellin-skate:returnItem')
        RCCar.Entity = nil
        RCCar.Driver = nil
        RCCar.Skate = nil
        Attached = false
    end
end

function RCCar.AttachPlayer(toggle)
    local ped = PlayerPedId()
    if toggle then
        TaskPlayAnim(ped, "move_strafe@stealth", "idle", 8.0, 8.0, -1, 1, 1.0, false, false, false)
        AttachEntityToEntity(ped, RCCar.Entity, 20, 0.0, 0.0, 0.98, 0.0, 0.0, -15.0, true, true, true, true, true, true)
        SetEntityCollision(ped, true, false)
        Attached = true
    else
        DetachEntity(ped, false, false)
        Attached = false
        StopAnimTask(ped, "move_strafe@stealth", "idle", 1.0)
    end
end
