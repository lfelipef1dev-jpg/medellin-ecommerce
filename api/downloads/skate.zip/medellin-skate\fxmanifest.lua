fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Medellin RP'
description 'Sistema de Skate (portado do VRPex para QBox)'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client.lua',
}

server_scripts {
    'server.lua',
}

dependencies {
    'ox_lib',
    'qbx_core',
    'ox_inventory',
}
