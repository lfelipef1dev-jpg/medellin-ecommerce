 // Klaus JavaScript Deobfuscator 1.0  
 const formatarNumero = a => {
    return a.toLocaleString('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
};
$(function () {
    $('.rgbr').css('display', 'unset');
    $('.cnhbr').css('display', 'unset');
    $('.rgam').css('display', 'none');
    $('.cnham').css('display', 'none');
    window.addEventListener('message', function (b) {
        if (b.data.type === 'abrirCarteira') {
            setData(b.data.dados);
            if (b.data.type_carteira == 'am') {
                $('.rgbr').css('display', 'none');
                $('.cnhbr').css('display', 'none');
                $('.rgam').css('display', 'unset');
                $('.cnham').css('display', 'unset');
            } else {
                $('.rgbr').css('display', 'unset');
                $('.cnhbr').css('display', 'unset');
                $('.rgam').css('display', 'none');
                $('.cnham').css('display', 'none');
            }
            if (b.data.prox) {
                $('.align-search').fadeIn();
            } else {
                $('.align').css('display', 'flex');
                $('.align').fadeIn();
            }
        }
        if (b.data.type === 'fecharCarteira') {
            $('.align-search').fadeOut();
            $('.align').fadeOut();
        }
    });
    document.onkeyup = function (c) {
        if (c.which == 27 || c.which == -103) {
            closeAll();
            sendData('ButtonClick', { action: 'fecharCarteira' }, false);
        }
    };
});
function setData(d) {
    if (d.foto == null || d.foto == '') {
        d.foto = './images/no-avatar.png';
    }
    // Se tiver imagem VIP válida, usa ela, senão mantém o gradiente personalizado Medellin
    if (d.vipimg && d.vipimg != 'Default.png' && d.vipimg != 'vip.png' && d.vipimg != '') {
        $('.cartao').css('background-image', 'url("./images/' + d.vipimg + '")');
        $('.cartao').css('background-size', 'cover');
        $('.cartao').css('background-blend-mode', 'overlay');
    } else {
        // Mantém o gradiente personalizado Medellin
        $('.cartao').css('background-image', 'none');
    }
    $('.fundo .bolso').css('background-image', 'url("images/carteiras/' + d.carteira + '/bolsod.png")');
    $('.back .bolso').css('background-image', 'url("images/carteiras/' + d.carteira + '/bolsoe.png")');
    $('.one figure.front').css('background-image', 'url("images/carteiras/' + d.carteira + '/capa.png")');
    $('.one figure.back').css('background-image', 'url("images/carteiras/' + d.carteira + '/textura.png")');
    $('.one .container').css('background-image', 'url("images/carteiras/' + d.carteira + '/textura.png")');
    $('.rg .nome .value').text(d.nome);
    $('.rg .cpf .value').text(d.id);
    $('.ass-nome-rg').text(d.nome);
    $('.rg .idade .value').text(d.idade);
    $('.rg .numrg .value').text(d.rg);
    $('.rg .tel .value').text(d.telefone);
    $('.rg .job .value').text(d.emprego);
    $('.rg .porte .value').text(d.porte);
    $('.rgam .foto .img').css('background-image', 'url(' + d.foto + ')');
    $('.cnh .nome .value').text(d.nome);
    $('.cnh .cpf .value').text(d.id);
    $('.ass-cnh').text(d.habilitacao);
    $('.cnh .foto .img').css('background-image', 'url(' + d.foto + ')');
    $('.cnh .multas .value').text(formatarNumero(d.multas));
    $('.cartao .vip .value').text(d.vip);
    $('.cartao .nome .value').text(d.nome);
    $('.cartao .saldob .value').text(formatarNumero(d.dinheironobanco));
    $('.cartao .saldom .value').text(formatarNumero(d.dinheironamao));
    $('.cartao .saldoc .value').text(formatarNumero(d.coins));
}
function closeAll() {
    $('.rg').removeClass('rg-select');
    $('.cnhbr').removeClass('cnhbr-select');
    $('.cnham').removeClass('cnham-select');
    $('.cartao').removeClass('cartao-select');
}
$('.align .container').hover(function () {
}, function () {
    if (!$('.align .container').is(':hover')) {
        $('.cartao').removeClass('cartao-select');
        setTimeout(() => {
            closeAll();
        }, 5000);
    }
});
$('.rg').click(function () {
    closeAll();
    $(this).addClass('rg-select');
});
$('.cnhbr').click(function () {
    closeAll();
    $(this).addClass('cnhbr-select');
});
$('.cnham').click(function () {
    closeAll();
    $(this).addClass('cnham-select');
});
$('.cartao').click(function () {
    closeAll();
    $(this).addClass('cartao-select');
});
function sendData(e, f) {
    $.post('https://medellin-identidade/' + e, JSON.stringify(f), function (g) {
    });
}