local QBCore = exports['qb-core']:GetCoreObject()

local isOpen = false

-- Função para abrir carteira
local function OpenWallet(prox)
    if isOpen then return end
    
    isOpen = true
    SetNuiFocus(true, true)
    
    QBCore.Functions.TriggerCallback('medellin-identidade:server:GetIdentity', function(data)
        if data then
            SendNUIMessage({
                type = 'abrirCarteira',
                dados = data,
                type_carteira = Config.Type,
                prox = prox or false
            })
        else
            isOpen = false
            SetNuiFocus(false, false)
            QBCore.Functions.Notify('Erro ao carregar identidade', 'error')
        end
    end, prox and GetClosestPlayerId() or nil)
end

-- Função para fechar carteira
local function CloseWallet()
    if not isOpen then return end
    
    isOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({
        type = 'fecharCarteira'
    })
end

-- Função para obter ID do jogador mais próximo
function GetClosestPlayerId()
    local player, distance = QBCore.Functions.GetClosestPlayer()
    if not player or player == -1 or distance > 5.0 then
        return nil
    end
    return GetPlayerServerId(player)
end

-- Evento para abrir carteira
RegisterNetEvent('medellin-identidade:client:OpenWallet', function(prox)
    OpenWallet(prox)
end)

-- NUI Callbacks
RegisterNUICallback('ButtonClick', function(data, cb)
    if data.action == 'fecharCarteira' then
        CloseWallet()
    end
    cb('ok')
end)

-- Abrir com F11 e fechar com ESC
CreateThread(function()
    while true do
        if isOpen then
            Wait(120)
            if IsControlJustPressed(0, 322) then -- ESC
                CloseWallet()
            end
        else
            Wait(250) -- Verificação menos frequente quando fechado (economiza recursos)
            if IsControlJustPressed(0, 344) then -- F11
                OpenWallet(false)
            end
        end
    end
end)

-- Comando para abrir carteira (mantido para compatibilidade)
RegisterCommand('carteira', function()
    OpenWallet(false)
end, false)
