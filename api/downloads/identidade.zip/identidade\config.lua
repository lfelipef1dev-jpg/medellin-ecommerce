Config = {}

-- Configurações Gerais
Config.Locale = 'pt-br'
Config.Type = 'br' -- 'br' ou 'am'

-- Configuração de Carteira (padrão 'gucci' como na Creative)
Config.Carteira = 'gucci'

-- Configuração de VIPs (igual à Creative)
Config.Vips = {
    { nomeVip = 'Black', img = 'cartaoblack.png' },
    { nomeVip = 'Medellin', img = 'cartaoblack.png' },
    { nomeVip = 'Monster', img = 'cartaoblack.png' },
    { nomeVip = 'Platinum', img = 'cartaoplatina.png' },
    { nomeVip = 'Ouro', img = 'cartao.png' },
    { nomeVip = 'Prata', img = 'cartao.png' },
    { nomeVip = 'Bronze', img = 'cartao.png' },
    { nomeVip = 'Sem vip', img = 'Default.png' }
}

-- Carteiras Disponíveis
Config.Carteiras = {
    ['tommy'] = 'carteiratommy',
    ['nike'] = 'carteiranike',
    ['adidas'] = 'carteiraadidas',
    ['gucci'] = 'carteiragucci',
    ['calvink'] = 'carteiracalvink',
    ['balenciaga'] = 'carteirabalenciaga',
    ['dolceg'] = 'carteiradolceg',
    ['cyclone'] = 'carteiracyclone',
    ['quicks'] = 'carteiraquicks',
    ['prada'] = 'carteiraprada',
    ['lacoste'] = 'carteiralacoste',
    ['louisv'] = 'carteiralouisv',
    ['chanel'] = 'carteirachanel',
    ['default'] = 'default'
}

-- Comando para ver identidade de outros (permissões)
Config.Documento = {
    ['pegar-docs'] = {
        comando = 'rgp',
        perms = { 'admin', 'police' } -- Adapte para suas permissões
    }
}
