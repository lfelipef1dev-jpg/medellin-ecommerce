fx_version 'cerulean'
game 'gta5'
lua54 'yes'
use_experimental_fxv2_oal 'yes'

author 'Medellin RP'
description 'Sistema de Identidade - Carteira Visual (Adaptado da Creative)'
version '1.0.0'

ui_page 'nui/index.html'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

files {
    'nui/*',
    'nui/images/*',
    'nui/images/carteiras/**/*'
}

dependencies {
    'ox_lib',
    'qbx_core',
    'oxmysql'
}
