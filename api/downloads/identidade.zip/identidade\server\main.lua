local QBCore = exports['qb-core']:GetCoreObject()

-- Função para calcular idade a partir da data de nascimento
local function CalculateAge(birthdate)
    if not birthdate or birthdate == '00-00-0000' then return 0 end
    
    local day, month, year = birthdate:match('(%d+)-(%d+)-(%d+)')
    if not day or not month or not year then return 0 end
    
    local birth = os.time({year = tonumber(year), month = tonumber(month), day = tonumber(day)})
    local now = os.time()
    local age = os.date('%Y', now) - os.date('%Y', birth)
    
    if os.date('%m%d', now) < os.date('%m%d', birth) then
        age = age - 1
    end
    
    return age
end

-- Função para obter tipo sanguíneo (converte número para string como na Creative)
local function Sanguine(Number)
    local Types = { "A+", "B+", "A-", "B-" }
    if Number and Number >= 1 and Number <= 4 then
        return Types[Number]
    end
    -- Se não for número, tenta pegar do metadata
    return Types[1] -- Default A+
end

-- Função para obter tipo sanguíneo (do metadata)
local function GetBloodType(metadata)
    if metadata and metadata.bloodtype then
        -- Se for número, converte
        if type(metadata.bloodtype) == 'number' then
            return Sanguine(metadata.bloodtype)
        end
        -- Se já for string, retorna
        return metadata.bloodtype
    end
    return 'A+'
end

-- Função para obter grupo de trabalho (otimizada - recebe Player direto)
local function GetUserJob(Player)
    if not Player then return 'Desempregado' end
    local job = Player.PlayerData.job
    if job and job.label then
        return job.label
    end
    return 'Desempregado'
end

-- Função para verificar CNH (otimizada - verifica direto no PlayerData)
local function HasDriverLicense(Player)
    if not Player then return 'Não possui' end
    local items = Player.PlayerData.items
    for slot, item in pairs(items) do
        if item.name == 'driver_license' and item.amount and item.amount > 0 then
            return 'Possui CNH'
        end
    end
    return 'Não possui'
end

-- Função para verificar porte de arma (otimizada - verifica direto no PlayerData)
local function HasWeaponLicense(Player)
    if not Player then return 'Não Possui' end
    local items = Player.PlayerData.items
    for slot, item in pairs(items) do
        if item.name == 'weaponlicense' and item.amount and item.amount > 0 then
            return 'Sim Possui'
        end
    end
    return 'Não Possui'
end

-- Função para obter VIP
local function GetUserVip(citizenid)
    -- Adapte conforme seu sistema de VIP
    -- Por enquanto retorna 'Sem vip'
    return 'Sem vip'
end

-- Função para obter multas (adaptar conforme seu sistema)
local function GetFines(citizenid)
    -- Adapte conforme seu sistema de multas
    return 0
end

-- Função para obter coins (adaptar conforme seu sistema)
local function GetCoins(citizenid)
    -- Adapte conforme seu sistema de coins
    return 0
end

-- Callback para obter identidade (otimizado)
QBCore.Functions.CreateCallback('medellin-identidade:server:GetIdentity', function(source, cb, targetId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return cb(nil) end
    
    local targetPlayer = nil
    if targetId then
        -- Verificar permissões para ver identidade de outros
        local hasPermission = false
        for _, perm in pairs(Config.Documento['pegar-docs'].perms) do
            if QBCore.Functions.HasPermission(src, perm) then
                hasPermission = true
                break
            end
        end
        
        if not hasPermission then
            return cb(nil)
        end
        
        targetPlayer = QBCore.Functions.GetPlayer(targetId)
        if not targetPlayer then
            QBCore.Functions.Notify(src, 'Jogador não encontrado', 'error')
            return cb(nil)
        end
    else
        targetPlayer = Player
    end
    
    -- Obter dados do jogador (otimizado - tudo de uma vez)
    local charinfo = targetPlayer.PlayerData.charinfo
    local metadata = targetPlayer.PlayerData.metadata
    local citizenid = targetPlayer.PlayerData.citizenid
    
    -- Calcular idade
    local age = CalculateAge(charinfo.birthdate)
    
    -- Obter tipo sanguíneo
    local bloodType = GetBloodType(metadata)
    
    -- Obter dinheiro
    local cash = targetPlayer.PlayerData.money.cash or 0
    local bank = targetPlayer.PlayerData.money.bank or 0
    
    -- Obter emprego, CNH e porte (otimizado - passa Player direto)
    local job = GetUserJob(targetPlayer)
    local cnh = HasDriverLicense(targetPlayer)
    local porte = HasWeaponLicense(targetPlayer)
    
    -- Obter VIP
    local vip = GetUserVip(citizenid)
    local vipimg = 'Default.png' -- Default para "Sem vip"
    for _, v in pairs(Config.Vips) do
        if v.nomeVip == vip then
            vipimg = v.img
            break
        end
    end
    
    -- Obter multas e coins (valores padrão por enquanto)
    local multas = GetFines(citizenid)
    local coins = GetCoins(citizenid)
    
    -- Foto (adaptar conforme seu sistema)
    local foto = 'images/no-avatar.png'
    
    -- Carteira (fixo 'gucci' como na Creative - linha 131 e 184 do server.lua original)
    local carteira = 'gucci'
    
    -- Retornar dados
    cb({
        foto = foto,
        carteira = carteira,
        nome = charinfo.firstname .. ' ' .. charinfo.lastname,
        id = citizenid,
        idade = age,
        rg = bloodType,
        telefone = charinfo.phone,
        emprego = job,
        porte = porte,
        habilitacao = cnh,
        multas = multas,
        vip = vip,
        dinheironobanco = bank,
        dinheironamao = cash,
        coins = coins,
        vipimg = vipimg
    })
end)

-- Comando para abrir carteira
QBCore.Commands.Add('carteira', 'Abrir carteira de identidade', {}, false, function(source, args)
    TriggerClientEvent('medellin-identidade:client:OpenWallet', source)
end)

-- Comando para ver identidade de outros (rgp)
QBCore.Commands.Add(Config.Documento['pegar-docs'].comando, 'Ver identidade de outro jogador', {}, false, function(source, args)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return end
    
    -- Verificar permissões
    local hasPermission = false
    for _, perm in pairs(Config.Documento['pegar-docs'].perms) do
        if QBCore.Functions.HasPermission(source, perm) then
            hasPermission = true
            break
        end
    end
    
    if not hasPermission then
        QBCore.Functions.Notify(source, 'Você não tem permissão', 'error')
        return
    end
    
    TriggerClientEvent('medellin-identidade:client:OpenWallet', source, true)
end)

