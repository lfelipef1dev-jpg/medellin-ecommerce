/**
 * MEDELLIN CLOTHING UI - JavaScript
 * Sistema de Roupas Visual Personalizado
 */

// Estado global
const state = {
    isOpen: false,
    isMale: true,
    currentCategory: null,
    currentComponent: null,
    currentProp: null,
    currentPage: 0,
    itemsPerPage: 12,
    selectedItem: -1,
    selectedTexture: 0,
    maxItems: {},
    originalAppearance: null,
};

// Mapeamento de categorias para componentes/props e recursos de imagens
// Consolidado: todas as 15 categorias usam medellin-assets-wearables com subdir
const WEARABLES_ASSET = 'medellin-assets-wearables';
const categoryMapping = {
    // Primárias
    tops: { component: 11, name: 'Jaquetas', folder: '11', asset: WEARABLES_ASSET, subdir: 'tops' },
    undershirts: { component: 8, name: 'Camisetas', folder: '8', asset: WEARABLES_ASSET, subdir: 'shirts' },
    legs: { component: 4, name: 'Calças', folder: '4', asset: WEARABLES_ASSET, subdir: 'pants' },
    shoes: { component: 6, name: 'Sapatos', folder: '6', asset: WEARABLES_ASSET, subdir: 'shoes' },
    accessories: { component: 7, name: 'Acessórios', folder: '7', asset: WEARABLES_ASSET, subdir: 'accessories' },
    glasses: { prop: 1, name: 'Óculos', folder: 'p1', asset: WEARABLES_ASSET, subdir: 'glasses' },
    hats: { prop: 0, name: 'Chapéu', folder: 'p0', asset: WEARABLES_ASSET, subdir: 'hats' },
    torsos: { component: 3, name: 'Mãos', folder: '3', asset: WEARABLES_ASSET, subdir: 'torsos' },

    // Secundárias
    bags: { component: 5, name: 'Mochilas', folder: '5', asset: WEARABLES_ASSET, subdir: 'bags' },
    bodyArmors: { component: 9, name: 'Coletes', folder: '9', asset: WEARABLES_ASSET, subdir: 'armors' },
    masks: { component: 1, name: 'Máscara', folder: '1', asset: WEARABLES_ASSET, subdir: 'masks' },
    decals: { component: 10, name: 'Adesivos', folder: '10', asset: WEARABLES_ASSET, subdir: 'decals' },
    ears: { prop: 2, name: 'Brincos', folder: 'p2', asset: WEARABLES_ASSET, subdir: 'ears' },
    bracelets: { prop: 7, name: 'Braceletes', folder: 'p7', asset: WEARABLES_ASSET, subdir: 'bracelets' },
    watches: { prop: 6, name: 'Relógios', folder: 'p6', asset: WEARABLES_ASSET, subdir: 'watches' },
};

// Número máximo de itens por categoria (aproximado)
const maxItemsDefault = {
    tops: 450,
    undershirts: 200,
    legs: 150,
    shoes: 120,
    accessories: 150,
    glasses: 40,
    hats: 160,
    torsos: 250,
    bags: 100,
    bodyArmors: 35,
    masks: 220,
    decals: 30,
    ears: 45,
    bracelets: 20,
    watches: 45,
};

// Elementos DOM
const elements = {
    app: document.getElementById('app'),
    mainMenu: document.getElementById('main-menu'),
    itemsMenu: document.getElementById('items-menu'),
    primaryCategories: document.getElementById('primary-categories'),
    secondaryCategories: document.getElementById('secondary-categories'),
    itemsGrid: document.getElementById('items-grid'),
    categoryTitle: document.getElementById('category-title'),
    pageNumber: document.getElementById('page-number'),
    itemNumber: document.getElementById('item-number'),
    textureNumber: document.getElementById('texture-number'),
    tabs: document.querySelectorAll('.tab'),
    categoryItems: document.querySelectorAll('.category-item'),
    btnCancel: document.getElementById('btn-cancel'),
    btnSave: document.getElementById('btn-save'),
    btnRotateLeft: document.getElementById('btn-rotate-left'),
    btnRotateRight: document.getElementById('btn-rotate-right'),
    btnBack: document.getElementById('btn-back'),
    btnPrev: document.getElementById('btn-prev'),
    btnNext: document.getElementById('btn-next'),
    btnTexturePrev: document.getElementById('btn-texture-prev'),
    btnTextureNext: document.getElementById('btn-texture-next'),
    btnItemPrev: document.getElementById('btn-item-prev'),
    btnItemNext: document.getElementById('btn-item-next'),
};

// ============================================
// INICIALIZAÇÃO
// ============================================

function init() {
    setupEventListeners();
    setupNuiCallbacks();
}

function setupEventListeners() {
    // Tabs
    elements.tabs.forEach(tab => {
        tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });
    
    // Categorias
    elements.categoryItems.forEach(item => {
        item.addEventListener('click', () => openCategory(item.dataset.category));
    });
    
    // Botões principais
    elements.btnCancel.addEventListener('click', cancel);
    elements.btnSave.addEventListener('click', save);
    elements.btnBack.addEventListener('click', goBack);
    
    // Paginação (se existir)
    if (elements.btnPrev) {
        elements.btnPrev.addEventListener('click', prevPage);
    }
    if (elements.btnNext) {
        elements.btnNext.addEventListener('click', nextPage);
    }
    
    // Texturas
    if (elements.btnTexturePrev) {
        elements.btnTexturePrev.addEventListener('click', prevTexture);
    }
    if (elements.btnTextureNext) {
        elements.btnTextureNext.addEventListener('click', nextTexture);
    }
    
    // Navegação por número de item
    if (elements.btnItemPrev) {
        elements.btnItemPrev.addEventListener('click', prevItem);
    }
    if (elements.btnItemNext) {
        elements.btnItemNext.addEventListener('click', nextItem);
    }
    
    // Rotação
    if (elements.btnRotateLeft) {
        elements.btnRotateLeft.addEventListener('click', () => rotateCharacter('left'));
    }
    if (elements.btnRotateRight) {
        elements.btnRotateRight.addEventListener('click', () => rotateCharacter('right'));
    }
    
    // ESC é tratado no client.lua para evitar abrir menu de pause
}

function setupNuiCallbacks() {
    window.addEventListener('message', (event) => {
        const data = event.data;
        if (data && data.action === 'open') console.log('[MEDELLIN-CLOTHING-UI] NUI recebeu action=open');
        
        switch (data.action) {
            case 'open':
                openUI(data);
                break;
            case 'close':
                closeUI();
                break;
            case 'goBack':
                // Voltar para menu principal se estiver nos itens
                if (!elements.itemsMenu.classList.contains('hidden')) {
                    goBack();
                }
                break;
            case 'updateMaxItems':
                state.maxItems = data.maxItems || {};
                break;
        }
    });
}

// ============================================
// UI PRINCIPAL
// ============================================

function openUI(data) {
    state.isOpen = true;
    state.isMale = data.isMale !== false;
    state.originalAppearance = data.appearance || null;
    state.maxItems = data.maxItems || state.maxItems || {};
    
    // Atualizar imagens baseado no sexo
    updateCategoryImages();
    
    elements.app.classList.remove('hidden');
    
    // Garantir que o scroll do menu de categorias comece no topo
    const mainContent = document.querySelector('#main-menu .panel-content');
    if (mainContent) mainContent.scrollTop = 0;
}

function closeUI() {
    state.isOpen = false;
    elements.app.classList.add('hidden');
    elements.mainMenu.classList.remove('hidden');
    elements.itemsMenu.classList.add('hidden');
    
    // Reset state
    state.currentCategory = null;
    state.currentPage = 0;
    state.selectedItem = -1;
}

// Tenta webp primeiro (carrega mais rápido), fallback para png
function setImageWithWebpFallback(img, baseUrl) {
    if (!img || !baseUrl) return;
    const urlWebp = baseUrl.replace(/\.(png|jpg|jpeg)$/i, '.webp');
    const urlPng = baseUrl.replace(/\.(webp|jpg|jpeg)$/i, '.png');
    img.onerror = function() {
        if (this.src === urlWebp || this.src.endsWith('.webp')) {
            this.src = urlPng;
            this.onerror = function() { this.style.display = 'none'; if (this.nextElementSibling) this.nextElementSibling.style.display = 'flex'; };
        } else {
            this.style.display = 'none';
            if (this.nextElementSibling) this.nextElementSibling.style.display = 'flex';
        }
    };
    img.src = urlWebp;
}

function updateCategoryImages() {
    const gender = state.isMale ? 'male' : 'female';
    const base = 'nui://medellin-assets-clothing/nation/nation_skinshop/menu';
    
    elements.categoryItems.forEach(item => {
        const category = item.dataset.category;
        const img = item.querySelector('img');
        if (img) setImageWithWebpFallback(img, `${base}/${gender}/${category}.png`);
    });
}

// ============================================
// TABS
// ============================================

function switchTab(tab) {
    elements.tabs.forEach(t => t.classList.remove('active'));
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
    
    if (tab === 'primary') {
        elements.primaryCategories.classList.add('active');
        elements.secondaryCategories.classList.remove('active');
    } else {
        elements.primaryCategories.classList.remove('active');
        elements.secondaryCategories.classList.add('active');
    }
}

// ============================================
// CATEGORIAS
// ============================================

function openCategory(category) {
    const mapping = categoryMapping[category];
    if (!mapping) return;
    
    state.currentCategory = category;
    state.currentComponent = mapping.component || null;
    state.currentProp = mapping.prop !== undefined ? mapping.prop : null;
    state.currentPage = 0;
    state.selectedItem = -1;
    state.selectedTexture = 0;
    
    elements.categoryTitle.textContent = mapping.name.toUpperCase();
    
    // Esconder menu principal, mostrar menu de itens
    elements.mainMenu.classList.add('hidden');
    elements.itemsMenu.classList.remove('hidden');
    
    // Buscar item atual do personagem
    fetch('https://medellin-clothing-ui/getCurrentItem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            component: state.currentComponent,
            prop: state.currentProp,
        }),
    }).then(response => response.json()).then(data => {
        if (data.drawable !== undefined && data.drawable >= 0) {
            state.selectedItem = data.drawable;
            state.selectedTexture = data.texture || 0;
        }
        updateItemDisplay();
        updateTextureDisplay();
        loadItems();
        
        // Scroll sempre no topo ao abrir a categoria (ver todos os cards desde o início)
        const itemsContent = document.querySelector('#items-menu .panel-content');
        if (itemsContent) itemsContent.scrollTop = 0;
        // Destacar item atual sem puxar o scroll para ele
        setTimeout(() => highlightSelectedItem(false), 100);
    }).catch(() => {
        loadItems();
        const itemsContent = document.querySelector('#items-menu .panel-content');
        if (itemsContent) itemsContent.scrollTop = 0;
        setTimeout(() => highlightSelectedItem(false), 100);
    });
}

function goBack() {
    elements.itemsMenu.classList.add('hidden');
    elements.mainMenu.classList.remove('hidden');
    
    state.currentCategory = null;
    state.currentPage = 0;
}

// ============================================
// ITENS
// ============================================

function loadItems() {
    const category = state.currentCategory;
    const mapping = categoryMapping[category];
    const gender = state.isMale ? 'male' : 'female';
    
    const maxItems = state.maxItems[category] || maxItemsDefault[category] || 100;
    
    // Scroll infinito para TODAS as categorias - carrega todos os itens
    const useInfiniteScroll = true;
    
    let startIndex, endIndex;
    if (useInfiniteScroll) {
        startIndex = 0;
        endIndex = maxItems;
    } else {
        startIndex = state.currentPage * state.itemsPerPage;
        endIndex = Math.min(startIndex + state.itemsPerPage, maxItems);
    }
    
    elements.itemsGrid.innerHTML = '';
    
    for (let i = startIndex; i < endIndex; i++) {
        const itemCard = document.createElement('div');
        itemCard.className = 'item-card';
        itemCard.dataset.index = i;
        
        if (i === state.selectedItem) {
            itemCard.classList.add('selected');
        }
        
        // Webp primeiro (mais rápido), fallback para png
        let imgPathWebp = null;
        let imgPathPng = null;
        if (mapping.asset) {
            const subdir = mapping.subdir || 'images';
            const base = `nui://${mapping.asset}/${subdir}/${gender}/${i}`;
            imgPathWebp = base + '.webp';
            imgPathPng = base + '.png';
        }
        
        if (imgPathWebp) {
            itemCard.innerHTML = `
                <img src="${imgPathWebp}" data-fallback="${imgPathPng}" onerror="if(this.dataset.fallback){this.src=this.dataset.fallback;this.dataset.fallback='';}else{this.style.display='none';this.nextElementSibling.style.display='flex';}" alt="Item ${i}" loading="lazy">
                <div class="item-icon" style="display:none;">${mapping.name.charAt(0)}</div>
                <span class="item-id">${i}</span>
            `;
        } else {
            // Sem recurso de imagens - mostrar apenas ícone
            itemCard.innerHTML = `
                <div class="item-icon">${mapping.name.charAt(0)}</div>
                <span class="item-id">${i}</span>
            `;
        }
        
        itemCard.addEventListener('click', () => selectItem(i));
        
        elements.itemsGrid.appendChild(itemCard);
    }
    
    // Atualizar paginação
    const totalPages = Math.ceil(maxItems / state.itemsPerPage);
    if (elements.pageNumber) {
        elements.pageNumber.textContent = useInfiniteScroll ? '-' : state.currentPage;
    }
    if (elements.itemNumber) {
        elements.itemNumber.textContent = state.selectedItem >= 0 ? state.selectedItem : '-';
    }
}

function selectItem(index) {
    state.selectedItem = index;
    state.selectedTexture = 0;
    
    // Atualizar visual
    document.querySelectorAll('.item-card').forEach(card => {
        card.classList.remove('selected');
        if (parseInt(card.dataset.index) === index) {
            card.classList.add('selected');
        }
    });
    
    elements.itemNumber.textContent = index;
    updateTextureDisplay();
    
    // Enviar para o jogo
    applyClothing();
}

function applyClothing() {
    fetch('https://medellin-clothing-ui/applyClothing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            component: state.currentComponent,
            prop: state.currentProp,
            drawable: state.selectedItem,
            texture: state.selectedTexture,
        }),
    });
}

// ============================================
// PAGINAÇÃO
// ============================================

function prevPage() {
    if (state.currentPage > 0) {
        state.currentPage--;
        loadItems();
    }
}

function nextPage() {
    const category = state.currentCategory;
    const maxItems = state.maxItems[category] || maxItemsDefault[category] || 100;
    const totalPages = Math.ceil(maxItems / state.itemsPerPage);
    
    if (state.currentPage < totalPages - 1) {
        state.currentPage++;
        loadItems();
    }
}

// ============================================
// TEXTURAS
// ============================================

function nextTexture() {
    if (state.selectedItem < 0) return;
    
    state.selectedTexture++;
    
    // Enviar para verificar se a textura existe
    fetch('https://medellin-clothing-ui/getMaxTexture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            component: state.currentComponent,
            prop: state.currentProp,
            drawable: state.selectedItem,
            currentTexture: state.selectedTexture,
        }),
    }).then(response => response.json()).then(data => {
        if (data.reset) {
            state.selectedTexture = 0;
        }
        updateTextureDisplay();
        applyClothing();
    }).catch(() => {
        updateTextureDisplay();
        applyClothing();
    });
}

function prevTexture() {
    if (state.selectedItem < 0) return;
    
    if (state.selectedTexture > 0) {
        state.selectedTexture--;
    } else {
        // Buscar máximo de texturas para voltar ao último
        fetch('https://medellin-clothing-ui/getMaxTexture', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                component: state.currentComponent,
                prop: state.currentProp,
                drawable: state.selectedItem,
                currentTexture: 999, // Valor alto para obter o máximo
            }),
        }).then(response => response.json()).then(data => {
            state.selectedTexture = Math.max(0, data.maxTexture - 1);
            updateTextureDisplay();
            applyClothing();
        }).catch(() => {
            updateTextureDisplay();
            applyClothing();
        });
        return;
    }
    
    updateTextureDisplay();
    applyClothing();
}

function updateTextureDisplay() {
    if (elements.textureNumber) {
        elements.textureNumber.textContent = state.selectedTexture;
    }
}

function updateItemDisplay() {
    if (elements.itemNumber) {
        elements.itemNumber.textContent = state.selectedItem >= 0 ? state.selectedItem : '-';
    }
}

// ============================================
// NAVEGAÇÃO POR NÚMERO DE ITEM
// ============================================

function nextItem() {
    const category = state.currentCategory;
    const maxItems = state.maxItems[category] || maxItemsDefault[category] || 100;
    
    if (state.selectedItem < maxItems - 1) {
        state.selectedItem++;
    } else {
        state.selectedItem = 0; // Volta ao início
    }
    
    state.selectedTexture = 0;
    updateItemDisplay();
    updateTextureDisplay();
    applyClothing();
    highlightSelectedItem(true); // scroll até o item ao navegar com setas
}

function prevItem() {
    const category = state.currentCategory;
    const maxItems = state.maxItems[category] || maxItemsDefault[category] || 100;
    
    if (state.selectedItem > 0) {
        state.selectedItem--;
    } else {
        state.selectedItem = maxItems - 1; // Vai para o último
    }
    
    state.selectedTexture = 0;
    updateItemDisplay();
    updateTextureDisplay();
    applyClothing();
    highlightSelectedItem(true); // scroll até o item ao navegar com setas
}

function highlightSelectedItem(scrollToItem) {
    // Remove seleção de todos
    document.querySelectorAll('.item-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Adiciona seleção ao item atual
    const selectedCard = document.querySelector(`.item-card[data-index="${state.selectedItem}"]`);
    if (selectedCard) {
        selectedCard.classList.add('selected');
        // Só faz scroll para o item quando o usuário navega com setas (não ao abrir a categoria)
        if (scrollToItem) {
            selectedCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }
}

// ============================================
// ROTAÇÃO DO PERSONAGEM
// ============================================

function rotateCharacter(direction) {
    const callback = direction === 'left' ? 'rotateLeft' : 'rotateRight';
    fetch(`https://medellin-clothing-ui/${callback}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
    });
}

// ============================================
// SALVAR/CANCELAR
// ============================================

function save() {
    fetch('https://medellin-clothing-ui/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            saved: true,
        }),
    });
    
    closeUI();
}

function cancel() {
    fetch('https://medellin-clothing-ui/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            cancelled: true,
        }),
    });
    
    closeUI();
}

// Inicializar
init();
