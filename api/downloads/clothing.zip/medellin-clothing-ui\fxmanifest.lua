--[[
    MEDELLIN CLOTHING UI v1.0
    Sistema de Roupas Visual Personalizado
    
    Cores: Verde/Azul/Preto (Paleta Medellin)
]]

fx_version 'cerulean'
lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
}
game 'gta5'

name 'medellin-clothing-ui'
description 'Sistema de Roupas Visual - Medellin Roleplay'
author 'Medellin Dev Team'
version '1.0.0'

ui_page 'html/index.html'

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client.lua',
}

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/app.js',
}

-- medellin-assets-clothing não é obrigatório: se existir, as imagens do menu carregam; senão o painel abre sem ícones.
dependencies {
    'ox_lib',
    'qbx_core',
}
