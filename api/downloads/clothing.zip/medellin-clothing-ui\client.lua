--[[
    MEDELLIN CLOTHING UI - Client
    Sistema de Roupas Visual Personalizado
]]

local QBCore = nil
local function GetQBCore()
    if not QBCore then
        local ok, core = pcall(function() return exports['qb-core']:GetCoreObject() end)
        if ok and core then QBCore = core end
    end
    return QBCore
end
local isOpen = false
local originalAppearance = nil
local blockEscUntil = 0 -- Timestamp para bloquear ESC
local lastOpenAttempt = 0 -- Cooldown para evitar spam de abertura
local cachedMaxItems = nil -- Cache dos valores máximos

-- ============================================
-- FUNÇÕES AUXILIARES
-- ============================================

local function IsPedValid(ped)
    return ped and DoesEntityExist(ped) and not IsEntityDead(ped)
end

local function IsMale()
    local ped = PlayerPedId()
    if not IsPedValid(ped) then return true end
    local model = GetEntityModel(ped)
    return model == GetHashKey("mp_m_freemode_01")
end

local function GetMaxDrawables(componentId)
    local ped = PlayerPedId()
    if not IsPedValid(ped) then return 0 end
    return GetNumberOfPedDrawableVariations(ped, componentId) or 0
end

local function GetMaxProps(propId)
    local ped = PlayerPedId()
    if not IsPedValid(ped) then return 0 end
    return GetNumberOfPedPropDrawableVariations(ped, propId) or 0
end

local function GetMaxTextures(componentId, drawableId)
    local ped = PlayerPedId()
    if not IsPedValid(ped) then return 0 end
    if drawableId < 0 then return 0 end
    return GetNumberOfPedTextureVariations(ped, componentId, drawableId) or 0
end

local function GetMaxPropTextures(propId, drawableId)
    local ped = PlayerPedId()
    if not IsPedValid(ped) then return 0 end
    if drawableId < 0 then return 0 end
    return GetNumberOfPedPropTextureVariations(ped, propId, drawableId) or 0
end

-- Função segura para aplicar componente
local function SafeSetPedComponent(ped, componentId, drawable, texture)
    if not IsPedValid(ped) then return false end
    if componentId < 0 or componentId > 11 then return false end
    
    local maxDrawable = GetNumberOfPedDrawableVariations(ped, componentId) or 0
    if drawable < 0 or drawable >= maxDrawable then
        drawable = 0
    end
    
    local maxTexture = GetNumberOfPedTextureVariations(ped, componentId, drawable) or 0
    if texture < 0 or texture >= maxTexture then
        texture = 0
    end
    
    SetPedComponentVariation(ped, componentId, drawable, texture, 0)
    return true
end

-- Função segura para aplicar prop
local function SafeSetPedProp(ped, propId, drawable, texture)
    if not IsPedValid(ped) then return false end
    if propId < 0 or propId > 7 then return false end
    
    if drawable == -1 then
        ClearPedProp(ped, propId)
        return true
    end
    
    local maxDrawable = GetNumberOfPedPropDrawableVariations(ped, propId) or 0
    if drawable < 0 or drawable >= maxDrawable then
        ClearPedProp(ped, propId)
        return true
    end
    
    local maxTexture = GetNumberOfPedPropTextureVariations(ped, propId, drawable) or 0
    if texture < 0 or texture >= maxTexture then
        texture = 0
    end
    
    SetPedPropIndex(ped, propId, drawable, texture, true)
    return true
end

local function SaveCurrentAppearance()
    local ped = PlayerPedId()
    
    if not IsPedValid(ped) then return nil end
    
    local appearance = {}
    
    -- Salvar componentes
    for i = 0, 11 do
        appearance["component_" .. i] = {
            drawable = GetPedDrawableVariation(ped, i) or 0,
            texture = GetPedTextureVariation(ped, i) or 0
        }
    end
    
    -- Salvar props
    for i = 0, 7 do
        appearance["prop_" .. i] = {
            drawable = GetPedPropIndex(ped, i) or -1,
            texture = GetPedPropTextureIndex(ped, i) or 0
        }
    end
    
    return appearance
end

local function RestoreAppearance(appearance)
    if not appearance then return end
    
    local ped = PlayerPedId()
    if not IsPedValid(ped) then return end
    
    -- Restaurar componentes
    for i = 0, 11 do
        local comp = appearance["component_" .. i]
        if comp then
            SafeSetPedComponent(ped, i, comp.drawable, comp.texture)
        end
    end
    
    -- Restaurar props
    for i = 0, 7 do
        local prop = appearance["prop_" .. i]
        if prop then
            SafeSetPedProp(ped, i, prop.drawable, prop.texture)
        end
    end
end

-- ============================================
-- ANIMAÇÃO DO PERSONAGEM
-- ============================================

local originalHeading = 0.0
local currentRotation = 0.0
local clothingCam = nil

local function PlayClothingPose()
    CreateThread(function()
        local ped = PlayerPedId()
        
        -- Verificar se ped é válido
        if not IsPedValid(ped) then return end
        
        local coords = GetEntityCoords(ped)
        
        -- Salvar rotação original
        originalHeading = GetEntityHeading(ped)
        
        -- Rotacionar personagem para olhar para a câmera
        local camRot = GetGameplayCamRot(2)
        local newHeading = camRot.z + 180.0
        SetEntityHeading(ped, newHeading)
        currentRotation = newHeading
        
        -- Congelar personagem
        FreezeEntityPosition(ped, true)
        
        -- Destruir câmera anterior se existir
        if clothingCam and DoesCamExist(clothingCam) then
            RenderScriptCams(false, false, 0, true, true)
            DestroyCam(clothingCam, false)
            clothingCam = nil
            Wait(100)
        end
        
        -- Criar câmera com zoom (mostrando corpo inteiro)
        clothingCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
        if clothingCam and DoesCamExist(clothingCam) then
            local camOffset = GetOffsetFromEntityInWorldCoords(ped, 0.0, 2.5, 0.3)
            SetCamCoord(clothingCam, camOffset.x, camOffset.y, camOffset.z)
            PointCamAtCoord(clothingCam, coords.x, coords.y, coords.z - 0.1)
            SetCamFov(clothingCam, 48.0)
            SetCamActive(clothingCam, true)
            RenderScriptCams(true, true, 500, true, true)
        end
        
        -- Animação com braços mais abertos
        local animDict = "amb@world_human_hang_out_street@female_hold_arm@idle_a"
        local animName = "idle_a"
        
        if IsMale() then
            animDict = "amb@world_human_hang_out_street@male_c@idle_a"
            animName = "idle_a"
        end
        
        RequestAnimDict(animDict)
        local timeout = 0
        while not HasAnimDictLoaded(animDict) and timeout < 100 do
            Wait(50)
            timeout = timeout + 1
            -- Verificar se ainda está aberto e ped válido
            if not isOpen or not IsPedValid(PlayerPedId()) then
                RemoveAnimDict(animDict)
                return
            end
        end
        
        -- Verificar novamente antes de aplicar animação
        ped = PlayerPedId()
        if HasAnimDictLoaded(animDict) and isOpen and IsPedValid(ped) then
            TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, 1, 0, false, false, false)
        end
        
        RemoveAnimDict(animDict)
    end)
end

-- Função para rotacionar personagem
local function RotateCharacter(direction)
    if not isOpen then return end
    
    local ped = PlayerPedId()
    if not IsPedValid(ped) then return end
    
    currentRotation = currentRotation + (direction * 5.0) -- 5 graus por frame
    SetEntityHeading(ped, currentRotation)
end

local function StopClothingPose()
    local ped = PlayerPedId()
    
    -- Limpar tasks e descongelar apenas se ped válido
    if IsPedValid(ped) then
        ClearPedTasks(ped)
        FreezeEntityPosition(ped, false)
        SetEntityHeading(ped, originalHeading)
    end
    
    -- Destruir câmera de forma segura
    if clothingCam then
        if DoesCamExist(clothingCam) then
            RenderScriptCams(false, true, 500, true, true)
            SetCamActive(clothingCam, false)
            DestroyCam(clothingCam, false)
        end
        clothingCam = nil
    end
end

-- ============================================
-- ABRIR/FECHAR UI
-- ============================================

local DEBUG = true
local function log(msg) if DEBUG then print("^3[CLOTHING-UI]^7 " .. tostring(msg)) end end

local function OpenClothingUI()
    log("OpenClothingUI chamada")
    if isOpen then log("RETORNO: painel ja aberto (isOpen)") return end
    -- [PÓS-AUDITORIA] Impede abertura simultânea com barbearia/tattoo (fonte única de lock: medellin-utils).
    if GetResourceState('medellin-utils') == 'started' and exports['medellin-utils'] and exports['medellin-utils'].IsAppearanceNuiOpen and exports['medellin-utils']:IsAppearanceNuiOpen() then
        if QBCore and QBCore.Functions then QBCore.Functions.Notify('Feche o outro menu de aparência primeiro.', 'error', 4000) end
        log("RETORNO: outro painel de aparência aberto")
        return
    end
    
    local currentTime = GetGameTimer()
    if currentTime - lastOpenAttempt < 1000 then log("RETORNO: cooldown 1s") return end
    lastOpenAttempt = currentTime
    
    local ped = PlayerPedId()
    if not ped or not DoesEntityExist(ped) then log("RETORNO: ped invalido ou nao existe") return end
    if IsEntityDead(ped) then log("RETORNO: ped morto") return end
    
    isOpen = true
    if GetResourceState('medellin-utils') == 'started' and exports['medellin-utils'] and exports['medellin-utils'].SetAppearanceNuiOpen then
        exports['medellin-utils']:SetAppearanceNuiOpen(true)
    end
    log("Abrindo painel (SetNuiFocus + SendNUIMessage)...")
    
    -- Salvar aparência (protegido: se falhar, painel ainda abre)
    originalAppearance = nil
    local ok, err = pcall(function()
        originalAppearance = SaveCurrentAppearance()
    end)
    if not ok then
        -- Log mas continua
    end
    
    -- Usar cache ou calcular máximo de itens (evita chamadas excessivas)
    if not cachedMaxItems then
        cachedMaxItems = {
            tops = GetMaxDrawables(11),
            undershirts = GetMaxDrawables(8),
            legs = GetMaxDrawables(4),
            shoes = GetMaxDrawables(6),
            accessories = GetMaxDrawables(7),
            glasses = GetMaxProps(1),
            hats = GetMaxProps(0),
            torsos = GetMaxDrawables(3),
            bags = GetMaxDrawables(5),
            bodyArmors = GetMaxDrawables(9),
            masks = GetMaxDrawables(1),
            decals = GetMaxDrawables(10),
            ears = GetMaxProps(2),
            bracelets = GetMaxProps(7),
            watches = GetMaxProps(6),
        }
    end
    
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)
    -- Desativar controles de ataque enquanto menu aberto
    CreateThread(function()
        while isOpen do
            DisableControlAction(0, 24, true)  -- Attack
            DisableControlAction(0, 25, true)  -- Aim
            DisableControlAction(0, 47, true)  -- Weapon
            DisableControlAction(0, 58, true)  -- Weapon
            DisableControlAction(0, 140, true) -- Melee light
            DisableControlAction(0, 141, true) -- Melee heavy
            DisableControlAction(0, 142, true) -- Melee alternate
            DisableControlAction(0, 257, true) -- Attack 2
            DisableControlAction(0, 263, true) -- Melee attack
            DisableControlAction(0, 264, true) -- Melee attack
            Wait(0)
        end
    end)
    log("SendNUIMessage action=open")
    SendNUIMessage({
        action = "open",
        isMale = IsMale(),
        maxItems = cachedMaxItems,
    })
    
    PlayClothingPose()
    log("Painel aberto (NUI enviada). Se nao aparecer, verifique F8 e console do NUI.")
end

-- Limpar cache quando jogador muda de personagem/spawna
AddEventHandler('playerSpawned', function()
    cachedMaxItems = nil
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    cachedMaxItems = nil
    GetQBCore()
end)

local function CloseClothingUI(save)
    if not isOpen then return end
    
    if GetResourceState('medellin-utils') == 'started' and exports['medellin-utils'] and exports['medellin-utils'].SetAppearanceNuiOpen then
        exports['medellin-utils']:SetAppearanceNuiOpen(false)
    end
    
    -- Bloquear ESC por 1 segundo após fechar
    blockEscUntil = GetGameTimer() + 1000
    
    isOpen = false
    
    SetNuiFocusKeepInput(false) -- Restaurar controle normal
    SetNuiFocus(false, false)
    
    -- Parar animação
    StopClothingPose()
    
    if not save and originalAppearance then
        RestoreAppearance(originalAppearance)
    end
    
    originalAppearance = nil
    
    SendNUIMessage({
        action = "close",
    })
end

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    if GetResourceState('medellin-utils') == 'started' and exports['medellin-utils'] and exports['medellin-utils'].SetAppearanceNuiOpen then
        exports['medellin-utils']:SetAppearanceNuiOpen(false)
    end
    if isOpen then SetNuiFocus(false, false) SetNuiFocusKeepInput(false) isOpen = false end
end)

-- ============================================
-- NUI CALLBACKS
-- ============================================

RegisterNUICallback('applyClothing', function(data, cb)
    local ped = PlayerPedId()
    
    if not IsPedValid(ped) then
        cb('error')
        return
    end
    
    local success = false
    
    if data.component ~= nil then
        success = SafeSetPedComponent(ped, data.component, data.drawable or 0, data.texture or 0)
    elseif data.prop ~= nil then
        success = SafeSetPedProp(ped, data.prop, data.drawable or 0, data.texture or 0)
    end
    
    cb(success and 'ok' or 'error')
end)

RegisterNUICallback('getMaxTexture', function(data, cb)
    local ped = PlayerPedId()
    local maxTexture = 0
    
    if data.component then
        maxTexture = GetMaxTextures(data.component, data.drawable)
    elseif data.prop ~= nil then
        maxTexture = GetMaxPropTextures(data.prop, data.drawable)
    end
    
    local reset = data.currentTexture >= maxTexture
    
    cb({ reset = reset, maxTexture = maxTexture })
end)

RegisterNUICallback('getCurrentItem', function(data, cb)
    local ped = PlayerPedId()
    local drawable = -1
    local texture = 0
    
    if data.component then
        drawable = GetPedDrawableVariation(ped, data.component)
        texture = GetPedTextureVariation(ped, data.component)
    elseif data.prop ~= nil then
        drawable = GetPedPropIndex(ped, data.prop)
        texture = GetPedPropTextureIndex(ped, data.prop)
    end
    
    cb({ drawable = drawable, texture = texture })
end)

RegisterNUICallback('save', function(data, cb)
    CloseClothingUI(true)

    -- Salvar aparência no banco via illenium-appearance (server)
    local appearance = exports['illenium-appearance']:getPedAppearance(PlayerPedId())
    if appearance then
        TriggerServerEvent('illenium-appearance:server:saveAppearance', appearance)
    end

    -- Notificação
    lib.notify({ title = 'Roupas', description = 'Roupa salva com sucesso!', type = 'success' })

    cb('ok')
end)

RegisterNUICallback('cancel', function(data, cb)
    CloseClothingUI(false)
    cb('ok')
end)

RegisterNUICallback('rotateLeft', function(data, cb)
    RotateCharacter(-1)
    cb('ok')
end)

RegisterNUICallback('rotateRight', function(data, cb)
    RotateCharacter(1)
    cb('ok')
end)

-- ============================================
-- COMANDOS E EVENTOS
-- ============================================

-- Comando no chat: /roupa
RegisterCommand('roupa', function()
    OpenClothingUI()
end, false)

-- Tecla F8 abre o mesmo painel (pode trocar em Configurações > Teclas do FiveM)
RegisterKeyMapping('roupa', 'Abrir painel de roupas (salvar aparência)', 'keyboard', 'F4') -- Movido de F8 (F8 = console FiveM)

log("========================================")
log("Recurso client.lua carregado. Comando /roupa e tecla F8 registrados.")
log("========================================")

-- Evento para abrir via outros recursos (AddEventHandler = TriggerEvent no client; RegisterNetEvent = TriggerClientEvent do server)
local function OnOpenRequest()
    OpenClothingUI()
end
AddEventHandler('medellin-clothing-ui:open', OnOpenRequest)
RegisterNetEvent('medellin-clothing-ui:open', OnOpenRequest)

-- Integração com illenium-appearance (substituir evento original)
AddEventHandler('medellin-clothing-ui:openFromShop', OnOpenRequest)
RegisterNetEvent('medellin-clothing-ui:openFromShop', OnOpenRequest)

-- ============================================
-- EXPORTS
-- ============================================

exports('OpenClothingUI', OpenClothingUI)
exports('CloseClothingUI', CloseClothingUI)

-- ============================================
-- TECLAS (ESC, A, D)
-- ============================================

CreateThread(function()
    while true do
        local sleep = 500
        
        -- Bloquear ESC durante cooldown (após fechar painel)
        if GetGameTimer() < blockEscUntil then
            sleep = 0
            DisableControlAction(0, 200, true) -- ESC
            SetPauseMenuActive(false)
        end
        
        if isOpen then
            sleep = 5 -- Pequeno delay para não sobrecarregar
            
            -- Verificar se ped ainda é válido
            local ped = PlayerPedId()
            if not IsPedValid(ped) then
                CloseClothingUI(false)
                goto continue
            end
            
            DisableControlAction(0, 200, true) -- ESC
            DisableControlAction(0, 1, true)   -- Mouse
            DisableControlAction(0, 2, true)   -- Mouse
            DisableControlAction(0, 30, true)  -- A (esquerda)
            DisableControlAction(0, 31, true)  -- S
            DisableControlAction(0, 32, true)  -- W
            DisableControlAction(0, 33, true)  -- D (direita)
            DisableControlAction(0, 199, true) -- P (pause menu alternativo)
            
            -- Bloquear menu de pause
            SetPauseMenuActive(false)
            
            -- Tecla ESC - Fechar painel (control 200)
            if IsDisabledControlJustPressed(0, 200) then
                CloseClothingUI(false)
            end
            
            -- Tecla Backspace - Voltar (control 194)
            if IsDisabledControlJustPressed(0, 194) then
                -- Envia mensagem para JS voltar
                SendNUIMessage({ action = "goBack" })
            end
            
            -- Tecla A - Rotacionar esquerda
            if IsDisabledControlJustPressed(0, 34) or IsDisabledControlPressed(0, 34) then
                RotateCharacter(-1)
            end
            
            -- Tecla D - Rotacionar direita
            if IsDisabledControlJustPressed(0, 35) or IsDisabledControlPressed(0, 35) then
                RotateCharacter(1)
            end
        end
        
        ::continue::
        Wait(sleep)
    end
end)

-- ============================================
-- MARKERS LOJA DE ROUPAS
-- ============================================

local ClothingStores = {
    { x = 71.88, y = -1399.13, z = 29.38 },       -- Loja 1
    { x = -708.35, y = -160.94, z = 37.42 },      -- Loja 2
    { x = -158.49, y = -296.58, z = 39.73 },      -- Loja 3
    { x = -829.52, y = -1073.65, z = 11.33 },     -- Loja 4
    { x = -1188.45, y = -765.53, z = 17.32 },     -- Loja 5
    { x = -1457.39, y = -240.97, z = 49.80 },     -- Loja 6 (Ponsonbys)
    { x = 11.95, y = 6514.23, z = 31.88 },         -- Loja 7 (Paleto Bay)
    { x = 1696.71, y = 4829.40, z = 42.06 },      -- Loja 8
    { x = 123.25, y = -228.68, z = 54.56 },       -- Loja 9
    { x = 614.65, y = 2768.28, z = 42.09 },       -- Loja 10
    { x = 1190.49, y = 2714.16, z = 38.22 },      -- Loja 11
    { x = -3173.48, y = 1038.88, z = 20.86 },     -- Loja 12 (Chumash)
    { x = -1108.70, y = 2709.45, z = 19.11 },     -- Loja 13
    { x = 429.27, y = -800.13, z = 29.49 },       -- Loja 14
    { x = -1638.31, y = -1104.74, z = 13.07 },    -- Loja 15 (Nova)
}

-- Mesmo tamanho e estilo do medellin-shops (loja de armas / conveniência)
local function Draw3DText(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
        local factor = (string.len(text)) / 370
        DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 0, 0, 0, 75)
    end
end

-- Raio em que marcador e notificação ficam visíveis (igual loja de armas / conveniência)
local StoreMarkerDistance = 20.0

CreateThread(function()
    Wait(2000)
    while true do
        local sleep = 1000
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        for _, store in ipairs(ClothingStores) do
            if store and store.x and store.y and store.z then
                local storeCoords = vector3(store.x, store.y, store.z)
                local dist = #(playerCoords - storeCoords)
                if dist < StoreMarkerDistance then
                    sleep = 0
                    -- Marcador circular no chão – cor do logo Medellin (Verde #00FF88)
                    DrawMarker(
                        27,
                        store.x, store.y, store.z - 0.98,
                        0.0, 0.0, 0.0,
                        0.0, 0.0, 0.0,
                        1.2, 1.2, 0.15,
                        0, 255, 136, 200,
                        false, true, 2, false, nil, nil, false
                    )
                    if not isOpen then
                        Draw3DText(store.x, store.y, store.z + 0.3, "~g~[E]~w~ Loja de Roupas")
                    end
                    if dist < 3.0 and IsControlJustPressed(0, 38) and not isOpen then
                        OpenClothingUI()
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
