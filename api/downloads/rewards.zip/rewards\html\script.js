// ========================================
// MEDELLIN-REWARDS - Lottie Animation System
// Replicado identico da Santa (hud/main.js linhas 413-539)
// ========================================

var audioPlayer = null;
var lootieAnimation = null;
const lottieQueue = [];

const lottieValueBackground = {
    diamond: "#39ADE6",
    airdrop: "#1146EC",
    "airdrop-marked": "#1146EC",
    gift: "#39ADE6",
    battlepass: undefined,
    money: "#9BEF66",
};

function directPlayLottieAnimation(data) {
    if ($(".rewards-frame").css("display") !== "flex") {
        return;
    }

    $("#reward-value").hide();
    $("#battlepass-reward").css("opacity", "0");
    $("#lottie-background").css("opacity", "0");

    if (lootieAnimation != null) {
        lootieAnimation.destroy();
        lootieAnimation = null;
    }

    if (data.animation === "battlepass") {
        $("#lottie-anim").css({
            width: "12.5vw",
            height: "12.5vw",
            bottom: "6.5vh",
        });
    } else {
        $("#lottie-anim").css({
            width: "10vw",
            height: "10vw",
            bottom: "0vh",
        });
    }

    lootieAnimation = bodymovin.loadAnimation({
        container: document.getElementById("lottie-anim"),
        path: `./animations/${data.animation}.json`,
        renderer: "svg",
        loop: false,
        autoplay: false,
        name: `${data.animation} animation`,
    });

    if (audioPlayer != null) {
        audioPlayer.pause();
    }
    try {
        audioPlayer = new Audio(`./sounds/${data.animation}.ogg`);
        if (audioPlayer) {
            audioPlayer.volume = 0.5;
            audioPlayer.play().catch(function() {});
        }
    } catch (e) {
        // Som nao encontrado - continuar sem som
    }

    lootieAnimation.play();
    const color = lottieValueBackground[data.animation];

    if (color) {
        $("#lottie-background").css(
            "background",
            `radial-gradient(49.85% 50.15% at 50.15% 50.15%, ${color} 0%, rgba(17, 70, 236, 0.00) 100%)`
        );
        $("#lottie-background").css("opacity", "1");
    }

    if (data.animation === "battlepass") {
        const value = data.value;
        if (value && value.item) {
            $("#battlepass-img").attr("src", `${value.item.image}`);
            $(".battlepass-reward-text").html(
                `<h1>${value.item.name}</h1> <span>${value.item.amount}x</span>`
            );
            $("#battlepass-reward").delay(500).animate({ opacity: "1.0" }, 500);
            $(".battlepass-level").html("");
            let initialLevel = value.level <= 2 ? 1 : value.level - 2;
            let endLevel = value.level > 2 ? value.level + 2 : 5;
            if (value.level >= value.maxLevel - 2) {
                initialLevel = value.maxLevel - 4;
                endLevel = value.maxLevel;
            }
            for (let i = initialLevel; i <= endLevel; i++) {
                const atEnd = i === endLevel;
                $(".battlepass-level").append(`
                    <div class="level-box ${value.level >= i ? "colored" : ""}">
                        ${i}
                    </div>
                    ${!atEnd ? `<div class="level-bar ${value.level > i ? "colored" : ""}">` : ""}
                `);
            }
        }
    }

    lootieAnimation.addEventListener("complete", function () {
        lootieAnimation.destroy();
        const delay = 2000;

        if (data.value && data.animation !== "battlepass") {
            $("#reward-value").css(
                "background",
                `linear-gradient(0deg, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), linear-gradient(90deg, ${color} 0%, rgba(0, 0, 0, 0) 50%), linear-gradient(0deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.2))`
            );
            $("#reward-value").find(".icon").show();
            $("#reward-value")
                .find(".icon")
                .attr("src", `./images/${data.animation}.svg`);
            $("#reward-value").find("span").html(`+${data.value}`);
            $("#reward-value").show();
            $("#reward-value")
                .animate({ bottom: "3vh", opacity: "1.0" }, 300)
                .delay(delay)
                .animate({ bottom: "-5vh", opacity: "0.0" }, 300);
        }

        if (data.animation === "airdrop" || data.animation === "airdrop-marked") {
            $("#reward-value").css(
                "background",
                `linear-gradient(0deg, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), linear-gradient(90deg, ${color} 0%, rgba(0, 0, 0, 0) 50%), linear-gradient(0deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.2))`
            );
            $("#reward-value").find(".icon").hide();
            $("#reward-value").find("span").html(`AIRDROP MARCADO NO MAPA`);
            $("#reward-value").show();
            $("#reward-value")
                .animate({ bottom: "3vh", opacity: "1.0" }, 300)
                .delay(delay)
                .animate({ bottom: "-5vh", opacity: "0.0" }, 300);
        }

        if (data.animation === "battlepass") {
            $("#battlepass-reward").animate({ opacity: "0.0" }, 200);
        }

        $("#lottie-background").css("opacity", "0");
        lootieAnimation = null;

        setTimeout(() => {
            lottieQueue.shift();
            if (lottieQueue.length > 0) {
                directPlayLottieAnimation(lottieQueue[0]);
            }
        }, delay);
    });
}

function playLottieAnimation(data) {
    if (lottieQueue.length > 0) {
        lottieQueue.push(data);
        return;
    }
    lottieQueue.push(data);
    directPlayLottieAnimation(data);
}

$(document).ready(function () {
    window.addEventListener("message", function (event) {
        var data = event.data;
        if (data.Action === "playLottieAnimation") {
            playLottieAnimation(data);
        }
    });
});
