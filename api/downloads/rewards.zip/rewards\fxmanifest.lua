fx_version 'cerulean'
game 'gta5'
lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
}

author 'Servidor RP'
description 'Sistema de animacoes Lottie para recompensas (identico Santa)'
version '1.0.0'

ui_page 'html/index.html'

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/main.lua'
}

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/lib/lottie.min.js',
    'html/lib/jquery.min.js',
    'html/animations/*.json',
    'html/sounds/*.ogg',
    'html/images/*.svg'
}

dependencies {
    'ox_lib',
    'qbx_core'
}
