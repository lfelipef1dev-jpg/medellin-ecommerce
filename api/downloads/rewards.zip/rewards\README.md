# Sistema de Recompensas (Rewards) para FiveM (QBox / QBCore)

Tela de recompensa com animações Lottie — ideal para recompensas diárias, conquistas, eventos e presentes.

## Funcionalidades

- Animações Lottie fluidas (JSON, leve)
- Sons de recompensa integrados
- Chamada simples via export de qualquer outro recurso
- Totalmente configurável (ícone, título, texto, cor)

## Como Usar

```lua
-- Em qualquer outro resource:
exports['rewards']:ShowReward({
    title = 'Recompensa Diária!',
    description = 'Você recebeu R$5.000',
    icon = 'money',    -- 'money', 'star', 'chest', etc.
})
```

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)

## Instalação

1. Coloque a pasta `rewards` dentro de `resources/`
2. Adicione ao `server.cfg`:
   ```
   ensure rewards
   ```

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
