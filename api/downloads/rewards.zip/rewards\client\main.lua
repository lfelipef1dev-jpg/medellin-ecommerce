-- ========================================
-- Servidor-REWARDS
-- Sistema de animacoes Lottie de recompensa
-- Identico ao HUD da Santa (rewardsAnimation)
-- ========================================

-- Evento principal: rewardsAnimation
-- Pode ser disparado via:
--   TriggerEvent("rewardsAnimation", "diamond", 500)        -- client local
--   TriggerClientEvent("rewardsAnimation", source, "money", 1000) -- server -> client
RegisterNetEvent("rewardsAnimation")
AddEventHandler("rewardsAnimation", function(Animation, Value)
    SendNUIMessage({
        Action = "playLottieAnimation",
        animation = Animation,
        value = Value
    })
end)

-- Export para outros recursos chamarem diretamente
exports('PlayRewardAnimation', function(animationType, value)
    TriggerEvent("rewardsAnimation", animationType, value)
end)

-- Comando de teste (F8: testreward <tipo> [valor])
RegisterCommand('testreward', function(_, args)
    local anim = args[1] or 'diamond'
    local val = tonumber(args[2]) or nil
    TriggerEvent("rewardsAnimation", anim, val)
end, false)
