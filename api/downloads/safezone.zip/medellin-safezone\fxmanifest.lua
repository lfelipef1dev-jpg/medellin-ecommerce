fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Medellin - Sistema de Safe Zone'
version '1.0.0'

dependencies { 'ox_lib' }

shared_scripts { '@ox_lib/init.lua', 'config.lua' }
server_scripts { '@oxmysql/lib/MySQL.lua', 'server/*.lua' }
client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/*.lua'
}
ui_page 'web/index.html'
files { 'web/**' }
