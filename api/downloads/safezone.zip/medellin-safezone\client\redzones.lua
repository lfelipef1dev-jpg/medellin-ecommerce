local QBCore = exports['qb-core']:GetCoreObject()

-- Red zones de facções
-- As coordenadas específicas devem ser adaptadas ao mapa do Medellín

local inRedZone = false
local currentRedZone = nil

exports('IsInRedZone', function()
    return inRedZone
end)

exports('GetCurrentRedZone', function()
    return currentRedZone
end)

-- Zonas vermelhas serão criadas via PolyZone quando configuradas
-- Placeholder para expansão futura com coordenadas do mapa Medellín
