-- Tema compartilhado (NUI pede ao iniciar)
RegisterNUICallback("getTheme", function(_, cb)
    cb({
        colors = {
            main = { [50] = '#00ff99', [100] = '#00ff88', [200] = '#00ee7a', [300] = '#00dd6c', [400] = '#00cc6a', [500] = '#00bb5e', [600] = '#00aa52', [700] = '#009946', [800] = '#00883a', [900] = '#00772e' },
            ['main-opacity'] = { [50] = 'rgba(0, 187, 94, 0.05)', [100] = 'rgba(0, 187, 94, 0.1)', [200] = 'rgba(0, 187, 94, 0.2)', [300] = 'rgba(0, 187, 94, 0.3)', [400] = 'rgba(0, 187, 94, 0.4)', [500] = 'rgba(0, 187, 94, 0.5)', [600] = 'rgba(0, 187, 94, 0.6)', [700] = 'rgba(0, 187, 94, 0.7)', [800] = 'rgba(0, 187, 94, 0.8)', [900] = 'rgba(0, 187, 94, 0.9)' },
            white = { [50] = '#ffffff', [100] = '#ffffff', [200] = '#f0f0f0', [300] = '#e0e0e0', [400] = '#d0d0d0', [500] = '#c0c0c0' },
            dark = { [100] = '#0d1f14', [200] = '#0f2518', [300] = '#112b1c', [400] = '#133120', [500] = '#153724' },
            background = { [50] = '#0a1a10', [200] = '#0f2518', [700] = '#009946' },
        }
    })
end)

-- Sistema de vídeo/promoção
RegisterNetEvent('medellin-safezone:client:openVideo', function(url)
    SendNUIMessage({ action = "setVideo", url = url })
end)

RegisterNUICallback("closeVideo", function(_, cb)
    SendNUIMessage({ action = "hideVideo" })
    cb('ok')
end)
