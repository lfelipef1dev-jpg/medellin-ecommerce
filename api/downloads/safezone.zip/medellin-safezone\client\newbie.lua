local QBCore = exports['qb-core']:GetCoreObject()

local isNewbie = false

RegisterNetEvent('medellin-safezone:client:setNewbie', function(state)
    isNewbie = state
end)

-- Proteger novatos ao morrer
AddEventHandler('gameEventTriggered', function(name, args)
    if name == 'CEventNetworkEntityDamage' and isNewbie then
        local victim = args[1]
        if victim == PlayerPedId() and IsPedDeadOrDying(victim) then
            local reviveCoords = Config.NewbieReviveCoords
            SetEntityCoords(victim, reviveCoords.x, reviveCoords.y, reviveCoords.z, false, false, false, false)
            NetworkResurrectLocalPlayer(reviveCoords.x, reviveCoords.y, reviveCoords.z, 0.0, true, false)
            SetEntityHealth(victim, GetEntityMaxHealth(victim))
            TriggerEvent('Notify', 'amarelo', 'Você foi protegido pelo modo novato. Use /safezone para desativar.', 5000)
        end
    end
end)
