local QBCore = exports['qb-core']:GetCoreObject()

local inSafeZone = false
local safeMode = false

-- Criar safe zones usando ox_lib (migrado de PolyZone)
CreateThread(function()
    for _, zone in ipairs(Config.SafeZones) do
        lib.zones.sphere({
            coords = zone.coords,
            radius = zone.radius,
            debug = false,
            onEnter = function()
                inSafeZone = true
                TriggerServerEvent('medellin-safezone:server:setSafeZone', true)
                TriggerEvent('Notify', 'verde', 'Você entrou na zona segura: ' .. zone.name, 3000)
            end,
            onExit = function()
                inSafeZone = false
                TriggerServerEvent('medellin-safezone:server:setSafeZone', false)
                TriggerEvent('Notify', 'amarelo', 'Você saiu da zona segura: ' .. zone.name, 3000)
            end,
        })
    end
end)

-- Thread 1 (Wait(500)): Natives que PERSISTEM — health, invincibilidade
-- Nao precisam rodar todo frame, basta reaplicar a cada 500ms
CreateThread(function()
    while true do
        if inSafeZone then
            local ped = PlayerPedId()
            if GetEntityHealth(ped) < GetEntityMaxHealth(ped) then
                SetEntityHealth(ped, GetEntityMaxHealth(ped))
            end
            SetEntityInvincible(ped, true)
            Wait(500)
        else
            local ped = PlayerPedId()
            SetEntityInvincible(ped, false)
            Wait(1000)
        end
    end
end)

-- Thread 2 (Wait(0)): SOMENTE natives ThisFrame — DisableControlAction + DisablePlayerFiring
-- So roda quando inSafeZone == true (custo zero quando fora da safezone)
CreateThread(function()
    while true do
        if inSafeZone then
            DisablePlayerFiring(PlayerId(), true)
            DisableControlAction(0, 24, true)  -- Attack
            DisableControlAction(0, 25, true)  -- Aim
            DisableControlAction(0, 140, true) -- Melee
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- Prevenir dano por queda na safe zone
AddEventHandler('gameEventTriggered', function(name, args)
    if name == 'CEventNetworkEntityDamage' then
        local victim = args[1]
        if victim == PlayerPedId() and inSafeZone then
            SetEntityHealth(victim, GetEntityMaxHealth(victim))
        end
    end
end)

-- Cleanup ao parar o resource
AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        local ped = PlayerPedId()
        SetEntityInvincible(ped, false)
    end
end)

-- Handlers de warmode (recebidos do server)
RegisterNetEvent('medellin-safezone:client:warModeEntered', function()
    safeMode = false
    inSafeZone = false
    local ped = PlayerPedId()
    SetEntityInvincible(ped, false)
    TriggerEvent('Notify', 'vermelho', 'Modo guerra ativado! PVP habilitado.', 5000)
end)

RegisterNetEvent('medellin-safezone:client:warModeExited', function()
    safeMode = true
    TriggerEvent('Notify', 'verde', 'Modo guerra desativado. Você está seguro.', 5000)
end)

-- Export para outros recursos
exports('IsInSafeZone', function()
    return inSafeZone
end)
