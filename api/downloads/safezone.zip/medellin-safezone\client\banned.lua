local QBCore = exports['qb-core']:GetCoreObject()

local isBanned = false

RegisterNetEvent('medellin-safezone:client:setBanned', function(state)
    isBanned = state
end)

CreateThread(function()
    while true do
        if isBanned then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local bannedPos = Config.BannedIsland

            -- Restringir à ilha de banidos
            if #(coords - bannedPos) > 200.0 then
                SetEntityCoords(ped, bannedPos.x, bannedPos.y, bannedPos.z, false, false, false, false)
                TriggerEvent('Notify', 'vermelho', 'Você está banido e restrito a esta área.', 5000)
            end

            -- Auto revive se morrer
            if GetEntityHealth(ped) <= 100 then
                SetEntityHealth(ped, 200)
            end

            -- Remover armas
            RemoveAllPedWeapons(ped, true)
            Wait(1000)
        else
            Wait(5000)
        end
    end
end)
