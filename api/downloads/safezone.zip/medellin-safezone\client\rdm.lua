local QBCore = exports['qb-core']:GetCoreObject()

-- Sistema anti-RDM em zonas de facção
-- Checa se o atacante tem permissão na zona da facção

RegisterNetEvent('medellin-safezone:client:factionPermResult', function(hasPermission)
    if not hasPermission then
        local ped = PlayerPedId()
        SetEntityHealth(ped, 0)
        TriggerEvent('Notify', 'vermelho', 'Você não tem permissão para atacar nesta zona.', 5000)
    end
end)
