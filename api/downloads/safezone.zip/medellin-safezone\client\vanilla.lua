-- Vanilla Unicorn prop management
local vanillaProps = {}
local inVanilla = false

local propPositions = {
    { coords = vector3(127.82, -1298.48, 29.25), rotation = vector3(0.0, 0.0, 30.0) },
    { coords = vector3(126.82, -1299.48, 29.25), rotation = vector3(0.0, 0.0, 30.0) },
    { coords = vector3(128.82, -1297.48, 29.25), rotation = vector3(0.0, 0.0, 30.0) },
}

local vanillaZone = nil

CreateThread(function()
    vanillaZone = lib.zones.sphere({
        coords = vector3(127.82, -1298.48, 29.25),
        radius = 30.0,
        debug = false,
        onEnter = function()
            inVanilla = true
            for _, prop in ipairs(propPositions) do
                local model = GetHashKey('v_res_d_paddedwall')
                RequestModel(model)
                while not HasModelLoaded(model) do Wait(10) end
                local obj = CreateObject(model, prop.coords.x, prop.coords.y, prop.coords.z, false, false, false)
                SetEntityRotation(obj, prop.rotation.x, prop.rotation.y, prop.rotation.z, 2, true)
                FreezeEntityPosition(obj, true)
                vanillaProps[#vanillaProps + 1] = obj
            end
        end,
        onExit = function()
            inVanilla = false
            for _, obj in ipairs(vanillaProps) do
                if DoesEntityExist(obj) then DeleteEntity(obj) end
            end
            vanillaProps = {}
        end,
    })
end)
