-- Helper seguro para setar bucket
local function SafeSetBucket(src, bucket)
    SetPlayerRoutingBucket(src, bucket)
    -- Mover veículo junto se estiver em um
    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then
        local vehicle = GetVehiclePedIsIn(ped, false)
        if vehicle and vehicle ~= 0 then
            SetEntityRoutingBucket(vehicle, bucket)
        end
    end
end

-- Definir safe zone state
RegisterNetEvent('medellin-safezone:server:setSafeZone', function(state)
    local src = source
    local Player = exports['qbx_core']:GetPlayer(src)
    if not Player then return end
    if type(state) ~= 'boolean' then return end
    Player.Functions.SetMetaData('inSafeZone', state)
end)

-- Definir safe mode
RegisterNetEvent('medellin-safezone:server:setSafeMode', function(state)
    local src = source
    local Player = exports['qbx_core']:GetPlayer(src)
    if not Player then return end
    if type(state) ~= 'boolean' then return end
    Player.Functions.SetMetaData('safeMode', state)
end)

-- Safe world event (mover entre dimensões safe/war) - validado server-side
RegisterNetEvent('medellin-safezone:server:safeWorld', function(enter)
    local src = source
    local Player = exports['qbx_core']:GetPlayer(src)
    if not Player then return end
    if type(enter) ~= 'boolean' then return end

    if enter then
        SafeSetBucket(src, src + 1000) -- Dimensão individual
    else
        SafeSetBucket(src, 0) -- Mundo padrão
    end
end)

-- Vanilla bucket (strip club) - validado server-side
RegisterNetEvent('medellin-safezone:server:vanillaBucket', function(enter)
    local src = source
    local Player = exports['qbx_core']:GetPlayer(src)
    if not Player then return end
    if type(enter) ~= 'boolean' then return end

    if enter then
        SafeSetBucket(src, 999)
    else
        SafeSetBucket(src, 0)
    end
end)
