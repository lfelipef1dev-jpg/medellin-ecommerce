local QBCore = exports['qb-core']:GetCoreObject()

local warModeCooldowns = {}
local srcToCitizenId = {}

AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
    srcToCitizenId[Player.PlayerData.source] = Player.PlayerData.citizenid
end)

RegisterNetEvent('medellin-safezone:server:enterWarMode', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local citizenid = Player.PlayerData.citizenid
    srcToCitizenId[src] = citizenid

    -- Checar cooldown (60 segundos)
    if warModeCooldowns[citizenid] and os.time() < warModeCooldowns[citizenid] then
        local remaining = warModeCooldowns[citizenid] - os.time()
        TriggerClientEvent('Notify', src, 'vermelho', 'Aguarde ' .. remaining .. 's para entrar no modo guerra.', 5000)
        return
    end

    -- Setar bucket de guerra (bucket 0 = mundo normal com PVP)
    SetPlayerRoutingBucket(src, 0)
    TriggerClientEvent('medellin-safezone:client:warModeEntered', src)
end)

RegisterNetEvent('medellin-safezone:server:exitWarMode', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local citizenid = Player.PlayerData.citizenid
    warModeCooldowns[citizenid] = os.time() + 60

    -- Setar bucket safe
    SetPlayerRoutingBucket(src, src + 1000)
    TriggerClientEvent('medellin-safezone:client:warModeExited', src)
end)

-- Cleanup on disconnect (GetPlayer não funciona aqui)
AddEventHandler('playerDropped', function()
    local src = source
    local citizenid = srcToCitizenId[src]
    srcToCitizenId[src] = nil
    if citizenid then
        warModeCooldowns[citizenid] = nil
    end
end)
