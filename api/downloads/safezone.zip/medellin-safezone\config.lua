Config = {}

Config.SafeZones = {
    { name = "Pier", coords = vector3(-1611.36, -972.13, 13.01), radius = 150.0 },
    { name = "Hospital", coords = vector3(338.17, -1394.87, 32.51), radius = 100.0 },
    { name = "Dealership", coords = vector3(-56.49, -1096.64, 26.42), radius = 80.0 },
    { name = "Mecanica", coords = vector3(-337.39, -136.83, 39.01), radius = 60.0 },
}

Config.BannedIsland = vector3(2844.81, -1434.19, 12.67)
Config.NewbieReviveCoords = vector3(-1611.36, -972.13, 13.01)

Config.AdminJobs = {
    ['admin'] = true,
    ['god'] = true,
}
