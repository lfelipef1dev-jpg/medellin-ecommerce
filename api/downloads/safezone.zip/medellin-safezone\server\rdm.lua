local QBCore = exports['qb-core']:GetCoreObject()

-- Checar se jogador tem permissão na facção
RegisterNetEvent('medellin-safezone:server:checkFactionPerm', function(faction)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local gang = Player.PlayerData.gang
    if gang and gang.name == faction then
        TriggerClientEvent('medellin-safezone:client:factionPermResult', src, true)
    else
        TriggerClientEvent('medellin-safezone:client:factionPermResult', src, false)
    end
end)
