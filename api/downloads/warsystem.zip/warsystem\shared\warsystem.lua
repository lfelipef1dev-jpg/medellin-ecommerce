WarConfig = {}

WarConfig.Groups = {
    "policia", "grove", "ballas", "vagos", "marabunta", "triads", "lost",
    "families", "aztecas", "professionals", "cartel", "bratva", "yakuza",
    "bloods", "crips", "hells", "outlaws", "warlocks", "sons", "sindicato",
    "mercenarios", "franca", "italia", "mexico", "israel", "russia",
    "gringa", "china", "brancos", "luxor", "bahamas", "bellagio",
    "laranjas", "verdes", "redline", "bennys", "driftking", "topgear"
}

WarConfig.Zones = {
    [1] = { name = "Porto", coords = vector3(-721.53, -1349.75, 1.6), radius = 150.0 },
    [2] = { name = "Industria", coords = vector3(1082.0, -2000.0, 30.0), radius = 120.0 },
    [3] = { name = "Sandy Shores", coords = vector3(1848.0, 3694.0, 34.0), radius = 200.0 },
    [4] = { name = "Paleto Bay", coords = vector3(-225.0, 6332.0, 32.0), radius = 150.0 },
    [5] = { name = "Zancudo", coords = vector3(-2352.0, 3249.0, 32.0), radius = 200.0 },
    -- Adicionar mais zonas conforme o mapa do seu servidor
}

WarConfig.KillLimit = 30
WarConfig.InvasionCooldown = 1800 -- 30 min cooldown
