-- Funções auxiliares para 1v1
function GetX1Ranking()
    return MySQL.query.await('SELECT citizenid, wins, losses FROM rank_1x1 ORDER BY wins DESC LIMIT 20', {})
end
