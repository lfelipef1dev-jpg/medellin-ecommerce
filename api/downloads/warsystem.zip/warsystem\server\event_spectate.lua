local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('warsystem:server:spectateEvent', function(eventId, targetSrc)
    local src = source
    local targetPed = GetPlayerPed(targetSrc)
    if targetPed and targetPed ~= 0 then
        local coords = GetEntityCoords(targetPed)
        TriggerClientEvent('warsystem:client:spectatePlayer', src, coords)
    end
end)
