local QBCore = exports['qb-core']:GetCoreObject()

-- Placeholder para sistema de invasão
RegisterNetEvent('warsystem:client:invasionStarted', function(data)
    TriggerEvent('Notify', 'amarelo', 'Invasão iniciada!', 5000)
end)
