var fs2 = require('fs');
var content = fs2.readFileSync('H:/Medellin/qbox-staging/resources/medellin-warsystem/web/assets/index.f6399ba6.js', 'utf8');
var regex = /colors\["?main-opacity"?\]/g;
var m;
while (m = regex.exec(content)) {
    var ctx = content.substring(m.index, m.index + 100);
    console.log(ctx);
    console.log('---');
}
// Also check for "red"
regex = /colors\.(red|dark)/g;
while (m = regex.exec(content)) {
    var ctx = content.substring(m.index, m.index + 100);
    console.log(ctx);
    console.log('---');
}
