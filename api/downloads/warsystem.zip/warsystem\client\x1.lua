local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('warsystem:client:x1Started', function(match)
    SendNUIMessage({ action = "x1Started", data = match })
    TriggerEvent('Notify', 'verde', 'Match 1v1 iniciado!', 5000)
end)

RegisterNetEvent('warsystem:client:x1ScoreUpdate', function(matchId, score1, score2)
    SendNUIMessage({ action = "x1Score", score1 = score1, score2 = score2 })
end)

RegisterNetEvent('warsystem:client:x1Ended', function(matchId, winner)
    local src = PlayerId()
    SendNUIMessage({ action = "x1Ended", winner = winner })
    if GetPlayerServerId(src) == winner then
        TriggerEvent('Notify', 'verde', 'Você venceu o 1v1!', 8000)
    else
        TriggerEvent('Notify', 'vermelho', 'Você perdeu o 1x1.', 8000)
    end
end)

RegisterNetEvent('warsystem:client:x1QueueUpdate', function(position)
    TriggerEvent('Notify', 'amarelo', 'Posição na fila: ' .. position, 3000)
end)
