DominationConfig = {}

DominationConfig.Zones = {
    [1] = { name = "Porto", coords = vector3(-721.53, -1349.75, 1.6), radius = 100.0, points = 2, doublePoints = false },
    [2] = { name = "Industria", coords = vector3(1082.0, -2000.0, 30.0), radius = 80.0, points = 1, doublePoints = false },
    [3] = { name = "Favela 1", coords = vector3(448.0, -1720.0, 29.0), radius = 80.0, points = 1, doublePoints = false },
    [4] = { name = "Favela 2", coords = vector3(100.0, -1927.0, 20.0), radius = 80.0, points = 1, doublePoints = false },
    [5] = { name = "Aeroporto", coords = vector3(-1034.0, -2733.0, 20.0), radius = 150.0, points = 3, doublePoints = true },
    -- Adicionar mais zonas
}

DominationConfig.Types = {
    ["Armas"] = { reward = "weapon_pistol", amount = 1 },
    ["Municoes"] = { reward = "ammo-9", amount = 50 },
    ["Drogas"] = { reward = "weed_brick", amount = 5 },
    ["Desmanche"] = { reward = "metalscrap", amount = 10 },
    ["Lavagem"] = { reward = "markedbills", amount = 5 },
    ["Legais"] = { reward = "sandwich", amount = 10 },
}

DominationConfig.AutoDom = {
    [1] = { name = "Porto", coords = vector3(-721.53, -1349.75, 1.6), radius = 80.0, time = 300 },
    [2] = { name = "Industria", coords = vector3(1082.0, -2000.0, 30.0), radius = 80.0, time = 300 },
}

DominationConfig.CaptureTime = 120 -- segundos para capturar
DominationConfig.PointInterval = 60 -- intervalo para ganhar pontos
