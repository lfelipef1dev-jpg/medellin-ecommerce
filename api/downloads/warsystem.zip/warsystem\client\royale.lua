local QBCore = exports['qb-core']:GetCoreObject()

local royaleActive = false
local currentRadius = 0

RegisterNetEvent('warsystem:client:royaleStarted', function(state)
    royaleActive = true
    currentRadius = state.currentRadius
    TriggerEvent('Notify', 'amarelo', 'Battle Royale iniciado! Zona: ' .. currentRadius .. 'm', 8000)
end)

RegisterNetEvent('warsystem:client:royaleUpdate', function(newRadius)
    currentRadius = newRadius
    TriggerEvent('Notify', 'vermelho', 'Zona encolhendo! Novo raio: ' .. math.floor(newRadius) .. 'm', 5000)
end)

-- Thread de dano fora da zona
CreateThread(function()
    while true do
        if royaleActive and currentRadius > 0 then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local dist = #(coords - RoyaleConfig.Center)
            if dist > currentRadius then
                ApplyDamageToPed(ped, RoyaleConfig.DamageOutside, false)
            end
            Wait(1000)
        else
            Wait(5000)
        end
    end
end)
