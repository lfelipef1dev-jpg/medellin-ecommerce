local QBCore = exports['qb-core']:GetCoreObject()

-- Auto-dominação: zonas que geram pontos passivamente
local autoDomOwners = {}

CreateThread(function()
    while true do
        Wait(DominationConfig.PointInterval * 1000)
        for id, zone in pairs(DominationConfig.AutoDom) do
            if autoDomOwners[id] then
                -- Dar pontos à facção dona
                MySQL.insert.await('INSERT INTO domination_points (zone_id, gang, points, earned_at) VALUES (?, ?, ?, NOW())', { id, autoDomOwners[id], DominationConfig.Zones[1] and DominationConfig.Zones[1].points or 1 })
            end
        end
    end
end)

RegisterNetEvent('warsystem:server:setAutoDomOwner', function(zoneId, gangName)
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') then return end
    autoDomOwners[zoneId] = gangName
end)
