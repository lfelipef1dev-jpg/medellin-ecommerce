local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('warsystem:client:loadConfig', function()
    -- Config já carregado via shared_scripts
end)

-- Tema compartilhado (NUI pede ao iniciar)
RegisterNUICallback("getTheme", function(_, cb)
    cb({
        colors = {
            main = { [50] = '#00ff99', [100] = '#00ff88', [200] = '#00ee7a', [300] = '#00dd6c', [400] = '#00cc6a', [500] = '#00bb5e', [600] = '#00aa52', [700] = '#009946', [800] = '#00883a', [900] = '#00772e' },
            ['main-opacity'] = { [50] = 'rgba(0, 187, 94, 0.05)', [100] = 'rgba(0, 187, 94, 0.1)', [200] = 'rgba(0, 187, 94, 0.2)', [300] = 'rgba(0, 187, 94, 0.3)', [400] = 'rgba(0, 187, 94, 0.4)', [500] = 'rgba(0, 187, 94, 0.5)', [600] = 'rgba(0, 187, 94, 0.6)', [700] = 'rgba(0, 187, 94, 0.7)', [800] = 'rgba(0, 187, 94, 0.8)', [900] = 'rgba(0, 187, 94, 0.9)' },
            red = { [50] = '#ffe1e1', [100] = '#ffb1b1', [200] = '#ff7f7f', [300] = '#ff4c4c', [400] = '#ff1a1a', [500] = '#e60000', [600] = '#b40000', [700] = '#810000', [800] = '#500000', [900] = '#210000' },
            ['red-opacity'] = { [50] = 'rgba(255, 29, 29, 0)', [100] = 'rgba(255, 29, 29, 0.1)', [200] = 'rgba(255, 29, 29, 0.2)', [300] = 'rgba(255, 29, 29, 0.3)', [400] = 'rgba(255, 29, 29, 0.4)', [500] = 'rgba(255, 29, 29, 0.5)', [600] = 'rgba(255, 29, 29, 0.6)', [700] = 'rgba(255, 29, 29, 0.7)', [800] = 'rgba(255, 29, 29, 0.8)', [900] = 'rgba(255, 29, 29, 0.9)' },
            white = { [50] = '#ffffff', [100] = '#ffffff', [200] = '#f0f0f0', [300] = '#e0e0e0', [400] = '#d0d0d0', [500] = '#c0c0c0', [600] = '#a0a0a0', [700] = '#808080', [800] = '#606060', [900] = '#404040' },
            dark = { [50] = '#0a1a10', [100] = '#0d1f14', [200] = '#0f2518', [300] = '#112b1c', [400] = '#133120', [500] = '#153724', [600] = '#173d28', [700] = '#19432c', [800] = '#1b4930', [900] = '#1d4f34' },
            background = { [50] = '#0a1a10', [100] = '#0c1f14', [200] = '#0f2518', [300] = '#112b1c', [400] = '#133120', [500] = '#153724', [600] = '#173d28', [700] = '#009946', [800] = '#00883a', [900] = '#00772e' },
        }
    })
end)

-- NUI handlers
RegisterNUICallback("close", function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

-- Spectate
RegisterNetEvent('warsystem:client:spectatePlayer', function(coords)
    SetEntityCoords(PlayerPedId(), coords.x, coords.y, coords.z + 5.0)
    FreezeEntityPosition(PlayerPedId(), true)
end)

RegisterCommand("stopspectate", function()
    FreezeEntityPosition(PlayerPedId(), false)
end, false)
