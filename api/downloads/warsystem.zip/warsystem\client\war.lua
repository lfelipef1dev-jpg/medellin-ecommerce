local QBCore = exports['qb-core']:GetCoreObject()

local activeWar = nil

RegisterNetEvent('warsystem:client:warStarted', function(war)
    activeWar = war
    SendNUIMessage({ action = "warStarted", data = war })
    TriggerEvent('Notify', 'amarelo', 'Guerra iniciada: ' .. war.attacker .. ' vs ' .. war.defender, 10000)
end)

RegisterNetEvent('warsystem:client:updateKills', function(warId, attackerKills, defenderKills)
    if activeWar and activeWar.id == warId then
        activeWar.attackerKills = attackerKills
        activeWar.defenderKills = defenderKills
        SendNUIMessage({ action = "updateKills", attacker = attackerKills, defender = defenderKills })
    end
end)

RegisterNetEvent('warsystem:client:warEnded', function(warId, winner)
    if activeWar and activeWar.id == warId then
        SendNUIMessage({ action = "warEnded", winner = winner })
        activeWar = nil
    end
end)
