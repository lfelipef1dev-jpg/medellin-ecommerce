-- Spectate system (war)
local spectating = false

RegisterNetEvent('warsystem:client:startSpectate', function(targetCoords)
    spectating = true
    SetEntityCoords(PlayerPedId(), targetCoords.x, targetCoords.y, targetCoords.z + 10.0)
    FreezeEntityPosition(PlayerPedId(), true)
    SetEntityVisible(PlayerPedId(), false, false)
end)

RegisterNetEvent('warsystem:client:stopSpectate', function()
    spectating = false
    FreezeEntityPosition(PlayerPedId(), false)
    SetEntityVisible(PlayerPedId(), true, false)
end)
