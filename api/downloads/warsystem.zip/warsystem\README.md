# War System para FiveM (QBox / QBCore)

Sistema completo de guerra entre gangues/facções, com múltiplos modos de jogo.

## Modos de Jogo

| Modo | Descrição |
|------|-----------|
| **Guerra (War)** | Gangue atacante vs defensora. Primeiro a X kills vence |
| **Invasão** | Uma gangue invade a zona de outra para dominá-la |
| **Dominação** | Captura e defesa de pontos no mapa (zones) |
| **Auto-Dominação** | Zonas que trocam de dono automaticamente por kills acumuladas |
| **Evento** | Admins criam eventos PvP customizados com times |
| **Battle Royale** | Último a sobreviver em zona que encolhe |
| **X1 (Duelo)** | Fila para 1v1 automático entre jogadores |
| **Espectador** | Assistir guerras e eventos ao vivo sem participar |

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)
- `oxmysql`

## Instalação

1. Coloque a pasta `warsystem` dentro de `resources/`
2. Execute o SQL: `sql/install.sql` no seu banco de dados
3. Adicione ao `server.cfg`:
   ```
   ensure warsystem
   ```
4. Configure `shared/warsystem.lua` com suas zonas e gangues

## Configuração Rápida (shared/warsystem.lua)

```lua
-- Facções/gangues do seu servidor
WarConfig.Groups = {
    "policia", "grove", "ballas", "vagos", -- adicione as suas aqui
}

-- Zonas de guerra no mapa (coords + raio)
WarConfig.Zones = {
    [1] = { name = "Porto", coords = vector3(-721.53, -1349.75, 1.6), radius = 150.0 },
    -- adicione mais zonas aqui
}

-- Kills necessárias para vencer uma guerra
WarConfig.KillLimit = 30

-- Cooldown entre invasões do mesmo território (segundos)
WarConfig.InvasionCooldown = 1800
```

## UI

Interface web integrada (React/HTML) para visualização de guerras ativas, placar e fila de X1.

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
