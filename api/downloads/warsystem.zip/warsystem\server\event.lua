local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('warsystem:server:createEvent', function(data)
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') then
        TriggerClientEvent('Notify', src, 'vermelho', 'Sem permissão.', 5000)
        return
    end

    EventIdCounter = EventIdCounter + 1
    local eventId = EventIdCounter
    ActiveEvents[eventId] = {
        id = eventId,
        arena = data.arena,
        teams = {},
        round = 0,
        maxRounds = EventConfig.MaxRounds,
        status = 'waiting',
    }

    TriggerClientEvent('warsystem:client:eventCreated', -1, ActiveEvents[eventId])
    TriggerClientEvent('Notify', src, 'verde', 'Evento criado na arena ' .. data.arena, 5000)
end)

RegisterNetEvent('warsystem:server:joinEvent', function(eventId, team)
    local src = source
    local event = ActiveEvents[eventId]
    if not event or event.status ~= 'waiting' then return end

    if not event.teams[team] then event.teams[team] = {} end
    if #event.teams[team] >= EventConfig.MaxPlayersPerTeam then
        TriggerClientEvent('Notify', src, 'vermelho', 'Time cheio.', 5000)
        return
    end

    event.teams[team][#event.teams[team] + 1] = src
    TriggerClientEvent('Notify', src, 'verde', 'Entrou no time ' .. team, 5000)
end)

RegisterNetEvent('warsystem:server:startEvent', function(eventId)
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') then return end

    local event = ActiveEvents[eventId]
    if not event then return end

    event.status = 'active'
    event.round = 1

    TriggerClientEvent('warsystem:client:eventStarted', -1, eventId)
end)
