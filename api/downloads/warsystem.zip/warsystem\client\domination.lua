local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('warsystem:client:captureStarted', function(zoneId, gangName)
    TriggerEvent('Notify', 'amarelo', gangName .. ' está capturando a zona ' .. zoneId .. '!', 8000)
end)

RegisterNetEvent('warsystem:client:zoneCaptured', function(zoneId, gangName)
    TriggerEvent('Notify', 'verde', gangName .. ' capturou a zona ' .. zoneId .. '!', 8000)
end)

RegisterNetEvent('warsystem:client:captureContested', function(zoneId)
    TriggerEvent('Notify', 'vermelho', 'Captura da zona ' .. zoneId .. ' foi contestada!', 5000)
end)
