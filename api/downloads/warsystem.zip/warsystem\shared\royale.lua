RoyaleConfig = {}

RoyaleConfig.Center = vector3(0.0, 0.0, 30.0)
RoyaleConfig.InitialRadius = 500.0
RoyaleConfig.ShrinkInterval = 60 -- segundos
RoyaleConfig.ShrinkAmount = 50.0 -- metros
RoyaleConfig.MinRadius = 50.0
RoyaleConfig.DamageOutside = 5 -- dano por tick fora do circulo
RoyaleConfig.MaxPlayers = 50
