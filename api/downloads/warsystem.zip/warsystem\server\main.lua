local QBCore = exports['qb-core']:GetCoreObject()

-- Contadores globais de IDs (evita colisão com #table)
WarIdCounter = 0
EventIdCounter = 0

-- Tabelas globais compartilhadas entre arquivos
ActiveEvents = {}

-- Funções auxiliares globais
function GetCitizenId(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return nil end
    return Player.PlayerData.citizenid
end

function GetFullName(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return 'Desconhecido' end
    local ci = Player.PlayerData.charinfo
    return ci.firstname .. ' ' .. ci.lastname
end

function GetPlayerGang(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return nil end
    return Player.PlayerData.gang
end

function IsValidGroup(gangName)
    if not gangName then return false end
    for _, g in ipairs(WarConfig.Groups) do
        if g == gangName then return true end
    end
    return false
end

-- Safe gang name getter (com nil check)
function GetSafeGangName(player)
    if not player or not player.PlayerData or not player.PlayerData.gang then return nil end
    return player.PlayerData.gang.name
end

function GetSafeGangLevel(player)
    if not player or not player.PlayerData or not player.PlayerData.gang or not player.PlayerData.gang.grade then return 0 end
    return player.PlayerData.gang.grade.level or 0
end

-- Enviar para o player ao spawnar (nome correto do evento)
AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
    local src = Player.PlayerData.source
    TriggerClientEvent('warsystem:client:loadConfig', src)
end)
