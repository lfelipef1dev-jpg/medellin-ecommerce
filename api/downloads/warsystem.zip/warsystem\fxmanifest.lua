fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Sistema de Guerra para FiveM (QBox/QBCore)'
version '1.0.0'

shared_scripts { '@ox_lib/init.lua', 'shared/*.lua' }
server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',         -- Deve carregar primeiro (funções globais)
    'server/war.lua',
    'server/invasion.lua',
    'server/domination.lua',
    'server/autodomination.lua',
    'server/event.lua',
    'server/event_functions.lua',
    'server/event_spectate.lua',
    'server/royale.lua',
    'server/war_spectate.lua',
    'server/x1.lua',
    'server/x1_functions.lua',
}
client_scripts { '@qbx_core/modules/playerdata.lua', 'client/*.lua' }
ui_page 'web/index.html'
files { 'web/**' }
