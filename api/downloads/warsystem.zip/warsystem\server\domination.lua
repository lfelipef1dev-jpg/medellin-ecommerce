local QBCore = exports['qb-core']:GetCoreObject()

local dominationState = {} -- Estado de cada zona de dominação

-- Inicializar zonas
CreateThread(function()
    for id, zone in pairs(DominationConfig.Zones) do
        dominationState[id] = {
            owner = nil,
            capturing = nil,
            captureProgress = 0,
            captureStart = nil,
        }
    end
end)

-- Iniciar captura
RegisterNetEvent('warsystem:server:startCapture', function(zoneId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local gang = Player.PlayerData.gang
    if not gang or not IsValidGroup(gang.name) then
        TriggerClientEvent('Notify', src, 'vermelho', 'Você precisa estar em uma facção.', 5000)
        return
    end

    local state = dominationState[zoneId]
    if not state then return end

    if state.owner == gang.name then
        TriggerClientEvent('Notify', src, 'amarelo', 'Sua facção já domina esta zona.', 5000)
        return
    end

    if state.capturing then
        TriggerClientEvent('Notify', src, 'vermelho', 'Esta zona já está sendo capturada.', 5000)
        return
    end

    state.capturing = gang.name
    state.captureStart = os.time()
    state.captureProgress = 0

    -- Notificar todos na área
    TriggerClientEvent('warsystem:client:captureStarted', -1, zoneId, gang.name)
    TriggerClientEvent('Notify', src, 'verde', 'Captura iniciada! Defenda por ' .. DominationConfig.CaptureTime .. 's.', 5000)
end)

-- Thread de captura
CreateThread(function()
    while true do
        Wait(1000)
        for id, state in pairs(dominationState) do
            if state.capturing and state.captureStart then
                local elapsed = os.time() - state.captureStart
                if elapsed >= DominationConfig.CaptureTime then
                    -- Zona capturada
                    state.owner = state.capturing
                    state.capturing = nil
                    state.captureStart = nil
                    state.captureProgress = 0

                    -- Salvar e notificar
                    MySQL.insert.await('INSERT INTO domination_log (zone_id, gang, captured_at) VALUES (?, ?, NOW())', { id, state.owner })
                    TriggerClientEvent('warsystem:client:zoneCaptured', -1, id, state.owner)
                end
            end
        end
    end
end)

-- Contestar captura (defender)
RegisterNetEvent('warsystem:server:contestCapture', function(zoneId)
    local src = source
    local state = dominationState[zoneId]
    if not state or not state.capturing then return end

    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local gang = Player.PlayerData.gang
    -- Se o defensor (dono atual) está presente, reseta a captura
    if gang and gang.name == state.owner then
        state.capturing = nil
        state.captureStart = nil
        state.captureProgress = 0
        TriggerClientEvent('warsystem:client:captureContested', -1, zoneId)
    end
end)
