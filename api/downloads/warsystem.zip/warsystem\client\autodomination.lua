-- Auto-domination client-side events
RegisterNetEvent('warsystem:client:autoDomUpdate', function(zoneId, owner, points)
    -- Atualizar HUD de auto-dominação
end)
