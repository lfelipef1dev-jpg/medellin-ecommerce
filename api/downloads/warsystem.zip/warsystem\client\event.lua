local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('warsystem:client:eventCreated', function(event)
    SendNUIMessage({ action = "eventCreated", data = event })
    TriggerEvent('Notify', 'verde', 'Novo evento criado! Arena: ' .. event.arena, 8000)
end)

RegisterNetEvent('warsystem:client:eventStarted', function(eventId)
    SendNUIMessage({ action = "eventStarted", eventId = eventId })
    TriggerEvent('Notify', 'amarelo', 'Evento começou!', 5000)
end)
