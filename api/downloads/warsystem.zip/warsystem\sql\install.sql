CREATE TABLE IF NOT EXISTS `warsystem` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `attacker` VARCHAR(50) NOT NULL,
    `defender` VARCHAR(50) NOT NULL,
    `zone_id` INT NOT NULL,
    `winner` VARCHAR(50) DEFAULT NULL,
    `attacker_kills` INT DEFAULT 0,
    `defender_kills` INT DEFAULT 0,
    `started` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `ended` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `rank_1x1` (
    `citizenid` VARCHAR(50) PRIMARY KEY,
    `wins` INT DEFAULT 0,
    `losses` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `domination_log` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `zone_id` INT NOT NULL,
    `gang` VARCHAR(50) NOT NULL,
    `captured_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `domination_points` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `zone_id` INT NOT NULL,
    `gang` VARCHAR(50) NOT NULL,
    `points` INT DEFAULT 0,
    `earned_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
