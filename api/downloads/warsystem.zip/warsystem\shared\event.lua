EventConfig = {}

EventConfig.Arenas = {
    [1] = { name = "Arena", coords = vector3(234.0, -1000.0, 30.0), radius = 100.0 },
    [2] = { name = "Predio", coords = vector3(-400.0, -1600.0, 45.0), radius = 80.0 },
    [3] = { name = "Fazenda", coords = vector3(2400.0, 4800.0, 36.0), radius = 150.0 },
    [4] = { name = "Cayo", coords = vector3(5000.0, -5200.0, 30.0), radius = 200.0 },
}

EventConfig.MaxTeams = 4
EventConfig.MaxPlayersPerTeam = 10
EventConfig.RoundTime = 300 -- 5 minutos por round
EventConfig.MaxRounds = 5
