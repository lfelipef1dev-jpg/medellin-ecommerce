-- Funções auxiliares do evento
function GetEventParticipants(eventId)
    local event = ActiveEvents and ActiveEvents[eventId]
    if not event then return {} end
    local participants = {}
    for team, members in pairs(event.teams) do
        for _, src in ipairs(members) do
            participants[#participants + 1] = { source = src, team = team }
        end
    end
    return participants
end
