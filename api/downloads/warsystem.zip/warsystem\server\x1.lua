local QBCore = exports['qb-core']:GetCoreObject()

local x1Queue = {}
local activeX1 = {}

RegisterNetEvent('warsystem:server:joinX1Queue', function()
    local src = source
    -- Evitar duplicatas
    for _, s in ipairs(x1Queue) do
        if s == src then
            TriggerClientEvent('Notify', src, 'vermelho', 'Você já está na fila.', 5000)
            return
        end
    end

    x1Queue[#x1Queue + 1] = src
    TriggerClientEvent('Notify', src, 'verde', 'Entrou na fila do 1x1. Posição: ' .. #x1Queue, 5000)
    TriggerClientEvent('warsystem:client:x1QueueUpdate', src, #x1Queue)

    -- Se tem 2 jogadores, iniciar match
    if #x1Queue >= 2 then
        local p1 = table.remove(x1Queue, 1)
        local p2 = table.remove(x1Queue, 1)

        local matchId = #activeX1 + 1
        activeX1[matchId] = {
            id = matchId,
            player1 = p1,
            player2 = p2,
            score1 = 0,
            score2 = 0,
            rounds = 10,
        }

        TriggerClientEvent('warsystem:client:x1Started', p1, activeX1[matchId])
        TriggerClientEvent('warsystem:client:x1Started', p2, activeX1[matchId])
    end
end)

RegisterNetEvent('warsystem:server:x1Kill', function(matchId)
    local src = source
    local match = activeX1[matchId]
    if not match then return end

    if src == match.player1 then
        match.score1 = match.score1 + 1
    elseif src == match.player2 then
        match.score2 = match.score2 + 1
    end

    local totalRounds = match.score1 + match.score2
    local winScore = math.ceil(match.rounds / 2) + 1

    if match.score1 >= winScore or match.score2 >= winScore or totalRounds >= match.rounds then
        local winner = match.score1 > match.score2 and match.player1 or match.player2
        local loser = winner == match.player1 and match.player2 or match.player1

        -- Salvar ranking
        local winnerCid = GetCitizenId(winner)
        local loserCid = GetCitizenId(loser)
        if winnerCid then
            MySQL.insert.await('INSERT INTO rank_1x1 (citizenid, wins, losses) VALUES (?, 1, 0) ON DUPLICATE KEY UPDATE wins = wins + 1', { winnerCid })
        end
        if loserCid then
            MySQL.insert.await('INSERT INTO rank_1x1 (citizenid, wins, losses) VALUES (?, 0, 1) ON DUPLICATE KEY UPDATE losses = losses + 1', { loserCid })
        end

        TriggerClientEvent('warsystem:client:x1Ended', match.player1, matchId, winner)
        TriggerClientEvent('warsystem:client:x1Ended', match.player2, matchId, winner)
        activeX1[matchId] = nil
    else
        TriggerClientEvent('warsystem:client:x1ScoreUpdate', match.player1, matchId, match.score1, match.score2)
        TriggerClientEvent('warsystem:client:x1ScoreUpdate', match.player2, matchId, match.score1, match.score2)
    end
end)

RegisterNetEvent('warsystem:server:leaveX1Queue', function()
    local src = source
    for i, s in ipairs(x1Queue) do
        if s == src then
            table.remove(x1Queue, i)
            TriggerClientEvent('Notify', src, 'amarelo', 'Saiu da fila.', 3000)
            return
        end
    end
end)
