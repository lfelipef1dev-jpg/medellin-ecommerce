local QBCore = exports['qb-core']:GetCoreObject()

local royaleState = {
    active = false,
    players = {},
    currentRadius = RoyaleConfig.InitialRadius,
    center = RoyaleConfig.Center,
}

RegisterNetEvent('warsystem:server:startRoyale', function()
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') then return end

    royaleState.active = true
    royaleState.players = {}
    royaleState.currentRadius = RoyaleConfig.InitialRadius

    TriggerClientEvent('warsystem:client:royaleStarted', -1, royaleState)
    TriggerClientEvent('Notify', src, 'verde', 'Battle Royale iniciado!', 5000)
end)

RegisterNetEvent('warsystem:server:joinRoyale', function()
    local src = source
    if not royaleState.active then return end
    if #royaleState.players >= RoyaleConfig.MaxPlayers then
        TriggerClientEvent('Notify', src, 'vermelho', 'Lotado.', 5000)
        return
    end

    royaleState.players[#royaleState.players + 1] = src
    TriggerClientEvent('Notify', src, 'verde', 'Entrou no Battle Royale!', 5000)
end)

-- Thread de encolhimento
CreateThread(function()
    while true do
        Wait(RoyaleConfig.ShrinkInterval * 1000)
        if royaleState.active then
            royaleState.currentRadius = math.max(RoyaleConfig.MinRadius, royaleState.currentRadius - RoyaleConfig.ShrinkAmount)
            TriggerClientEvent('warsystem:client:royaleUpdate', -1, royaleState.currentRadius)

            if royaleState.currentRadius <= RoyaleConfig.MinRadius then
                -- Zona final
            end
        end
    end
end)
