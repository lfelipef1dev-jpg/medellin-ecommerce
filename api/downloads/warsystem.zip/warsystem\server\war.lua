local QBCore = exports['qb-core']:GetCoreObject()

local activeWars = {}
local warCooldowns = {}

-- Iniciar guerra
RegisterNetEvent('warsystem:server:startWar', function(zoneId, targetGang)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local gangLevel = GetSafeGangLevel(Player)
    local attackerGang = GetSafeGangName(Player)
    if not attackerGang or gangLevel < 4 then
        TriggerClientEvent('Notify', src, 'vermelho', 'Apenas líderes podem declarar guerra.', 5000)
        return
    end

    if not IsValidGroup(attackerGang) or not IsValidGroup(targetGang) then
        TriggerClientEvent('Notify', src, 'vermelho', 'Facção inválida.', 5000)
        return
    end

    -- Cooldown check
    local cooldownKey = attackerGang .. '_' .. targetGang
    if warCooldowns[cooldownKey] and os.time() < warCooldowns[cooldownKey] then
        TriggerClientEvent('Notify', src, 'vermelho', 'Guerra em cooldown.', 5000)
        return
    end

    WarIdCounter = WarIdCounter + 1
    local warId = WarIdCounter
    activeWars[warId] = {
        id = warId,
        zoneId = zoneId,
        attacker = attackerGang,
        defender = targetGang,
        attackerKills = 0,
        defenderKills = 0,
        started = os.time(),
        participants = {},
    }

    -- Salvar no banco
    MySQL.insert.await('INSERT INTO warsystem (attacker, defender, zone_id, started) VALUES (?, ?, ?, NOW())', { attackerGang, targetGang, zoneId })

    -- Notificar ambas facções
    local players = QBCore.Functions.GetQBPlayers()
    for _, v in pairs(players) do
        if v then
            local pGang = GetSafeGangName(v)
            if pGang and (pGang == attackerGang or pGang == targetGang) then
                TriggerClientEvent('Notify', v.PlayerData.source, 'amarelo', 'GUERRA! ' .. attackerGang .. ' vs ' .. targetGang .. '!', 10000)
                TriggerClientEvent('warsystem:client:warStarted', v.PlayerData.source, activeWars[warId])
            end
        end
    end
end)

-- Registrar kill na guerra
RegisterNetEvent('warsystem:server:registerKill', function(warId, victimSrc)
    local src = source
    local war = activeWars[warId]
    if not war then return end

    local killer = QBCore.Functions.GetPlayer(src)
    local victim = QBCore.Functions.GetPlayer(victimSrc)
    if not killer or not victim then return end

    local killerGang = GetSafeGangName(killer)
    if not killerGang then return end
    if killerGang == war.attacker then
        war.attackerKills = war.attackerKills + 1
    elseif killerGang == war.defender then
        war.defenderKills = war.defenderKills + 1
    end

    -- Checar vitória
    if war.attackerKills >= WarConfig.KillLimit then
        EndWar(warId, war.attacker)
    elseif war.defenderKills >= WarConfig.KillLimit then
        EndWar(warId, war.defender)
    else
        -- Broadcast kills
        local players = QBCore.Functions.GetQBPlayers()
        for _, v in pairs(players) do
            if v then
                local pGang = GetSafeGangName(v)
                if pGang and (pGang == war.attacker or pGang == war.defender) then
                    TriggerClientEvent('warsystem:client:updateKills', v.PlayerData.source, warId, war.attackerKills, war.defenderKills)
                end
            end
        end
    end
end)

function EndWar(warId, winner)
    local war = activeWars[warId]
    if not war then return end

    local loser = winner == war.attacker and war.defender or war.attacker
    local cooldownKey = war.attacker .. '_' .. war.defender
    warCooldowns[cooldownKey] = os.time() + WarConfig.InvasionCooldown

    -- Salvar resultado
    MySQL.update.await('UPDATE warsystem SET winner = ?, attacker_kills = ?, defender_kills = ?, ended = NOW() WHERE id = (SELECT id FROM (SELECT MAX(id) as id FROM warsystem WHERE attacker = ? AND defender = ?) t)', { winner, war.attackerKills, war.defenderKills, war.attacker, war.defender })

    -- Notificar
    local players = QBCore.Functions.GetQBPlayers()
    for _, v in pairs(players) do
        if v then
            local pGang = GetSafeGangName(v)
            if pGang and (pGang == war.attacker or pGang == war.defender) then
                TriggerClientEvent('Notify', v.PlayerData.source, 'verde', winner .. ' venceu a guerra!', 10000)
                TriggerClientEvent('warsystem:client:warEnded', v.PlayerData.source, warId, winner)
            end
        end
    end

    activeWars[warId] = nil
end
