local QBCore = exports['qb-core']:GetCoreObject()

-- Sistema de invasão (ataque a território)
RegisterNetEvent('warsystem:server:startInvasion', function(zoneId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local gang = Player.PlayerData.gang
    if not gang or gang.grade.level < 4 then
        TriggerClientEvent('Notify', src, 'vermelho', 'Apenas líderes podem iniciar invasões.', 5000)
        return
    end

    TriggerClientEvent('Notify', src, 'verde', 'Invasão iniciada na zona ' .. zoneId, 5000)
end)
