fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'Medellin ROLEPLAY'
description 'Sistema de pets – soltar, seguir, veículo, sentar, dormir (portado da Base Monkey)'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/main.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',
}

dependencies {
    'ox_lib',
    'oxmysql',
    'qbx_core',
    'ox_inventory',
}
