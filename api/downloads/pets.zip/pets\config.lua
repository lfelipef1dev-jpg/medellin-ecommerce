Config = {}

--[[
  LOJA VIP – O QUE VENDER COM SEGURANÇA
  
  GTA V NÃO TEM modelo nativo para: urso, crocodilo, greyhound, yorkshire, bulldog.
  
  • COM VISUAL CORRETO (pode vender na loja sem aviso):
    husky, poodle, pug, retriever, rottweiler, shepherd, westy, gato_gris, chimp, rhesus,
    lobo_sirius (coyote), tigor (mountain lion), rajah (mountain lion 02).
  
  • COM VISUAL SUBSTITUTO (no jogo aparece outro bicho – ou não venda, ou avise na loja):
    ursa       → no GTA aparece como JAVALI (a_c_boar). Para urso real: use addon (veja abaixo).
    crocodilo  → no GTA aparece como FELINO (a_c_mtlion_02). Para crocodilo real: use addon.
    greyhound  → retriever | yorkshire → pug | bulldog → rottweiler
  
  • USAR MODELO ADDON (urso/crocodilo de loja de assets):
    Coloque o resource do addon no servidor e use o nome do model aqui. Ex.:
    { item = 'ursa',      model = 'np_urso_01' },      -- nome do ped no addon
    { item = 'crocodilo', model = 'np_crocodilo_01' },
]]

-- Item (nome no inventário) -> model do ped (nativo GTA ou addon)
-- Loja: product-id "pets_XXX" entrega item name = XXX (pets_husky_siberiana -> husky, etc.)
Config.Pets = {
    -- Cães (modelos nativos – visual correto)
    { item = 'husky',      model = 'a_c_husky' },
    { item = 'poodle',     model = 'a_c_poodle' },
    { item = 'pug',        model = 'a_c_pug' },
    { item = 'retriever',  model = 'a_c_retriever' },
    { item = 'rottweiler', model = 'a_c_rottweiler' },
    { item = 'shepherd',   model = 'a_c_shepherd' },
    { item = 'westy',      model = 'a_c_westy' },
    { item = 'greyhound',  model = 'a_c_retriever' },
    { item = 'yorkshire',  model = 'a_c_pug' },
    { item = 'bulldog',    model = 'a_c_rottweiler' },
    -- Gato
    { item = 'gato_gris',  model = 'a_c_cat_01' },
    -- Primatas
    { item = 'chimp',      model = 'a_c_chimp' },
    { item = 'rhesus',     model = 'a_c_rhesus' },
    -- Selvagens (nativos – visual correto)
    { item = 'lobo_sirius', model = 'a_c_coyote' },
    { item = 'tigor',     model = 'a_c_mtlion' },
    { item = 'rajah',     model = 'a_c_mtlion_02' },
    -- Sem modelo nativo no GTA – placeholder até você colocar addon (troque o model pelo nome do addon)
    { item = 'ursa',      model = 'a_c_boar' },         -- placeholder: javali (troque por model do addon de urso)
    { item = 'crocodilo', model = 'a_c_mtlion_02' },    -- placeholder: felino (troque por model do addon de crocodilo)
    -- 29 pets nativos adicionais (42 totais na loja VIP)
    { item = 'boar',        model = 'a_c_boar' },
    -- { item = 'boar_02',     model = 'a_c_boar_02' },  -- removido: igual ao boar (1 e 2 iguais)
    -- { item = 'cat_02',      model = 'a_c_cat_02' },  -- removido: igual ao gato gris
    { item = 'chickenhawk', model = 'a_c_chickenhawk' },
    -- { item = 'chimp_02',    model = 'a_c_chimp_02' },  -- removido: igual ao chimp (Cuximpe)
    -- { item = 'chop',        model = 'a_c_chop' },      -- removido: spawnava como javali
    -- { item = 'chop_02',     model = 'a_c_chop_02' },   -- removido: igual
    { item = 'cormorant',   model = 'a_c_cormorant' },
    { item = 'cow',         model = 'a_c_cow' },
    -- { item = 'coyote_02',   model = 'a_c_coyote_02' },  -- removido: já temos lobo_sirius (coyote)
    { item = 'crow',        model = 'a_c_crow' },
    { item = 'deer',        model = 'a_c_deer' },
    -- { item = 'deer_02',     model = 'a_c_deer_02' },  -- removido: já temos deer
    -- { item = 'dolphin',     model = 'a_c_dolphin' },  -- removido
    -- { item = 'fish',        model = 'a_c_fish' },  -- removido
    { item = 'hen',         model = 'a_c_hen' },
    -- { item = 'humpback',    model = 'a_c_humpback' },  -- removido
    -- { item = 'killerwhale', model = 'a_c_killerwhale' },  -- removido
    -- { item = 'panther',     model = 'a_c_panther' },  -- removido
    { item = 'pig',         model = 'a_c_pig' },
    -- { item = 'pigeon',      model = 'a_c_pigeon' },  -- removido
    -- { item = 'pug_02',      model = 'a_c_pug_02' },  -- removido: já temos pug
    { item = 'rabbit_01',   model = 'a_c_rabbit_01' },
    -- { item = 'rabbit_02',   model = 'a_c_rabbit_02' },  -- removido: já temos rabbit_01
    -- { item = 'rat',         model = 'a_c_rat' },  -- removido
    -- { item = 'seagull',     model = 'a_c_seagull' },  -- removido
    -- { item = 'sharkhammer', model = 'a_c_sharkhammer' },  -- removido
    -- { item = 'sharktiger',  model = 'a_c_sharktiger' },  -- removido
    -- { item = 'stingray',    model = 'a_c_stingray' },  -- removido
}

-- Tecla do painel do pet. F2/F3 conflitam com medellin-notify; usar F7 para evitar abrir nos dois.
-- Control IDs: F2=289, F3=170, F5=166, F6=167, F7=168, F8=169
Config.MenuKey = 'F7'
Config.MenuKeyControl = 168  -- F7 (evita conflito com F2 notificações e F3 recrutamento)

-- Textos do painel e notificações
Config.MenuTitle = 'Menu do Pet'
Config.NotifyNoPet = 'Você não tem um pet solto.'
Config.NotifyPetNoSitSleep = 'Este pet não faz essa ação.'
-- Mensagem quando abre o painel sem pet (só informativa)
Config.PanelNoPetTitle = 'Nenhum pet solto'
Config.PanelNoPetText = 'Use um item de pet no inventário para soltar. Depois use a tecla do painel para interagir.'

-- Pets que têm Sentar e Dormir no menu (rig de cão; Poodle e Pug excluídos – ficam com comportamento de gato).
Config.DogAnimModels = {
    ['a_c_husky'] = true,      -- Husky Siberiana
    -- ['a_c_poodle'] = false, -- excluído: comportamento igual ao gato (sem sentar/dormir)
    -- ['a_c_pug'] = false,    -- excluído: comportamento igual ao gato (sem sentar/dormir)
    -- ['a_c_pug_02'] = true,     -- Pug variante (removido: já temos pug)
    ['a_c_retriever'] = true,  -- Golden Retriever
    ['a_c_rottweiler'] = true,-- Rottweiler
    ['a_c_shepherd'] = true,  -- Pastor Alemão
    ['a_c_westy'] = true,     -- Westy
    ['a_c_coyote'] = true,    -- Lobo Sirius
    -- ['a_c_coyote_02'] = true, -- Coyote variante (removido: já temos lobo_sirius)
    -- ['a_c_chop'] = true,      -- Chop (removido: spawnava como javali)
    -- ['a_c_chop_02'] = true,   -- Chop variante
    ['a_c_mtlion'] = true,    -- Tigor (mountain lion)
    ['a_c_mtlion_02'] = true, -- Rajah (mountain lion 02)
}

-- Mapeamento Loja VIP (product-id) -> item do inventário (para entrega ao comprar)
-- Use esta tabela no backend/webhook ao entregar compras de pets.
Config.LojaProductIdToItem = {
    ['pets_ursa'] = 'ursa',
    ['pets_lobo_sirius'] = 'lobo_sirius',
    ['pets_chimp'] = 'chimp',
    ['pets_rhesus'] = 'rhesus',
    ['pets_crocodilo'] = 'crocodilo',
    ['pets_tigor'] = 'tigor',
    ['pets_rajah'] = 'rajah',
    ['pets_gato_gris'] = 'gato_gris',
    ['pets_pastor_alemao'] = 'shepherd',
    ['pets_rottweiler'] = 'rottweiler',
    ['pets_husky_siberiana'] = 'husky',
    ['pets_poodle'] = 'poodle',
    ['pets_greyhound'] = 'greyhound',
    ['pets_yorkshire'] = 'yorkshire',
    ['pets_pug'] = 'pug',
    ['pets_bulldog'] = 'bulldog',
    ['pets_golden_retriever'] = 'retriever',
    ['pets_westy'] = 'westy',
    -- 29 pets nativos adicionais (42 totais)
    ['pets_boar'] = 'boar',
    -- ['pets_boar_02'] = 'boar_02',  -- removido da loja: igual ao boar
    -- ['pets_cat_02'] = 'cat_02',  -- removido: igual ao gato gris
    ['pets_chickenhawk'] = 'chickenhawk',
    -- ['pets_chimp_02'] = 'chimp_02',  -- removido: igual ao chimp
    -- ['pets_chop'] = 'chop',      -- removido: spawnava como javali
    -- ['pets_chop_02'] = 'chop_02',
    ['pets_cormorant'] = 'cormorant',
    ['pets_cow'] = 'cow',
    -- ['pets_coyote_02'] = 'coyote_02',  -- removido: já temos lobo_sirius
    ['pets_crow'] = 'crow',
    ['pets_deer'] = 'deer',
    -- ['pets_deer_02'] = 'deer_02',  -- removido: já temos deer
    -- ['pets_dolphin'] = 'dolphin',  -- removido
    -- ['pets_fish'] = 'fish',  -- removido
    ['pets_hen'] = 'hen',
    -- ['pets_humpback'] = 'humpback',  -- removido
    -- ['pets_killerwhale'] = 'killerwhale',  -- removido
    -- ['pets_panther'] = 'panther',  -- removido
    ['pets_pig'] = 'pig',
    -- ['pets_pigeon'] = 'pigeon',  -- removido
    -- ['pets_pug_02'] = 'pug_02',  -- removido: já temos pug
    ['pets_rabbit_01'] = 'rabbit_01',
    -- ['pets_rabbit_02'] = 'rabbit_02',  -- removido: já temos rabbit_01
    -- ['pets_rat'] = 'rat',  -- removido
    -- ['pets_seagull'] = 'seagull',  -- removido
    -- ['pets_sharkhammer'] = 'sharkhammer',  -- removido
    -- ['pets_sharktiger'] = 'sharktiger',  -- removido
    -- ['pets_stingray'] = 'stingray',  -- removido
}
