-- ============================================================================
-- medellin-pets – Entrega por loja (product-id -> item). Fila para offline, idempotência por transaction_id.
-- ============================================================================

local QBCore = exports['qb-core']:GetCoreObject()

local function normalizeLicense(license)
    if not license or type(license) ~= 'string' then return nil end
    license = license:gsub('^%s+', ''):gsub('%s+$', '')
    if license == '' then return nil end
    if license:find('license:', 1, true) ~= 1 then
        license = 'license:' .. license
    end
    return license
end

local function getLicenseFromSource(source)
    if not source or not GetPlayerName(source) then return nil end
    local ids = GetPlayerIdentifiers(source)
    for _, id in ipairs(ids or {}) do
        if id:find('license:', 1, true) == 1 then return id end
    end
    return nil
end

local function resolveLicenseFromAccountId(accountId)
    if not accountId then return nil end
    local wl = GetResourceState('medellin-whitelist') == 'started' and exports['medellin-whitelist']
    if not wl or not wl.GetLicenseByAccountId then return nil end
    return wl:GetLicenseByAccountId(accountId)
end

local function getSourceByLicense(license)
    license = normalizeLicense(license)
    if not license then return nil end
    local players = QBCore.Functions.GetQBPlayers()
    if not players then return nil end
    for _, Player in pairs(players) do
        if Player and Player.PlayerData then
            local lic = Player.PlayerData.license or getLicenseFromSource(Player.PlayerData.source)
            if lic and normalizeLicense(lic) == license then
                return Player.PlayerData.source
            end
        end
    end
    return nil
end

-- Tabela de fila (entrega ao logar)
MySQL.ready(function()
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS medellin_pets_delivery_queue (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            license VARCHAR(255) NOT NULL,
            product_id VARCHAR(64) NOT NULL,
            transaction_id VARCHAR(128) NULL,
            delivered_at TIMESTAMP NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_transaction (transaction_id),
            INDEX idx_license_pending (license(191), delivered_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ]])
end)

local function getItemNameForProductId(productId)
    local map = Config.LojaProductIdToItem or {}
    if type(productId) == 'string' then
        local item = map[productId]
        if item and type(item) == 'string' then return item:lower() end
    end
    return nil
end

local function deliverPetToPlayer(Player, productId)
    if not Player or not Player.PlayerData then return false end
    local itemName = getItemNameForProductId(productId)
    if not itemName then
        return false
    end
    local src = Player.PlayerData.source
    if not exports.ox_inventory:CanCarryItem(src, itemName, 1) then
        if src then
            TriggerClientEvent('QBCore:Notify', src, 'Inventário cheio. Esvazie um slot e relogue para receber o pet.', 'error', 8000)
        end
        return false
    end
    local added = exports.ox_inventory:AddItem(src, itemName, 1, {}, nil)
    if added then
        if src then
            TriggerClientEvent('QBCore:Notify', src, 'Pet recebido: ' .. (QBCore.Shared.Items[itemName] and QBCore.Shared.Items[itemName].label or itemName), 'success')
        end
        return true
    end
    return false
end

local function queuePet(license, productId, transactionId)
    license = normalizeLicense(license)
    if not license then return false end
    local itemName = getItemNameForProductId(productId)
    if not itemName then return false end

    if transactionId and transactionId ~= '' then
        local existing = MySQL.single.await('SELECT id, delivered_at FROM medellin_pets_delivery_queue WHERE transaction_id = ? LIMIT 1', { transactionId })
        if existing and existing.delivered_at then return true end
        if not existing then
            MySQL.insert.await(
                'INSERT INTO medellin_pets_delivery_queue (license, product_id, transaction_id) VALUES (?, ?, ?)',
                { license, productId, transactionId }
            )
        end
        return true
    end

    MySQL.insert.await(
        'INSERT INTO medellin_pets_delivery_queue (license, product_id, transaction_id) VALUES (?, ?, NULL)',
        { license, productId }
    )
    return true
end

local function processPendingPetsForPlayer(Player)
    if not Player or not Player.PlayerData then return end
    local license = Player.PlayerData.license or getLicenseFromSource(Player.PlayerData.source)
    license = normalizeLicense(license)
    if not license then return end

    local rows = MySQL.query.await(
        'SELECT id, product_id FROM medellin_pets_delivery_queue WHERE license = ? AND delivered_at IS NULL ORDER BY id ASC LIMIT 20',
        { license }
    )
    if not rows or #rows == 0 then return end

    for _, row in ipairs(rows) do
        local ok = deliverPetToPlayer(Player, row.product_id)
        if ok then
            MySQL.update.await('UPDATE medellin_pets_delivery_queue SET delivered_at = NOW() WHERE id = ?', { row.id })
        else
            break
        end
    end
end

-- Concede pet à license (entrega na hora se online, senão na fila). Idempotência por transaction_id.
local function grantPetToLicense(license, productId, transactionId)
    license = normalizeLicense(license)
    if not license or not productId or not MySQL then return false, 'invalid' end
    if not getItemNameForProductId(productId) then return false, 'unknown_product' end

    if transactionId and transactionId ~= '' then
        local existing = MySQL.single.await('SELECT delivered_at FROM medellin_pets_delivery_queue WHERE transaction_id = ? LIMIT 1', { transactionId })
        if existing and existing.delivered_at then
            return true
        end
        MySQL.insert.await(
            'INSERT INTO medellin_pets_delivery_queue (license, product_id, transaction_id) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE license = license',
            { license, productId, transactionId }
        )
        existing = MySQL.single.await('SELECT delivered_at FROM medellin_pets_delivery_queue WHERE transaction_id = ? LIMIT 1', { transactionId })
        if existing and existing.delivered_at then
            return true
        end
    end

    local src = getSourceByLicense(license)
    if src then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local ok = deliverPetToPlayer(Player, productId)
            if ok then
                if transactionId and transactionId ~= '' then
                    MySQL.update.await('UPDATE medellin_pets_delivery_queue SET delivered_at = NOW() WHERE transaction_id = ?', { transactionId })
                end
                return true
            end
            return false, 'delivery_failed'
        end
    end

    if not (transactionId and transactionId ~= '') then
        queuePet(license, productId, nil)
    end
    return true
end

AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
    if not Player then return end
    processPendingPetsForPlayer(Player)
end)

-- Comando: petgrant <accountId|license> <product_id> [transaction_id]
-- Ex.: petgrant 5 pets_lobo_sirius tebex_abc123
RegisterCommand('petgrant', function(source, args, rawCommand)
    if source ~= 0 then return end
    local accountIdOrLicense = args[1]
    local productId = (args[2] or ''):lower()
    local transactionId = args[3]

    if not accountIdOrLicense or not productId or productId == '' then
        return
    end

    local license = nil
    local num = tonumber(accountIdOrLicense)
    if num and num > 0 then
        license = resolveLicenseFromAccountId(num)
        if not license then
            return
        end
    else
        license = normalizeLicense(accountIdOrLicense)
    end

    if not license then
        return
    end

    local ok, err = grantPetToLicense(license, productId, transactionId)
    if ok then
    else
    end
end, true)

exports('GrantPetToLicense', function(license, productId, transactionId)
    return grantPetToLicense(license, productId, transactionId)
end)

-- ============================================================================
-- Itens utilizáveis (soltar pet) e guardar pet
-- ============================================================================

for _, pet in ipairs(Config.Pets) do
    QBCore.Functions.CreateUseableItem(pet.item, function(source, itemData)
        local Player = QBCore.Functions.GetPlayer(source)
        if not Player then return end
        -- slot pode vir como itemData.slot; se nil, RemoveItem usa GetFirstSlotByItem
        local slot = (type(itemData) == 'table' and (itemData.slot or itemData.slotId)) or nil
        local removed = exports.ox_inventory:RemoveItem(source, pet.item, 1, nil, slot)
        if removed then
            TriggerClientEvent('medellin-pets:client:spawnPet', source, pet.model, pet.item)
        else
            TriggerClientEvent('QBCore:Notify', source, 'Não foi possível usar o item. (Inventário pode estar dessincronizado – tente guardar e pegar o item de novo.)', 'error')
        end
    end)
end

-- Cliente pede para guardar o pet; só confirmamos se o item couber no inventário (evita perder o pet)
RegisterNetEvent('medellin-pets:server:pickUpPet', function(itemName)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    if not itemName or type(itemName) ~= 'string' then
        TriggerClientEvent('QBCore:Notify', src, 'Erro ao guardar pet.', 'error')
        return
    end
    local itemNameLower = string.lower(itemName)
    local valid = false
    for _, pet in ipairs(Config.Pets) do
        if pet.item == itemNameLower then valid = true break end
    end
    if not valid then
        TriggerClientEvent('QBCore:Notify', src, 'Item de pet inválido.', 'error')
        return
    end
    local canAdd = exports.ox_inventory:CanCarryItem(src, itemNameLower, 1)
    if not canAdd then
        TriggerClientEvent('medellin-pets:client:pickUpFailed', src, 'inventário cheio')
        return
    end
    local added = exports.ox_inventory:AddItem(src, itemNameLower, 1, {}, nil)
    if added then
        TriggerClientEvent('medellin-pets:client:confirmPickUp', src)
    else
        TriggerClientEvent('medellin-pets:client:pickUpFailed', src, 'inventário cheio')
    end
end)
