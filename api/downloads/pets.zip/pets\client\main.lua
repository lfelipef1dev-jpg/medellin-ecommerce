local QBCore = exports['qb-core']:GetCoreObject()
local animalPed = nil
local animalFollow = false
local currentPetItem = nil
local currentPetModel = nil  -- string do model (ex: 'a_c_husky') para checar animações

-- Carrega o dicionário de animação (chama o native do jogo; não usar mesmo nome para não causar recursão/deadloop)
local function LoadAnimDict(dict)
    if not dict or type(dict) ~= 'string' then return end
    if HasAnimDictLoaded(dict) then return end
    RequestAnimDict(dict)
    local timeout = 0
    while not HasAnimDictLoaded(dict) and timeout < 150 do
        Wait(10)
        timeout = timeout + 1
    end
end

local function HasPetSpawned()
    return animalPed and DoesEntityExist(animalPed)
end

local function UsesDogAnims()
    return Config.DogAnimModels and currentPetModel and Config.DogAnimModels[currentPetModel]
end

-- Sempre abre o painel: com pet = menu de interacoes; sem pet = mensagem explicativa
local function OpenPetMenu()
    local title = (Config.MenuTitle and Config.MenuTitle ~= '') and Config.MenuTitle or 'Menu do Pet'
    local options = {}

    if HasPetSpawned() then
        options[#options + 1] = { title = animalFollow and 'Parar de seguir' or 'Seguir', description = animalFollow and 'Pet para de seguir voce.' or 'Pet passa a seguir voce.', event = 'medellin-pets:client:petAction', args = { action = 'seguir' } }
        options[#options + 1] = { title = 'Colocar no veiculo', description = 'Coloca o pet no banco do carro.', event = 'medellin-pets:client:petAction', args = { action = 'colocar' } }
        options[#options + 1] = { title = 'Remover do veiculo', description = 'Tira o pet do carro.', event = 'medellin-pets:client:petAction', args = { action = 'remover' } }
        options[#options + 1] = { title = 'Pegar animal', description = 'Guarda o pet e devolve o item ao inventario.', event = 'medellin-pets:client:petAction', args = { action = 'deletar' } }
        -- Sentar e Dormir so para caes (modelos com animacao de cachorro)
        if UsesDogAnims() then
            options[#options + 1] = { title = 'Sentar', description = 'Pet senta no chao.', event = 'medellin-pets:client:petAction', args = { action = 'sentar' } }
            options[#options + 1] = { title = 'Dormir', description = 'Pet deita para dormir.', event = 'medellin-pets:client:petAction', args = { action = 'dormir' } }
        end
        options[#options + 1] = { title = 'Postura normal', description = 'Pet fica em pe.', event = 'medellin-pets:client:petAction', args = { action = 'direito' } }
    else
        local noPetTitle = Config.PanelNoPetTitle or 'Nenhum pet solto'
        local noPetTxt = Config.PanelNoPetText or 'Use um item de pet no inventario para soltar. Depois use a tecla do painel para interagir.'
        options[#options + 1] = { title = noPetTitle, description = noPetTxt }
    end

    lib.registerContext({
        id = 'pets_menu',
        title = title,
        options = options
    })
    lib.showContext('pets_menu')
end

RegisterNetEvent('medellin-pets:client:petAction', function(data)
    local action = data and data.action
    if not action or not HasPetSpawned() then return end

    local ped = PlayerPedId()

    if action == 'seguir' then
        if not animalFollow then
            TaskFollowToOffsetOfEntity(animalPed, ped, 1.0, 1.0, 0.0, 5.0, -1, 2.5, true)
            SetPedKeepTask(animalPed, true)
            animalFollow = true
            QBCore.Functions.Notify('Pet passou a seguir você.', 'success')
        else
            SetPedKeepTask(animalPed, false)
            ClearPedTasks(animalPed)
            animalFollow = false
            QBCore.Functions.Notify('Pet parou de seguir.', 'primary')
        end
    elseif action == 'colocar' then
        if IsPedInAnyVehicle(ped, false) and not IsPedOnAnyBike(ped) then
            local veh = GetVehiclePedIsIn(ped, false)
            if IsVehicleSeatFree(veh, 0) then
                TaskEnterVehicle(animalPed, veh, -1, 0, 2.0, 16, 0)
                QBCore.Functions.Notify('Pet entrando no veículo...', 'primary')
            end
        else
            QBCore.Functions.Notify('Entre em um carro (não moto) primeiro.', 'error')
        end
    elseif action == 'remover' then
        if IsPedInAnyVehicle(ped, false) and not IsPedOnAnyBike(ped) then
            TaskLeaveVehicle(animalPed, GetVehiclePedIsIn(ped, false), 256)
            Wait(500)
            TriggerEvent('medellin-pets:client:petAction', { action = 'seguir' })
            QBCore.Functions.Notify('Pet saindo do veículo.', 'primary')
        end
    elseif action == 'deletar' then
        if not currentPetItem or currentPetItem == '' then
            QBCore.Functions.Notify('Erro: não foi possível identificar o pet.', 'error')
            return
        end
        QBCore.Functions.Notify('Guardando pet...', 'primary')
        TriggerServerEvent('medellin-pets:server:pickUpPet', currentPetItem)
        -- Pet só é removido quando o servidor confirmar (confirmPickUp); se falhar, pickUpFailed
    elseif action == 'sentar' then
        if not UsesDogAnims() then
            QBCore.Functions.Notify(Config.NotifyPetNoSitSleep or 'Este pet não faz essa ação.', 'primary')
            return
        end
        LoadAnimDict('creatures@rottweiler@amb@world_dog_sitting@base')
        TaskPlayAnim(animalPed, 'creatures@rottweiler@amb@world_dog_sitting@base', 'base', 8.0, -8.0, -1, 1, 0, false, false, false)
        animalFollow = false
        QBCore.Functions.Notify('Pet sentou.', 'primary')
    elseif action == 'dormir' then
        if not UsesDogAnims() then
            QBCore.Functions.Notify(Config.NotifyPetNoSitSleep or 'Este pet não faz essa ação.', 'primary')
            return
        end
        LoadAnimDict('creatures@rottweiler@amb@sleep_in_kennel@')
        TaskPlayAnim(animalPed, 'creatures@rottweiler@amb@sleep_in_kennel@', 'sleep_in_kennel', 8.0, -8.0, -1, 1, 0, false, false, false)
        animalFollow = false
        QBCore.Functions.Notify('Pet deitou para dormir.', 'primary')
    elseif action == 'direito' then
        ClearPedTasks(animalPed)
        TaskFollowToOffsetOfEntity(animalPed, ped, 1.0, 1.0, 0.0, 5.0, -1, 2.5, true)
        SetPedKeepTask(animalPed, true)
        animalFollow = true
        QBCore.Functions.Notify('Pet em postura normal.', 'primary')
    end
end)

-- Servidor confirmou: item foi pro inventário, aí sim removemos o pet (comportamento correto para item VIP)
RegisterNetEvent('medellin-pets:client:confirmPickUp', function()
    if DoesEntityExist(animalPed) then
        SetEntityAsMissionEntity(animalPed, true, true)
        DeleteEntity(animalPed)
    end
    animalFollow = false
    animalPed = nil
    currentPetItem = nil
    currentPetModel = nil
    QBCore.Functions.Notify('Pet guardado. Item devolvido ao inventário.', 'success')
end)

-- Servidor falhou (ex.: inventário cheio) – pet continua solto, item não é perdido
RegisterNetEvent('medellin-pets:client:pickUpFailed', function(reason)
    local msg = (reason == 'inventário cheio') and 'Inventário cheio. Libere espaço e tente de novo.' or tostring(reason or 'Não foi possível guardar o pet.')
    QBCore.Functions.Notify(msg, 'error')
end)

RegisterNetEvent('medellin-pets:client:spawnPet', function(model, itemName)
    if HasPetSpawned() and animalPed and DoesEntityExist(animalPed) then
        SetEntityAsMissionEntity(animalPed, true, true)
        DeleteEntity(animalPed)
        animalPed = nil
        animalFollow = false
    end

    local hash = type(model) == 'string' and GetHashKey(model) or model
    RequestModel(hash)
    local timeout = 0
    while not HasModelLoaded(hash) and timeout < 200 do
        Wait(10)
        timeout = timeout + 1
    end
    if not HasModelLoaded(hash) then
        QBCore.Functions.Notify('Erro ao carregar modelo do pet. Tente de novo ou mude de lugar.', 'error')
        return
    end

    local ped = PlayerPedId()
    local coords = GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0)
    -- Padrão: pet no nível do chão (ou levemente acima) para não afundar/flutuar (ex.: Rhesus, cães)
    local groundZ = coords.z
    local found, z = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z + 2.0, false)
    if found then
        groundZ = z
    end
    local newPed = CreatePed(28, hash, coords.x, coords.y, groundZ, GetEntityHeading(ped), true, false)
    if not newPed or newPed == 0 then
        SetModelAsNoLongerNeeded(hash)
        QBCore.Functions.Notify('Erro ao criar o pet. Tente de novo.', 'error')
        return
    end
    animalPed = newPed
    currentPetModel = type(model) == 'string' and model or nil
    currentPetItem = itemName

    SetNetworkIdCanMigrate(PedToNet(animalPed), true)
    SetPedCanRagdoll(animalPed, false)
    SetEntityInvincible(animalPed, true)
    SetPedFleeAttributes(animalPed, 0, false)
    SetEntityAsMissionEntity(animalPed, true, false)
    SetBlockingOfNonTemporaryEvents(animalPed, true)
    SetPedRelationshipGroupHash(animalPed, GetHashKey('k9'))

    SetModelAsNoLongerNeeded(hash)

    animalFollow = true
    TaskFollowToOffsetOfEntity(animalPed, ped, 1.0, 1.0, 0.0, 5.0, -1, 2.5, true)
    SetPedKeepTask(animalPed, true)

    local key = Config.MenuKey or 'F3'
    QBCore.Functions.Notify('Pet solto! Use ' .. key .. ' para abrir o painel de interação.', 'success')
end)

-- Painel do pet: só F7 abre (thread). Comando "petmenu" fica vazio para F2 não abrir (muitos têm F2 vinculado a esse comando).
RegisterCommand('petmenu', function() end, false)
RegisterCommand('abrirpainelpet', function() OpenPetMenu() end, false)
local CONTROL_PET = Config.MenuKeyControl or 168  -- 168 = F7
-- [ESTABILIDADE] Wait(100): evita loop por frame; F7 continua responsivo (crash GTA5_b3258).
CreateThread(function()
    while true do
        Wait(100)
        if IsControlJustPressed(0, CONTROL_PET) then
            OpenPetMenu()
        end
    end
end)

-- Limpeza ao parar o resource (evita ped órfão)
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    if HasPetSpawned() and animalPed and DoesEntityExist(animalPed) then
        SetEntityAsMissionEntity(animalPed, true, true)
        DeleteEntity(animalPed)
    end
    animalPed = nil
    animalFollow = false
    currentPetItem = nil
    currentPetModel = nil
end)
