-- ============================================================================
-- fishing: Server XP - Niveis 1-50, conquistas, daily caps
-- ============================================================================

-- Cache de nivel por citizenid
local levelCache = {} -- [citizenid] = { level, xp, lastFetch }
local CACHE_TTL = 60

-- Cache de conquistas desbloqueadas
local achievementCache = {} -- [citizenid] = { [achievement_id] = true }

-- ============================================================================
-- HELPERS
-- ============================================================================

local function getCitizenId(source)
    local Player = exports.qbx_core:GetPlayer(source)
    return Player and Player.PlayerData and Player.PlayerData.citizenid
end

local function xpForLevel(level)
    return Config.XPFormula.base + (level * Config.XPFormula.perLevel)
end

-- ============================================================================
-- OBTER NIVEL DO JOGADOR
-- ============================================================================

function GetPlayerLevel(source)
    local citizenid = getCitizenId(source)
    if not citizenid then return 1 end

    local cached = levelCache[citizenid]
    if cached and (os.time() - cached.lastFetch) < CACHE_TTL then
        return cached.level
    end

    local result = MySQL.scalar.await(
        'SELECT level FROM fishing_stats WHERE citizenid = ?',
        { citizenid }
    )

    local level = result or 1
    levelCache[citizenid] = { level = level, xp = 0, lastFetch = os.time() }
    return level
end

function GetPlayerXPData(source)
    local citizenid = getCitizenId(source)
    if not citizenid then return { level = 1, xp = 0, xpNeeded = xpForLevel(2) } end

    local result = MySQL.query.await(
        'SELECT level, xp FROM fishing_stats WHERE citizenid = ?',
        { citizenid }
    )

    if result and result[1] then
        local lvl = result[1].level
        return { level = lvl, xp = result[1].xp, xpNeeded = xpForLevel(lvl + 1) }
    end

    return { level = 1, xp = 0, xpNeeded = xpForLevel(2) }
end

-- ============================================================================
-- ADICIONAR XP (suporta niveis 1-50)
-- ============================================================================

---@return boolean levelUp, number|nil newLevel
function AddPlayerXP(source, amount)
    if not amount or amount <= 0 then return false, nil end

    local citizenid = getCitizenId(source)
    if not citizenid then return false, nil end

    -- Garantir registro no banco
    MySQL.insert.await([[
        INSERT IGNORE INTO fishing_stats (citizenid, level, xp)
        VALUES (?, 1, 0)
    ]], { citizenid })

    -- Adicionar XP
    MySQL.update.await(
        'UPDATE fishing_stats SET xp = xp + ? WHERE citizenid = ?',
        { amount, citizenid }
    )

    -- Verificar level up
    local data = MySQL.query.await(
        'SELECT level, xp FROM fishing_stats WHERE citizenid = ?',
        { citizenid }
    )

    if not data or not data[1] then return false, nil end

    local currentLevel = data[1].level
    local currentXP = data[1].xp
    local leveledUp = false
    local newLevel = currentLevel
    local oldLevel = currentLevel

    -- Loop de level up (pode subir varios niveis de uma vez)
    while newLevel < Config.MaxLevel do
        local needed = xpForLevel(newLevel + 1)
        if currentXP >= needed then
            currentXP = currentXP - needed
            newLevel = newLevel + 1
            leveledUp = true
        else
            break
        end
    end

    if leveledUp then
        MySQL.update.await(
            'UPDATE fishing_stats SET level = ?, xp = ? WHERE citizenid = ?',
            { newLevel, currentXP, citizenid }
        )

        levelCache[citizenid] = { level = newLevel, xp = currentXP, lastFetch = os.time() }

        -- Notificar cada level up individualmente
        for lvl = oldLevel + 1, newLevel do
            TriggerClientEvent('ox_lib:notify', source, {
                title = 'Level Up!',
                description = string.format('Nivel %d de pesca!', lvl),
                type = 'success',
                duration = 5000,
            })

            -- Verificar desbloqueios neste nivel
            local bonus = Config.LevelBonuses[lvl]
            if bonus then
                TriggerClientEvent('ox_lib:notify', source, {
                    title = 'Desbloqueio!',
                    description = bonus.unlockText,
                    type = 'inform',
                    duration = 6000,
                })
            end

            -- Conquistas de nivel
            if lvl == 10 then CheckAchievement(source, 'level_10') end
            if lvl == 25 then CheckAchievement(source, 'level_25') end
            if lvl == 50 then CheckAchievement(source, 'level_50') end
        end

        -- print(string.format('^2[fishing]^0 %s subiu para nivel %d de pesca', citizenid, newLevel))
    else
        levelCache[citizenid] = { level = currentLevel, xp = currentXP, lastFetch = os.time() }
    end

    return leveledUp, leveledUp and newLevel or nil
end

-- ============================================================================
-- SISTEMA DE CONQUISTAS
-- ============================================================================

function LoadPlayerAchievements(citizenid)
    if achievementCache[citizenid] then return achievementCache[citizenid] end

    local result = MySQL.query.await(
        'SELECT achievement_id FROM fishing_achievements WHERE citizenid = ?',
        { citizenid }
    )

    local achievements = {}
    if result then
        for _, row in ipairs(result) do
            achievements[row.achievement_id] = true
        end
    end

    achievementCache[citizenid] = achievements
    return achievements
end

function HasAchievement(source, achievementId)
    local citizenid = getCitizenId(source)
    if not citizenid then return true end -- nao bloquear se erro
    local achievements = LoadPlayerAchievements(citizenid)
    return achievements[achievementId] == true
end

function CheckAchievement(source, achievementId)
    if HasAchievement(source, achievementId) then return false end

    local config = Config.Achievements[achievementId]
    if not config then return false end

    local citizenid = getCitizenId(source)
    if not citizenid then return false end

    -- Desbloquear
    local inserted = MySQL.insert.await([[
        INSERT IGNORE INTO fishing_achievements (citizenid, achievement_id)
        VALUES (?, ?)
    ]], { citizenid, achievementId })

    if not inserted or inserted == 0 then return false end

    -- Atualizar cache
    if not achievementCache[citizenid] then
        achievementCache[citizenid] = {}
    end
    achievementCache[citizenid][achievementId] = true

    -- Recompensas
    if config.xpReward and config.xpReward > 0 then
        AddPlayerXP(source, config.xpReward)
    end

    if config.moneyReward and config.moneyReward > 0 then
        local Player = exports.qbx_core:GetPlayer(source)
        if Player then
            Player.Functions.AddMoney('cash', config.moneyReward, 'fishing-achievement')
        end
    end

    -- Notificar
    PlaySoundForPlayer(source, Config.Sounds.achievement)
    TriggerClientEvent('ox_lib:notify', source, {
        title = 'Conquista Desbloqueada!',
        description = string.format('%s - %s (+R$%d)', config.label, config.description, config.moneyReward or 0),
        type = 'success',
        duration = 8000,
    })

    -- Discord webhook
    SendWebhook('achievements', string.format('**%s** desbloqueou: **%s** - %s', citizenid, config.label, config.description))

    -- print(string.format('^2[fishing]^0 %s desbloqueou conquista: %s', citizenid, config.label))
    return true
end

-- Verificar conquistas baseadas em stats
function CheckStatAchievements(source, fishData)
    local citizenid = getCitizenId(source)
    if not citizenid then return end

    local stats = MySQL.query.await(
        'SELECT total_caught, total_sold, money_earned, biggest_weight FROM fishing_stats WHERE citizenid = ?',
        { citizenid }
    )

    if not stats or not stats[1] then return end
    local s = stats[1]

    -- Contagem de peixes
    if s.total_caught >= 1 then CheckAchievement(source, 'first_catch') end
    if s.total_caught >= 10 then CheckAchievement(source, 'catch_10') end
    if s.total_caught >= 50 then CheckAchievement(source, 'catch_50') end
    if s.total_caught >= 100 then CheckAchievement(source, 'catch_100') end
    if s.total_caught >= 500 then CheckAchievement(source, 'catch_500') end
    if s.total_caught >= 1000 then CheckAchievement(source, 'catch_1000') end

    -- Dinheiro
    if s.money_earned >= 10000 then CheckAchievement(source, 'sell_10k') end
    if s.money_earned >= 100000 then CheckAchievement(source, 'sell_100k') end

    -- Peso
    if s.biggest_weight >= 5000 then CheckAchievement(source, 'big_fish') end
    if s.biggest_weight >= 10000 then CheckAchievement(source, 'monster_fish') end

    -- Raridade do peixe atual
    if fishData then
        local order = (Config.Rarity[fishData.rarity] or {}).order or 1
        if order >= 3 then CheckAchievement(source, 'first_rare') end
        if order >= 4 then CheckAchievement(source, 'first_epic') end
        if order >= 5 then CheckAchievement(source, 'first_legendary') end
        if order >= 6 then CheckAchievement(source, 'first_mythic') end
    end
end

-- ============================================================================
-- DAILY CAP SYSTEM
-- ============================================================================

function CheckDailyCap(source, type)
    if not Config.DailyCaps.enabled then return true, 0 end

    local citizenid = getCitizenId(source)
    if not citizenid then return true, 0 end

    -- Reset diario se necessario
    local today = os.date('%Y-%m-%d')
    MySQL.update.await([[
        UPDATE fishing_stats
        SET fish_caught_today = 0, money_earned_today = 0, last_daily_reset = ?
        WHERE citizenid = ? AND (last_daily_reset IS NULL OR last_daily_reset < ?)
    ]], { today, citizenid, today })

    local result = MySQL.query.await(
        'SELECT fish_caught_today, money_earned_today FROM fishing_stats WHERE citizenid = ?',
        { citizenid }
    )

    if not result or not result[1] then return true, 0 end

    if type == 'catch' then
        local remaining = Config.DailyCaps.maxCatchPerDay - result[1].fish_caught_today
        return remaining > 0, remaining
    elseif type == 'sell' then
        local remaining = Config.DailyCaps.maxEarningsPerDay - result[1].money_earned_today
        return remaining > 0, remaining
    end

    return true, 0
end

function IncrementDailyCatch(source)
    local citizenid = getCitizenId(source)
    if not citizenid then return end
    MySQL.update('UPDATE fishing_stats SET fish_caught_today = fish_caught_today + 1 WHERE citizenid = ?', { citizenid })
end

function IncrementDailyEarnings(source, amount)
    local citizenid = getCitizenId(source)
    if not citizenid then return end
    MySQL.update('UPDATE fishing_stats SET money_earned_today = money_earned_today + ? WHERE citizenid = ?', { amount, citizenid })
end

-- ============================================================================
-- ZONAS VISITADAS (para conquista "Explorador")
-- ============================================================================

function TrackZoneVisit(source, zoneId)
    local citizenid = getCitizenId(source)
    if not citizenid then return end

    local result = MySQL.scalar.await(
        'SELECT zones_visited FROM fishing_stats WHERE citizenid = ?',
        { citizenid }
    )

    local zones = {}
    if result and result ~= '' then
        for z in string.gmatch(result, '[^,]+') do
            zones[z] = true
        end
    end

    if zones[zoneId] then return end
    zones[zoneId] = true

    local zoneList = {}
    for z in pairs(zones) do
        zoneList[#zoneList + 1] = z
    end
    local zonesStr = table.concat(zoneList, ',')

    MySQL.update('UPDATE fishing_stats SET zones_visited = ? WHERE citizenid = ?', { zonesStr, citizenid })

    -- Verificar se visitou todas as zonas (excluindo ilegal)
    local normalZones = 0
    local visitedNormal = 0
    for id, zone in pairs(Config.Zones) do
        if id ~= 'ilegal' then
            normalZones = normalZones + 1
            if zones[id] then visitedNormal = visitedNormal + 1 end
        end
    end

    if visitedNormal >= normalZones then
        CheckAchievement(source, 'all_zones')
    end
end

-- ============================================================================
-- DISCORD WEBHOOKS
-- ============================================================================

function SendWebhook(type, message)
    if not Config.Webhooks.enabled then return end
    local url = Config.Webhooks[type]
    if not url or url == '' then return end

    PerformHttpRequest(url, function() end, 'POST',
        json.encode({
            username = 'Fishing System',
            embeds = {{
                title = 'Pesca Log',
                description = message,
                color = 65280, -- verde
                footer = { text = os.date('%d/%m/%Y %H:%M:%S') },
            }},
        }),
        { ['Content-Type'] = 'application/json' }
    )
end

function PlaySoundForPlayer(source, sound)
    if sound then
        TriggerClientEvent('fishing:client:playSound', source, sound.name, sound.set)
    end
end

-- ============================================================================
-- LOG DE PESCA (anti-abuse analytics)
-- ============================================================================

function LogFishCatch(source, fishData, zoneId, method)
    local citizenid = getCitizenId(source)
    if not citizenid then return end

    MySQL.insert([[
        INSERT INTO fishing_log (citizenid, fish_item, rarity, weight, zone_id, method)
        VALUES (?, ?, ?, ?, ?, ?)
    ]], { citizenid, fishData.item, fishData.rarity, fishData.weight, zoneId, method or 'manual' })
end

-- ============================================================================
-- CALLBACKS
-- ============================================================================

lib.callback.register('fishing:server:getPlayerStats', function(source)
    local citizenid = getCitizenId(source)
    if not citizenid then return nil end

    local result = MySQL.query.await(
        'SELECT citizenid, level, xp, total_caught, total_sold, money_earned, biggest_weight, biggest_fish, fish_caught_today, money_earned_today FROM fishing_stats WHERE citizenid = ?',
        { citizenid }
    )

    if result and result[1] then
        local data = result[1]
        data.xpNeeded = xpForLevel(data.level + 1)
        data.maxLevel = Config.MaxLevel
        return data
    end

    return { level = 1, xp = 0, total_caught = 0, total_sold = 0, money_earned = 0, xpNeeded = xpForLevel(2), maxLevel = Config.MaxLevel }
end)

lib.callback.register('fishing:server:getPlayerAchievements', function(source)
    local citizenid = getCitizenId(source)
    if not citizenid then return {} end

    local unlocked = LoadPlayerAchievements(citizenid)
    local result = {}

    for id, config in pairs(Config.Achievements) do
        result[#result + 1] = {
            id = id,
            label = config.label,
            description = config.description,
            xpReward = config.xpReward,
            moneyReward = config.moneyReward,
            unlocked = unlocked[id] == true,
        }
    end

    -- Ordenar: desbloqueadas primeiro
    table.sort(result, function(a, b)
        if a.unlocked ~= b.unlocked then return a.unlocked end
        return a.label < b.label
    end)

    return result
end)

-- ============================================================================
-- CLEANUP
-- ============================================================================

AddEventHandler('playerDropped', function()
    local source = source
    local citizenid = getCitizenId(source)
    if citizenid then
        -- Manter cache por mais tempo para reconexoes rapidas
    end
end)
