-- ============================================================================
-- fishing: Client Boats - Aluguel de barcos
-- ============================================================================

local boatNPC = nil
local boatBlip = nil
local activeBoatEntity = nil
local boatTimerActive = false

-- ============================================================================
-- SPAWN NPC DE ALUGUEL
-- ============================================================================

local function SpawnNPC(model, x, y, z, heading)
    local hash = type(model) == 'string' and joaat(model) or model
    lib.requestModel(hash)
    local ped = CreatePed(0, hash, x, y, z - 1.0, heading or 0.0, false, true)

    if not ped or ped == 0 then
        -- print('^1[fishing:boats]^0 ERRO: Falha ao criar NPC')
        return nil
    end
    SetPedDefaultComponentVariation(ped)

    SetEntityAsMissionEntity(ped, true, true)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedCanBeTargetted(ped, false)
    SetPedCanRagdoll(ped, false)
    SetModelAsNoLongerNeeded(hash)

    return ped
end

-- ============================================================================
-- INICIALIZAR NPC E BLIP
-- ============================================================================

CreateThread(function()
    if not Config.Boats.enabled then return end

    Wait(3000)

    local rental = Config.Boats.rental
    if not rental then return end

    -- Blip
    if rental.blip then
        boatBlip = AddBlipForCoord(rental.coords.x, rental.coords.y, rental.coords.z)
        SetBlipSprite(boatBlip, rental.blip.sprite)
        SetBlipScale(boatBlip, rental.blip.scale)
        SetBlipColour(boatBlip, rental.blip.color)
        SetBlipAsShortRange(boatBlip, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName(rental.blip.label)
        EndTextCommandSetBlipName(boatBlip)
    end

    -- NPC
    boatNPC = SpawnNPC(rental.npcModel, rental.coords.x, rental.coords.y, rental.coords.z, rental.npcHeading)
    if not boatNPC then return end

    Wait(300)

    -- ox_target no NPC
    exports.ox_target:addLocalEntity(boatNPC, {
        {
            name = 'fishing_boat_rental',
            icon = 'fas fa-ship',
            label = 'Alugar Barco',
            distance = 3.0,
            onSelect = function()
                OpenBoatRentalMenu()
            end,
        },
        {
            name = 'fishing_boat_return',
            icon = 'fas fa-undo',
            label = 'Devolver Barco',
            distance = 3.0,
            onSelect = function()
                ReturnBoat()
            end,
        },
    })

    if Config.Debug then
        -- print('^3[fishing:boats]^0 NPC de aluguel de barcos criado')
    end
end)

-- ============================================================================
-- MENU DE ALUGUEL
-- ============================================================================

function OpenBoatRentalMenu()
    local boats = lib.callback.await('fishing:server:getBoatMenu', false)
    if not boats or #boats == 0 then
        lib.notify({ title = 'Barcos', description = 'Nenhum barco disponivel', type = 'error' })
        return
    end

    local options = {}
    for _, boat in ipairs(boats) do
        local priceText = string.format('R$%d', boat.price)
        if boat.vipDiscount then
            priceText = string.format('~~R$%d~~ R$%d (VIP)', boat.originalPrice, boat.price)
        end

        local icon = boat.canRent and 'fas fa-ship' or 'fas fa-lock'
        local color = boat.canRent and '#00FF88' or '#8892a4'

        options[#options + 1] = {
            title = boat.label,
            description = string.format('%s | Nivel %d necessario', priceText, boat.minLevel),
            icon = icon,
            iconColor = color,
            disabled = not boat.canRent,
            onSelect = function()
                RentBoat(boat.model)
            end,
        }
    end

    lib.registerContext({
        id = 'fishing_boat_rental',
        title = 'Aluguel de Barcos',
        options = options,
    })
    lib.showContext('fishing_boat_rental')
end

-- ============================================================================
-- ALUGAR BARCO
-- ============================================================================

function RentBoat(modelName)
    local result = lib.callback.await('fishing:server:rentBoat', false, modelName)

    if not result or not result.success then
        lib.notify({ title = 'Barcos', description = result and result.message or 'Erro', type = 'error' })
        return
    end

    lib.notify({ title = 'Barcos', description = result.message, type = 'success', duration = 5000 })
    PlaySound(Config.Sounds.sell)

    -- Spawnar barco
    local sp = result.spawnPoint
    SpawnBoatEntity(result.model, sp.x, sp.y, sp.z, sp.w)

    -- Iniciar timer
    StartBoatTimer(result.remainingSeconds or (result.rentalMinutes * 60))
end

-- ============================================================================
-- SPAWNAR BARCO
-- ============================================================================

function SpawnBoatEntity(model, x, y, z, heading)
    local hash = joaat(model)
    lib.requestModel(hash)

    local boat = CreateVehicle(hash, x, y, z, heading or 0.0, true, false)
    if boat and boat ~= 0 then
        SetEntityAsMissionEntity(boat, true, true)
        SetVehicleOnGroundProperly(boat)
        SetVehicleEngineOn(boat, true, true, false)
        activeBoatEntity = boat

        -- Colocar jogador no barco
        Wait(500)
        local ped = PlayerPedId()
        TaskWarpPedIntoVehicle(ped, boat, -1)
    end

    SetModelAsNoLongerNeeded(hash)
end

-- ============================================================================
-- TIMER HUD
-- ============================================================================

function StartBoatTimer(totalSeconds)
    if boatTimerActive then return end
    boatTimerActive = true

    CreateThread(function()
        local remaining = totalSeconds

        while remaining > 0 and boatTimerActive do
            Wait(1000)
            remaining = remaining - 1

            -- Mostrar textUI a cada 30 segundos ou quando < 5 min
            if remaining <= 300 or remaining % 30 == 0 then
                local mins = math.floor(remaining / 60)
                local secs = remaining % 60
                local color = remaining <= 60 and 'error' or (remaining <= 300 and 'warning' or 'inform')

                if remaining % 30 == 0 or remaining <= 60 then
                    lib.notify({
                        title = 'Barco',
                        description = string.format('Tempo restante: %d:%02d', mins, secs),
                        type = color,
                        duration = 3000,
                    })
                end
            end
        end

        boatTimerActive = false
    end)
end

-- ============================================================================
-- DEVOLVER BARCO
-- ============================================================================

function ReturnBoat()
    local result = lib.callback.await('fishing:server:returnBoat', false)

    if not result or not result.success then
        lib.notify({ title = 'Barcos', description = result and result.message or 'Erro', type = 'error' })
        return
    end

    lib.notify({ title = 'Barcos', description = result.message, type = 'success', duration = 5000 })
    PlaySound(Config.Sounds.sell)

    -- Remover barco
    DeleteBoatEntity()
    boatTimerActive = false
end

-- ============================================================================
-- EVENT: Barco expirou (server notifica)
-- ============================================================================

RegisterNetEvent('fishing:client:boatExpired', function()
    lib.notify({
        title = 'Barco',
        description = 'Seu barco expirou e foi removido!',
        type = 'error',
        duration = 8000,
    })
    DeleteBoatEntity()
    boatTimerActive = false
end)

-- ============================================================================
-- DELETAR ENTIDADE DO BARCO
-- ============================================================================

function DeleteBoatEntity()
    if activeBoatEntity and DoesEntityExist(activeBoatEntity) then
        local ped = PlayerPedId()
        if GetVehiclePedIsIn(ped, false) == activeBoatEntity then
            TaskLeaveVehicle(ped, activeBoatEntity, 0)
            Wait(1500)
        end
        DeleteEntity(activeBoatEntity)
        activeBoatEntity = nil
    end
end

-- ============================================================================
-- VERIFICAR SE PODE PESCAR DO BARCO
-- ============================================================================

function IsOnBoat()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then return false end

    -- Verificar se esta parado (velocidade < 1 km/h)
    local speed = GetEntitySpeed(vehicle) * 3.6
    return speed < 1.0
end

-- ============================================================================
-- RESTAURAR BARCO AO RECONECTAR
-- ============================================================================

CreateThread(function()
    if not Config.Boats.enabled then return end
    Wait(8000)

    local boat = lib.callback.await('fishing:server:getActiveBoat', false)
    if boat then
        lib.notify({
            title = 'Barco',
            description = string.format('Voce tem um %s alugado (%d min restante)', boat.label, math.ceil(boat.remainingSeconds / 60)),
            type = 'inform',
            duration = 8000,
        })
        StartBoatTimer(boat.remainingSeconds)
    end
end)

-- ============================================================================
-- COMANDO DEVOLVER
-- ============================================================================

RegisterCommand('devolverbarco', function()
    ReturnBoat()
end, false)

-- ============================================================================
-- CLEANUP
-- ============================================================================

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    if boatNPC and DoesEntityExist(boatNPC) then
        DeleteEntity(boatNPC)
    end
    if boatBlip and DoesBlipExist(boatBlip) then
        RemoveBlip(boatBlip)
    end
    DeleteBoatEntity()
    boatTimerActive = false
end)
