# Sistema de Pesca para FiveM (QBox / QBCore)

Sistema completo de pesca com XP, conquistas, barcos, redes, crafting e mercado.

## Funcionalidades

### Pesca
- Minigame de pesca interativo com barra de habilidade
- +30 tipos de peixes com raridade configurável (comum, incomum, raro, épico, lendário)
- Zonas de pesca no mapa (rios, lagos, oceano)
- Sistema de equipamentos (varas, iscas, anzóis)
- Cap diário anti-farm configurável

### Barcos
- Aluguel de barcos por tempo
- Barcos específicos para pesca em alto mar

### Redes
- Coloque redes e volte depois para coletar peixes
- Timer de coleta realista

### XP e Conquistas
- Nível de pesca (1-50) com progressão
- +15 conquistas desbloqueáveis (1000 peixes, peixe lendário, etc.)
- Bônus de recompensa por nível

### Mercado
- Venda peixes no mercado legal ou mercado negro
- Preços dinâmicos configuráveis

### Crafting
- Transforme peixes em itens processados (filé, conserva, etc.)

### Logs Discord
- Webhook para peixes raros, vendas grandes, conquistas e exploits

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)
- `ox_inventory`
- `ox_target`
- `oxmysql`

## Instalação

1. Coloque a pasta `fishing` dentro de `resources/`
2. Execute o SQL de instalação
3. Adicione ao `server.cfg`:
   ```
   ensure fishing
   ```
4. Configure peixes, zonas e preços em `config.lua`
5. (Opcional) Configure webhooks em `config.lua`:
   ```lua
   Config.Webhooks = {
       enabled = true,
       catches = 'https://discord.com/api/webhooks/SEU_WEBHOOK',
       -- ...
   }
   ```

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
