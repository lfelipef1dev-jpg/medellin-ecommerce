-- ============================================================================
-- fishing: Server Market - Precos dinamicos e venda
-- ============================================================================

-- Cache de multiplicadores em memoria
local marketCache = {} -- [fish_item] = multiplier
local lastMarketUpdate = 0

-- Rate limit de vendas
local playerSellCount = {} -- [source] = { count, resetTime }

-- ============================================================================
-- INICIALIZAR MERCADO
-- ============================================================================

CreateThread(function()
    Wait(2000)

    -- Garantir que todos os peixes existem na tabela de mercado
    local allFish = {}
    for _, fishList in pairs(Config.Fish) do
        for _, fish in ipairs(fishList) do
            if not allFish[fish.item] then
                allFish[fish.item] = true
                MySQL.insert([[
                    INSERT IGNORE INTO fishing_market (fish_item, multiplier, total_sold)
                    VALUES (?, 1.0, 0)
                ]], { fish.item })
            end
        end
    end

    -- Carregar mercado
    LoadMarketCache()

    -- Timer de atualizacao
    CreateThread(function()
        while true do
            Wait(Config.MarketUpdate.interval * 60 * 1000)
            UpdateMarketPrices()
        end
    end)

    if Config.Debug then
        -- print('^3[fishing:market]^0 Mercado dinamico inicializado')
    end
end)

-- ============================================================================
-- CARREGAR CACHE
-- ============================================================================

function LoadMarketCache()
    local result = MySQL.query.await('SELECT fish_item, multiplier FROM fishing_market')
    if result then
        for _, row in ipairs(result) do
            marketCache[row.fish_item] = row.multiplier
        end
    end
    lastMarketUpdate = os.time()
end

-- ============================================================================
-- ATUALIZAR PRECOS (tick periodico)
-- ============================================================================

function UpdateMarketPrices()
    local cfg = Config.MarketUpdate

    -- Para cada peixe, recuperar em direcao a 1.0
    MySQL.query('SELECT fish_item, multiplier, total_sold FROM fishing_market', {}, function(result)
        if not result then return end

        for _, row in ipairs(result) do
            local newMult = row.multiplier

            -- Recuperar em direcao a 1.0
            if newMult < 1.0 then
                newMult = math.min(1.0, newMult + cfg.recoveryPerTick)
            elseif newMult > 1.0 then
                newMult = math.max(1.0, newMult - cfg.recoveryPerTick * 0.5)
            end

            -- Se ninguem vendeu desde ultimo tick, demanda sobe
            if row.total_sold == 0 then
                newMult = math.min(cfg.maxMultiplier, newMult + cfg.recoveryPerTick)
            end

            newMult = math.max(cfg.minMultiplier, math.min(cfg.maxMultiplier, newMult))

            MySQL.update(
                'UPDATE fishing_market SET multiplier = ?, total_sold = 0 WHERE fish_item = ?',
                { newMult, row.fish_item }
            )

            marketCache[row.fish_item] = newMult
        end

        if Config.Debug then
            -- print('^3[fishing:market]^0 Precos de mercado atualizados')
        end
    end)
end

-- ============================================================================
-- OBTER MULTIPLICADOR
-- ============================================================================

function GetMarketMultiplier(fishItem)
    return marketCache[fishItem] or 1.0
end

-- ============================================================================
-- CALLBACK: Precos do mercado
-- ============================================================================

lib.callback.register('fishing:server:getMarketPrices', function(source)
    local prices = {}

    for _, fishList in pairs(Config.Fish) do
        for _, fish in ipairs(fishList) do
            if not prices[fish.item] then
                local mult = GetMarketMultiplier(fish.item)
                local avgWeight = (fish.weight[1] + fish.weight[2]) / 2
                prices[fish.item] = {
                    label = fish.label,
                    basePrice = fish.basePrice,
                    multiplier = mult,
                    price = math.floor(fish.basePrice * mult),
                    avgWeight = avgWeight,
                }
            end
        end
    end

    return prices
end)

-- ============================================================================
-- VENDER PEIXES
-- ============================================================================

lib.callback.register('fishing:server:sellFish', function(source, fishItem, amount)
    if not fishItem or not amount or amount < 1 then
        return { success = false, message = 'Dados invalidos' }
    end

    -- Rate limit
    local now = os.time()
    if not playerSellCount[source] then
        playerSellCount[source] = { count = 0, resetTime = now }
    end
    if now - playerSellCount[source].resetTime >= 60 then
        playerSellCount[source] = { count = 0, resetTime = now }
    end
    if playerSellCount[source].count >= Config.Cooldowns.sellRate then
        return { success = false, message = 'Aguarde antes de vender novamente' }
    end

    -- Verificar se e um peixe valido
    local fishConfig = nil
    for _, fishList in pairs(Config.Fish) do
        for _, fish in ipairs(fishList) do
            if fish.item == fishItem then
                fishConfig = fish
                break
            end
        end
        if fishConfig then break end
    end

    if not fishConfig then
        return { success = false, message = 'Este item nao pode ser vendido aqui' }
    end

    -- Verificar quantidade no inventario
    local playerItems = exports.ox_inventory:GetInventoryItems(source)
    if not playerItems then
        return { success = false, message = 'Erro ao acessar inventario' }
    end

    -- Coletar items com metadata de peso
    local fishSlots = {}
    local totalAvailable = 0
    for _, item in pairs(playerItems) do
        if item and item.name == fishItem then
            totalAvailable = totalAvailable + item.count
            fishSlots[#fishSlots + 1] = {
                slot = item.slot,
                count = item.count,
                weight = (item.metadata and item.metadata.weight) or 0,
            }
        end
    end

    if totalAvailable < amount then
        return { success = false, message = string.format('Voce so tem %d %s', totalAvailable, fishConfig.label) }
    end

    -- Calcular preco total
    local mult = GetMarketMultiplier(fishItem)
    local avgWeight = (fishConfig.weight[1] + fishConfig.weight[2]) / 2
    local totalPrice = 0
    local remaining = amount

    -- Remover items e calcular preco baseado no peso de cada um
    for _, slot in ipairs(fishSlots) do
        if remaining <= 0 then break end
        local toRemove = math.min(remaining, slot.count)
        local weightMult = slot.weight > 0 and (slot.weight / avgWeight) or 1.0
        local unitPrice = math.floor(fishConfig.basePrice * mult * weightMult)
        totalPrice = totalPrice + (unitPrice * toRemove)

        exports.ox_inventory:RemoveItem(source, fishItem, toRemove, nil, slot.slot)
        remaining = remaining - toRemove
    end

    -- Dar dinheiro
    local Player = exports.qbx_core:GetPlayer(source)
    if not Player then
        return { success = false, message = 'Erro interno' }
    end
    -- Daily cap check (protegido)
    local canSell = true
    pcall(function()
        local can, _ = CheckDailyCap(source, 'sell')
        canSell = can
    end)
    if not canSell then
        return { success = false, message = 'Limite diario de vendas atingido! Volte amanha.' }
    end

    Player.Functions.AddMoney('cash', totalPrice, 'fishing-sell')

    -- Stats protegidos (nao impede a venda)
    pcall(function()
        -- Atualizar mercado (multiplicador cai com vendas)
        local cfg = Config.MarketUpdate
        local newMult = math.max(cfg.minMultiplier, mult - (cfg.decayPerSale * amount))
        MySQL.update(
            'UPDATE fishing_market SET multiplier = ?, total_sold = total_sold + ? WHERE fish_item = ?',
            { newMult, amount, fishItem }
        )
        marketCache[fishItem] = newMult

        -- Atualizar stats do jogador
        local citizenid = Player.PlayerData.citizenid
        MySQL.update([[
            UPDATE fishing_stats
            SET total_sold = total_sold + ?, money_earned = money_earned + ?
            WHERE citizenid = ?
        ]], { amount, totalPrice, citizenid })

        -- Daily earnings tracking
        IncrementDailyEarnings(source, totalPrice)

        -- Conquistas de venda
        CheckStatAchievements(source, nil)
    end)

    playerSellCount[source].count = playerSellCount[source].count + 1

    -- Webhook para vendas grandes
    if totalPrice >= 5000 then
        local playerName = Player.PlayerData.charinfo and
            ((Player.PlayerData.charinfo.firstname or '') .. ' ' .. (Player.PlayerData.charinfo.lastname or '')) or 'Desconhecido'
        SendWebhook('sales', string.format('%s vendeu %dx %s por R$%d', playerName, amount, fishConfig.label, totalPrice))
    end

    if Config.Debug then
        -- print(string.format('^3[fishing:market]^0 %s vendeu %dx %s por R$%d (mult: %.2f)',
        --     citizenid, amount, fishItem, totalPrice, newMult))
    end

    return { success = true, total = totalPrice }
end)

-- ============================================================================
-- VENDER TODOS OS PEIXES DE UMA VEZ
-- ============================================================================

lib.callback.register('fishing:server:sellAllFish', function(source)
    local Player = exports.qbx_core:GetPlayer(source)
    if not Player then
        return { success = false, message = 'Erro interno' }
    end

    -- Daily cap check
    local canSell = true
    pcall(function()
        local can, _ = CheckDailyCap(source, 'sell')
        canSell = can
    end)
    if not canSell then
        return { success = false, message = 'Limite diario de vendas atingido! Volte amanha.' }
    end

    local playerItems = exports.ox_inventory:GetInventoryItems(source)
    if not playerItems then
        return { success = false, message = 'Erro ao acessar inventario' }
    end

    local totalPrice = 0
    local totalFish = 0
    local citizenid = Player.PlayerData.citizenid

    -- Percorrer todos os items e vender os que sao peixes
    for _, item in pairs(playerItems) do
        if item and item.name then
            -- Verificar se e um peixe valido
            local fishConfig = nil
            for _, fishList in pairs(Config.Fish) do
                for _, fish in ipairs(fishList) do
                    if fish.item == item.name then
                        fishConfig = fish
                        break
                    end
                end
                if fishConfig then break end
            end

            if fishConfig then
                local mult = GetMarketMultiplier(item.name)
                local avgWeight = (fishConfig.weight[1] + fishConfig.weight[2]) / 2
                local fishWeight = (item.metadata and item.metadata.weight) or 0
                local weightMult = fishWeight > 0 and (fishWeight / avgWeight) or 1.0
                local unitPrice = math.floor(fishConfig.basePrice * mult * weightMult)
                local itemTotal = unitPrice * item.count

                totalPrice = totalPrice + itemTotal
                totalFish = totalFish + item.count

                exports.ox_inventory:RemoveItem(source, item.name, item.count, nil, item.slot)

                -- Atualizar mercado
                pcall(function()
                    local cfg = Config.MarketUpdate
                    local newMult = math.max(cfg.minMultiplier, mult - (cfg.decayPerSale * item.count))
                    MySQL.update(
                        'UPDATE fishing_market SET multiplier = ?, total_sold = total_sold + ? WHERE fish_item = ?',
                        { newMult, item.count, item.name }
                    )
                    marketCache[item.name] = newMult
                end)
            end
        end
    end

    if totalFish == 0 then
        return { success = false, message = 'Voce nao tem peixes para vender' }
    end

    Player.Functions.AddMoney('cash', totalPrice, 'fishing-sell-all')

    -- Stats
    pcall(function()
        MySQL.update([[
            UPDATE fishing_stats
            SET total_sold = total_sold + ?, money_earned = money_earned + ?
            WHERE citizenid = ?
        ]], { totalFish, totalPrice, citizenid })
        IncrementDailyEarnings(source, totalPrice)
        CheckStatAchievements(source, nil)
    end)

    return { success = true, total = totalPrice, count = totalFish }
end)

-- ============================================================================
-- CLEANUP
-- ============================================================================

AddEventHandler('playerDropped', function()
    local source = source
    playerSellCount[source] = nil
end)
