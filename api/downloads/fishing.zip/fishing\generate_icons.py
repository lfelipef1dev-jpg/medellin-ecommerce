"""
Gerador de icones para o sistema de pesca medellin-fishing
36 imagens 128x128px PNG fundo transparente
"""
from PIL import Image, ImageDraw, ImageFont
import math, os

OUTPUT = r"H:\Medellin\qbox-staging\resources\ox_inventory\web\images"

# ============================================================================
# DEFINICOES
# ============================================================================

# Raridades e cores de fundo/silhueta
STYLES = {
    'common':    {'bg': (100, 180, 255, 200), 'fg': (255, 255, 255, 255), 'border': (70, 140, 220, 255)},
    'uncommon':  {'bg': (80, 180, 80, 200),   'fg': (255, 255, 255, 255), 'border': (50, 150, 50, 255)},
    'rare':      {'bg': (40, 80, 160, 200),   'fg': (255, 215, 0, 255),   'border': (30, 60, 140, 255)},
    'epic':      {'bg': (120, 40, 180, 200),  'fg': (255, 215, 0, 255),   'border': (100, 20, 160, 255)},
    'legendary': {'bg': (220, 180, 40, 200),  'fg': (30, 30, 30, 255),    'border': (200, 160, 20, 255)},
    'mythic':    {'bg': (200, 30, 30, 200),   'fg': (255, 215, 0, 255),   'border': (180, 20, 20, 255)},
    'equipment': {'bg': (100, 100, 110, 200), 'fg': (255, 255, 255, 255), 'border': (80, 80, 90, 255)},
    'material':  {'bg': (140, 100, 60, 200),  'fg': (255, 255, 255, 255), 'border': (120, 80, 40, 255)},
}

# Itens com raridade e tipo de forma
ITEMS = {
    # PEIXES - Rio (common/uncommon/rare)
    'traira':           {'rarity': 'common',    'shape': 'fish',       'label': 'Traira'},
    'piapara':          {'rarity': 'common',    'shape': 'fish',       'label': 'Piapara'},
    'curimbata':        {'rarity': 'common',    'shape': 'fish',       'label': 'Curimbata'},
    'matrinxa':         {'rarity': 'uncommon',  'shape': 'fish',       'label': 'Matrinxa'},
    'jauu':             {'rarity': 'rare',      'shape': 'fish',       'label': 'Jau'},
    'pirarara':         {'rarity': 'rare',      'shape': 'fish',       'label': 'Pirarara'},
    'piranha_gold':     {'rarity': 'epic',      'shape': 'fish',       'label': 'Piranha Gold'},
    # PEIXES - Saltwater
    'robalo':           {'rarity': 'uncommon',  'shape': 'fish',       'label': 'Robalo'},
    'pescada':          {'rarity': 'common',    'shape': 'fish',       'label': 'Pescada'},
    'garoupa':          {'rarity': 'uncommon',  'shape': 'fish',       'label': 'Garoupa'},
    'peixe_espada':     {'rarity': 'rare',      'shape': 'fish_long',  'label': 'Peixe Espada'},
    # PEIXES - Deepsea
    'barracuda':        {'rarity': 'rare',      'shape': 'fish_long',  'label': 'Barracuda'},
    'wahoo':            {'rarity': 'rare',      'shape': 'fish_long',  'label': 'Wahoo'},
    'tubarao_martelo':  {'rarity': 'epic',      'shape': 'shark',      'label': 'Tub. Martelo'},
    'mero_gigante':     {'rarity': 'epic',      'shape': 'fish_fat',   'label': 'Mero Gigante'},
    'peixe_lua':        {'rarity': 'legendary', 'shape': 'fish_round', 'label': 'Peixe Lua'},
    'orca_fish':        {'rarity': 'legendary', 'shape': 'shark',      'label': 'Orca'},
    # PEIXES - Tropical
    'peixe_palha':      {'rarity': 'common',    'shape': 'fish',       'label': 'Peixe Palha'},
    'cirurgiao':        {'rarity': 'uncommon',  'shape': 'fish',       'label': 'Cirurgiao'},
    'peixe_leao':       {'rarity': 'rare',      'shape': 'fish_spiky', 'label': 'Peixe Leao'},
    'tartaruga_mar':    {'rarity': 'epic',      'shape': 'turtle',     'label': 'Tartaruga'},
    'tubarao_branco':   {'rarity': 'legendary', 'shape': 'shark',      'label': 'Tub. Branco'},
    'agua_viva_rara':   {'rarity': 'epic',      'shape': 'jellyfish',  'label': 'Agua Viva'},
    'perola_negra':     {'rarity': 'legendary', 'shape': 'pearl',      'label': 'Perola Negra'},
    'kraken_baby':      {'rarity': 'mythic',    'shape': 'octopus',    'label': 'Baby Kraken'},
    # PEIXES - Illegal
    'peixe_mutante':    {'rarity': 'rare',      'shape': 'fish_spiky', 'label': 'P. Mutante'},
    'enguia_eletrica':  {'rarity': 'epic',      'shape': 'eel',        'label': 'Enguia Eletr.'},
    'baiacu_toxico':    {'rarity': 'rare',      'shape': 'fish_round', 'label': 'Baiacu'},
    'arraia_venenosa':  {'rarity': 'epic',      'shape': 'ray',        'label': 'Arraia'},
    'peixe_radioativo': {'rarity': 'legendary', 'shape': 'fish_spiky', 'label': 'P. Radioativo'},
    'polvo_sombra':     {'rarity': 'mythic',    'shape': 'octopus',    'label': 'Polvo Sombra'},
    'tubarao_fantasma': {'rarity': 'mythic',    'shape': 'shark',      'label': 'Tub. Fantasma'},
    'leviata':          {'rarity': 'mythic',    'shape': 'fish_fat',   'label': 'Leviata'},
    # EQUIPAMENTO
    'fishingrod_titanium': {'rarity': 'equipment', 'shape': 'rod',    'label': 'Vara Titanio'},
    'fishingrod_legend':   {'rarity': 'equipment', 'shape': 'rod',    'label': 'Vara Lendaria'},
    'fishbait_viva':       {'rarity': 'equipment', 'shape': 'bait',   'label': 'Isca Viva'},
    # REDES
    'fishingnet':          {'rarity': 'equipment', 'shape': 'net',    'label': 'Rede Pesca'},
    'fishingnet_pro':      {'rarity': 'equipment', 'shape': 'net',    'label': 'Rede Premium'},
    'fishingnet_legend':   {'rarity': 'equipment', 'shape': 'net',    'label': 'Rede Lendaria'},
}

# ============================================================================
# FUNCOES DE DESENHO
# ============================================================================

def draw_rounded_rect(draw, xy, radius, fill, outline=None):
    x0, y0, x1, y1 = xy
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=2)

def draw_fish(draw, cx, cy, w, h, color):
    """Peixe generico - oval com cauda triangular"""
    # Corpo oval
    body_w = int(w * 0.65)
    draw.ellipse([cx - body_w//2, cy - h//2, cx + body_w//2, cy + h//2], fill=color)
    # Cauda
    tail_pts = [
        (cx + body_w//2 - 4, cy),
        (cx + w//2, cy - h//2 + 2),
        (cx + w//2, cy + h//2 - 2),
    ]
    draw.polygon(tail_pts, fill=color)
    # Olho
    eye_x = cx - body_w//4
    draw.ellipse([eye_x-3, cy-4, eye_x+3, cy+2], fill=(0,0,0,180))

def draw_fish_long(draw, cx, cy, w, h, color):
    """Peixe alongado (barracuda, espada)"""
    body_h = int(h * 0.4)
    draw.ellipse([cx - w//2 + 5, cy - body_h//2, cx + w//3, cy + body_h//2], fill=color)
    # Corpo alongado
    draw.polygon([
        (cx - w//2 + 10, cy - body_h//3),
        (cx + w//2 - 5, cy),
        (cx - w//2 + 10, cy + body_h//3),
    ], fill=color)
    # Cauda
    draw.polygon([
        (cx + w//3, cy),
        (cx + w//2, cy - h//3),
        (cx + w//2, cy + h//3),
    ], fill=color)
    eye_x = cx - w//3
    draw.ellipse([eye_x-2, cy-3, eye_x+2, cy+1], fill=(0,0,0,180))

def draw_fish_fat(draw, cx, cy, w, h, color):
    """Peixe gordo (mero, leviata)"""
    draw.ellipse([cx - w//2 + 5, cy - h//2 + 2, cx + w//3, cy + h//2 - 2], fill=color)
    draw.polygon([
        (cx + w//3 - 5, cy),
        (cx + w//2, cy - h//3),
        (cx + w//2, cy + h//3),
    ], fill=color)
    # Barbatana dorsal
    draw.polygon([
        (cx - w//6, cy - h//2 + 2),
        (cx + w//6, cy - h//2 + 2),
        (cx, cy - h//2 - 8),
    ], fill=color)
    eye_x = cx - w//4
    draw.ellipse([eye_x-3, cy-4, eye_x+3, cy+2], fill=(0,0,0,180))

def draw_fish_round(draw, cx, cy, w, h, color):
    """Peixe redondo (baiacu, peixe lua)"""
    r = min(w, h) // 2 - 4
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color)
    # Cauda pequena
    draw.polygon([
        (cx + r - 4, cy),
        (cx + r + 12, cy - 10),
        (cx + r + 12, cy + 10),
    ], fill=color)
    eye_x = cx - r//3
    draw.ellipse([eye_x-3, cy-4, eye_x+3, cy+2], fill=(0,0,0,180))

def draw_fish_spiky(draw, cx, cy, w, h, color):
    """Peixe com espinhos (leao, mutante)"""
    draw_fish(draw, cx, cy, w, h, color)
    # Espinhos dorsais
    for i in range(5):
        sx = cx - w//4 + i * (w//5)
        draw.line([(sx, cy - h//2 + 5), (sx, cy - h//2 - 10)], fill=color, width=2)
    # Espinhos ventrais
    for i in range(3):
        sx = cx - w//6 + i * (w//4)
        draw.line([(sx, cy + h//2 - 5), (sx, cy + h//2 + 8)], fill=color, width=2)

def draw_shark(draw, cx, cy, w, h, color):
    """Tubarao"""
    # Corpo
    pts = [
        (cx - w//2 + 5, cy),
        (cx - w//4, cy - h//3),
        (cx + w//4, cy - h//4),
        (cx + w//2 - 5, cy),
        (cx + w//4, cy + h//4),
        (cx - w//4, cy + h//3),
    ]
    draw.polygon(pts, fill=color)
    # Barbatana dorsal grande
    draw.polygon([
        (cx - 5, cy - h//3),
        (cx + 10, cy - h//3),
        (cx, cy - h//2 - 5),
    ], fill=color)
    # Cauda
    draw.polygon([
        (cx + w//2 - 10, cy),
        (cx + w//2 + 5, cy - h//3),
        (cx + w//2 + 5, cy + h//6),
    ], fill=color)
    eye_x = cx - w//4
    draw.ellipse([eye_x-2, cy-3, eye_x+2, cy+1], fill=(0,0,0,180))

def draw_turtle(draw, cx, cy, w, h, color):
    """Tartaruga marinha"""
    # Casco
    shell_w, shell_h = int(w*0.5), int(h*0.45)
    draw.ellipse([cx - shell_w, cy - shell_h, cx + shell_w, cy + shell_h], fill=color)
    # Cabeca
    draw.ellipse([cx - shell_w - 12, cy - 8, cx - shell_w + 5, cy + 8], fill=color)
    # Nadadeiras
    draw.ellipse([cx - 10, cy - shell_h - 10, cx + 15, cy - shell_h + 5], fill=color)
    draw.ellipse([cx - 10, cy + shell_h - 5, cx + 15, cy + shell_h + 10], fill=color)
    draw.ellipse([cx + shell_w - 8, cy - 10, cx + shell_w + 12, cy + 5], fill=color)
    eye_x = cx - shell_w - 6
    draw.ellipse([eye_x-2, cy-3, eye_x+2, cy+1], fill=(0,0,0,180))

def draw_jellyfish(draw, cx, cy, w, h, color):
    """Agua viva"""
    # Cupula
    dome_h = int(h * 0.4)
    draw.pieslice([cx - w//3, cy - h//3, cx + w//3, cy + dome_h//2], start=180, end=0, fill=color)
    # Tentaculos
    for i in range(5):
        tx = cx - w//3 + 8 + i * (w*2//3 - 8) // 4
        for j in range(4):
            ty = cy + dome_h//2 + j * 8
            draw.ellipse([tx-2, ty, tx+2, ty+6], fill=color)

def draw_octopus(draw, cx, cy, w, h, color):
    """Polvo/Kraken"""
    # Cabeca
    head_r = int(min(w,h) * 0.25)
    draw.ellipse([cx - head_r, cy - h//3, cx + head_r, cy - h//3 + head_r*2], fill=color)
    # Tentaculos (6)
    for i in range(6):
        angle = -30 + i * 36
        rad = math.radians(angle)
        tx = cx + int(math.sin(rad) * w//3)
        ty = cy + h//4 + abs(int(math.cos(rad) * h//6))
        draw.line([(cx + int(math.sin(rad)*head_r*0.6), cy - h//3 + head_r), (tx, ty)], fill=color, width=3)
        draw.ellipse([tx-3, ty-3, tx+3, ty+3], fill=color)
    # Olhos
    draw.ellipse([cx-head_r//2-3, cy-h//3+head_r//2, cx-head_r//2+3, cy-h//3+head_r//2+5], fill=(0,0,0,180))
    draw.ellipse([cx+head_r//2-3, cy-h//3+head_r//2, cx+head_r//2+3, cy-h//3+head_r//2+5], fill=(0,0,0,180))

def draw_eel(draw, cx, cy, w, h, color):
    """Enguia"""
    # Corpo sinuoso
    pts = []
    for i in range(40):
        t = i / 39.0
        x = cx - w//2 + 10 + int(t * (w - 20))
        y = cy + int(math.sin(t * math.pi * 2.5) * h * 0.2)
        pts.append((x, y))
    # Desenhar como linha grossa
    for i in range(len(pts)-1):
        thickness = max(2, int(6 * (1 - i/len(pts)) + 2))
        draw.line([pts[i], pts[i+1]], fill=color, width=thickness)
    # Cabeca
    hx, hy = pts[0]
    draw.ellipse([hx-6, hy-5, hx+4, hy+5], fill=color)
    draw.ellipse([hx-4, hy-3, hx-1, hy], fill=(0,0,0,180))

def draw_ray(draw, cx, cy, w, h, color):
    """Arraia"""
    # Corpo em losango achatado
    pts = [
        (cx, cy - h//4),
        (cx + w//2 - 5, cy + 2),
        (cx, cy + h//4),
        (cx - w//2 + 5, cy + 2),
    ]
    draw.polygon(pts, fill=color)
    # Cauda
    draw.line([(cx, cy + h//4), (cx, cy + h//2 + 5)], fill=color, width=2)
    # Olhos
    draw.ellipse([cx-8, cy-4, cx-4, cy], fill=(0,0,0,180))
    draw.ellipse([cx+4, cy-4, cx+8, cy], fill=(0,0,0,180))

def draw_pearl(draw, cx, cy, w, h, color):
    """Perola"""
    r = min(w, h) // 3
    # Concha base
    draw.pieslice([cx - r - 10, cy - r + 5, cx + r + 10, cy + r + 10], start=180, end=0, fill=color)
    draw.pieslice([cx - r - 10, cy - 2, cx + r + 10, cy + r + 10], start=0, end=180, fill=color)
    # Perola brilhante
    pearl_r = r // 2
    draw.ellipse([cx - pearl_r, cy - pearl_r - 2, cx + pearl_r, cy + pearl_r - 2], fill=(220, 220, 240, 255))
    # Brilho
    draw.ellipse([cx - pearl_r//3, cy - pearl_r//2 - 2, cx + pearl_r//4, cy - pearl_r//4 - 2], fill=(255, 255, 255, 200))

def draw_rod(draw, cx, cy, w, h, color):
    """Vara de pesca"""
    # Vara diagonal
    draw.line([(cx - w//3, cy + h//3), (cx + w//3, cy - h//3)], fill=color, width=3)
    # Ponta
    draw.ellipse([cx + w//3 - 3, cy - h//3 - 3, cx + w//3 + 3, cy - h//3 + 3], fill=color)
    # Linha
    draw.line([(cx + w//3, cy - h//3), (cx + w//3 + 5, cy + h//6)], fill=color, width=1)
    # Carretilha
    draw.ellipse([cx - w//6 - 4, cy + h//10 - 4, cx - w//6 + 4, cy + h//10 + 4], fill=color)
    # Anzol
    draw.arc([cx + w//3, cy + h//6 - 5, cx + w//3 + 12, cy + h//6 + 10], start=0, end=270, fill=color, width=2)
    # Grip
    draw.rectangle([cx - w//3 - 5, cy + h//3 - 2, cx - w//3 + 5, cy + h//3 + 6], fill=color)

def draw_bait(draw, cx, cy, w, h, color):
    """Isca"""
    # Gancho
    draw.arc([cx - 10, cy - 15, cx + 10, cy + 10], start=0, end=270, fill=color, width=3)
    draw.line([(cx, cy - 15), (cx, cy - h//3)], fill=color, width=2)
    # Isca (minhoca enrolada)
    for i in range(5):
        angle = i * 72
        bx = cx + int(math.cos(math.radians(angle)) * 8)
        by = cy + 2 + int(math.sin(math.radians(angle)) * 5)
        draw.ellipse([bx-3, by-2, bx+3, by+2], fill=color)
    # Ponta do anzol
    draw.line([(cx + 10, cy + 5), (cx + 13, cy)], fill=color, width=2)

def draw_net(draw, cx, cy, w, h, color):
    """Rede de pesca"""
    # Grade
    grid_w = int(w * 0.6)
    grid_h = int(h * 0.5)
    x0 = cx - grid_w // 2
    y0 = cy - grid_h // 2
    spacing = 10
    # Linhas horizontais
    for i in range(grid_h // spacing + 1):
        y = y0 + i * spacing
        draw.line([(x0, y), (x0 + grid_w, y)], fill=color, width=1)
    # Linhas verticais
    for i in range(grid_w // spacing + 1):
        x = x0 + i * spacing
        draw.line([(x, y0), (x, y0 + grid_h)], fill=color, width=1)
    # Borda
    draw.rectangle([x0-2, y0-2, x0+grid_w+2, y0+grid_h+2], outline=color, width=2)
    # Flutuadores no topo
    for i in range(4):
        fx = x0 + i * (grid_w // 3)
        draw.ellipse([fx-3, y0-8, fx+3, y0-2], fill=color)

# Map shape names to functions
SHAPE_FUNCS = {
    'fish': draw_fish,
    'fish_long': draw_fish_long,
    'fish_fat': draw_fish_fat,
    'fish_round': draw_fish_round,
    'fish_spiky': draw_fish_spiky,
    'shark': draw_shark,
    'turtle': draw_turtle,
    'jellyfish': draw_jellyfish,
    'octopus': draw_octopus,
    'eel': draw_eel,
    'ray': draw_ray,
    'pearl': draw_pearl,
    'rod': draw_rod,
    'bait': draw_bait,
    'net': draw_net,
}

# ============================================================================
# GERAR IMAGENS
# ============================================================================

def get_font(size):
    """Tenta carregar fonte TrueType, fallback pra default"""
    paths = [
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/calibri.ttf",
    ]
    for p in paths:
        try:
            return ImageFont.truetype(p, size)
        except:
            pass
    return ImageFont.load_default()

def generate_icon(name, info):
    img = Image.new('RGBA', (128, 128), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    style = STYLES[info['rarity']]

    # Fundo arredondado
    draw_rounded_rect(draw, [4, 4, 124, 124], radius=16, fill=style['bg'], outline=style['border'])

    # Brilho mythic
    if info['rarity'] == 'mythic':
        draw_rounded_rect(draw, [6, 6, 122, 122], radius=14,
                         fill=(255, 215, 0, 40))

    # Desenhar forma
    shape_func = SHAPE_FUNCS.get(info['shape'], draw_fish)
    shape_func(draw, 64, 55, 90, 60, style['fg'])

    # Label embaixo
    font_sm = get_font(11)
    label = info['label']
    bbox = draw.textbbox((0, 0), label, font=font_sm)
    tw = bbox[2] - bbox[0]
    tx = (128 - tw) // 2
    # Sombra
    draw.text((tx+1, 101), label, font=font_sm, fill=(0, 0, 0, 150))
    draw.text((tx, 100), label, font=font_sm, fill=(255, 255, 255, 230))

    # Indicador de raridade (bolinha no canto)
    rarity_colors = {
        'common': (180, 210, 255),
        'uncommon': (100, 220, 100),
        'rare': (60, 120, 255),
        'epic': (180, 60, 255),
        'legendary': (255, 200, 0),
        'mythic': (255, 50, 50),
        'equipment': (200, 200, 210),
        'material': (180, 140, 80),
    }
    rc = rarity_colors.get(info['rarity'], (200,200,200))
    draw.ellipse([104, 8, 118, 22], fill=(*rc, 255), outline=(255,255,255,180), width=1)

    filepath = os.path.join(OUTPUT, f"{name}.png")
    img.save(filepath, 'PNG')
    size_kb = os.path.getsize(filepath) / 1024
    return filepath, size_kb

# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    print(f"Gerando {len(ITEMS)} icones em: {OUTPUT}\n")
    total = 0
    for name, info in ITEMS.items():
        path, size = generate_icon(name, info)
        print(f"  OK  {name}.png ({size:.1f} KB)")
        total += 1
    print(f"\n{total} imagens geradas com sucesso!")
