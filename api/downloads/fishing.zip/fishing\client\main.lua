-- ============================================================================
-- fishing: Client Main v2.0 - Zonas, NPCs, lojas, menus
-- ============================================================================

-- Estado global do cliente
FishingState = {
    inZone = false,
    currentZone = nil,
    isFishing = false,
    isAFK = false,
    rod = nil,
    bait = nil,
}

-- ============================================================================
-- HELPER: Criar NPC seguro
-- ============================================================================

local function SpawnNPC(model, x, y, z, heading)
    local hash = type(model) == 'string' and joaat(model) or model
    lib.requestModel(hash)
    local ped = CreatePed(0, hash, x, y, z - 1.0, heading or 0.0, false, true)

    if not ped or ped == 0 then
        -- print('^1[fishing]^0 ERRO: Falha ao criar NPC modelo ' .. tostring(model))
        return nil
    end
    SetPedDefaultComponentVariation(ped)

    SetEntityAsMissionEntity(ped, true, true)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedCanBeTargetted(ped, false)
    SetPedCanRagdoll(ped, false)
    SetModelAsNoLongerNeeded(hash)

    return ped
end

-- ============================================================================
-- ZONAS DE PESCA (ox_lib zones)
-- ============================================================================

CreateThread(function()
    -- print('^2[fishing:client]^0 Iniciando zonas de pesca...')
    for zoneId, zone in pairs(Config.Zones) do
        lib.zones.sphere({
            coords = zone.coords,
            radius = zone.radius,
            debug = Config.Debug,
            onEnter = function()
                -- Verificar nivel
                local level = lib.callback.await('fishing:server:getPlayerLevel', false)
                if (level or 1) < (zone.minLevel or 1) then
                    lib.notify({
                        title = 'Pesca',
                        description = string.format('Nivel %d necessario para pescar aqui', zone.minLevel),
                        type = 'error',
                        duration = 4000,
                    })
                    return
                end

                -- Zona ilegal: verificar horario
                if zone.nightOnly then
                    local hour = GetClockHours()
                    if hour >= 5 and hour < 22 then
                        lib.notify({
                            title = 'Zona Proibida',
                            description = 'Esta zona so funciona a noite (22h-5h)',
                            type = 'error',
                            duration = 4000,
                        })
                        return
                    end
                end

                FishingState.inZone = true
                FishingState.currentZone = zoneId

                local title = zone.nightOnly and 'Zona Proibida' or 'Pesca'
                lib.notify({
                    title = title,
                    description = 'Voce entrou na zona: ' .. zone.label,
                    type = 'inform',
                    duration = 3000,
                })
            end,
            onExit = function()
                if FishingState.isFishing and not FishingState.isAFK then
                    CancelFishing('Voce saiu da zona de pesca')
                end
                -- AFK: NAO para aqui. O loop AFK verifica posicao (5m) por conta propria.
                -- Isso evita que micro-movimentos de animacao cancelem a pesca AFK.
                if not FishingState.isAFK then
                    FishingState.inZone = false
                    FishingState.currentZone = nil
                end
            end,
        })

        -- Blips das zonas
        if zone.blip then
            local blip = AddBlipForCoord(zone.coords.x, zone.coords.y, zone.coords.z)
            SetBlipSprite(blip, zone.blip.sprite or 317)
            SetBlipDisplay(blip, 4)
            SetBlipScale(blip, zone.blip.scale or 0.7)
            SetBlipColour(blip, zone.blip.color or 2)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(zone.blip.label or zone.label)
            EndTextCommandSetBlipName(blip)
        end
    end
end)

-- ============================================================================
-- NPC MERCADO DE PEIXES (ox_target)
-- ============================================================================

local marketNPC = nil

CreateThread(function()
    Wait(500)
    local market = Config.Market
    -- print(string.format('^3[fishing:client]^0 Criando NPC mercado: modelo=%s coords=%.1f,%.1f,%.1f', market.npcModel, market.coords.x, market.coords.y, market.coords.z))
    marketNPC = SpawnNPC(market.npcModel, market.coords.x, market.coords.y, market.coords.z, market.npcHeading)

    if not marketNPC then
        -- print('^1[fishing:client]^0 FALHA ao criar NPC do mercado!')
        return
    end
    -- print('^2[fishing:client]^0 NPC mercado criado com sucesso (entity=' .. tostring(marketNPC) .. ')')

    Wait(300)

    exports.ox_target:addLocalEntity(marketNPC, {
        {
            name = 'fishing_sell',
            icon = 'fas fa-fish',
            label = 'Vender Peixes',
            distance = 2.5,
            onSelect = function()
                OpenSellMenu()
            end,
        },
        {
            name = 'fishing_leaderboard',
            icon = 'fas fa-trophy',
            label = 'Ranking de Pesca',
            distance = 2.5,
            onSelect = function()
                OpenLeaderboard()
            end,
        },
        {
            name = 'fishing_stats',
            icon = 'fas fa-chart-bar',
            label = 'Meus Stats',
            distance = 2.5,
            onSelect = function()
                OpenPlayerStats()
            end,
        },
        {
            name = 'fishing_achievements',
            icon = 'fas fa-medal',
            label = 'Conquistas',
            distance = 2.5,
            onSelect = function()
                OpenAchievements()
            end,
        },
    })

    -- Zona de proximidade para notificar o jogador
    lib.zones.sphere({
        coords = market.coords,
        radius = 5.0,
        debug = Config.Debug,
        onEnter = function()
            lib.notify({ title = 'Mercado de Peixes', description = 'Use o alvo (ALT) no NPC para vender peixes', type = 'inform', duration = 4000 })
        end,
    })

    local marketBlip = AddBlipForCoord(market.coords.x, market.coords.y, market.coords.z)
    SetBlipSprite(marketBlip, 317)
    SetBlipDisplay(marketBlip, 4)
    SetBlipScale(marketBlip, 0.8)
    SetBlipColour(marketBlip, 1)
    SetBlipAsShortRange(marketBlip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName('Mercado de Peixes')
    EndTextCommandSetBlipName(marketBlip)
end)

-- ============================================================================
-- NPC MERCADO NEGRO
-- ============================================================================

local blackMarketNPC = nil

CreateThread(function()
    Wait(800)
    local bm = Config.BlackMarket
    if not bm or not bm.coords then return end

    blackMarketNPC = SpawnNPC(bm.npcModel, bm.coords.x, bm.coords.y, bm.coords.z, bm.npcHeading)
    if not blackMarketNPC then return end

    Wait(300)

    exports.ox_target:addLocalEntity(blackMarketNPC, {
        {
            name = 'fishing_black_market',
            icon = 'fas fa-skull-crossbones',
            label = 'Vender Peixes (Mercado Negro)',
            distance = 2.5,
            onSelect = function()
                OpenBlackMarketMenu()
            end,
        },
    })
end)

-- ============================================================================
-- NPCs LOJAS DE PESCA
-- ============================================================================

local shopNPCs = {}
local shopBlips = {}

CreateThread(function()
    Wait(1000)
    -- print('^3[fishing:client]^0 Criando NPCs das lojas...')
    for shopId, shop in pairs(Config.Shops) do
        local npc = SpawnNPC(shop.npcModel, shop.coords.x, shop.coords.y, shop.coords.z, shop.heading)

        if npc then
            shopNPCs[shopId] = npc
            -- print(string.format('^2[fishing:client]^0 NPC loja %s criado (entity=%d)', shopId, npc))

            Wait(300)

            local capturedShopId = shopId
            exports.ox_target:addLocalEntity(npc, {
                {
                    name = 'fishing_shop_' .. capturedShopId,
                    icon = 'fas fa-store',
                    label = 'Loja de Pesca',
                    distance = 2.5,
                    onSelect = function()
                        OpenFishingShop(capturedShopId)
                    end,
                },
            })
        end

        -- Zona de proximidade para notificar jogador
        local capturedLabel = shop.label
        lib.zones.sphere({
            coords = shop.coords,
            radius = 5.0,
            debug = Config.Debug,
            onEnter = function()
                lib.notify({ title = capturedLabel, description = 'Use o alvo (ALT) no NPC para comprar itens', type = 'inform', duration = 4000 })
            end,
        })

        if shop.blip then
            local blip = AddBlipForCoord(shop.coords.x, shop.coords.y, shop.coords.z)
            SetBlipSprite(blip, shop.blip.sprite or 317)
            SetBlipDisplay(blip, 4)
            SetBlipScale(blip, shop.blip.scale or 0.8)
            SetBlipColour(blip, shop.blip.color or 2)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(shop.blip.label or shop.label)
            EndTextCommandSetBlipName(blip)
            shopBlips[shopId] = blip
        end
    end
end)

-- ============================================================================
-- MENU DA LOJA DE PESCA
-- ============================================================================

function OpenFishingShop(shopId)
    local shop = Config.Shops[shopId]
    if not shop then
        lib.notify({ title = 'Loja de Pesca', description = 'Loja nao encontrada', type = 'error' })
        return
    end

    lib.callback('fishing:server:getPlayerLevel', false, function(playerLevel)
        playerLevel = playerLevel or 1

        local options = {}

        for _, item in ipairs(shop.items) do
            local itemData = exports.ox_inventory:Items()[item.name]
            local label = itemData and itemData.label or item.name
            local locked = playerLevel < (item.minLevel or 1)

            local desc = string.format('R$%d', item.price)
            if item.minLevel and item.minLevel > 1 then
                desc = desc .. string.format(' | Nivel %d', item.minLevel)
            end
            if locked then
                desc = desc .. ' (BLOQUEADO)'
            end

            local rodConfig = Config.Rods[item.name]
            local baitConfig = Config.Baits[item.name]
            local netConfig = Config.Nets[item.name]
            local metadata = {}

            if rodConfig then
                metadata[#metadata + 1] = { label = 'Tier', value = rodConfig.tier .. '/5' }
                metadata[#metadata + 1] = { label = 'Durabilidade', value = rodConfig.durability .. ' usos' }
                if rodConfig.rarityBonus > 0 then
                    metadata[#metadata + 1] = { label = 'Bonus Raridade', value = string.format('+%d%%', rodConfig.rarityBonus * 100) }
                end
            elseif baitConfig then
                if baitConfig.rarityBonus > 0 then
                    metadata[#metadata + 1] = { label = 'Bonus Raridade', value = string.format('+%d%%', baitConfig.rarityBonus * 100) }
                end
                if baitConfig.restrictRarity then
                    metadata[#metadata + 1] = { label = 'Restricao', value = 'So pega ' .. (Config.Rarity[baitConfig.restrictRarity] or {}).label .. '+' }
                end
            elseif netConfig then
                metadata[#metadata + 1] = { label = 'Coleta', value = netConfig.collectTime .. ' min' }
                metadata[#metadata + 1] = { label = 'Max Peixes', value = tostring(netConfig.maxFish) }
                metadata[#metadata + 1] = { label = 'Durabilidade', value = netConfig.durability .. ' usos' }
            end

            local icon = 'fas fa-question'
            if rodConfig then icon = 'fas fa-wand-magic-sparkles'
            elseif baitConfig then icon = 'fas fa-worm'
            elseif netConfig then icon = 'fas fa-net-wired' end

            options[#options + 1] = {
                title = label,
                description = desc,
                icon = icon,
                disabled = locked,
                metadata = #metadata > 0 and metadata or nil,
                onSelect = function()
                    if locked then
                        lib.notify({ title = 'Loja de Pesca', description = string.format('Nivel %d necessario!', item.minLevel), type = 'error' })
                        return
                    end
                    BuyFishingItem(shopId, item.name, label, item.price)
                end,
            }
        end

        lib.registerContext({
            id = 'fishing_shop_' .. shopId,
            title = shop.label .. ' (Nivel ' .. playerLevel .. ')',
            options = options,
        })
        lib.showContext('fishing_shop_' .. shopId)
    end)
end

function BuyFishingItem(shopId, itemName, itemLabel, price)
    local input = lib.inputDialog('Comprar ' .. itemLabel, {
        { type = 'number', label = 'Quantidade', default = 1, min = 1, max = 100 },
    })
    if not input then return end

    local amount = math.floor(tonumber(input[1]) or 0)
    if amount < 1 then return end

    lib.callback('fishing:server:buyShopItem', false, function(result)
        if result and result.success then
            PlaySound(Config.Sounds.sell)
            lib.notify({
                title = 'Loja de Pesca',
                description = string.format('Comprou %dx %s por R$%d', amount, itemLabel, result.total),
                type = 'success',
            })
        else
            lib.notify({ title = 'Loja de Pesca', description = result and result.message or 'Erro ao comprar', type = 'error' })
        end
    end, shopId, itemName, amount)
end

-- ============================================================================
-- MENU DE VENDA (Mercado Normal)
-- ============================================================================

function OpenSellMenu()
    local inventory = exports.ox_inventory:GetPlayerItems()
    if not inventory then
        lib.notify({ title = 'Pesca', description = 'Erro ao acessar inventario', type = 'error' })
        return
    end

    lib.callback('fishing:server:getMarketPrices', false, function(prices)
        if not prices then return end

        local options = {}
        local hasFish = false

        for _, invItem in pairs(inventory) do
            if invItem and prices[invItem.name] then
                hasFish = true
                local priceInfo = prices[invItem.name]
                local fishWeight = (invItem.metadata and invItem.metadata.weight) or 0
                local avgWeight = priceInfo.avgWeight or 1
                local weightMult = fishWeight > 0 and (fishWeight / avgWeight) or 1.0
                local unitPrice = math.floor(priceInfo.price * weightMult)

                local rarityColor = '#8892a4'
                if invItem.metadata and invItem.metadata.rarity then
                    rarityColor = (Config.Rarity[invItem.metadata.rarity] or {}).color or '#8892a4'
                end

                options[#options + 1] = {
                    title = string.format('%s x%d', priceInfo.label or invItem.label, invItem.count),
                    description = string.format('R$%d/un (Mercado: %.0f%%)', unitPrice, priceInfo.multiplier * 100),
                    icon = 'fas fa-fish',
                    iconColor = rarityColor,
                    metadata = {
                        { label = 'Preco unitario', value = 'R$' .. unitPrice },
                        { label = 'Total', value = 'R$' .. (unitPrice * invItem.count) },
                    },
                    onSelect = function()
                        SellFishDialog(invItem.name, invItem.count, unitPrice, priceInfo.label)
                    end,
                }
            end
        end

        if not hasFish then
            lib.notify({ title = 'Pesca', description = 'Voce nao tem peixes para vender', type = 'error' })
            return
        end

        -- Botao Vender Tudo no topo
        table.insert(options, 1, {
            title = 'Vender Todos os Peixes',
            description = 'Vende tudo de uma vez',
            icon = 'fas fa-cash-register',
            iconColor = '#00FF88',
            onSelect = function()
                SellAllFish()
            end,
        })

        lib.registerContext({
            id = 'fishing_sell_menu',
            title = 'Vender Peixes',
            options = options,
        })
        lib.showContext('fishing_sell_menu')
    end)
end

function SellAllFish()
    local confirm = lib.alertDialog({
        header = 'Vender Todos os Peixes',
        content = 'Tem certeza que deseja vender TODOS os peixes do inventario?',
        centered = true,
        cancel = true,
    })
    if confirm ~= 'confirm' then return end

    lib.callback('fishing:server:sellAllFish', false, function(result)
        if result and result.success then
            PlaySound(Config.Sounds.sell)
            lib.notify({
                title = 'Pesca',
                description = string.format('Vendeu %dx peixes por R$%d!', result.count, result.total),
                type = 'success',
                duration = 5000,
            })
        else
            lib.notify({ title = 'Pesca', description = result and result.message or 'Erro ao vender', type = 'error' })
        end
    end)
end

function SellFishDialog(fishItem, maxCount, unitPrice, fishLabel)
    local input = lib.inputDialog('Vender ' .. (fishLabel or fishItem), {
        { type = 'number', label = 'Quantidade (max: ' .. maxCount .. ')', default = maxCount, min = 1, max = maxCount },
    })
    if not input then return end

    local amount = math.floor(tonumber(input[1]) or 0)
    if amount < 1 or amount > maxCount then return end

    lib.callback('fishing:server:sellFish', false, function(result)
        if result and result.success then
            PlaySound(Config.Sounds.sell)
            lib.notify({
                title = 'Pesca',
                description = string.format('Vendeu %dx %s por R$%d', amount, fishLabel or fishItem, result.total),
                type = 'success',
            })
        else
            lib.notify({ title = 'Pesca', description = result and result.message or 'Erro ao vender', type = 'error' })
        end
    end, fishItem, amount)
end

-- ============================================================================
-- MENU DE VENDA (Mercado Negro)
-- ============================================================================

function OpenBlackMarketMenu()
    local inventory = exports.ox_inventory:GetPlayerItems()
    if not inventory then return end

    lib.callback('fishing:server:getMarketPrices', false, function(prices)
        if not prices then return end

        local options = {}
        local hasFish = false
        local bmMult = Config.BlackMarket.priceMultiplier or 1.5

        for _, invItem in pairs(inventory) do
            if invItem and prices[invItem.name] then
                hasFish = true
                local priceInfo = prices[invItem.name]
                local fishWeight = (invItem.metadata and invItem.metadata.weight) or 0
                local avgWeight = priceInfo.avgWeight or 1
                local weightMult = fishWeight > 0 and (fishWeight / avgWeight) or 1.0
                local unitPrice = math.floor(priceInfo.price * weightMult * bmMult)

                options[#options + 1] = {
                    title = string.format('%s x%d', priceInfo.label or invItem.label, invItem.count),
                    description = string.format('R$%d/un (Mercado Negro: +50%%)', unitPrice),
                    icon = 'fas fa-skull',
                    iconColor = '#e94560',
                    metadata = {
                        { label = 'Preco unitario', value = 'R$' .. unitPrice },
                        { label = 'Total', value = 'R$' .. (unitPrice * invItem.count) },
                    },
                    onSelect = function()
                        SellFishBlackMarket(invItem.name, invItem.count, unitPrice, priceInfo.label)
                    end,
                }
            end
        end

        if not hasFish then
            lib.notify({ title = 'Mercado Negro', description = 'Voce nao tem peixes para vender', type = 'error' })
            return
        end

        lib.registerContext({
            id = 'fishing_black_market_menu',
            title = 'Mercado Negro - Peixes',
            options = options,
        })
        lib.showContext('fishing_black_market_menu')
    end)
end

function SellFishBlackMarket(fishItem, maxCount, unitPrice, fishLabel)
    local input = lib.inputDialog('Vender (Mercado Negro) ' .. (fishLabel or fishItem), {
        { type = 'number', label = 'Quantidade (max: ' .. maxCount .. ')', default = maxCount, min = 1, max = maxCount },
    })
    if not input then return end

    local amount = math.floor(tonumber(input[1]) or 0)
    if amount < 1 or amount > maxCount then return end

    lib.callback('fishing:server:sellFishBlackMarket', false, function(result)
        if result and result.success then
            PlaySound(Config.Sounds.sell)
            lib.notify({
                title = 'Mercado Negro',
                description = string.format('Vendeu %dx %s por R$%d', amount, fishLabel or fishItem, result.total),
                type = 'success',
            })
        else
            lib.notify({ title = 'Mercado Negro', description = result and result.message or 'Erro ao vender', type = 'error' })
        end
    end, fishItem, amount)
end

-- ============================================================================
-- LEADERBOARD
-- ============================================================================

function OpenLeaderboard()
    lib.callback('fishing:server:getLeaderboard', false, function(data)
        if not data or #data == 0 then
            lib.notify({ title = 'Pesca', description = 'Nenhum recorde registrado', type = 'inform' })
            return
        end

        local options = {}
        for i, entry in ipairs(data) do
            local rarityInfo = Config.Rarity[entry.rarity] or Config.Rarity.common
            options[#options + 1] = {
                title = string.format('#%d - %s (%s)', i, entry.fish_label, entry.player_name or 'Desconhecido'),
                description = string.format('%dg | %dcm | %s', entry.weight, entry.size, rarityInfo.label),
                icon = rarityInfo.icon or 'fas fa-trophy',
                iconColor = rarityInfo.color,
            }
        end

        lib.registerContext({
            id = 'fishing_leaderboard',
            title = 'Top 10 - Maiores Peixes',
            options = options,
        })
        lib.showContext('fishing_leaderboard')
    end)
end

-- ============================================================================
-- PLAYER STATS
-- ============================================================================

function OpenPlayerStats()
    lib.callback('fishing:server:getPlayerStats', false, function(stats)
        if not stats then return end

        local xpPercent = 0
        if stats.xpNeeded and stats.xpNeeded > 0 then
            xpPercent = math.floor((stats.xp or 0) / stats.xpNeeded * 100)
        end

        local options = {
            {
                title = string.format('Nivel %d / %d', stats.level or 1, stats.maxLevel or 50),
                description = string.format('XP: %d / %d (%d%%)', stats.xp or 0, stats.xpNeeded or 100, xpPercent),
                icon = 'fas fa-star',
                iconColor = '#ffd700',
                progress = xpPercent,
                colorScheme = 'green',
            },
            {
                title = 'Peixes Pescados',
                description = string.format('Total: %d | Hoje: %d / %d', stats.total_caught or 0, stats.fish_caught_today or 0, Config.DailyCaps.maxCatchPerDay or 200),
                icon = 'fas fa-fish',
                iconColor = '#00FF88',
            },
            {
                title = 'Vendas',
                description = string.format('Vendidos: %d | Ganhos: R$%d', stats.total_sold or 0, stats.money_earned or 0),
                icon = 'fas fa-coins',
                iconColor = '#ffd700',
            },
            {
                title = 'Maior Peixe',
                description = string.format('%dg - %s', stats.biggest_weight or 0, stats.biggest_fish or 'Nenhum'),
                icon = 'fas fa-trophy',
                iconColor = '#48c9b0',
            },
        }

        lib.registerContext({
            id = 'fishing_stats',
            title = 'Estatisticas de Pesca',
            options = options,
        })
        lib.showContext('fishing_stats')
    end)
end

-- ============================================================================
-- CONQUISTAS
-- ============================================================================

function OpenAchievements()
    lib.callback('fishing:server:getPlayerAchievements', false, function(achievements)
        if not achievements or #achievements == 0 then
            lib.notify({ title = 'Pesca', description = 'Nenhuma conquista disponivel', type = 'inform' })
            return
        end

        local options = {}
        for _, ach in ipairs(achievements) do
            local icon = ach.unlocked and 'fas fa-check-circle' or 'fas fa-lock'
            local color = ach.unlocked and '#00FF88' or '#8892a4'
            local desc = ach.description
            if ach.moneyReward and ach.moneyReward > 0 then
                desc = desc .. string.format(' (+R$%d)', ach.moneyReward)
            end
            if ach.xpReward and ach.xpReward > 0 then
                desc = desc .. string.format(' (+%d XP)', ach.xpReward)
            end

            options[#options + 1] = {
                title = ach.label,
                description = desc,
                icon = icon,
                iconColor = color,
                disabled = not ach.unlocked,
            }
        end

        lib.registerContext({
            id = 'fishing_achievements',
            title = 'Conquistas de Pesca',
            options = options,
        })
        lib.showContext('fishing_achievements')
    end)
end

-- ============================================================================
-- UTILITIES
-- ============================================================================

function PlaySound(sound)
    if sound then
        PlaySoundFrontend(-1, sound.name, sound.set, true)
    end
end

-- Event para server triggar som no client
RegisterNetEvent('fishing:client:playSound', function(soundName, soundSet)
    PlaySoundFrontend(-1, soundName, soundSet, true)
end)

function GetTimeOfDay()
    local hour = GetClockHours()
    if hour >= 6 and hour < 12 then return 'morning' end
    if hour >= 12 and hour < 18 then return 'afternoon' end
    return 'night'
end

function GetCurrentWeather()
    local weatherHash = GetPrevWeatherTypeHashName()
    if weatherHash == joaat('RAIN') or weatherHash == joaat('THUNDER') then
        if weatherHash == joaat('THUNDER') then return 'thunder' end
        return 'rain'
    end
    return 'default'
end

-- ============================================================================
-- PESCA AFK - TOGGLE
-- ============================================================================

RegisterCommand('pescaafk', function()
    if FishingState.isAFK then
        StopAFKFishing('Pesca AFK desativada')
        return
    end
    StartAFKFishing()
end, false)

RegisterCommand('guardarvara', function()
    if FishingState.isAFK then
        StopAFKFishing('Voce guardou a vara')
    elseif FishingState.isFishing then
        CancelFishing('Voce guardou a vara')
    else
        lib.notify({ title = 'Pesca', description = 'Voce nao esta pescando', type = 'error' })
    end
end, false)

RegisterCommand('pescastats', function()
    OpenStatsNUI()
end, false)

RegisterCommand('conquistas', function()
    OpenAchievements()
end, false)

RegisterCommand('fishrank', function()
    OpenLeaderboardNUI()
end, false)

RegisterCommand('pescaboard', function()
    OpenLeaderboardNUI()
end, false)

RegisterKeyMapping('guardarvara', 'Guardar Vara de Pesca', 'keyboard', '')
TriggerEvent('chat:removeSuggestion', '/guardarvara')

-- Comando de emergencia: descongelar jogador
RegisterCommand('descongelar', function()
    local ped = PlayerPedId()
    ClearPedTasksImmediately(ped)
    ClearPedTasks(ped)
    FreezeEntityPosition(ped, false)
    SetPlayerControl(PlayerId(), true, 0)
    SetNuiFocus(false, false)
    FishingState.isFishing = false
    FishingState.isAFK = false
    SafeCleanup()
    lib.notify({ title = 'OK', description = 'Descongelado!', type = 'success' })
end, false)

-- ============================================================================
-- CLEANUP
-- ============================================================================

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    if marketNPC and DoesEntityExist(marketNPC) then
        DeleteEntity(marketNPC)
    end
    if blackMarketNPC and DoesEntityExist(blackMarketNPC) then
        DeleteEntity(blackMarketNPC)
    end
    for _, npc in pairs(shopNPCs) do
        if npc and DoesEntityExist(npc) then
            DeleteEntity(npc)
        end
    end
    for _, blip in pairs(shopBlips) do
        if blip and DoesBlipExist(blip) then
            RemoveBlip(blip)
        end
    end
    SafeCleanup()
end)

-- ============================================================================
-- SAFETY NET: descongelar jogador se algo bugar
-- ============================================================================

CreateThread(function()
    while true do
        Wait(10000)
        if not FishingState.isFishing and not FishingState.isAFK then
            local ped = PlayerPedId()
            if IsEntityPositionFrozen(ped) then
                FreezeEntityPosition(ped, false)
                SetPlayerControl(PlayerId(), true, 0)
                ClearPedTasksImmediately(ped)
                -- Safety net ativou (jogador estava congelado fora da pesca)
            end
        end
    end
end)
