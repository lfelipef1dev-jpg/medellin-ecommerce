-- ============================================================================
-- fishing: Client Minigame - SkillCheck + NUI Catch Screen
-- ============================================================================

local minigameActive = false

-- ============================================================================
-- FECHAR MINIGAME
-- ============================================================================

function CloseMinigame()
    minigameActive = false
end

-- ============================================================================
-- TELA DE CAPTURA (NUI com imagem, stats, XP bar, level up)
-- ============================================================================

function ShowCatchScreen(catchData)
    local rarityInfo = Config.Rarity[catchData.rarity] or Config.Rarity.common

    -- Obter dados de XP/nivel do servidor (protegido)
    local ok, xpData = pcall(lib.callback.await, 'fishing:server:getPlayerXPData', false)
    if not ok then xpData = nil end

    -- Calcular progresso XP
    local xpProgress = 0
    if xpData and xpData.xpNeeded and xpData.xpNeeded > 0 then
        xpProgress = math.floor((xpData.xp / xpData.xpNeeded) * 100)
    end

    SendNUIMessage({
        action = 'showCatch',
        item = catchData.item,
        label = catchData.label,
        rarity = catchData.rarity,
        rarityLabel = rarityInfo.label or 'Comum',
        rarityColor = rarityInfo.color or '#8892a4',
        image = ('nui://ox_inventory/web/images/%s.png'):format(catchData.item or 'fishingrod'),
        weight = catchData.weight or 0,
        size = catchData.size or 0,
        xp = catchData.xp or 0,
        value = catchData.value or 0,
        level = xpData and xpData.level or 1,
        xpProgress = xpProgress,
        levelUp = catchData.levelUp or false,
        newLevel = catchData.newLevel or nil,
        duration = 4000,
    })
    -- NAO usar SetNuiFocus aqui — a catch screen e apenas visual, sem interacao
end

-- ============================================================================
-- NUI CALLBACK: Fechar tela de captura
-- ============================================================================

RegisterNUICallback('closeCatch', function(_, cb)
    cb('ok')
end)

-- ============================================================================
-- LEADERBOARD NUI
-- ============================================================================

function OpenLeaderboardNUI()
    -- Buscar dados do servidor
    local leaderboard = lib.callback.await('fishing:server:getLeaderboardFull', false)
    if not leaderboard then
        lib.notify({ title = 'Pesca', description = 'Erro ao carregar ranking', type = 'error' })
        return
    end

    SendNUIMessage({
        action = 'showLeaderboard',
        mostFish = leaderboard.mostFish or {},
        heaviest = leaderboard.heaviest or {},
        mostMoney = leaderboard.mostMoney or {},
        highestLevel = leaderboard.highestLevel or {},
        playerPosition = leaderboard.playerPosition or nil,
    })

    SetNuiFocus(true, true)
end

RegisterNUICallback('closeLeaderboard', function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

-- ============================================================================
-- STATS NUI
-- ============================================================================

function OpenStatsNUI()
    local stats = lib.callback.await('fishing:server:getPlayerStats', false)
    if not stats then
        lib.notify({ title = 'Pesca', description = 'Erro ao carregar estatisticas', type = 'error' })
        return
    end

    -- Obter dados de redes/varas
    local netsData = lib.callback.await('fishing:server:getPlayerNetsAndRods', false)
    local achievements = lib.callback.await('fishing:server:getPlayerAchievements', false)

    local activeNets = netsData and #(netsData.nets or {}) or 0
    local activeRods = netsData and #(netsData.rods or {}) or 0
    local achievementsUnlocked = 0
    local achievementsTotal = achievements and #achievements or 0
    if achievements then
        for _, ach in ipairs(achievements) do
            if ach.unlocked then achievementsUnlocked = achievementsUnlocked + 1 end
        end
    end

    SendNUIMessage({
        action = 'showStats',
        level = stats.level or 1,
        xp = stats.xp or 0,
        xpNeeded = stats.xpNeeded or 100,
        maxLevel = stats.maxLevel or 50,
        total_caught = stats.total_caught or 0,
        total_sold = stats.total_sold or 0,
        money_earned = stats.money_earned or 0,
        biggest_weight = stats.biggest_weight or 0,
        biggest_fish = stats.biggest_fish or '',
        fish_caught_today = stats.fish_caught_today or 0,
        money_earned_today = stats.money_earned_today or 0,
        activeNets = activeNets,
        activeRods = activeRods,
        achievementsUnlocked = achievementsUnlocked,
        achievementsTotal = achievementsTotal,
    })

    SetNuiFocus(true, true)
end

RegisterNUICallback('closeStats', function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

