// ============================================================================
// medellin-fishing: Minigame NUI - Barra estilo New World/Sea of Thieves
// ============================================================================

(function () {
    'use strict';

    const container = document.getElementById('minigame-container');
    const bar = document.getElementById('minigame-bar');
    const greenZone = document.getElementById('green-zone');
    const fishIndicator = document.getElementById('fish-indicator');
    const progressFill = document.getElementById('progress-fill');
    const progressBarFill = document.getElementById('progress-bar-fill');
    const fishNameEl = document.getElementById('fish-name');
    const fishRarityEl = document.getElementById('fish-rarity');

    let active = false;
    let animFrame = null;
    let mouseDown = false;

    // Game state
    let fishPos = 0.5;       // 0 = top, 1 = bottom (position in bar)
    let greenPos = 0.5;      // center of green zone
    let progress = 0.3;      // 0-1 catch progress
    let greenSize = 0.25;    // size as fraction of bar
    let fishPull = 0.003;    // gravity pulling fish down
    let reelSpeed = 0.006;   // how fast player pulls fish up
    let progressRate = 0.008;
    let regressRate = 0.004;
    let duration = 12000;
    let startTime = 0;

    // Green zone movement
    let greenDir = 1;
    let greenSpeed = 0.002;

    // ========================================================================
    // EVENT LISTENERS
    // ========================================================================

    document.addEventListener('mousedown', function (e) {
        if (e.button === 0) mouseDown = true;
    });
    document.addEventListener('mouseup', function (e) {
        if (e.button === 0) mouseDown = false;
    });

    // Keyboard support (space bar)
    document.addEventListener('keydown', function (e) {
        if (e.code === 'Space' && active) {
            e.preventDefault();
            mouseDown = true;
        }
    });
    document.addEventListener('keyup', function (e) {
        if (e.code === 'Space') {
            mouseDown = false;
        }
    });

    // ========================================================================
    // NUI MESSAGE HANDLER
    // ========================================================================

    window.addEventListener('message', function (event) {
        const data = event.data;

        if (data.action === 'startMinigame') {
            startGame(data);
        } else if (data.action === 'closeMinigame') {
            endGame(false, true);
        }
    });

    // ========================================================================
    // GAME LOGIC
    // ========================================================================

    function startGame(data) {
        fishNameEl.textContent = data.fishLabel || 'Peixe';
        fishRarityEl.textContent = data.rarityLabel || 'Comum';
        fishRarityEl.style.backgroundColor = (data.rarityColor || '#AAAAAA') + '33';
        fishRarityEl.style.color = data.rarityColor || '#AAAAAA';

        greenSize = data.greenZoneSize || 0.25;
        fishPull = data.fishPullSpeed || 0.003;
        reelSpeed = data.reelSpeed || 0.006;
        progressRate = data.progressPerTick || 0.008;
        regressRate = data.regressPerTick || 0.004;
        duration = data.duration || 12000;

        // Reset state
        fishPos = 0.5;
        greenPos = 0.5;
        progress = 0.3;
        greenDir = 1;
        greenSpeed = 0.001 + Math.random() * 0.002;
        mouseDown = false;
        startTime = Date.now();

        container.classList.remove('hidden');
        active = true;

        if (animFrame) cancelAnimationFrame(animFrame);
        animFrame = requestAnimationFrame(gameLoop);
    }

    function gameLoop() {
        if (!active) return;

        const elapsed = Date.now() - startTime;

        // Time's up = fail
        if (elapsed >= duration) {
            endGame(false);
            return;
        }

        // Move green zone (bouncing)
        greenPos += greenDir * greenSpeed;
        if (greenPos - greenSize / 2 <= 0) {
            greenPos = greenSize / 2;
            greenDir = 1;
            greenSpeed = 0.001 + Math.random() * 0.003;
        }
        if (greenPos + greenSize / 2 >= 1) {
            greenPos = 1 - greenSize / 2;
            greenDir = -1;
            greenSpeed = 0.001 + Math.random() * 0.003;
        }

        // Fish physics
        // Gravity pulls down (pos increases)
        fishPos += fishPull;
        // Player pulls up (pos decreases)
        if (mouseDown) {
            fishPos -= reelSpeed;
        }
        // Clamp
        fishPos = Math.max(0.02, Math.min(0.98, fishPos));

        // Check if fish is in green zone
        const greenTop = greenPos - greenSize / 2;
        const greenBottom = greenPos + greenSize / 2;
        const inZone = fishPos >= greenTop && fishPos <= greenBottom;

        if (inZone) {
            progress += progressRate;
        } else {
            progress -= regressRate;
        }

        progress = Math.max(0, Math.min(1, progress));

        // Win/Lose checks
        if (progress >= 1.0) {
            endGame(true);
            return;
        }
        if (progress <= 0.0) {
            endGame(false);
            return;
        }

        // Render
        render(inZone);

        animFrame = requestAnimationFrame(gameLoop);
    }

    function render(inZone) {
        const barHeight = bar.offsetHeight;

        // Green zone
        const gzTop = (greenPos - greenSize / 2) * barHeight;
        const gzHeight = greenSize * barHeight;
        greenZone.style.top = gzTop + 'px';
        greenZone.style.height = gzHeight + 'px';

        // Fish
        const fishTop = fishPos * barHeight - 18;
        fishIndicator.style.top = Math.max(0, fishTop) + 'px';

        // Glow effect when in zone
        if (inZone) {
            fishIndicator.style.filter = 'drop-shadow(0 0 10px rgba(0, 179, 65, 1))';
            greenZone.style.background = 'linear-gradient(180deg, rgba(0,179,65,0.25) 0%, rgba(0,179,65,0.7) 50%, rgba(0,179,65,0.25) 100%)';
        } else {
            fishIndicator.style.filter = 'drop-shadow(0 0 6px rgba(241, 196, 15, 0.8))';
            greenZone.style.background = 'linear-gradient(180deg, rgba(0,179,65,0.15) 0%, rgba(0,179,65,0.5) 50%, rgba(0,179,65,0.15) 100%)';
        }

        // Progress fill (bottom of bar)
        progressFill.style.height = (progress * 100) + '%';

        // Side progress bar
        progressBarFill.style.height = (progress * 100) + '%';

        // Color side bar based on progress
        if (progress > 0.7) {
            progressBarFill.style.background = 'linear-gradient(0deg, #00B341 0%, #00FF55 100%)';
        } else if (progress > 0.3) {
            progressBarFill.style.background = 'linear-gradient(0deg, #F1C40F 0%, #FFEC44 100%)';
        } else {
            progressBarFill.style.background = 'linear-gradient(0deg, #E74C3C 0%, #FF6655 100%)';
        }
    }

    function endGame(success, silent) {
        active = false;
        mouseDown = false;
        if (animFrame) {
            cancelAnimationFrame(animFrame);
            animFrame = null;
        }
        container.classList.add('hidden');

        if (!silent) {
            fetch('https://' + GetParentResourceName() + '/minigameResult', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ success: success })
            }).catch(function () {});
        }
    }

    // Utility for NUI
    function GetParentResourceName() {
        return window.__cfx_nui_resource || 'medellin-fishing';
    }

    // Override for CEF
    if (window.GetParentResourceName) {
        // Already defined by FiveM
    } else {
        window.GetParentResourceName = GetParentResourceName;
    }
})();
