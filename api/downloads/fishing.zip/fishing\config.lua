Config = {}

Config.Debug = false
Config.CraftingBench = true   -- Criar bancada de craft perto das lojas (false = desativa)

-- ============================================================================
-- NIVEIS E PROGRESSAO (1-50)
-- ============================================================================
Config.MaxLevel = 50

-- XP necessario para subir de nivel: base + (nivel * multiplicador)
-- Nivel 2 = 150, Nivel 10 = 550, Nivel 25 = 1300, Nivel 50 = 2550
Config.XPFormula = {
    base = 100,
    perLevel = 50,
}

-- Bonus de XP por nivel (% extra)
Config.LevelBonuses = {
    [5]  = { unlockText = 'Vara Carbono desbloqueada' },
    [10] = { unlockText = 'Vara Profissional desbloqueada' },
    [15] = { unlockText = 'Vara Titanio desbloqueada' },
    [20] = { unlockText = 'Zona Abissal desbloqueada' },
    [25] = { unlockText = 'Isca Lendaria desbloqueada' },
    [30] = { unlockText = 'Vara Lendaria desbloqueada' },
    [35] = { unlockText = 'Zona Ilegal desbloqueada' },
    [40] = { unlockText = 'Rede Premium desbloqueada' },
    [50] = { unlockText = 'Mestre Pescador - Titulo exclusivo!' },
}

-- ============================================================================
-- ZONAS DE PESCA (5 zonas + 1 ilegal)
-- ============================================================================
Config.Zones = {
    paleto = {
        label = 'Lago Paleto',
        coords = vector3(-906.61, 5687.01, 1.21),
        radius = 35.0,
        waterType = 'freshwater',
        minLevel = 1,
        blip = { sprite = 317, color = 2, scale = 0.7, label = 'Pesca - Lago Paleto' },
    },
    pier = {
        label = 'Pier Del Perro',
        coords = vector3(-1850.5, -1248.5, 8.6),
        radius = 60.0,
        waterType = 'saltwater',
        minLevel = 1,
        blip = { sprite = 317, color = 2, scale = 0.7, label = 'Pesca - Pier Del Perro' },
    },
    zancudo = {
        label = 'Rio Zancudo',
        coords = vector3(-2082.49, 2616.95, 3.08),
        radius = 60.0,
        waterType = 'river',
        minLevel = 5,
        blip = { sprite = 317, color = 25, scale = 0.7, label = 'Pesca - Rio Zancudo' },
    },
    altomar = {
        label = 'Alto Mar',
        coords = vector3(599.95, -3879.83, -0.20),
        radius = 100.0,
        waterType = 'deepsea',
        minLevel = 10,
        blip = { sprite = 317, color = 3, scale = 0.7, label = 'Pesca - Alto Mar' },
    },
    cayo = {
        label = 'Aguas de Cayo Perico',
        coords = vector3(4905.77, -5175.87, 2.0),
        radius = 80.0,
        waterType = 'tropical',
        minLevel = 20,
        blip = { sprite = 317, color = 5, scale = 0.7, label = 'Pesca - Aguas Tropicais' },
    },
    ilegal = {
        label = 'Zona Proibida',
        coords = vector3(3826.23, 4458.71, 2.71),
        radius = 50.0,
        waterType = 'illegal',
        minLevel = 35,
        nightOnly = true,          -- so funciona entre 22h-5h
        dirtyMoney = true,         -- paga em dirty money
        wantedChance = 0.10,       -- 10% chance de ganhar wanted level
        blip = nil,                -- sem blip no mapa (zona secreta)
    },
}

-- ============================================================================
-- MERCADO DE PEIXES (NPC vendedor)
-- ============================================================================
Config.Market = {
    label = 'Mercado de Peixes',
    coords = vector3(-3411.58, 967.39, 8.35),
    radius = 5.0,
    npcModel = 's_m_m_linecook',
    npcHeading = 273.05,
}

-- ============================================================================
-- MERCADO NEGRO (venda de peixes ilegais)
-- ============================================================================
Config.BlackMarket = {
    label = 'Receptador',
    coords = vector3(1393.85, 3606.44, 34.98),
    npcModel = 'g_m_y_mexgoon_01',
    npcHeading = 200.0,
    priceMultiplier = 1.5,          -- 50% mais caro que mercado normal
    dirtyMoney = true,              -- paga em dirty money
}

-- ============================================================================
-- PEIXES POR TIPO DE AGUA (30+ especies)
-- ============================================================================
-- raridade: common, uncommon, rare, epic, legendary, mythic
-- weight: range {min, max} em gramas
-- size: range {min, max} em cm

Config.Fish = {
    -- ===== AGUA DOCE (lagos, rios) =====
    freshwater = {
        { item = 'tilapia',       label = 'Tilapia',         rarity = 'common',    chance = 25, basePrice = 50,    xp = 5,    weight = {200, 500},    size = {15, 35} },
        { item = 'lambari',       label = 'Lambari',         rarity = 'common',    chance = 25, basePrice = 30,    xp = 3,    weight = {20, 80},      size = {5, 15} },
        { item = 'carp',          label = 'Carpa',           rarity = 'common',    chance = 15, basePrice = 60,    xp = 5,    weight = {300, 800},    size = {20, 45} },
        { item = 'catfish',       label = 'Bagre',           rarity = 'common',    chance = 10, basePrice = 70,    xp = 6,    weight = {250, 600},    size = {20, 40} },
        { item = 'pintado',       label = 'Pintado',         rarity = 'uncommon',  chance = 8,  basePrice = 150,   xp = 15,   weight = {500, 1200},   size = {30, 70} },
        { item = 'tambaqui',      label = 'Tambaqui',        rarity = 'uncommon',  chance = 6,  basePrice = 180,   xp = 18,   weight = {400, 1000},   size = {25, 60} },
        { item = 'pacu',          label = 'Pacu',            rarity = 'uncommon',  chance = 5,  basePrice = 120,   xp = 12,   weight = {250, 700},    size = {20, 50} },
        { item = 'fish_dourado',  label = 'Dourado',         rarity = 'rare',      chance = 3,  basePrice = 500,   xp = 50,   weight = {500, 1500},   size = {40, 80} },
        { item = 'fish_pirarucu', label = 'Pirarucu',        rarity = 'epic',      chance = 2,  basePrice = 1200,  xp = 120,  weight = {1500, 5000},  size = {80, 200} },
        { item = 'goldenfish',    label = 'Peixe Dourado',   rarity = 'legendary', chance = 1,  basePrice = 3000,  xp = 300,  weight = {50, 200},     size = {5, 20} },
    },

    -- ===== RIO (exclusivos de rio) =====
    river = {
        { item = 'lambari',       label = 'Lambari',         rarity = 'common',    chance = 20, basePrice = 30,    xp = 3,    weight = {20, 80},      size = {5, 15} },
        { item = 'traira',        label = 'Traira',          rarity = 'common',    chance = 18, basePrice = 65,    xp = 7,    weight = {200, 600},    size = {15, 40} },
        { item = 'piapara',       label = 'Piapara',         rarity = 'common',    chance = 15, basePrice = 55,    xp = 5,    weight = {150, 400},    size = {15, 35} },
        { item = 'curimbata',     label = 'Curimbata',       rarity = 'common',    chance = 12, basePrice = 45,    xp = 4,    weight = {200, 500},    size = {15, 35} },
        { item = 'tucunare',      label = 'Tucunare',        rarity = 'uncommon',  chance = 10, basePrice = 200,   xp = 20,   weight = {300, 900},    size = {25, 55} },
        { item = 'matrinxa',      label = 'Matrinxa',        rarity = 'uncommon',  chance = 8,  basePrice = 170,   xp = 17,   weight = {300, 800},    size = {25, 50} },
        { item = 'jauu',          label = 'Jau',             rarity = 'rare',      chance = 5,  basePrice = 600,   xp = 60,   weight = {1000, 3000},  size = {50, 120} },
        { item = 'pirarara',      label = 'Pirarara',        rarity = 'rare',      chance = 4,  basePrice = 700,   xp = 70,   weight = {800, 2500},   size = {50, 100} },
        { item = 'fish_pirarucu', label = 'Pirarucu',        rarity = 'epic',      chance = 2,  basePrice = 1200,  xp = 120,  weight = {1500, 5000},  size = {80, 200} },
        { item = 'piranha_gold',  label = 'Piranha Dourada', rarity = 'legendary', chance = 1,  basePrice = 3500,  xp = 350,  weight = {100, 300},    size = {10, 25} },
    },

    -- ===== AGUA SALGADA (costa, pier) =====
    saltwater = {
        { item = 'tainha',        label = 'Tainha',          rarity = 'common',    chance = 22, basePrice = 60,    xp = 6,    weight = {200, 500},    size = {20, 40} },
        { item = 'corvina',       label = 'Corvina',         rarity = 'common',    chance = 18, basePrice = 100,   xp = 10,   weight = {300, 700},    size = {25, 50} },
        { item = 'robalo',        label = 'Robalo',          rarity = 'common',    chance = 12, basePrice = 90,    xp = 9,    weight = {250, 600},    size = {20, 45} },
        { item = 'pescada',       label = 'Pescada',         rarity = 'common',    chance = 10, basePrice = 80,    xp = 8,    weight = {200, 500},    size = {20, 40} },
        { item = 'salmao',        label = 'Salmao',          rarity = 'uncommon',  chance = 10, basePrice = 300,   xp = 30,   weight = {400, 1200},   size = {30, 80} },
        { item = 'fish_atum',     label = 'Atum',            rarity = 'uncommon',  chance = 8,  basePrice = 250,   xp = 25,   weight = {600, 2000},   size = {40, 100} },
        { item = 'garoupa',       label = 'Garoupa',         rarity = 'rare',      chance = 5,  basePrice = 550,   xp = 55,   weight = {500, 1500},   size = {30, 70} },
        { item = 'lagosta',       label = 'Lagosta',         rarity = 'rare',      chance = 4,  basePrice = 700,   xp = 70,   weight = {300, 800},    size = {20, 45} },
        { item = 'peixe_espada',  label = 'Peixe Espada',    rarity = 'epic',      chance = 3,  basePrice = 1500,  xp = 150,  weight = {1000, 3000},  size = {80, 200} },
        { item = 'horsefish',     label = 'Cavalo Marinho',  rarity = 'legendary', chance = 1,  basePrice = 5000,  xp = 500,  weight = {20, 80},      size = {5, 25} },
    },

    -- ===== MAR PROFUNDO (alto mar, barco necessario) =====
    deepsea = {
        { item = 'corvina',       label = 'Corvina',         rarity = 'common',    chance = 15, basePrice = 100,   xp = 10,   weight = {300, 700},    size = {25, 50} },
        { item = 'fish_atum',     label = 'Atum',            rarity = 'common',    chance = 15, basePrice = 250,   xp = 25,   weight = {600, 2000},   size = {40, 100} },
        { item = 'barracuda',     label = 'Barracuda',       rarity = 'uncommon',  chance = 12, basePrice = 350,   xp = 35,   weight = {500, 1500},   size = {50, 120} },
        { item = 'wahoo',         label = 'Wahoo',           rarity = 'uncommon',  chance = 10, basePrice = 400,   xp = 40,   weight = {600, 1800},   size = {50, 130} },
        { item = 'fish_pintado',  label = 'Pintado Mar',     rarity = 'rare',      chance = 8,  basePrice = 600,   xp = 60,   weight = {600, 1800},   size = {40, 90} },
        { item = 'fish_marfimazul',label = 'Marlim Azul',    rarity = 'rare',      chance = 6,  basePrice = 1500,  xp = 150,  weight = {1000, 5000},  size = {100, 300} },
        { item = 'tubarao_martelo',label = 'Tubarao Martelo', rarity = 'epic',     chance = 4,  basePrice = 2500,  xp = 250,  weight = {3000, 8000},  size = {150, 350} },
        { item = 'mero_gigante',  label = 'Mero Gigante',    rarity = 'epic',      chance = 3,  basePrice = 3000,  xp = 300,  weight = {5000, 15000}, size = {100, 250} },
        { item = 'peixe_lua',     label = 'Peixe Lua',       rarity = 'legendary', chance = 2,  basePrice = 8000,  xp = 800,  weight = {8000, 20000}, size = {100, 300} },
        { item = 'orca_fish',     label = 'Peixe Abissal',   rarity = 'mythic',    chance = 1,  basePrice = 15000, xp = 1500, weight = {100, 500},    size = {15, 40} },
    },

    -- ===== AGUAS TROPICAIS (Cayo Perico) =====
    tropical = {
        { item = 'peixe_palha',   label = 'Peixe Palhaco',   rarity = 'common',    chance = 18, basePrice = 80,    xp = 8,    weight = {50, 150},     size = {5, 15} },
        { item = 'cirurgiao',     label = 'Peixe Cirurgiao', rarity = 'common',    chance = 15, basePrice = 120,   xp = 12,   weight = {100, 300},    size = {10, 25} },
        { item = 'peixe_anjo',    label = 'Peixe Anjo',      rarity = 'uncommon',  chance = 12, basePrice = 250,   xp = 25,   weight = {80, 250},     size = {10, 25} },
        { item = 'barracuda',     label = 'Barracuda',       rarity = 'uncommon',  chance = 10, basePrice = 350,   xp = 35,   weight = {500, 1500},   size = {50, 120} },
        { item = 'peixe_leao',    label = 'Peixe Leao',      rarity = 'rare',      chance = 8,  basePrice = 800,   xp = 80,   weight = {200, 500},    size = {15, 35} },
        { item = 'tartaruga_mar', label = 'Tartaruga Marinha',rarity = 'rare',      chance = 5,  basePrice = 1000,  xp = 100,  weight = {2000, 5000},  size = {40, 80} },
        { item = 'tubarao_branco',label = 'Tubarao Branco',  rarity = 'epic',      chance = 3,  basePrice = 5000,  xp = 500,  weight = {5000, 20000}, size = {200, 500} },
        { item = 'agua_viva_rara',label = 'Agua Viva Rara',  rarity = 'epic',      chance = 3,  basePrice = 3000,  xp = 300,  weight = {50, 200},     size = {10, 40} },
        { item = 'perola_negra',  label = 'Ostra Perola Negra',rarity = 'legendary',chance = 2,  basePrice = 12000, xp = 1200, weight = {100, 300},    size = {5, 15} },
        { item = 'kraken_baby',   label = 'Lula Colossal',   rarity = 'mythic',    chance = 1,  basePrice = 25000, xp = 2500, weight = {500, 2000},   size = {50, 150} },
    },

    -- ===== PESCA ILEGAL (zona proibida, noite) =====
    illegal = {
        { item = 'peixe_mutante', label = 'Peixe Mutante',    rarity = 'uncommon',  chance = 20, basePrice = 300,   xp = 30,   weight = {100, 500},    size = {10, 30} },
        { item = 'enguia_eletrica',label = 'Enguia Eletrica', rarity = 'uncommon',  chance = 18, basePrice = 400,   xp = 40,   weight = {200, 800},    size = {30, 80} },
        { item = 'baiacu_toxico', label = 'Baiacu Toxico',    rarity = 'rare',      chance = 15, basePrice = 800,   xp = 80,   weight = {100, 400},    size = {10, 25} },
        { item = 'arraia_venenosa',label = 'Arraia Venenosa', rarity = 'rare',      chance = 12, basePrice = 1000,  xp = 100,  weight = {500, 2000},   size = {30, 80} },
        { item = 'peixe_radioativo',label = 'Peixe Radioativo',rarity = 'epic',     chance = 8,  basePrice = 3000,  xp = 300,  weight = {50, 200},     size = {5, 20} },
        { item = 'polvo_sombra',  label = 'Polvo das Sombras',rarity = 'epic',      chance = 6,  basePrice = 4000,  xp = 400,  weight = {300, 1000},   size = {20, 60} },
        { item = 'tubarao_fantasma',label = 'Tubarao Fantasma',rarity = 'legendary',chance = 3,  basePrice = 15000, xp = 1500, weight = {2000, 8000},  size = {100, 300} },
        { item = 'leviata',       label = 'Leviata',          rarity = 'mythic',    chance = 1,  basePrice = 50000, xp = 5000, weight = {10000, 50000},size = {200, 800} },
    },
}

-- ============================================================================
-- RARIDADE CONFIG
-- ============================================================================
Config.Rarity = {
    common    = { label = 'Comum',      color = '#8892a4', order = 1, icon = 'fas fa-fish' },
    uncommon  = { label = 'Incomum',    color = '#00FF88', order = 2, icon = 'fas fa-fish' },
    rare      = { label = 'Raro',       color = '#48c9b0', order = 3, icon = 'fas fa-star' },
    epic      = { label = 'Epico',      color = '#e94560', order = 4, icon = 'fas fa-crown' },
    legendary = { label = 'Lendario',   color = '#ffd700', order = 5, icon = 'fas fa-gem' },
    mythic    = { label = 'Mitico',     color = '#ff00ff', order = 6, icon = 'fas fa-dragon' },
}

-- ============================================================================
-- VARAS DE PESCA (5 tiers)
-- ============================================================================
Config.Rods = {
    fishingrod = {
        label = 'Vara de Bambu',
        durability = 15,
        minLevel = 1,
        rarityBonus = 0.0,
        tier = 1,
    },
    fishingrod_carbon = {
        label = 'Vara de Carbono',
        durability = 40,
        minLevel = 5,
        rarityBonus = 0.10,
        tier = 2,
    },
    fishingrod_pro = {
        label = 'Vara Profissional',
        durability = 80,
        minLevel = 10,
        rarityBonus = 0.20,
        tier = 3,
    },
    fishingrod_titanium = {
        label = 'Vara de Titanio',
        durability = 150,
        minLevel = 15,
        rarityBonus = 0.35,
        tier = 4,
    },
    fishingrod_legend = {
        label = 'Vara Lendaria',
        durability = 300,
        minLevel = 30,
        rarityBonus = 0.50,
        tier = 5,
    },
}

-- ============================================================================
-- ISCAS (4 tipos)
-- ============================================================================
Config.Baits = {
    fishbait = {
        label = 'Isca de Minhoca',
        rarityBonus = 0.0,
        restrictRarity = nil,
        tier = 1,
    },
    fishbait_pro = {
        label = 'Isca Artificial',
        rarityBonus = 0.15,
        restrictRarity = nil,
        tier = 2,
    },
    fishbait_viva = {
        label = 'Isca Viva',
        rarityBonus = 0.25,
        restrictRarity = nil,
        tier = 3,
    },
    fishbait_legend = {
        label = 'Isca Lendaria',
        rarityBonus = 0.40,
        restrictRarity = 'rare', -- so pega raro+
        tier = 4,
    },
}

-- ============================================================================
-- MINIGAME (skillCheck ox_lib)
-- ============================================================================
Config.Minigame = {
    baseDuration = 12000,
    minDuration = 8000,
    maxDuration = 20000,
    greenZoneSize = 0.25,
    fishPullSpeed = 0.003,
    reelSpeed = 0.006,
    progressPerTick = 0.008,
    regressPerTick = 0.004,
    failThreshold = 0.0,
}

-- Modificadores por raridade (multiplica dificuldade do skillCheck)
Config.MinigameDifficulty = {
    common    = { pullMult = 1.0, zoneMult = 1.0, inputs = 1 },
    uncommon  = { pullMult = 1.2, zoneMult = 0.9, inputs = 2 },
    rare      = { pullMult = 1.5, zoneMult = 0.75, inputs = 3 },
    epic      = { pullMult = 1.8, zoneMult = 0.6, inputs = 4 },
    legendary = { pullMult = 2.2, zoneMult = 0.5, inputs = 5 },
    mythic    = { pullMult = 2.8, zoneMult = 0.4, inputs = 6 },
}

-- ============================================================================
-- TEMPO E CLIMA
-- ============================================================================
Config.TimeModifiers = {
    morning   = { commonMod = 1.2,  rareMod = 0.9  }, -- 06-12
    afternoon = { commonMod = 1.0,  rareMod = 1.0  }, -- 12-18
    night     = { commonMod = 0.8,  rareMod = 1.3  }, -- 18-06
}

Config.WeatherModifiers = {
    rain      = { globalMod = 1.3 },
    thunder   = { blocked = true },
    default   = { globalMod = 1.0 },
}

-- ============================================================================
-- MERCADO DINAMICO
-- ============================================================================
Config.MarketUpdate = {
    interval = 30,            -- minutos entre atualizacoes
    minMultiplier = 0.5,
    maxMultiplier = 2.0,
    decayPerSale = 0.02,
    recoveryPerTick = 0.05,
}

-- ============================================================================
-- COOLDOWNS E LIMITES
-- ============================================================================
Config.Cooldowns = {
    castMin = 10,             -- segundos minimo entre pescas manuais
    sellRate = 5,             -- vendas por minuto max
    afkCooldown = 300,        -- segundos entre sessoes AFK
}

-- ============================================================================
-- PESCA AFK (VIP)
-- ============================================================================
Config.AFKFishing = {
    enabled = true,
    requireVIP = false,
    -- Tier "free" = jogador sem VIP
    -- maxTime = 0 = sem limite de tempo, para quando inventario encher
    free = { allowed = true, interval = 60, maxTime = 0, rarityMax = 'common' },
    vipTiers = {
        bronze   = { allowed = true, interval = 75, maxTime = 0, rarityMax = 'common' },
        pvp      = { allowed = true, interval = 75, maxTime = 0, rarityMax = 'common' },
        policia  = { allowed = true, interval = 75, maxTime = 0, rarityMax = 'common' },
        prata    = { allowed = true, interval = 60, maxTime = 0, rarityMax = 'uncommon' },
        ouro     = { allowed = true, interval = 45, maxTime = 0, rarityMax = 'uncommon' },
        platinum = { allowed = true, interval = 30, maxTime = 0, rarityMax = 'rare' },
        black    = { allowed = true, interval = 20, maxTime = 0, rarityMax = 'rare' },
    },
    xpPenalty = 0.5,
    pricePenalty = 0.7,
}

-- ============================================================================
-- REDES DE PESCA (plantaveis)
-- ============================================================================
Config.Nets = {
    fishingnet = {
        label = 'Rede de Pesca',
        minLevel = 10,
        collectTime = 30,       -- minutos para coletar
        maxFish = 3,            -- peixes max por coleta
        rarityMax = 'uncommon',
        durability = 5,         -- usos
        tier = 1,
    },
    fishingnet_pro = {
        label = 'Rede Premium',
        minLevel = 25,
        collectTime = 45,
        maxFish = 5,
        rarityMax = 'rare',
        durability = 10,
        tier = 2,
    },
    fishingnet_legend = {
        label = 'Rede Lendaria',
        minLevel = 40,
        collectTime = 60,
        maxFish = 8,
        rarityMax = 'epic',
        durability = 20,
        tier = 3,
    },
}

-- ============================================================================
-- VARA PLANTADA (pesca passiva)
-- ============================================================================
Config.PlantedRod = {
    enabled = true,
    maxPerPlayer = 1,
    maxBucket = 20,          -- peixes max no balde
    maxBucketVIP = 30,       -- peixes max no balde (VIP)
    fishInterval = 600,      -- segundos entre peixes (10 min)
    rarityMax = 'uncommon',  -- raridade maxima pesca passiva
    xpPerFish = 5,           -- XP reduzido
    propModel = 'prop_fishing_rod_01',
    maxIdleHours = 24,       -- auto-remove apos 24h
}

-- ============================================================================
-- LOJAS DE PESCA (NPC vendedor perto das zonas)
-- ============================================================================
Config.Shops = {
    paleto_shop = {
        label = 'Loja de Pesca - Paleto',
        coords = vector3(-901.69, 5730.33, 4.02),
        heading = 89.72,
        benchCoords = vector3(-904.50, 5727.50, 3.46),
        npcModel = 's_m_y_ammucity_01',
        blip = { sprite = 317, color = 2, scale = 0.8, label = 'Loja de Pesca' },
        items = {
            -- Varas
            { name = 'fishingrod',           price = 150,    minLevel = 1  },
            { name = 'fishingrod_carbon',    price = 1500,   minLevel = 5  },
            { name = 'fishingrod_pro',       price = 5000,   minLevel = 10 },
            { name = 'fishingrod_titanium',  price = 15000,  minLevel = 15 },
            { name = 'fishingrod_legend',    price = 50000,  minLevel = 30 },
            -- Iscas
            { name = 'fishbait',             price = 10,     minLevel = 1  },
            { name = 'fishbait_pro',         price = 50,     minLevel = 3  },
            { name = 'fishbait_viva',        price = 150,    minLevel = 8  },
            { name = 'fishbait_legend',      price = 500,    minLevel = 25 },
            -- Redes
            { name = 'fishingnet',           price = 3000,   minLevel = 10 },
            { name = 'fishingnet_pro',       price = 10000,  minLevel = 25 },
            { name = 'fishingnet_legend',    price = 30000,  minLevel = 40 },
            -- Materiais de Craft
            { name = 'rope',                 price = 50,     minLevel = 1  },
            { name = 'carbon_fiber',         price = 300,    minLevel = 5  },
            { name = 'metalscrap',           price = 200,    minLevel = 5  },
            { name = 'plastic',              price = 30,     minLevel = 1  },
        },
    },
    pier_shop = {
        label = 'Loja de Pesca - Pier',
        coords = vector3(-1831.11, -1199.27, 14.3),
        heading = 315.0,
        npcModel = 's_m_y_ammucity_01',
        blip = { sprite = 317, color = 2, scale = 0.8, label = 'Loja de Pesca' },
        items = {
            { name = 'fishingrod',           price = 150,    minLevel = 1  },
            { name = 'fishingrod_carbon',    price = 1500,   minLevel = 5  },
            { name = 'fishingrod_pro',       price = 5000,   minLevel = 10 },
            { name = 'fishingrod_titanium',  price = 15000,  minLevel = 15 },
            { name = 'fishingrod_legend',    price = 50000,  minLevel = 30 },
            { name = 'fishbait',             price = 10,     minLevel = 1  },
            { name = 'fishbait_pro',         price = 50,     minLevel = 3  },
            { name = 'fishbait_viva',        price = 150,    minLevel = 8  },
            { name = 'fishbait_legend',      price = 500,    minLevel = 25 },
            { name = 'fishingnet',           price = 3000,   minLevel = 10 },
            { name = 'fishingnet_pro',       price = 10000,  minLevel = 25 },
        },
    },
    altomar_shop = {
        label = 'Loja de Pesca - Porto',
        coords = vector3(591.48, -3877.35, 1.50),
        heading = 180.0,
        npcModel = 's_m_y_ammucity_01',
        blip = { sprite = 317, color = 2, scale = 0.8, label = 'Loja de Pesca' },
        items = {
            { name = 'fishingrod',           price = 150,    minLevel = 1  },
            { name = 'fishingrod_carbon',    price = 1500,   minLevel = 5  },
            { name = 'fishingrod_pro',       price = 5000,   minLevel = 10 },
            { name = 'fishingrod_titanium',  price = 15000,  minLevel = 15 },
            { name = 'fishingrod_legend',    price = 50000,  minLevel = 30 },
            { name = 'fishbait',             price = 10,     minLevel = 1  },
            { name = 'fishbait_pro',         price = 50,     minLevel = 3  },
            { name = 'fishbait_viva',        price = 150,    minLevel = 8  },
            { name = 'fishbait_legend',      price = 500,    minLevel = 25 },
            { name = 'fishingnet',           price = 3000,   minLevel = 10 },
            { name = 'fishingnet_pro',       price = 10000,  minLevel = 25 },
            { name = 'fishingnet_legend',    price = 30000,  minLevel = 40 },
        },
    },
}

-- ============================================================================
-- CONQUISTAS / ACHIEVEMENTS
-- ============================================================================
Config.Achievements = {
    first_catch      = { label = 'Primeiro Peixe',      description = 'Pegue seu primeiro peixe',              xpReward = 50,    moneyReward = 100 },
    catch_10         = { label = 'Pescador Iniciante',   description = 'Pegue 10 peixes',                       xpReward = 100,   moneyReward = 200 },
    catch_50         = { label = 'Pescador Dedicado',    description = 'Pegue 50 peixes',                       xpReward = 300,   moneyReward = 500 },
    catch_100        = { label = 'Pescador Experiente',  description = 'Pegue 100 peixes',                      xpReward = 500,   moneyReward = 1000 },
    catch_500        = { label = 'Mestre da Pesca',      description = 'Pegue 500 peixes',                      xpReward = 1500,  moneyReward = 5000 },
    catch_1000       = { label = 'Lenda da Pesca',       description = 'Pegue 1000 peixes',                     xpReward = 5000,  moneyReward = 15000 },
    first_rare       = { label = 'Sorte de Iniciante',   description = 'Pegue seu primeiro peixe raro',         xpReward = 200,   moneyReward = 500 },
    first_epic        = { label = 'Destino Epico',       description = 'Pegue seu primeiro peixe epico',        xpReward = 500,   moneyReward = 1500 },
    first_legendary  = { label = 'Toque de Midas',      description = 'Pegue seu primeiro peixe lendario',     xpReward = 1000,  moneyReward = 5000 },
    first_mythic     = { label = 'Escolhido dos Mares',  description = 'Pegue seu primeiro peixe mitico',       xpReward = 3000,  moneyReward = 15000 },
    big_fish         = { label = 'Peixe Grande',         description = 'Pegue um peixe com mais de 5kg',        xpReward = 200,   moneyReward = 300 },
    monster_fish     = { label = 'Monstro do Lago',      description = 'Pegue um peixe com mais de 10kg',       xpReward = 500,   moneyReward = 1000 },
    sell_10k         = { label = 'Comerciante',          description = 'Ganhe R$10.000 vendendo peixes',         xpReward = 300,   moneyReward = 0 },
    sell_100k        = { label = 'Magnata da Pesca',     description = 'Ganhe R$100.000 vendendo peixes',        xpReward = 1500,  moneyReward = 0 },
    level_10         = { label = 'Nivel 10',             description = 'Alcance nivel 10 de pesca',              xpReward = 0,     moneyReward = 2000 },
    level_25         = { label = 'Nivel 25',             description = 'Alcance nivel 25 de pesca',              xpReward = 0,     moneyReward = 5000 },
    level_50         = { label = 'Nivel 50 - Maximo!',   description = 'Alcance o nivel maximo de pesca',        xpReward = 0,     moneyReward = 25000 },
    all_zones        = { label = 'Explorador',           description = 'Pesque em todas as 5 zonas',             xpReward = 500,   moneyReward = 2000 },
    night_fisher     = { label = 'Pescador Noturno',     description = 'Pegue 20 peixes durante a noite',        xpReward = 300,   moneyReward = 500 },
}

-- ============================================================================
-- CRAFTING (receitas para criar itens)
-- ============================================================================
Config.Crafting = {
    fishingrod_carbon = {
        label = 'Vara de Carbono',
        minLevel = 5,
        time = 10, -- segundos
        ingredients = {
            { item = 'fishingrod', amount = 1 },
            { item = 'carbon_fiber', amount = 2 },
        },
    },
    fishingrod_pro = {
        label = 'Vara Profissional',
        minLevel = 10,
        time = 15,
        ingredients = {
            { item = 'fishingrod_carbon', amount = 1 },
            { item = 'carbon_fiber', amount = 3 },
            { item = 'metalscrap', amount = 2 },
        },
    },
    fishingrod_titanium = {
        label = 'Vara de Titanio',
        minLevel = 15,
        time = 20,
        ingredients = {
            { item = 'fishingrod_pro', amount = 1 },
            { item = 'titanium_bar', amount = 2 },
            { item = 'carbon_fiber', amount = 2 },
        },
    },
    fishbait_pro = {
        label = 'Isca Artificial',
        minLevel = 3,
        time = 5,
        ingredients = {
            { item = 'fishbait', amount = 3 },
            { item = 'plastic', amount = 1 },
        },
    },
    fishbait_viva = {
        label = 'Isca Viva',
        minLevel = 8,
        time = 8,
        ingredients = {
            { item = 'fishbait', amount = 5 },
            { item = 'worm', amount = 2 },
        },
    },
    fishingnet = {
        label = 'Rede de Pesca',
        minLevel = 10,
        time = 15,
        ingredients = {
            { item = 'rope', amount = 5 },
            { item = 'plastic', amount = 3 },
        },
    },
}

-- ============================================================================
-- BARCOS (aluguel para zonas de mar profundo)
-- ============================================================================
Config.Boats = {
    enabled = true,
    maxRentalMinutes = 60,
    returnRefundPercent = 0.3,
    vipDiscount = 0.3,
    rental = {
        coords = vector3(-1606.56, -1041.59, 13.02),
        npcModel = 's_m_y_dockwork_01',
        npcHeading = 130.0,
        blip = { sprite = 410, color = 3, scale = 0.7, label = 'Aluguel de Barcos' },
        spawnPoint = vector4(-1609.74, -1054.39, 0.0, 150.0),
        models = {
            { model = 'dinghy',   label = 'Canoa',          price = 500,   minLevel = 1  },
            { model = 'speeder',  label = 'Lancha',         price = 2000,  minLevel = 15 },
            { model = 'tug',      label = 'Barco de Pesca', price = 5000,  minLevel = 30 },
        },
    },
}

-- ============================================================================
-- DISCORD WEBHOOKS (logs)
-- ============================================================================
Config.Webhooks = {
    enabled = false,
    catches = '',     -- URL do webhook para peixes raros+
    sales = '',       -- URL do webhook para vendas grandes
    exploits = '',    -- URL do webhook para tentativas de exploit
    achievements = '', -- URL do webhook para conquistas
}

-- ============================================================================
-- ANTI-ABUSE
-- ============================================================================
Config.AntiAbuse = {
    maxFishPerHour = 60,           -- maximo de peixes por hora
    maxSellPerHour = 100000,       -- R$ maximo de venda por hora
    teleportCheck = true,          -- detectar teleporte
    speedCheck = true,             -- detectar speed hack durante pesca
    maxDistanceFromZone = 15.0,    -- tolerancia em metros
}

-- ============================================================================
-- DAILY CAPS
-- ============================================================================
Config.DailyCaps = {
    enabled = true,
    maxCatchPerDay = 200,          -- peixes por dia
    maxEarningsPerDay = 500000,    -- R$ por dia
    resetHour = 6,                 -- hora de reset (6:00 AM)
}

-- ============================================================================
-- ANIMACOES
-- ============================================================================
Config.Anims = {
    cast = { dict = 'amb@world_human_stand_fishing@idle_a', clip = 'idle_c' },
    idle = { dict = 'amb@world_human_stand_fishing@base', clip = 'base' },
    reel = { dict = 'amb@world_human_stand_fishing@idle_a', clip = 'idle_b' },
    pull = { dict = 'amb@world_human_stand_fishing@idle_a', clip = 'idle_a' },
    celebrate = { dict = 'anim@mp_player_intcelebrationmale@thumbs_up', clip = 'thumbs_up' },
    net_place = { dict = 'anim@heists@narcotics@funding@gang_idle', clip = '  gang_chatting_idle01' },
}

-- ============================================================================
-- SONS (PlaySoundFrontend)
-- ============================================================================
Config.Sounds = {
    cast = { name = 'PICK_UP', set = 'HUD_FRONTEND_DEFAULT_SOUNDSET' },
    bite = { name = 'CHALLENGE_UNLOCKED', set = 'HUD_AWARDS' },
    catch = { name = 'RANK_UP', set = 'HUD_AWARDS' },
    fail = { name = 'LOSE_1ST', set = 'HUD_MINI_GAME_SOUNDSET' },
    sell = { name = 'PURCHASE', set = 'HUD_LIQUOR_STORE_SOUNDSET' },
    achievement = { name = 'COLLECTED', set = 'HUD_AWARDS' },
    levelup = { name = 'RANK_UP', set = 'HUD_AWARDS' },
}
