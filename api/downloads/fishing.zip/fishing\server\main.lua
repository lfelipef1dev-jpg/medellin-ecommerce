-- ============================================================================
-- fishing: Server Main v2.0 - Handlers, validacao, rewards, anti-exploit
-- ============================================================================

-- Cooldown tracking
local playerCooldowns = {}  -- [source] = lastCatchTime
local playerSellCount = {}  -- [source] = { count, resetTime }
local playerAFKState = {}   -- [source] = { active, lastSession, zone }
local playerHourlyFish = {} -- [source] = { count, resetTime }

-- ============================================================================
-- HELPERS
-- ============================================================================

local function debugLog(...)
    if Config.Debug then
        -- print('^3[fishing:debug]^0', ...)
    end
end

local function getPlayer(source)
    return exports.qbx_core:GetPlayer(source)
end

local function getCitizenId(source)
    local Player = getPlayer(source)
    return Player and Player.PlayerData and Player.PlayerData.citizenid
end

local function getPlayerVIPTier(source)
    local Player = getPlayer(source)
    if not Player or not Player.PlayerData then return nil end
    local vip = Player.PlayerData.metadata and Player.PlayerData.metadata.vip
    if not vip or vip == false then return nil end
    return tostring(vip):lower()
end

local function getPlayerName(source)
    local Player = getPlayer(source)
    if not Player or not Player.PlayerData then return 'Desconhecido' end
    local charinfo = Player.PlayerData.charinfo
    if charinfo then
        return (charinfo.firstname or '') .. ' ' .. (charinfo.lastname or '')
    end
    return 'Desconhecido'
end

local function isInZone(source, zoneId)
    local Player = getPlayer(source)
    if not Player then return false end
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return false end
    local coords = GetEntityCoords(ped)
    local zone = Config.Zones[zoneId]
    if not zone then return false end
    return #(coords - zone.coords) <= zone.radius + (Config.AntiAbuse.maxDistanceFromZone or 15.0)
end

-- ============================================================================
-- ANTI-ABUSE: Rate limiting por hora
-- ============================================================================

local function checkHourlyRate(source)
    local now = os.time()
    if not playerHourlyFish[source] then
        playerHourlyFish[source] = { count = 0, resetTime = now }
    end
    if now - playerHourlyFish[source].resetTime >= 3600 then
        playerHourlyFish[source] = { count = 0, resetTime = now }
    end
    if playerHourlyFish[source].count >= Config.AntiAbuse.maxFishPerHour then
        SendWebhook('exploits', string.format('**RATE LIMIT** - Jogador %d atingiu %d peixes/hora', source, playerHourlyFish[source].count))
        return false
    end
    playerHourlyFish[source].count = playerHourlyFish[source].count + 1
    return true
end

-- ============================================================================
-- ZONA ILEGAL: Verificar horario noturno
-- ============================================================================

local function isNightTime()
    -- No servidor, usamos hora real ou hora do jogo via client
    -- Aqui confiamos no client enviando timeOfDay
    return true -- validacao real e feita no client
end

-- ============================================================================
-- DETERMINAR PEIXE (chance roll com modificadores)
-- ============================================================================

local function rollFish(zoneId, rod, bait, timeOfDay, weather)
    local zone = Config.Zones[zoneId]
    if not zone then return nil end

    local fishList = Config.Fish[zone.waterType]
    if not fishList then return nil end

    local rodConfig = Config.Rods[rod] or Config.Rods.fishingrod
    local baitConfig = Config.Baits[bait] or Config.Baits.fishbait

    local timeMod = Config.TimeModifiers[timeOfDay] or Config.TimeModifiers.afternoon
    local weatherMod = Config.WeatherModifiers[weather] or Config.WeatherModifiers.default

    if weatherMod.blocked then return nil end

    -- Build weighted pool
    local pool = {}
    local totalWeight = 0

    for _, fish in ipairs(fishList) do
        local chance = fish.chance
        local rarityOrder = (Config.Rarity[fish.rarity] or {}).order or 1

        -- Time modifier
        if rarityOrder >= 3 then
            chance = chance * (timeMod.rareMod or 1.0)
        else
            chance = chance * (timeMod.commonMod or 1.0)
        end

        -- Weather modifier
        chance = chance * (weatherMod.globalMod or 1.0)

        -- Rod rarity bonus (increases rare+ chances)
        if rarityOrder >= 3 then
            chance = chance * (1.0 + (rodConfig.rarityBonus or 0))
        end

        -- Bait rarity bonus
        if rarityOrder >= 3 then
            chance = chance * (1.0 + (baitConfig.rarityBonus or 0))
        end

        -- Bait restriction (legendary bait = only rare+)
        if baitConfig.restrictRarity then
            local minOrder = (Config.Rarity[baitConfig.restrictRarity] or {}).order or 1
            if rarityOrder < minOrder then
                chance = 0
            end
        end

        if chance > 0 then
            totalWeight = totalWeight + chance
            pool[#pool + 1] = { fish = fish, cumWeight = totalWeight }
        end
    end

    if #pool == 0 or totalWeight == 0 then return nil end

    local roll = math.random() * totalWeight
    for _, entry in ipairs(pool) do
        if roll <= entry.cumWeight then
            local fish = entry.fish
            local fishWeight = math.random(fish.weight[1], fish.weight[2])
            local fishSize = math.random(fish.size[1], fish.size[2])
            return {
                item = fish.item,
                label = fish.label,
                rarity = fish.rarity,
                basePrice = fish.basePrice,
                xp = fish.xp,
                weight = fishWeight,
                size = fishSize,
            }
        end
    end

    return nil
end

local function rollFishAFK(zoneId, rod, bait, timeOfDay, weather, maxRarity)
    local zone = Config.Zones[zoneId]
    if not zone then return nil end

    local fishList = Config.Fish[zone.waterType]
    if not fishList then return nil end

    local maxOrder = (Config.Rarity[maxRarity] or {}).order or 1

    local filtered = {}
    for _, fish in ipairs(fishList) do
        local order = (Config.Rarity[fish.rarity] or {}).order or 1
        if order <= maxOrder then
            filtered[#filtered + 1] = fish
        end
    end

    if #filtered == 0 then return nil end

    local totalWeight = 0
    local pool = {}
    for _, fish in ipairs(filtered) do
        totalWeight = totalWeight + fish.chance
        pool[#pool + 1] = { fish = fish, cumWeight = totalWeight }
    end

    local roll = math.random() * totalWeight
    for _, entry in ipairs(pool) do
        if roll <= entry.cumWeight then
            local fish = entry.fish
            local fishWeight = math.random(fish.weight[1], fish.weight[2])
            local fishSize = math.random(fish.size[1], fish.size[2])
            return {
                item = fish.item,
                label = fish.label,
                rarity = fish.rarity,
                basePrice = fish.basePrice,
                xp = math.floor(fish.xp * Config.AFKFishing.xpPenalty),
                weight = fishWeight,
                size = fishSize,
            }
        end
    end

    return nil
end

-- ============================================================================
-- CALLBACKS
-- ============================================================================

-- Validar equipamento (vara + isca)
lib.callback.register('fishing:server:validateEquipment', function(source)
    debugLog('validateEquipment chamado por jogador ' .. tostring(source))
    local rod, bait = nil, nil

    -- Encontrar a melhor vara que o jogador tem
    local bestRodTier = 0
    for rodItem, rodConfig in pairs(Config.Rods) do
        local count = exports.ox_inventory:GetItemCount(source, rodItem)
        if count and count > 0 then
            if (rodConfig.tier or 1) > bestRodTier then
                bestRodTier = rodConfig.tier or 1
                rod = rodItem
            end
        end
    end

    if not rod then
        return { valid = false, message = 'Voce precisa de uma vara de pesca' }
    end

    -- Encontrar a melhor isca
    local bestBaitTier = 0
    for baitItem, baitConfig in pairs(Config.Baits) do
        local count = exports.ox_inventory:GetItemCount(source, baitItem)
        if count and count > 0 then
            if (baitConfig.tier or 1) > bestBaitTier then
                bestBaitTier = baitConfig.tier or 1
                bait = baitItem
            end
        end
    end

    if not bait then
        return { valid = false, message = 'Voce precisa de isca para pescar' }
    end

    -- Check rod level requirement (protegido contra erro de DB)
    local rodConfig = Config.Rods[rod]
    local level = 1
    local lvlOk, lvlErr = pcall(function()
        level = GetPlayerLevel(source)
    end)
    if not lvlOk then
        -- print('^1[fishing]^0 ERRO GetPlayerLevel em validateEquipment: ' .. tostring(lvlErr))
        -- Se falhar, assume nivel 1 e deixa pescar
    end
    if level < (rodConfig.minLevel or 1) then
        return { valid = false, message = string.format('Nivel %d necessario para usar %s', rodConfig.minLevel, rodConfig.label) }
    end

    return { valid = true, rod = rod, bait = bait }
end)

-- Obter nivel do jogador
lib.callback.register('fishing:server:getPlayerLevel', function(source)
    local ok, level = pcall(GetPlayerLevel, source)
    if not ok then
        -- print('^1[fishing]^0 ERRO getPlayerLevel callback: ' .. tostring(level))
        return 1
    end
    return level or 1
end)

-- Determinar qual peixe vai morder
lib.callback.register('fishing:server:determineFish', function(source, zoneId, rod, bait, timeOfDay, weather)
    if not zoneId or not Config.Zones[zoneId] then
        debugLog(string.format('Jogador %d tentou pescar com zona invalida %s', source, tostring(zoneId)))
        return nil
    end

    -- Zona ilegal: verificar se e noite
    local zone = Config.Zones[zoneId]
    if zone and zone.nightOnly and timeOfDay ~= 'night' then
        return nil
    end

    local ok, fish = pcall(rollFish, zoneId, rod, bait, timeOfDay, weather)
    if not ok then
        -- print('^1[fishing]^0 ERRO rollFish: ' .. tostring(fish))
        return nil
    end
    return fish
end)

-- Pescar peixe (apos minigame bem sucedido)
lib.callback.register('fishing:server:catchFish', function(source, fishData, zoneId, rod, bait)
    debugLog(string.format('catchFish chamado: jogador=%d item=%s zona=%s', source, fishData and fishData.item or 'nil', tostring(zoneId)))
    if not fishData then return { success = false, message = 'Dados invalidos' } end

    -- Anti-exploit: cooldown
    local now = os.time()
    if playerCooldowns[source] and (now - playerCooldowns[source]) < Config.Cooldowns.castMin then
        return { success = false, message = 'Aguarde antes de pescar novamente' }
    end
    playerCooldowns[source] = now

    -- Anti-exploit: zona
    if not zoneId or not Config.Zones[zoneId] then
        return { success = false, message = 'Zona invalida' }
    end

    -- Anti-abuse: rate limit por hora
    if not checkHourlyRate(source) then
        return { success = false, message = 'Limite de peixes por hora atingido. Descanse um pouco!' }
    end

    -- Daily cap (protegido contra erros de DB)
    local canCatch = true
    local capOk, capErr = pcall(function()
        local can, _ = CheckDailyCap(source, 'catch')
        canCatch = can
    end)
    if not capOk then
        -- print('^1[fishing]^0 ERRO CheckDailyCap: ' .. tostring(capErr))
    end
    if not canCatch then
        return { success = false, message = 'Limite diario de pesca atingido! Volte amanha.' }
    end

    -- Consumir isca
    local baitRemoved = exports.ox_inventory:RemoveItem(source, bait, 1)
    if not baitRemoved then
        return { success = false, message = 'Sem isca disponivel' }
    end

    -- Adicionar ao inventario (sem metadata para permitir agrupamento/stack)
    local added = exports.ox_inventory:AddItem(source, fishData.item, 1)
    if not added then
        -- Devolver isca se nao conseguiu adicionar peixe
        exports.ox_inventory:AddItem(source, bait, 1)
        return { success = false, message = 'Inventario cheio ou item nao registrado (' .. tostring(fishData.item) .. ')' }
    end

    -- XP (protegido)
    local levelUp, newLevel = false, nil
    local xpOk, xpErr = pcall(function()
        levelUp, newLevel = AddPlayerXP(source, fishData.xp)
    end)
    if not xpOk then
        -- print('^1[fishing]^0 ERRO AddPlayerXP: ' .. tostring(xpErr))
    end

    -- Calcular valor estimado
    local marketMult = GetMarketMultiplier(fishData.item)
    local avgWeight = 500
    local zone = Config.Zones[zoneId]
    if zone then
        for _, f in ipairs(Config.Fish[zone.waterType] or {}) do
            if f.item == fishData.item then
                avgWeight = (f.weight[1] + f.weight[2]) / 2
                break
            end
        end
    end
    local value = math.floor(fishData.basePrice * marketMult * (fishData.weight / avgWeight))

    -- Zona ilegal: dirty money
    local isDirty = zone and zone.dirtyMoney

    -- Wanted chance na zona ilegal
    local wantedLevel = 0
    if zone and zone.wantedChance and math.random() < zone.wantedChance then
        wantedLevel = math.random(1, 2)
    end

    -- Stats, leaderboard, conquistas (protegidos - nao impede a pesca)
    pcall(function()
        UpdatePlayerStats(source, fishData)
        IncrementDailyCatch(source)
        TrackZoneVisit(source, zoneId)
        LogFishCatch(source, fishData, zoneId, 'manual')
        SaveToLeaderboard(source, fishData, zoneId)
        CheckStatAchievements(source, fishData)
    end)

    -- Log de raros
    local rarityOrder = (Config.Rarity[fishData.rarity] or {}).order or 1
    if rarityOrder >= 3 then
        local msg = string.format('%s pescou **%s** (%s) - %dg %dcm na zona %s',
            getPlayerName(source), fishData.label,
            (Config.Rarity[fishData.rarity] or {}).label or '?',
            fishData.weight, fishData.size, zoneId)
        -- print('^2[fishing]^0 ' .. msg)
        pcall(SendWebhook, 'catches', msg)
    end

    return {
        success = true,
        item = fishData.item,
        label = fishData.label,
        rarity = fishData.rarity,
        weight = fishData.weight,
        size = fishData.size,
        xp = fishData.xp,
        value = value,
        levelUp = levelUp,
        newLevel = newLevel,
        isDirty = isDirty,
        wantedLevel = wantedLevel,
    }
end)

-- ============================================================================
-- LOJA DE PESCA
-- ============================================================================

lib.callback.register('fishing:server:buyShopItem', function(source, shopId, itemName, amount)
    if not shopId or not itemName or not amount or amount < 1 then
        return { success = false, message = 'Dados invalidos' }
    end

    local shop = Config.Shops[shopId]
    if not shop then
        return { success = false, message = 'Loja nao encontrada' }
    end

    local shopItem = nil
    for _, item in ipairs(shop.items) do
        if item.name == itemName then
            shopItem = item
            break
        end
    end

    if not shopItem then
        return { success = false, message = 'Item nao disponivel nesta loja' }
    end

    local level = GetPlayerLevel(source)
    if level < (shopItem.minLevel or 1) then
        return { success = false, message = string.format('Nivel %d necessario', shopItem.minLevel) }
    end

    local totalCost = shopItem.price * amount

    local Player = getPlayer(source)
    if not Player then
        return { success = false, message = 'Erro interno' }
    end

    local cash = Player.Functions.GetMoney('cash')
    if cash < totalCost then
        return { success = false, message = string.format('Dinheiro insuficiente (precisa R$%d)', totalCost) }
    end

    local canCarry = exports.ox_inventory:CanCarryItem(source, itemName, amount)
    if not canCarry then
        return { success = false, message = 'Inventario cheio' }
    end

    Player.Functions.RemoveMoney('cash', totalCost, 'fishing-shop')
    exports.ox_inventory:AddItem(source, itemName, amount)

    debugLog(string.format('Jogador %d comprou %dx %s por R$%d na loja %s', source, amount, itemName, totalCost, shopId))

    return { success = true, total = totalCost }
end)

-- Consumir isca (em caso de falha no minigame)
lib.callback.register('fishing:server:consumeBait', function(source, bait)
    if bait then
        exports.ox_inventory:RemoveItem(source, bait, 1)
    end
end)

-- ============================================================================
-- PESCA AFK (VIP)
-- ============================================================================

lib.callback.register('fishing:server:startAFK', function(source, zoneId)
    -- Client ja verificou posicao. Server so valida se a zona existe.
    if not zoneId or not Config.Zones[zoneId] then
        return { allowed = false, message = 'Zona invalida' }
    end

    -- Zona ilegal nao permite AFK
    local zone = Config.Zones[zoneId]
    if zone and zone.nightOnly then
        return { allowed = false, message = 'Pesca AFK nao permitida nesta zona' }
    end

    local tier = getPlayerVIPTier(source)
    local tierConfig = nil
    local tierLabel = 'free'

    if tier then
        tierConfig = Config.AFKFishing.vipTiers[tier]
        tierLabel = tier
    end

    if not tierConfig or not tierConfig.allowed then
        tierConfig = Config.AFKFishing.free
        tierLabel = 'free'
    end

    if not tierConfig or not tierConfig.allowed then
        return { allowed = false, message = 'Pesca AFK desativada' }
    end

    local now = os.time()
    if playerAFKState[source] and playerAFKState[source].lastSession then
        local elapsed = now - playerAFKState[source].lastSession
        if elapsed < Config.Cooldowns.afkCooldown then
            local remaining = Config.Cooldowns.afkCooldown - elapsed
            return { allowed = false, message = string.format('Aguarde %d segundos para pescar AFK novamente', remaining) }
        end
    end

    -- Validar equipamento inline
    local rod, bait = nil, nil
    local bestRodTier = 0

    for rodItem, rodConfig in pairs(Config.Rods) do
        local count = exports.ox_inventory:GetItemCount(source, rodItem)
        if count and count > 0 then
            if (rodConfig.tier or 1) > bestRodTier then
                bestRodTier = rodConfig.tier or 1
                rod = rodItem
            end
        end
    end

    if not rod then
        return { allowed = false, message = 'Voce precisa de uma vara de pesca' }
    end

    local bestBaitTier = 0
    for baitItem, baitConfig in pairs(Config.Baits) do
        local count = exports.ox_inventory:GetItemCount(source, baitItem)
        if count and count > 0 then
            if (baitConfig.tier or 1) > bestBaitTier then
                bestBaitTier = baitConfig.tier or 1
                bait = baitItem
            end
        end
    end

    if not bait then
        return { allowed = false, message = 'Voce precisa de isca para pescar' }
    end

    local rodConfig = Config.Rods[rod]
    local level = GetPlayerLevel(source)
    if level < (rodConfig.minLevel or 1) then
        return { allowed = false, message = string.format('Nivel %d necessario para usar %s', rodConfig.minLevel, rodConfig.label) }
    end

    playerAFKState[source] = {
        active = true,
        lastSession = now,
        zone = zoneId,
        tier = tierLabel,
    }

    TrackZoneVisit(source, zoneId)
    debugLog(string.format('Jogador %d iniciou pesca AFK (tier: %s) na zona %s', source, tierLabel, zoneId))

    return {
        allowed = true,
        rod = rod,
        bait = bait,
        interval = tierConfig.interval,
        maxTime = tierConfig.maxTime,
        maxRarity = tierConfig.rarityMax,
    }
end)

lib.callback.register('fishing:server:afkCatch', function(source, zoneId, rod, bait, timeOfDay, weather)
    local state = playerAFKState[source]
    if not state or not state.active then
        return { success = false, message = 'Sessao AFK encerrada' }
    end

    if not zoneId or not Config.Zones[zoneId] then
        playerAFKState[source].active = false
        return { success = false, message = 'Zona invalida' }
    end

    -- Anti-abuse
    if not checkHourlyRate(source) then
        playerAFKState[source].active = false
        return { success = false, message = 'Limite de peixes por hora atingido' }
    end

    -- Daily cap
    local canCatch = CheckDailyCap(source, 'catch')
    if not canCatch then
        playerAFKState[source].active = false
        return { success = false, message = 'Limite diario atingido' }
    end

    -- Verificar isca
    local baitCount = exports.ox_inventory:GetItemCount(source, bait)
    if not baitCount or baitCount < 1 then
        playerAFKState[source].active = false
        return { success = false, message = 'Suas iscas acabaram' }
    end

    exports.ox_inventory:RemoveItem(source, bait, 1)

    local tierConfig
    if state.tier == 'free' then
        tierConfig = Config.AFKFishing.free
    else
        tierConfig = Config.AFKFishing.vipTiers[state.tier]
    end
    local maxRarity = tierConfig and tierConfig.rarityMax or 'common'

    local fish = rollFishAFK(zoneId, rod, bait, timeOfDay, weather, maxRarity)
    if not fish then
        return { success = true, label = 'Nada', weight = 0, value = 0 }
    end

    local added = exports.ox_inventory:AddItem(source, fish.item, 1)
    if not added then
        playerAFKState[source].active = false
        return { success = false, message = 'Inventario cheio' }
    end

    -- Stats protegidos (nao impede o catch)
    pcall(function()
        AddPlayerXP(source, fish.xp)
        UpdatePlayerStats(source, fish)
        SaveToLeaderboard(source, fish, zoneId)
        IncrementDailyCatch(source)
        LogFishCatch(source, fish, zoneId, 'afk')
        CheckStatAchievements(source, fish)
    end)

    local marketMult = GetMarketMultiplier(fish.item)
    local value = math.floor(fish.basePrice * marketMult * Config.AFKFishing.pricePenalty)

    debugLog(string.format('AFK Catch: %d pescou %s (%dg) na zona %s', source, fish.label, fish.weight, zoneId))

    return {
        success = true,
        item = fish.item,
        label = fish.label,
        rarity = fish.rarity,
        weight = fish.weight,
        size = fish.size,
        value = value,
    }
end)

RegisterNetEvent('fishing:server:stopAFK', function()
    local source = source
    if playerAFKState[source] then
        playerAFKState[source].active = false
        playerAFKState[source].lastSession = os.time()
        debugLog(string.format('Jogador %d parou pesca AFK', source))
    end
end)

-- Evento fire-and-forget: client pede catch AFK, server responde via TriggerClientEvent
RegisterNetEvent('fishing:server:afkCatchRequest', function(zoneId, rod, bait, timeOfDay, weather)
    local src = source

    local state = playerAFKState[src]
    if not state or not state.active then
        -- print(('[fishing] AFK PAROU src=%d motivo=sessao_inativa'):format(src))
        TriggerClientEvent('fishing:client:afkCatchResult', src, { success = false, message = 'Sessao AFK encerrada' })
        return
    end

    if not zoneId or not Config.Zones[zoneId] then
        -- print(('[fishing] AFK PAROU src=%d motivo=zona_invalida zona=%s'):format(src, tostring(zoneId)))
        playerAFKState[src].active = false
        TriggerClientEvent('fishing:client:afkCatchResult', src, { success = false, message = 'Zona invalida' })
        return
    end

    -- Rate limit por hora (nao para AFK, so pula este peixe)
    if not checkHourlyRate(src) then
        -- print(('[fishing] AFK AVISO src=%d motivo=rate_limit_hora (NAO para, pula peixe)'):format(src))
        TriggerClientEvent('fishing:client:afkCatchResult', src, { success = true, label = 'Limite/hora', weight = 0, value = 0 })
        return
    end

    -- Cap diario (usa pcall pra nao travar se MySQL demorar)
    local capOk, capResult = pcall(CheckDailyCap, src, 'catch')
    if capOk and not capResult then
        -- print(('[fishing] AFK PAROU src=%d motivo=limite_diario'):format(src))
        playerAFKState[src].active = false
        TriggerClientEvent('fishing:client:afkCatchResult', src, { success = false, message = 'Limite diario atingido' })
        return
    end

    -- Verificar isca
    local baitOk, baitCount = pcall(function()
        return exports.ox_inventory:GetItemCount(src, bait)
    end)
    if not baitOk or not baitCount or baitCount < 1 then
        -- print(('[fishing] AFK PAROU src=%d motivo=isca_acabou bait=%s count=%s'):format(src, tostring(bait), tostring(baitCount)))
        playerAFKState[src].active = false
        TriggerClientEvent('fishing:client:afkCatchResult', src, { success = false, message = 'Iscas acabaram' })
        return
    end

    -- Consumir isca
    pcall(function() exports.ox_inventory:RemoveItem(src, bait, 1) end)

    local tierConfig
    if state.tier == 'free' then
        tierConfig = Config.AFKFishing.free
    else
        tierConfig = Config.AFKFishing.vipTiers[state.tier]
    end
    local maxRarity = tierConfig and tierConfig.rarityMax or 'common'

    local fishOk, fish = pcall(rollFishAFK, zoneId, rod, bait, timeOfDay, weather, maxRarity)
    if not fishOk or not fish then
        TriggerClientEvent('fishing:client:afkCatchResult', src, { success = true, label = 'Nada', weight = 0, value = 0 })
        return
    end

    -- Tentar adicionar o peixe ao inventario
    local addOk, added = pcall(function()
        return exports.ox_inventory:AddItem(src, fish.item, 1)
    end)

    -- Log detalhado para debug
    local canCarryOk, canCarry = pcall(function()
        return exports.ox_inventory:CanCarryItem(src, fish.item, 1)
    end)
    local slotsOk, slotsCount = pcall(function()
        return exports.ox_inventory:GetSlots(src)
    end)

    -- print(('[fishing] AFK AddItem: src=%d item=%s addOk=%s added=%s canCarry=%s'):format(
    --     src, tostring(fish.item), tostring(addOk), tostring(added), tostring(canCarryOk and canCarry)))

    if not addOk or not added then
        -- Verificar se o item existe (talvez o item nao esta registrado no ox_inventory)
        if not canCarryOk or canCarry == nil then
            -- Item provavelmente nao existe no ox_inventory — pular, nao parar
            -- print(('[fishing] AFK AVISO: item %s pode nao existir no ox_inventory — pulando'):format(tostring(fish.item)))
            TriggerClientEvent('fishing:client:afkCatchResult', src, { success = true, label = 'Nada', weight = 0, value = 0 })
            return
        elseif canCarry == false then
            -- Inventario realmente cheio
            -- print(('[fishing] AFK PAROU src=%d motivo=inventario_cheio item=%s'):format(src, tostring(fish.item)))
            playerAFKState[src].active = false
            TriggerClientEvent('fishing:client:afkCatchResult', src, { success = false, message = 'Inventario cheio' })
            return
        else
            -- AddItem falhou mas CanCarry diz que pode — tentar de novo
            -- print(('[fishing] AFK AVISO: AddItem falhou mas CanCarry=true, tentando novamente...'):format())
            Wait(500)
            local retryOk, retryAdded = pcall(function()
                return exports.ox_inventory:AddItem(src, fish.item, 1)
            end)
            if not retryOk or not retryAdded then
                -- print(('[fishing] AFK AVISO: retry falhou tambem — pulando peixe'):format())
                TriggerClientEvent('fishing:client:afkCatchResult', src, { success = true, label = 'Nada', weight = 0, value = 0 })
                return
            end
            added = retryAdded
        end
    end

    pcall(function()
        AddPlayerXP(src, fish.xp)
        UpdatePlayerStats(src, fish)
        SaveToLeaderboard(src, fish, zoneId)
        IncrementDailyCatch(src)
        LogFishCatch(src, fish, zoneId, 'afk')
        CheckStatAchievements(src, fish)
    end)

    local marketMult = GetMarketMultiplier(fish.item)
    local value = math.floor(fish.basePrice * marketMult * Config.AFKFishing.pricePenalty)

    TriggerClientEvent('fishing:client:afkCatchResult', src, {
        success = true,
        item = fish.item,
        label = fish.label,
        rarity = fish.rarity,
        weight = fish.weight,
        size = fish.size,
        value = value,
    })
end)

-- Evento fire-and-forget: consumir isca
RegisterNetEvent('fishing:server:consumeBaitEvent', function(bait)
    local source = source
    if bait then
        exports.ox_inventory:RemoveItem(source, bait, 1)
    end
end)

-- ============================================================================
-- STATS
-- ============================================================================

function UpdatePlayerStats(source, fishData)
    local citizenid = getCitizenId(source)
    if not citizenid then return end

    MySQL.update([[
        INSERT INTO fishing_stats (citizenid, total_caught, biggest_weight, biggest_fish)
        VALUES (?, 1, ?, ?)
        ON DUPLICATE KEY UPDATE
            total_caught = total_caught + 1,
            biggest_weight = GREATEST(biggest_weight, VALUES(biggest_weight)),
            biggest_fish = IF(VALUES(biggest_weight) > biggest_weight, VALUES(biggest_fish), biggest_fish)
    ]], { citizenid, fishData.weight, fishData.item })
end

function SaveToLeaderboard(source, fishData, zoneId)
    local citizenid = getCitizenId(source)
    if not citizenid then return end

    local name = getPlayerName(source)

    MySQL.query([[
        SELECT MIN(weight) as min_weight, COUNT(*) as cnt
        FROM fishing_leaderboard
        WHERE fish_item = ?
    ]], { fishData.item }, function(result)
        if not result or not result[1] then return end

        local minWeight = result[1].min_weight or 0
        local count = result[1].cnt or 0

        if count < 10 or fishData.weight > minWeight then
            MySQL.insert([[
                INSERT INTO fishing_leaderboard (citizenid, player_name, fish_item, fish_label, weight, size, rarity, zone_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ]], { citizenid, name, fishData.item, fishData.label, fishData.weight, fishData.size, fishData.rarity, zoneId })

            if count >= 10 then
                MySQL.query([[
                    DELETE FROM fishing_leaderboard
                    WHERE fish_item = ? AND id NOT IN (
                        SELECT id FROM (
                            SELECT id FROM fishing_leaderboard
                            WHERE fish_item = ?
                            ORDER BY weight DESC
                            LIMIT 10
                        ) as top
                    )
                ]], { fishData.item, fishData.item })
            end
        end
    end)
end

-- ============================================================================
-- LEADERBOARD CALLBACK
-- ============================================================================

lib.callback.register('fishing:server:getLeaderboard', function(source)
    local result = MySQL.query.await([[
        SELECT player_name, fish_item, fish_label, weight, size, rarity, zone_id
        FROM fishing_leaderboard
        ORDER BY weight DESC
        LIMIT 10
    ]])
    return result or {}
end)

-- Leaderboard completo para NUI (4 categorias)
lib.callback.register('fishing:server:getLeaderboardFull', function(source)
    local citizenid = getCitizenId(source)

    -- Mais peixes
    local mostFish = MySQL.query.await([[
        SELECT citizenid, level, total_caught FROM fishing_stats
        ORDER BY total_caught DESC LIMIT 20
    ]]) or {}

    -- Mais pesado (leaderboard)
    local heaviest = MySQL.query.await([[
        SELECT player_name, fish_label, weight, rarity FROM fishing_leaderboard
        ORDER BY weight DESC LIMIT 20
    ]]) or {}

    -- Mais dinheiro
    local mostMoney = MySQL.query.await([[
        SELECT citizenid, money_earned FROM fishing_stats
        ORDER BY money_earned DESC LIMIT 20
    ]]) or {}

    -- Maior nivel
    local highestLevel = MySQL.query.await([[
        SELECT citizenid, level, xp FROM fishing_stats
        ORDER BY level DESC, xp DESC LIMIT 20
    ]]) or {}

    -- Formatar resultados
    local function formatMostFish(rows)
        local result = {}
        for _, r in ipairs(rows) do
            result[#result + 1] = {
                name = r.citizenid,
                detail = 'Nivel ' .. (r.level or 1),
                value = tostring(r.total_caught or 0) .. ' peixes',
            }
        end
        return result
    end

    local function formatHeaviest(rows)
        local result = {}
        for _, r in ipairs(rows) do
            local w = r.weight or 0
            local wStr = w >= 1000 and string.format('%.1fkg', w / 1000) or (w .. 'g')
            result[#result + 1] = {
                name = r.player_name or 'Jogador',
                detail = r.fish_label or '',
                value = wStr,
            }
        end
        return result
    end

    local function formatMostMoney(rows)
        local result = {}
        for _, r in ipairs(rows) do
            local m = r.money_earned or 0
            local mStr = m >= 1000000 and string.format('R$%.1fM', m / 1000000) or
                         m >= 1000 and string.format('R$%.1fK', m / 1000) or ('R$' .. m)
            result[#result + 1] = {
                name = r.citizenid,
                detail = '',
                value = mStr,
            }
        end
        return result
    end

    local function formatHighestLevel(rows)
        local result = {}
        for _, r in ipairs(rows) do
            result[#result + 1] = {
                name = r.citizenid,
                detail = (r.xp or 0) .. ' XP',
                value = 'Nivel ' .. (r.level or 1),
            }
        end
        return result
    end

    -- Posicao do jogador
    local playerPos = nil
    if citizenid then
        local myStats = MySQL.query.await(
            'SELECT total_caught, money_earned, level FROM fishing_stats WHERE citizenid = ?',
            { citizenid }
        )
        if myStats and myStats[1] then
            local rank = MySQL.scalar.await(
                'SELECT COUNT(*) + 1 FROM fishing_stats WHERE total_caught > (SELECT total_caught FROM fishing_stats WHERE citizenid = ?)',
                { citizenid }
            )
            playerPos = {
                rank = rank or '?',
                detail = 'Nivel ' .. (myStats[1].level or 1),
                value = (myStats[1].total_caught or 0) .. ' peixes',
            }
        end
    end

    return {
        mostFish = formatMostFish(mostFish),
        heaviest = formatHeaviest(heaviest),
        mostMoney = formatMostMoney(mostMoney),
        highestLevel = formatHighestLevel(highestLevel),
        playerPosition = playerPos,
    }
end)

-- XP data callback para NUI
lib.callback.register('fishing:server:getPlayerXPData', function(source)
    return GetPlayerXPData(source)
end)

-- ============================================================================
-- MERCADO NEGRO (venda de peixes ilegais por dirty money)
-- ============================================================================

lib.callback.register('fishing:server:sellFishBlackMarket', function(source, fishItem, amount)
    if not fishItem or not amount or amount < 1 then
        return { success = false, message = 'Dados invalidos' }
    end

    -- Verificar se e um peixe ilegal
    local fishConfig = nil
    local illegalFish = Config.Fish.illegal or {}
    for _, fish in ipairs(illegalFish) do
        if fish.item == fishItem then
            fishConfig = fish
            break
        end
    end

    -- Tambem aceita peixes normais, mas com bonus menor
    if not fishConfig then
        for _, fishList in pairs(Config.Fish) do
            for _, fish in ipairs(fishList) do
                if fish.item == fishItem then
                    fishConfig = fish
                    break
                end
            end
            if fishConfig then break end
        end
    end

    if not fishConfig then
        return { success = false, message = 'Este item nao pode ser vendido aqui' }
    end

    local playerItems = exports.ox_inventory:GetInventoryItems(source)
    if not playerItems then
        return { success = false, message = 'Erro ao acessar inventario' }
    end

    local fishSlots = {}
    local totalAvailable = 0
    for _, item in pairs(playerItems) do
        if item and item.name == fishItem then
            totalAvailable = totalAvailable + item.count
            fishSlots[#fishSlots + 1] = {
                slot = item.slot,
                count = item.count,
                weight = (item.metadata and item.metadata.weight) or 0,
            }
        end
    end

    if totalAvailable < amount then
        return { success = false, message = string.format('Voce so tem %d', totalAvailable) }
    end

    local mult = Config.BlackMarket.priceMultiplier or 1.5
    local avgWeight = (fishConfig.weight[1] + fishConfig.weight[2]) / 2
    local totalPrice = 0
    local remaining = amount

    for _, slot in ipairs(fishSlots) do
        if remaining <= 0 then break end
        local toRemove = math.min(remaining, slot.count)
        local weightMult = slot.weight > 0 and (slot.weight / avgWeight) or 1.0
        local unitPrice = math.floor(fishConfig.basePrice * mult * weightMult)
        totalPrice = totalPrice + (unitPrice * toRemove)
        exports.ox_inventory:RemoveItem(source, fishItem, toRemove, nil, slot.slot)
        remaining = remaining - toRemove
    end

    local Player = getPlayer(source)
    if not Player then
        return { success = false, message = 'Erro interno' }
    end

    -- Pagar em dirty money (black_money ou cash dependendo do setup)
    local moneyType = 'cash' -- mudar para 'black_money' se tiver implementado
    Player.Functions.AddMoney(moneyType, totalPrice, 'fishing-black-market')

    local citizenid = getCitizenId(source)
    if citizenid then
        MySQL.update([[
            UPDATE fishing_stats
            SET total_sold = total_sold + ?, money_earned = money_earned + ?
            WHERE citizenid = ?
        ]], { amount, totalPrice, citizenid })
        IncrementDailyEarnings(source, totalPrice)
    end

    SendWebhook('sales', string.format('**MERCADO NEGRO** - %s vendeu %dx %s por R$%d', getPlayerName(source), amount, fishConfig.label, totalPrice))

    return { success = true, total = totalPrice }
end)

-- ============================================================================
-- CLIENT EVENTS
-- ============================================================================

RegisterNetEvent('fishing:client:playSound', function() end) -- handled client-side

-- ============================================================================
-- CLEANUP
-- ============================================================================

AddEventHandler('playerDropped', function()
    local source = source
    playerCooldowns[source] = nil
    playerSellCount[source] = nil
    playerAFKState[source] = nil
    playerHourlyFish[source] = nil
end)

-- ============================================================================
-- INIT
-- ============================================================================

CreateThread(function()
    Wait(1000)
    local totalFish = 0
    for _, fishList in pairs(Config.Fish) do
        totalFish = totalFish + #fishList
    end
    local totalZones = 0
    for _ in pairs(Config.Zones) do totalZones = totalZones + 1 end
    local rodCount = 0
    for _ in pairs(Config.Rods) do rodCount = rodCount + 1 end
    local baitCount = 0
    for _ in pairs(Config.Baits) do baitCount = baitCount + 1 end
    local achieveCount = 0
    for _ in pairs(Config.Achievements) do achieveCount = achieveCount + 1 end
    local netCount = 0
    for _ in pairs(Config.Nets) do netCount = netCount + 1 end
    local craftCount = 0
    for _ in pairs(Config.Crafting) do craftCount = craftCount + 1 end

    -- print(string.format('^2[fishing]^0 Sistema v2.0 carregado! %d peixes, %d zonas, %d varas, %d iscas',
        totalFish, totalZones, rodCount, baitCount))
    -- print(string.format('^2[fishing]^0 %d redes, %d receitas, %d conquistas, nivel max %d',
        netCount, craftCount, achieveCount, Config.MaxLevel))
end)
