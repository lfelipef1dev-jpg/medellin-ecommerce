// ============================================================================
// medellin-fishing: Catch Screen NUI - Tela de captura
// ============================================================================

(function () {
    'use strict';

    const container = document.getElementById('catch-container');
    const catchName = document.getElementById('catch-name');
    const catchRarity = document.getElementById('catch-rarity');
    const catchWeight = document.getElementById('catch-weight');
    const catchSize = document.getElementById('catch-size');
    const catchXP = document.getElementById('catch-xp');
    const catchValue = document.getElementById('catch-value');
    const catchLevelUp = document.getElementById('catch-levelup');
    const catchNewLevel = document.getElementById('catch-newlevel');

    window.addEventListener('message', function (event) {
        const data = event.data;

        if (data.action === 'showCatch') {
            showCatch(data);
        } else if (data.action === 'closeCatch') {
            closeCatch();
        }
    });

    function showCatch(data) {
        catchName.textContent = data.fishLabel || 'Peixe';

        catchRarity.textContent = data.rarityLabel || 'Comum';
        catchRarity.style.backgroundColor = (data.rarityColor || '#AAAAAA') + '33';
        catchRarity.style.color = data.rarityColor || '#AAAAAA';

        catchWeight.textContent = (data.weight || 0) + 'g';
        catchSize.textContent = (data.size || 0) + 'cm';
        catchXP.textContent = '+' + (data.xp || 0);
        catchValue.textContent = 'R$' + (data.value || 0);

        if (data.levelUp && data.newLevel) {
            catchLevelUp.classList.remove('hidden');
            catchNewLevel.textContent = 'Nivel ' + data.newLevel;
        } else {
            catchLevelUp.classList.add('hidden');
        }

        container.classList.remove('hidden');
    }

    function closeCatch() {
        container.classList.add('hidden');

        // Notify Lua
        fetch('https://' + GetParentResourceName() + '/closeCatch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        }).catch(function () {});
    }

    // Click to dismiss
    container.addEventListener('click', function () {
        closeCatch();
    });
})();
