// ============================================================================
// medellin-fishing: NUI App - Catch Screen, Leaderboard, Stats
// ============================================================================

(function () {
    'use strict';

    // ========================================================================
    // RARITY CONFIG
    // ========================================================================
    const RARITY = {
        common:    { label: 'Comum',    color: '#8892a4' },
        uncommon:  { label: 'Incomum',  color: '#00FF88' },
        rare:      { label: 'Raro',     color: '#48c9b0' },
        epic:      { label: 'Epico',    color: '#e94560' },
        legendary: { label: 'Lendario', color: '#ffd700' },
        mythic:    { label: 'Mitico',   color: '#ff00ff' },
    };

    // ========================================================================
    // HELPER
    // ========================================================================
    function getResourceName() {
        if (window.GetParentResourceName) return window.GetParentResourceName();
        return 'medellin-fishing';
    }

    function post(event, data) {
        fetch('https://' + getResourceName() + '/' + event, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data || {})
        }).catch(function () {});
    }

    function formatWeight(grams) {
        if (grams >= 1000) return (grams / 1000).toFixed(1) + 'kg';
        return grams + 'g';
    }

    // ========================================================================
    // CATCH SCREEN
    // ========================================================================
    const catchScreen = document.getElementById('catch-screen');
    const catchCard = document.getElementById('catch-card');
    let catchTimeout = null;

    function showCatch(data) {
        if (!catchScreen) return;

        const rarity = RARITY[data.rarity] || RARITY.common;

        // Image
        const img = document.getElementById('catch-image');
        if (img) {
            img.src = data.image || ('nui://ox_inventory/web/images/' + (data.item || 'fishingrod') + '.png');
            img.onerror = function () { this.style.display = 'none'; };
            img.style.display = '';
        }

        // Name
        const nameEl = document.getElementById('catch-name-nui');
        if (nameEl) nameEl.textContent = data.label || 'Peixe';

        // Rarity badge
        const badge = document.getElementById('catch-rarity-badge');
        if (badge) {
            badge.textContent = rarity.label;
            badge.style.backgroundColor = rarity.color + '22';
            badge.style.color = rarity.color;
            badge.style.borderColor = rarity.color + '44';
        }

        // Stats
        const weightEl = document.getElementById('catch-weight-nui');
        const sizeEl = document.getElementById('catch-size-nui');
        const valueEl = document.getElementById('catch-value-nui');
        if (weightEl) weightEl.textContent = formatWeight(data.weight || 0);
        if (sizeEl) sizeEl.textContent = (data.size || 0) + 'cm';
        if (valueEl) valueEl.textContent = 'R$' + (data.value || 0);

        // XP
        const xpEl = document.getElementById('catch-xp-amount');
        if (xpEl) xpEl.textContent = '+' + (data.xp || 0) + ' XP';

        // Level bar
        const levelFill = document.getElementById('catch-level-fill');
        const levelText = document.getElementById('catch-level-text');
        if (levelFill && data.xpProgress !== undefined) {
            levelFill.style.width = Math.min(100, data.xpProgress) + '%';
        }
        if (levelText) {
            levelText.textContent = 'Nivel ' + (data.level || 1);
        }

        // Card rarity class
        if (catchCard) {
            catchCard.className = 'catch-card rarity-' + (data.rarity || 'common');
        }

        // Glow color
        const glow = document.getElementById('catch-glow');
        if (glow) {
            glow.style.setProperty('--glow-color', rarity.color + '33');
        }

        // Level up
        const levelUpEl = document.getElementById('catch-levelup-nui');
        const newLevelEl = document.getElementById('catch-newlevel-nui');
        if (data.levelUp && data.newLevel) {
            if (levelUpEl) levelUpEl.classList.remove('hidden');
            if (newLevelEl) newLevelEl.textContent = 'Nivel ' + data.newLevel;
        } else {
            if (levelUpEl) levelUpEl.classList.add('hidden');
        }

        // Show
        catchScreen.classList.remove('hidden');

        // Auto-close after 4s
        if (catchTimeout) clearTimeout(catchTimeout);
        catchTimeout = setTimeout(function () {
            closeCatch();
        }, data.duration || 4000);
    }

    function closeCatch() {
        if (!catchScreen) return;
        catchScreen.classList.add('hidden');
        if (catchTimeout) { clearTimeout(catchTimeout); catchTimeout = null; }
        post('closeCatch');
    }

    if (catchScreen) {
        catchScreen.addEventListener('click', closeCatch);
    }

    // ========================================================================
    // LEADERBOARD
    // ========================================================================
    const lbPanel = document.getElementById('leaderboard-panel');
    const lbContent = document.getElementById('leaderboard-content');
    const lbPlayer = document.getElementById('leaderboard-player');
    const lbClose = document.getElementById('leaderboard-close');
    let currentTab = 'most-fish';

    function showLeaderboard(data) {
        if (!lbPanel) return;

        currentTab = 'most-fish';
        renderLeaderboard(data);
        lbPanel.classList.remove('hidden');

        // Tab buttons
        document.querySelectorAll('.tab-btn').forEach(function (btn) {
            btn.classList.remove('active');
            if (btn.dataset.tab === currentTab) btn.classList.add('active');

            btn.onclick = function () {
                currentTab = this.dataset.tab;
                document.querySelectorAll('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
                this.classList.add('active');
                renderLeaderboard(data);
            };
        });
    }

    function renderLeaderboard(data) {
        if (!lbContent) return;

        let entries = [];
        if (currentTab === 'most-fish') entries = data.mostFish || [];
        else if (currentTab === 'heaviest') entries = data.heaviest || [];
        else if (currentTab === 'most-money') entries = data.mostMoney || [];
        else if (currentTab === 'highest-level') entries = data.highestLevel || [];

        let html = '';
        entries.forEach(function (entry, idx) {
            const rank = idx + 1;
            const topClass = rank === 1 ? 'top-1' : rank === 2 ? 'top-2' : rank === 3 ? 'top-3' : '';
            const rankClass = rank === 1 ? 'gold' : rank === 2 ? 'silver' : rank === 3 ? 'bronze' : '';

            html += '<div class="leaderboard-row ' + topClass + '">';
            html += '  <div class="lb-rank ' + rankClass + '">' + rank + '</div>';
            html += '  <div class="lb-info">';
            html += '    <div class="lb-name">' + escapeHtml(entry.name || 'Jogador') + '</div>';
            html += '    <div class="lb-detail">' + escapeHtml(entry.detail || '') + '</div>';
            html += '  </div>';
            html += '  <div class="lb-value">' + escapeHtml(entry.value || '') + '</div>';
            html += '</div>';
        });

        lbContent.innerHTML = html || '<div style="text-align:center;color:#8892a4;padding:40px;">Sem dados</div>';

        // Player position
        if (lbPlayer && data.playerPosition) {
            const pp = data.playerPosition;
            lbPlayer.innerHTML = '<div class="leaderboard-row">' +
                '<div class="lb-rank">#' + (pp.rank || '?') + '</div>' +
                '<div class="lb-info"><div class="lb-name">Voce</div><div class="lb-detail">' + escapeHtml(pp.detail || '') + '</div></div>' +
                '<div class="lb-value">' + escapeHtml(pp.value || '') + '</div></div>';
            lbPlayer.style.display = '';
        } else if (lbPlayer) {
            lbPlayer.style.display = 'none';
        }
    }

    function closeLeaderboard() {
        if (lbPanel) lbPanel.classList.add('hidden');
        post('closeLeaderboard');
    }

    if (lbClose) lbClose.addEventListener('click', closeLeaderboard);

    // ========================================================================
    // STATS PANEL
    // ========================================================================
    const statsPanel = document.getElementById('stats-panel');
    const statsContent = document.getElementById('stats-content');
    const statsClose = document.getElementById('stats-close');

    function showStats(data) {
        if (!statsPanel || !statsContent) return;

        const xpProgress = data.xpNeeded > 0 ? Math.floor((data.xp / data.xpNeeded) * 100) : 100;
        const isMax = data.level >= (data.maxLevel || 50);

        let html = '';

        // Level section
        html += '<div class="stats-level-section">';
        html += '  <div class="stats-level-number">' + (data.level || 1) + '</div>';
        html += '  <div class="stats-level-label">' + (isMax ? 'Nivel Maximo!' : 'Nivel de Pesca') + '</div>';
        html += '  <div class="stats-xp-bar"><div class="stats-xp-fill" style="width:' + xpProgress + '%"></div></div>';
        html += '  <div class="stats-xp-text">' + (isMax ? 'MAX' : (data.xp || 0) + ' / ' + (data.xpNeeded || 0) + ' XP') + '</div>';
        html += '</div>';

        // Stats grid
        html += '<div class="stats-grid">';
        html += statCard('fa-fish', data.total_caught || 0, 'Peixes Pescados');
        html += statCard('fa-store', data.total_sold || 0, 'Peixes Vendidos');
        html += statCard('fa-coins', 'R$' + formatNumber(data.money_earned || 0), 'Dinheiro Ganho');
        html += statCard('fa-weight-hanging', formatWeight(data.biggest_weight || 0), 'Maior Peixe');
        html += statCard('fa-fish', data.fish_caught_today || 0, 'Peixes Hoje');
        html += statCard('fa-coins', 'R$' + formatNumber(data.money_earned_today || 0), 'Ganho Hoje');
        html += '</div>';

        // Active nets/rods
        if (data.activeNets !== undefined || data.activeRods !== undefined) {
            html += '<div class="stats-section-title"><i class="fas fa-border-all"></i> Equipamento Ativo</div>';
            html += '<div class="stats-grid">';
            html += statCard('fa-border-all', data.activeNets || 0, 'Redes Ativas');
            html += statCard('fa-fish', data.activeRods || 0, 'Varas Plantadas');
            html += '</div>';
        }

        // Achievements
        if (data.achievementsTotal !== undefined) {
            html += '<div class="stats-section-title"><i class="fas fa-trophy"></i> Conquistas</div>';
            html += '<div class="stats-grid">';
            html += statCard('fa-trophy', (data.achievementsUnlocked || 0) + '/' + (data.achievementsTotal || 0), 'Desbloqueadas');
            html += '</div>';
        }

        statsContent.innerHTML = html;
        statsPanel.classList.remove('hidden');
    }

    function statCard(icon, value, label) {
        return '<div class="stat-card">' +
            '<div class="stat-card-icon"><i class="fas ' + icon + '"></i></div>' +
            '<div class="stat-card-value">' + value + '</div>' +
            '<div class="stat-card-label">' + label + '</div>' +
            '</div>';
    }

    function closeStats() {
        if (statsPanel) statsPanel.classList.add('hidden');
        post('closeStats');
    }

    if (statsClose) statsClose.addEventListener('click', closeStats);

    // ========================================================================
    // SHOP PANEL
    // ========================================================================
    const shopPanel = document.getElementById('shop-panel');
    const shopTitle = document.getElementById('shop-title');
    const shopSubtitle = document.getElementById('shop-subtitle');
    const shopIconWrap = document.getElementById('shop-icon-wrap');
    const shopItems = document.getElementById('shop-items');
    const shopClose = document.getElementById('shop-close');
    const shopQtyOverlay = document.getElementById('shop-qty-overlay');
    const shopQtyTitle = document.getElementById('shop-qty-title');
    const shopQtyImage = document.getElementById('shop-qty-image');
    const shopQtyItemName = document.getElementById('shop-qty-item-name');
    const shopQtyItemPrice = document.getElementById('shop-qty-item-price');
    const shopQtyInput = document.getElementById('shop-qty-input');
    const shopQtyTotalValue = document.getElementById('shop-qty-total-value');
    const shopQtyMinus = document.getElementById('shop-qty-minus');
    const shopQtyPlus = document.getElementById('shop-qty-plus');
    const shopQtyCancel = document.getElementById('shop-qty-cancel');
    const shopQtyConfirm = document.getElementById('shop-qty-confirm');
    const shopQtyClose = document.getElementById('shop-qty-close');

    let shopCurrentData = null;
    let shopSelectedItem = null;

    function showShop(data) {
        if (!shopPanel) return;
        shopCurrentData = data;

        // Header
        if (shopTitle) shopTitle.textContent = data.title || 'Loja';
        if (shopSubtitle) {
            shopSubtitle.textContent = data.subtitle || '';
            shopSubtitle.className = 'shop-subtitle' + (data.mode === 'sell' ? ' sell' : data.mode === 'black' ? ' black' : '');
        }
        if (shopIconWrap) {
            shopIconWrap.className = 'shop-icon-wrap' + (data.mode === 'sell' ? ' sell' : data.mode === 'black' ? ' black' : '');
            const iconMap = { buy: 'fa-store', sell: 'fa-coins', black: 'fa-skull-crossbones' };
            shopIconWrap.innerHTML = '<i class="fas ' + (iconMap[data.mode] || 'fa-store') + '"></i>';
        }

        // Items
        if (!data.items || data.items.length === 0) {
            shopItems.innerHTML = '<div class="shop-empty"><i class="fas fa-box-open"></i>Nenhum item disponivel</div>';
        } else {
            let html = '';
            data.items.forEach(function (item, idx) {
                const locked = item.locked || false;
                const modeClass = data.mode === 'sell' ? ' sell-mode' : data.mode === 'black' ? ' black-mode' : '';

                html += '<div class="shop-item' + (locked ? ' locked' : '') + modeClass + '" data-index="' + idx + '">';

                // Icon/image
                html += '<div class="shop-item-icon">';
                if (item.image) {
                    html += '<img src="' + escapeHtml(item.image) + '" onerror="this.style.display=\'none\'">';
                } else {
                    html += '<i class="fas ' + escapeHtml(item.icon || 'fa-box') + '" style="color:' + escapeHtml(item.iconColor || '#8892a4') + '"></i>';
                }
                html += '</div>';

                // Info
                html += '<div class="shop-item-info">';
                html += '<div class="shop-item-name">' + escapeHtml(item.label || item.name || 'Item') + '</div>';
                html += '<div class="shop-item-desc">';

                // Metadata tags
                if (item.metadata) {
                    item.metadata.forEach(function (m) {
                        html += '<span class="shop-item-meta"><i class="fas fa-info-circle"></i> ' + escapeHtml(m.label) + ': ' + escapeHtml(m.value) + '</span>';
                    });
                }

                // Market multiplier
                if (item.marketInfo) {
                    html += '<span class="shop-item-meta" style="color:#ffd700"><i class="fas fa-chart-line"></i> ' + escapeHtml(item.marketInfo) + '</span>';
                }

                html += '</div></div>';

                // Right side - price & badges
                html += '<div class="shop-item-right">';
                html += '<div class="shop-item-price">R$' + formatNumber(item.price || 0) + '</div>';

                if (locked && item.minLevel) {
                    html += '<span class="shop-item-badge shop-badge-locked"><i class="fas fa-lock"></i> Nv.' + item.minLevel + '</span>';
                } else if (item.minLevel && item.minLevel > 1) {
                    html += '<span class="shop-item-badge shop-badge-level">Nv.' + item.minLevel + '</span>';
                }

                if (item.count) {
                    html += '<span class="shop-item-badge shop-badge-count">x' + item.count + '</span>';
                }

                html += '</div>';
                html += '</div>';
            });
            shopItems.innerHTML = html;

            // Click handlers
            shopItems.querySelectorAll('.shop-item:not(.locked)').forEach(function (el) {
                el.addEventListener('click', function () {
                    const idx = parseInt(this.dataset.index);
                    const item = data.items[idx];
                    if (item) openQtyModal(item, data.mode);
                });
            });
        }

        shopQtyOverlay.classList.add('hidden');
        shopPanel.classList.remove('hidden');
    }

    function openQtyModal(item, mode) {
        shopSelectedItem = item;
        const maxQty = item.maxCount || 100;

        if (shopQtyTitle) shopQtyTitle.textContent = (mode === 'buy' ? 'Comprar' : 'Vender') + ' ' + (item.label || item.name);
        if (shopQtyImage) {
            shopQtyImage.src = item.image || ('nui://ox_inventory/web/images/' + (item.name || 'fishingrod') + '.png');
            shopQtyImage.onerror = function () { this.style.display = 'none'; };
            shopQtyImage.style.display = '';
        }
        if (shopQtyItemName) shopQtyItemName.textContent = item.label || item.name;
        if (shopQtyItemPrice) shopQtyItemPrice.textContent = 'R$' + formatNumber(item.price || 0) + '/un';

        shopQtyInput.value = mode === 'buy' ? 1 : (item.count || 1);
        shopQtyInput.max = maxQty;
        shopQtyInput.min = 1;
        updateQtyTotal();

        shopQtyOverlay.classList.remove('hidden');
    }

    function updateQtyTotal() {
        if (!shopSelectedItem) return;
        let qty = parseInt(shopQtyInput.value) || 1;
        const max = parseInt(shopQtyInput.max) || 100;
        if (qty < 1) qty = 1;
        if (qty > max) qty = max;
        shopQtyInput.value = qty;
        const total = qty * (shopSelectedItem.price || 0);
        if (shopQtyTotalValue) shopQtyTotalValue.textContent = 'R$' + formatNumber(total);
    }

    if (shopQtyMinus) shopQtyMinus.addEventListener('click', function () {
        shopQtyInput.value = Math.max(1, (parseInt(shopQtyInput.value) || 1) - 1);
        updateQtyTotal();
    });

    if (shopQtyPlus) shopQtyPlus.addEventListener('click', function () {
        const max = parseInt(shopQtyInput.max) || 100;
        shopQtyInput.value = Math.min(max, (parseInt(shopQtyInput.value) || 1) + 1);
        updateQtyTotal();
    });

    if (shopQtyInput) shopQtyInput.addEventListener('input', updateQtyTotal);

    if (shopQtyCancel) shopQtyCancel.addEventListener('click', function () {
        shopQtyOverlay.classList.add('hidden');
    });

    if (shopQtyClose) shopQtyClose.addEventListener('click', function () {
        shopQtyOverlay.classList.add('hidden');
    });

    if (shopQtyConfirm) shopQtyConfirm.addEventListener('click', function () {
        if (!shopSelectedItem || !shopCurrentData) return;
        const qty = parseInt(shopQtyInput.value) || 1;
        post('shopConfirm', {
            mode: shopCurrentData.mode,
            shopId: shopCurrentData.shopId,
            item: shopSelectedItem.name,
            amount: qty,
            label: shopSelectedItem.label || shopSelectedItem.name,
            price: shopSelectedItem.price || 0,
        });
        shopQtyOverlay.classList.add('hidden');
        closeShop();
    });

    function closeShop() {
        if (shopPanel) shopPanel.classList.add('hidden');
        shopQtyOverlay.classList.add('hidden');
        shopCurrentData = null;
        shopSelectedItem = null;
        post('closeShop');
    }

    if (shopClose) shopClose.addEventListener('click', closeShop);

    // ========================================================================
    // UTILS
    // ========================================================================
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function formatNumber(num) {
        if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
        if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
        return String(num);
    }

    // ========================================================================
    // AFK NOTIFICATIONS (lado direito)
    // ========================================================================
    const afkNotifContainer = document.getElementById('afk-notif-container');

    function showAFKNotif(data) {
        if (!afkNotifContainer) return;

        const notif = document.createElement('div');
        notif.className = 'afk-notif';

        const iconType = data.type || 'info';
        const iconMap = {
            success: 'fa-fish',
            error: 'fa-times',
            info: 'fa-info',
            bite: 'fa-bolt',
        };

        notif.innerHTML =
            '<div class="afk-notif-icon ' + iconType + '"><i class="fas ' + (iconMap[iconType] || 'fa-info') + '"></i></div>' +
            '<div class="afk-notif-text">' +
            '<div class="afk-notif-title">' + escapeHtml(data.title || '') + '</div>' +
            (data.description ? '<div class="afk-notif-desc">' + escapeHtml(data.description) + '</div>' : '') +
            '</div>';

        afkNotifContainer.appendChild(notif);

        // Max 5 notifs
        while (afkNotifContainer.children.length > 5) {
            afkNotifContainer.removeChild(afkNotifContainer.firstChild);
        }

        // Auto-remove
        var duration = data.duration || 3000;
        setTimeout(function () {
            notif.classList.add('closing');
            setTimeout(function () {
                if (notif.parentNode) notif.parentNode.removeChild(notif);
            }, 300);
        }, duration);
    }

    function clearAFKNotifs() {
        if (afkNotifContainer) afkNotifContainer.innerHTML = '';
    }

    // ========================================================================
    // AFK HUD
    // ========================================================================
    const afkHud = document.getElementById('afk-hud');
    const afkFishCount = document.getElementById('afk-fish-count');
    const afkFishEscaped = document.getElementById('afk-fish-escaped');
    const afkTimeRemaining = document.getElementById('afk-time-remaining');
    const afkNextBite = document.getElementById('afk-next-bite');
    const afkLastCatch = document.getElementById('afk-last-catch');
    const afkLastCatchRow = document.getElementById('afk-last-catch-row');
    const afkRodBait = document.getElementById('afk-rod-bait');
    const afkStatus = document.getElementById('afk-status');
    const afkProgressFill = document.getElementById('afk-progress-fill');

    function showAFKHud() {
        if (afkHud) afkHud.classList.remove('hidden');
    }

    function hideAFKHud() {
        if (afkHud) afkHud.classList.add('hidden');
    }

    function updateAFKHud(data) {
        if (!afkHud) return;
        afkHud.classList.remove('hidden');

        if (afkFishCount) afkFishCount.textContent = data.fishCaught || 0;
        if (afkFishEscaped) afkFishEscaped.textContent = data.fishEscaped || 0;
        if (afkTimeRemaining) afkTimeRemaining.textContent = data.timeRemaining || '00:00';
        if (afkNextBite) afkNextBite.textContent = data.nextBite || '--';
        if (afkRodBait) afkRodBait.textContent = data.rodBait || '';
        if (afkStatus) afkStatus.textContent = data.status || 'Aguardando...';
        if (afkProgressFill && data.progress !== undefined) {
            afkProgressFill.style.width = Math.max(0, Math.min(100, data.progress)) + '%';
        }

        // Last catch
        if (data.lastCatch && afkLastCatch && afkLastCatchRow) {
            afkLastCatch.textContent = data.lastCatch;
            afkLastCatchRow.style.display = '';
        }

        // Status visual variant
        afkHud.classList.remove('status-bite', 'status-caught', 'status-escaped');
        if (data.statusType === 'bite') afkHud.classList.add('status-bite');
        else if (data.statusType === 'caught') afkHud.classList.add('status-caught');
        else if (data.statusType === 'escaped') afkHud.classList.add('status-escaped');
    }

    // ========================================================================
    // NUI MESSAGE HANDLER
    // ========================================================================
    window.addEventListener('message', function (event) {
        const data = event.data;
        if (!data || !data.action) return;

        switch (data.action) {
            case 'showAFKHud':
                showAFKHud();
                break;
            case 'hideAFKHud':
                hideAFKHud();
                clearAFKNotifs();
                break;
            case 'updateAFKHud':
                updateAFKHud(data);
                break;
            case 'afkNotify':
                showAFKNotif(data);
                break;
            case 'showCatch':
                showCatch(data);
                break;
            case 'closeCatch':
                closeCatch();
                break;
            case 'showLeaderboard':
                showLeaderboard(data);
                break;
            case 'closeLeaderboard':
                closeLeaderboard();
                break;
            case 'showStats':
                showStats(data);
                break;
            case 'closeStats':
                closeStats();
                break;
            case 'showShop':
                showShop(data);
                break;
            case 'closeShop':
                closeShop();
                break;
        }
    });

    // ========================================================================
    // ESC TO CLOSE
    // ========================================================================
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            if (shopPanel && !shopPanel.classList.contains('hidden')) {
                if (shopQtyOverlay && !shopQtyOverlay.classList.contains('hidden')) {
                    shopQtyOverlay.classList.add('hidden');
                } else {
                    closeShop();
                }
            } else if (lbPanel && !lbPanel.classList.contains('hidden')) {
                closeLeaderboard();
            } else if (statsPanel && !statsPanel.classList.contains('hidden')) {
                closeStats();
            } else if (catchScreen && !catchScreen.classList.contains('hidden')) {
                closeCatch();
            }
        }
    });
})();
