-- ============================================================================
-- fishing: Server Boats - Aluguel de barcos
-- ============================================================================

-- Cache de barcos ativos
local activeBoats = {} -- [source] = { citizenid, model, rented_at, expires_at, dbId, netHandle }

-- ============================================================================
-- HELPERS
-- ============================================================================

local function getPlayer(source)
    return exports.qbx_core:GetPlayer(source)
end

local function getCitizenId(source)
    local Player = getPlayer(source)
    return Player and Player.PlayerData and Player.PlayerData.citizenid
end

local function getPlayerVIPTier(source)
    local Player = getPlayer(source)
    if not Player or not Player.PlayerData then return nil end
    local vip = Player.PlayerData.metadata and Player.PlayerData.metadata.vip
    if not vip or vip == false then return nil end
    return tostring(vip):lower()
end

local function isVIP(source)
    return getPlayerVIPTier(source) ~= nil
end

-- ============================================================================
-- CALLBACK: Alugar Barco
-- ============================================================================

lib.callback.register('fishing:server:rentBoat', function(source, modelName)
    if not Config.Boats.enabled then
        return { success = false, message = 'Aluguel de barcos desativado' }
    end

    if not modelName then
        return { success = false, message = 'Modelo invalido' }
    end

    local citizenid = getCitizenId(source)
    if not citizenid then
        return { success = false, message = 'Erro interno' }
    end

    -- Verificar se ja tem barco ativo
    if activeBoats[source] then
        return { success = false, message = 'Voce ja tem um barco alugado' }
    end

    -- Encontrar modelo na config
    local boatConfig = nil
    for _, boat in ipairs(Config.Boats.rental.models) do
        if boat.model == modelName then
            boatConfig = boat
            break
        end
    end

    if not boatConfig then
        return { success = false, message = 'Modelo de barco nao encontrado' }
    end

    -- Verificar nivel
    local level = GetPlayerLevel(source)
    if level < (boatConfig.minLevel or 1) then
        return { success = false, message = string.format('Nivel %d necessario para alugar %s', boatConfig.minLevel, boatConfig.label) }
    end

    -- Calcular preco com desconto VIP
    local price = boatConfig.price
    if isVIP(source) then
        price = math.floor(price * (1 - Config.Boats.vipDiscount))
    end

    -- Verificar dinheiro
    local Player = getPlayer(source)
    if not Player then
        return { success = false, message = 'Erro interno' }
    end

    local cash = Player.Functions.GetMoney('cash')
    if cash < price then
        return { success = false, message = string.format('Dinheiro insuficiente (R$%d necessario)', price) }
    end

    -- Cobrar
    Player.Functions.RemoveMoney('cash', price, 'fishing-boat-rental')

    -- Calcular expiracao
    local rentalMinutes = Config.Boats.maxRentalMinutes or 60
    local expiresAt = os.time() + (rentalMinutes * 60)

    -- Salvar no banco
    local dbId = MySQL.insert.await([[
        INSERT INTO fishing_boats (citizenid, boat_model, expires_at, price_paid)
        VALUES (?, ?, FROM_UNIXTIME(?), ?)
    ]], { citizenid, modelName, expiresAt, price })

    -- Cache
    activeBoats[source] = {
        citizenid = citizenid,
        model = modelName,
        label = boatConfig.label,
        rented_at = os.time(),
        expires_at = expiresAt,
        dbId = dbId,
        price_paid = price,
    }

    if Config.Debug then
        -- print(string.format('^3[fishing:boats]^0 %s alugou barco %s por R$%d (%d min)',
        --     citizenid, modelName, price, rentalMinutes))
    end

    return {
        success = true,
        model = modelName,
        label = boatConfig.label,
        price = price,
        expiresAt = expiresAt,
        rentalMinutes = rentalMinutes,
        spawnPoint = {
            x = Config.Boats.rental.spawnPoint.x,
            y = Config.Boats.rental.spawnPoint.y,
            z = Config.Boats.rental.spawnPoint.z,
            w = Config.Boats.rental.spawnPoint.w,
        },
        message = string.format('Barco %s alugado por R$%d! (%d min)', boatConfig.label, price, rentalMinutes),
    }
end)

-- ============================================================================
-- CALLBACK: Devolver Barco
-- ============================================================================

lib.callback.register('fishing:server:returnBoat', function(source)
    local boat = activeBoats[source]
    if not boat then
        return { success = false, message = 'Voce nao tem barco alugado' }
    end

    -- Calcular reembolso (30% se devolvido antes de expirar)
    local refund = 0
    local now = os.time()
    if now < boat.expires_at then
        refund = math.floor(boat.price_paid * (Config.Boats.returnRefundPercent or 0.3))
    end

    -- Dar reembolso
    if refund > 0 then
        local Player = getPlayer(source)
        if Player then
            Player.Functions.AddMoney('cash', refund, 'fishing-boat-refund')
        end
    end

    -- Marcar como devolvido no banco
    MySQL.update('UPDATE fishing_boats SET returned = 1 WHERE id = ?', { boat.dbId })

    local label = boat.label
    activeBoats[source] = nil

    if Config.Debug then
        -- print(string.format('^3[fishing:boats]^0 Barco devolvido (refund: R$%d)', refund))
    end

    return {
        success = true,
        refund = refund,
        message = refund > 0 and string.format('Barco %s devolvido! Reembolso: R$%d', label, refund) or string.format('Barco %s devolvido!', label),
    }
end)

-- ============================================================================
-- CALLBACK: Verificar se tem barco ativo
-- ============================================================================

lib.callback.register('fishing:server:getActiveBoat', function(source)
    local boat = activeBoats[source]
    if not boat then return nil end

    local now = os.time()
    if now >= boat.expires_at then
        -- Barco expirou
        MySQL.update('UPDATE fishing_boats SET returned = 1 WHERE id = ?', { boat.dbId })
        activeBoats[source] = nil
        return nil
    end

    return {
        model = boat.model,
        label = boat.label,
        remainingSeconds = boat.expires_at - now,
        expiresAt = boat.expires_at,
    }
end)

-- ============================================================================
-- CALLBACK: Obter menu de barcos
-- ============================================================================

lib.callback.register('fishing:server:getBoatMenu', function(source)
    local level = GetPlayerLevel(source)
    local vip = isVIP(source)

    local boats = {}
    for _, boat in ipairs(Config.Boats.rental.models) do
        local price = boat.price
        if vip then
            price = math.floor(price * (1 - Config.Boats.vipDiscount))
        end

        boats[#boats + 1] = {
            model = boat.model,
            label = boat.label,
            price = price,
            originalPrice = boat.price,
            minLevel = boat.minLevel,
            canRent = level >= (boat.minLevel or 1),
            vipDiscount = vip,
        }
    end

    return boats
end)

-- ============================================================================
-- THREAD: Timer de expiracao de barcos
-- ============================================================================

CreateThread(function()
    Wait(5000)
    while true do
        Wait(30000) -- verificar a cada 30s

        local now = os.time()
        for src, boat in pairs(activeBoats) do
            if now >= boat.expires_at then
                -- Barco expirou
                MySQL.update('UPDATE fishing_boats SET returned = 1 WHERE id = ?', { boat.dbId })
                TriggerClientEvent('fishing:client:boatExpired', src)
                activeBoats[src] = nil

                if Config.Debug then
                    -- print(string.format('^3[fishing:boats]^0 Barco de %s expirou', boat.citizenid))
                end
            elseif (boat.expires_at - now) <= 300 and not boat.warned then
                -- Aviso de 5 minutos
                boat.warned = true
                TriggerClientEvent('ox_lib:notify', src, {
                    title = 'Aluguel de Barco',
                    description = 'Seu barco expira em 5 minutos!',
                    type = 'warning',
                    duration = 8000,
                })
            end
        end
    end
end)

-- ============================================================================
-- CLEANUP
-- ============================================================================

AddEventHandler('playerDropped', function()
    local source = source
    local boat = activeBoats[source]
    if boat then
        -- Nao remover o barco quando o jogador sai, manter no banco
        -- O barco sera removido quando expirar
        activeBoats[source] = nil
    end
end)
