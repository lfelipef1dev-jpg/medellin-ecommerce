-- ============================================================================
-- fishing: Server Crafting - Sistema de craft
-- ============================================================================

-- ============================================================================
-- HELPERS
-- ============================================================================

local function getPlayer(source)
    return exports.qbx_core:GetPlayer(source)
end

local function getCitizenId(source)
    local Player = getPlayer(source)
    return Player and Player.PlayerData and Player.PlayerData.citizenid
end

-- ============================================================================
-- CALLBACK: Obter receitas disponiveis
-- ============================================================================

lib.callback.register('fishing:server:getCraftRecipes', function(source)
    local level = GetPlayerLevel(source)
    local recipes = {}

    for itemName, recipe in pairs(Config.Crafting) do
        local canCraft = level >= (recipe.minLevel or 1)

        -- Verificar materiais
        local hasAll = true
        local ingredients = {}
        for _, ing in ipairs(recipe.ingredients) do
            local count = exports.ox_inventory:GetItemCount(source, ing.item)
            local has = count and count >= ing.amount
            if not has then hasAll = false end

            ingredients[#ingredients + 1] = {
                item = ing.item,
                amount = ing.amount,
                has = count or 0,
                sufficient = has,
            }
        end

        recipes[#recipes + 1] = {
            item = itemName,
            label = recipe.label,
            minLevel = recipe.minLevel,
            time = recipe.time,
            ingredients = ingredients,
            canCraft = canCraft and hasAll,
            levelOk = canCraft,
            materialsOk = hasAll,
        }
    end

    -- Ordenar por nivel necessario
    table.sort(recipes, function(a, b)
        return a.minLevel < b.minLevel
    end)

    return recipes
end)

-- ============================================================================
-- CALLBACK: Craftar Item
-- ============================================================================

lib.callback.register('fishing:server:craftItem', function(source, itemName)
    if not itemName then
        return { success = false, message = 'Dados invalidos' }
    end

    local recipe = Config.Crafting[itemName]
    if not recipe then
        return { success = false, message = 'Receita nao encontrada' }
    end

    -- Verificar nivel
    local level = GetPlayerLevel(source)
    if level < (recipe.minLevel or 1) then
        return { success = false, message = string.format('Nivel %d necessario', recipe.minLevel) }
    end

    -- Verificar materiais
    for _, ing in ipairs(recipe.ingredients) do
        local count = exports.ox_inventory:GetItemCount(source, ing.item)
        if not count or count < ing.amount then
            return { success = false, message = string.format('Faltando %s (%d/%d)', ing.item, count or 0, ing.amount) }
        end
    end

    -- Verificar espaco no inventario
    local canCarry = exports.ox_inventory:CanCarryItem(source, itemName, 1)
    if not canCarry then
        return { success = false, message = 'Inventario cheio' }
    end

    -- Consumir materiais
    for _, ing in ipairs(recipe.ingredients) do
        local removed = exports.ox_inventory:RemoveItem(source, ing.item, ing.amount)
        if not removed then
            return { success = false, message = 'Erro ao consumir materiais' }
        end
    end

    -- Dar item craftado
    local added = exports.ox_inventory:AddItem(source, itemName, 1)
    if not added then
        -- Devolver materiais se falhar
        for _, ing in ipairs(recipe.ingredients) do
            exports.ox_inventory:AddItem(source, ing.item, ing.amount)
        end
        return { success = false, message = 'Erro ao criar item' }
    end

    -- XP por crafting (10-30 baseado no tempo)
    local craftXP = math.floor((recipe.time or 10) * 2)
    AddPlayerXP(source, craftXP)

    if Config.Debug then
        local citizenid = getCitizenId(source)
        -- print(string.format('^3[fishing:crafting]^0 %s craftou %s (+%d XP)', citizenid or '?', itemName, craftXP))
    end

    return {
        success = true,
        item = itemName,
        label = recipe.label,
        xp = craftXP,
        message = string.format('%s criado! (+%d XP)', recipe.label, craftXP),
    }
end)
