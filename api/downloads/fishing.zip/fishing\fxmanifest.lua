fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Seu Servidor'
description 'Sistema de Pesca Completo v2.0 - Minigame, XP, Mercado, AFK, Redes, Barcos, Craft, NUI'
version '2.0.0'

dependencies {
    'ox_lib',
    'ox_inventory',
    'ox_target',
    'oxmysql',
    'qbx_core',
}

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_scripts {
    'client/main.lua',
    'client/fishing.lua',
    'client/minigame.lua',
    'client/nets.lua',
    'client/boats.lua',
    'client/crafting.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',
    'server/xp.lua',
    'server/market.lua',
    'server/nets.lua',
    'server/boats.lua',
    'server/crafting.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/minigame.js',
    'html/js/catch.js',
    'html/js/app.js',
}
