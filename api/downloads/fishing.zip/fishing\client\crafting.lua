-- ============================================================================
-- fishing: Client Crafting - Bancada de craft
-- ============================================================================

local craftingActive = false
local craftingBenches = {} -- para cleanup

-- ============================================================================
-- WORKBENCH: Criar zona de craft perto de cada loja
-- ============================================================================

CreateThread(function()
    Wait(4000)

    if Config.CraftingBench == false then
        if Config.Debug then
            -- print('^3[fishing:crafting]^0 Bancadas desativadas via config')
        end
        return
    end

    for shopId, shop in pairs(Config.Shops) do
        -- Usar coords fixas se definidas, senao offset da loja
        local benchCoords = shop.benchCoords or vector3(shop.coords.x + 2.0, shop.coords.y + 2.0, shop.coords.z)

        -- Criar prop de bancada
        local hash = joaat('prop_tool_bench02')
        lib.requestModel(hash)
        local bench = CreateObject(hash, benchCoords.x, benchCoords.y, benchCoords.z - 1.0, false, true, false)
        if bench and bench ~= 0 then
            SetEntityAsMissionEntity(bench, true, true)
            FreezeEntityPosition(bench, true)
            PlaceObjectOnGroundProperly(bench)
            SetModelAsNoLongerNeeded(hash)

            craftingBenches[#craftingBenches + 1] = bench

            Wait(300)

            exports.ox_target:addLocalEntity(bench, {
                {
                    name = 'fishing_craft_' .. shopId,
                    icon = 'fas fa-hammer',
                    label = 'Bancada de Craft',
                    distance = 2.5,
                    onSelect = function()
                        OpenCraftingMenu()
                    end,
                },
            })
        end
    end

    if Config.Debug then
        -- print('^3[fishing:crafting]^0 Bancadas de craft criadas: ' .. #craftingBenches)
    end
end)

-- Cleanup das bancadas quando resource para
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    for _, bench in ipairs(craftingBenches) do
        if bench and DoesEntityExist(bench) then
            DeleteEntity(bench)
        end
    end
end)

-- ============================================================================
-- MENU DE CRAFTING
-- ============================================================================

function OpenCraftingMenu()
    if craftingActive then
        lib.notify({ title = 'Craft', description = 'Ja esta craftando', type = 'error' })
        return
    end

    local recipes = lib.callback.await('fishing:server:getCraftRecipes', false)
    if not recipes or #recipes == 0 then
        lib.notify({ title = 'Craft', description = 'Nenhuma receita disponivel', type = 'error' })
        return
    end

    local options = {}
    for _, recipe in ipairs(recipes) do
        -- Montar descricao dos ingredientes
        local ingDesc = {}
        for _, ing in ipairs(recipe.ingredients) do
            local status = ing.sufficient and '~g~' or '~r~'
            ingDesc[#ingDesc + 1] = string.format('%s%s (%d/%d)', status, ing.item, ing.has, ing.amount)
        end

        local icon = recipe.canCraft and 'fas fa-hammer' or 'fas fa-lock'
        local color = recipe.canCraft and '#00FF88' or (recipe.levelOk and '#e94560' or '#8892a4')

        local desc = table.concat(ingDesc, ' | ')
        if not recipe.levelOk then
            desc = string.format('Nivel %d necessario', recipe.minLevel)
        end

        options[#options + 1] = {
            title = recipe.label,
            description = desc,
            icon = icon,
            iconColor = color,
            disabled = not recipe.canCraft,
            metadata = {
                { label = 'Tempo', value = recipe.time .. 's' },
                { label = 'Nivel', value = tostring(recipe.minLevel) },
            },
            onSelect = function()
                StartCrafting(recipe.item, recipe.label, recipe.time)
            end,
        }
    end

    lib.registerContext({
        id = 'fishing_crafting',
        title = 'Bancada de Craft - Pesca',
        options = options,
    })
    lib.showContext('fishing_crafting')
end

-- ============================================================================
-- EXECUTAR CRAFT
-- ============================================================================

function StartCrafting(itemName, label, duration)
    if craftingActive then return end
    craftingActive = true

    local ped = PlayerPedId()

    local success = lib.progressBar({
        duration = (duration or 10) * 1000,
        label = string.format('Fabricando %s...', label),
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
        anim = {
            dict = 'mini@repair',
            clip = 'fixing_a_player',
        },
    })

    ClearPedTasks(ped)
    craftingActive = false

    if not success then
        lib.notify({ title = 'Craft', description = 'Fabricacao cancelada', type = 'error' })
        return
    end

    local result = lib.callback.await('fishing:server:craftItem', false, itemName)

    if result and result.success then
        lib.notify({ title = 'Craft', description = result.message, type = 'success', duration = 5000 })
        PlaySound(Config.Sounds.catch)
    else
        lib.notify({ title = 'Craft', description = result and result.message or 'Erro na fabricacao', type = 'error' })
    end
end
