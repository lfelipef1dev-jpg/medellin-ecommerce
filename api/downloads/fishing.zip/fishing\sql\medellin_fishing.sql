-- ============================================================================
-- medellin-fishing: Tabelas do sistema de pesca v2.0
-- ============================================================================

-- Stats do jogador (nivel, xp, contadores)
CREATE TABLE IF NOT EXISTS `medellin_fishing_stats` (
    `citizenid` VARCHAR(50) NOT NULL,
    `level` INT NOT NULL DEFAULT 1,
    `xp` INT NOT NULL DEFAULT 0,
    `total_caught` INT NOT NULL DEFAULT 0,
    `total_sold` INT NOT NULL DEFAULT 0,
    `money_earned` BIGINT NOT NULL DEFAULT 0,
    `biggest_weight` INT NOT NULL DEFAULT 0,
    `biggest_fish` VARCHAR(50) DEFAULT NULL,
    `fish_caught_today` INT NOT NULL DEFAULT 0,
    `money_earned_today` BIGINT NOT NULL DEFAULT 0,
    `last_daily_reset` DATE DEFAULT NULL,
    `total_playtime_min` INT NOT NULL DEFAULT 0,
    `zones_visited` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Leaderboard global (top peixes)
CREATE TABLE IF NOT EXISTS `medellin_fishing_leaderboard` (
    `id` INT AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `player_name` VARCHAR(100) DEFAULT NULL,
    `fish_item` VARCHAR(50) NOT NULL,
    `fish_label` VARCHAR(100) NOT NULL,
    `weight` INT NOT NULL DEFAULT 0,
    `size` INT NOT NULL DEFAULT 0,
    `rarity` VARCHAR(20) NOT NULL DEFAULT 'common',
    `zone_id` VARCHAR(50) DEFAULT NULL,
    `caught_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_fish_weight` (`fish_item`, `weight` DESC),
    INDEX `idx_citizenid` (`citizenid`),
    INDEX `idx_rarity` (`rarity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Mercado dinamico (preco de cada peixe)
CREATE TABLE IF NOT EXISTS `medellin_fishing_market` (
    `fish_item` VARCHAR(50) NOT NULL,
    `multiplier` FLOAT NOT NULL DEFAULT 1.0,
    `total_sold` INT NOT NULL DEFAULT 0,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`fish_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Conquistas desbloqueadas
CREATE TABLE IF NOT EXISTS `medellin_fishing_achievements` (
    `id` INT AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `achievement_id` VARCHAR(50) NOT NULL,
    `unlocked_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_citizen_achievement` (`citizenid`, `achievement_id`),
    INDEX `idx_citizenid` (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Redes plantadas no mundo
CREATE TABLE IF NOT EXISTS `medellin_fishing_nets` (
    `id` INT AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `net_item` VARCHAR(50) NOT NULL,
    `zone_id` VARCHAR(50) NOT NULL,
    `coords_x` FLOAT NOT NULL,
    `coords_y` FLOAT NOT NULL,
    `coords_z` FLOAT NOT NULL,
    `placed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `collect_after` TIMESTAMP NOT NULL,
    `collected` TINYINT(1) NOT NULL DEFAULT 0,
    `uses_remaining` INT NOT NULL DEFAULT 5,
    PRIMARY KEY (`id`),
    INDEX `idx_citizenid` (`citizenid`),
    INDEX `idx_zone` (`zone_id`),
    INDEX `idx_collected` (`collected`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Log de peixes pescados (para anti-abuse e analytics)
CREATE TABLE IF NOT EXISTS `medellin_fishing_log` (
    `id` INT AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `fish_item` VARCHAR(50) NOT NULL,
    `rarity` VARCHAR(20) NOT NULL,
    `weight` INT NOT NULL DEFAULT 0,
    `zone_id` VARCHAR(50) DEFAULT NULL,
    `method` ENUM('manual', 'afk', 'net', 'planted_rod') NOT NULL DEFAULT 'manual',
    `caught_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_citizenid_date` (`citizenid`, `caught_at`),
    INDEX `idx_method` (`method`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Varas plantadas (pesca passiva)
CREATE TABLE IF NOT EXISTS `medellin_fishing_planted_rods` (
    `id` INT AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `rod_item` VARCHAR(50) NOT NULL,
    `bait_item` VARCHAR(50) NOT NULL,
    `zone_id` VARCHAR(50) NOT NULL,
    `coords_x` FLOAT NOT NULL,
    `coords_y` FLOAT NOT NULL,
    `coords_z` FLOAT NOT NULL,
    `placed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `fish_bucket` JSON DEFAULT NULL,
    `last_fish_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `active` TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (`id`),
    INDEX `idx_citizenid` (`citizenid`),
    INDEX `idx_active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Barcos alugados
CREATE TABLE IF NOT EXISTS `medellin_fishing_boats` (
    `id` INT AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `boat_model` VARCHAR(50) NOT NULL,
    `rented_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `expires_at` TIMESTAMP NOT NULL,
    `returned` TINYINT(1) NOT NULL DEFAULT 0,
    `price_paid` INT NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    INDEX `idx_citizenid` (`citizenid`),
    INDEX `idx_returned` (`returned`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- MIGRACAO: Adicionar colunas novas se tabela ja existe
-- MySQL 8.x nao suporta ADD COLUMN IF NOT EXISTS, usando procedimento seguro
-- ============================================================================

-- Procedimento para adicionar coluna se nao existir
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS _mf_add_column_if_not_exists(
    IN tbl VARCHAR(100), IN col VARCHAR(100), IN col_def VARCHAR(500))
BEGIN
    SET @db = DATABASE();
    SET @exists = (SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = @db AND TABLE_NAME = tbl AND COLUMN_NAME = col);
    IF @exists = 0 THEN
        SET @sql = CONCAT('ALTER TABLE `', tbl, '` ADD COLUMN `', col, '` ', col_def);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //
DELIMITER ;

-- Stats novas colunas
CALL _mf_add_column_if_not_exists('medellin_fishing_stats', 'fish_caught_today', 'INT NOT NULL DEFAULT 0 AFTER `biggest_fish`');
CALL _mf_add_column_if_not_exists('medellin_fishing_stats', 'money_earned_today', 'BIGINT NOT NULL DEFAULT 0 AFTER `fish_caught_today`');
CALL _mf_add_column_if_not_exists('medellin_fishing_stats', 'last_daily_reset', 'DATE DEFAULT NULL AFTER `money_earned_today`');
CALL _mf_add_column_if_not_exists('medellin_fishing_stats', 'total_playtime_min', 'INT NOT NULL DEFAULT 0 AFTER `last_daily_reset`');
CALL _mf_add_column_if_not_exists('medellin_fishing_stats', 'zones_visited', 'TEXT DEFAULT NULL AFTER `total_playtime_min`');

-- Leaderboard nova coluna
CALL _mf_add_column_if_not_exists('medellin_fishing_leaderboard', 'zone_id', 'VARCHAR(50) DEFAULT NULL AFTER `rarity`');

-- Limpar procedimento auxiliar
DROP PROCEDURE IF EXISTS _mf_add_column_if_not_exists;

-- Log: adicionar planted_rod ao enum method
ALTER TABLE `medellin_fishing_log`
    MODIFY COLUMN `method` ENUM('manual', 'afk', 'net', 'planted_rod') NOT NULL DEFAULT 'manual';
