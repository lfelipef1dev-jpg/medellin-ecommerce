-- ============================================================================
-- fishing: Client Fishing - Pesca manual, AFK, cleanup
-- REWRITE COMPLETO — zero chamadas bloqueantes em loops, zero freezes
-- ============================================================================

local lastCastTime = 0
local fishingRodProp = nil
local ROD_MODEL = `prop_fishing_rod_01`

local function isPlayerInAnyZone()
    local ped = PlayerPedId()
    if not ped or not DoesEntityExist(ped) then return false, nil end
    local coords = GetEntityCoords(ped)
    for zId, z in pairs(Config.Zones) do
        if #(coords - z.coords) <= z.radius then
            return true, zId
        end
    end
    return false, nil
end

-- ============================================================================
-- PROP DA VARA DE PESCA
-- ============================================================================

local function AttachFishingRod(ped)
    if fishingRodProp then
        if DoesEntityExist(fishingRodProp) then
            DetachEntity(fishingRodProp, true, true)
            DeleteEntity(fishingRodProp)
        end
        fishingRodProp = nil
    end
    lib.requestModel(ROD_MODEL)
    fishingRodProp = CreateObject(ROD_MODEL, 0.0, 0.0, 0.0, true, true, false)
    AttachEntityToEntity(fishingRodProp, ped, GetPedBoneIndex(ped, 18905),
        0.06, 0.01, -0.05, 290.0, 80.0, 5.0, true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(ROD_MODEL)
end

local function DetachFishingRod()
    if fishingRodProp then
        if DoesEntityExist(fishingRodProp) then
            DetachEntity(fishingRodProp, true, true)
            DeleteEntity(fishingRodProp)
        end
        fishingRodProp = nil
    end
    local ped = PlayerPedId()
    local obj = GetEntityAttachedTo(ped)
    if obj and obj ~= 0 and DoesEntityExist(obj) then
        if GetEntityModel(obj) == ROD_MODEL then
            DetachEntity(obj, true, true)
            DeleteEntity(obj)
        end
    end
end

-- ============================================================================
-- FORMATAR TEMPO
-- ============================================================================

local function formatTime(ms)
    local totalSec = math.floor(ms / 1000)
    local min = math.floor(totalSec / 60)
    local sec = totalSec % 60
    return string.format('%02d:%02d', min, sec)
end

-- ============================================================================
-- HUD AFK (NUI — painel estilizado com cores do projeto)
-- ============================================================================

local afkHudVisible = false
local afkMaxTimeMs = 0
local afkLastCatch = nil
local afkFishEscaped = 0
local afkNextBiteAt = 0
local afkRodBait = ''

local function UpdateAFKHud(fishCaught, timeRemaining, status, statusType)
    local progress = 100
    if afkMaxTimeMs > 0 and timeRemaining > 0 then
        progress = math.max(0, math.min(100, (timeRemaining / afkMaxTimeMs) * 100))
    end

    local nextBiteStr = '--'
    if afkNextBiteAt > 0 then
        local remaining = afkNextBiteAt - GetGameTimer()
        if remaining > 0 then
            nextBiteStr = formatTime(remaining)
        else
            nextBiteStr = 'Agora!'
        end
    end

    SendNUIMessage({
        action = 'updateAFKHud',
        fishCaught = fishCaught,
        fishEscaped = afkFishEscaped,
        timeRemaining = afkMaxTimeMs > 0 and formatTime(timeRemaining) or '∞',
        nextBite = nextBiteStr,
        lastCatch = afkLastCatch,
        rodBait = afkRodBait,
        status = status or 'Aguardando...',
        statusType = statusType or 'idle',
        progress = progress,
    })
    afkHudVisible = true
end

local function ShowAFKHud()
    SendNUIMessage({ action = 'showAFKHud' })
    afkHudVisible = true
end

local function HideAFKHud()
    SendNUIMessage({ action = 'hideAFKHud' })
    afkHudVisible = false
    afkLastCatch = nil
    afkFishEscaped = 0
    afkNextBiteAt = 0
    afkRodBait = ''
end

-- ============================================================================
-- SAFE CLEANUP — funcao UNICA que SEMPRE libera o jogador
-- Chamada em: StopAFKFishing, CancelFishing, fim do loop AFK,
--             fim do DoCastSequence, onResourceStop, onResourceStart
-- ============================================================================

function SafeCleanup()
    DetachFishingRod()
    HideAFKHud()
    local ped = PlayerPedId()
    ClearPedTasksImmediately(ped)
    ClearPedTasks(ped)
    ClearPedSecondaryTask(ped)
    FreezeEntityPosition(ped, false)
    SetEntityCollision(ped, true, true)
    SetPlayerControl(PlayerId(), true, 0)
end

-- ============================================================================
-- INTERACAO COM ox_target NA ZONA (pescar)
-- ============================================================================

CreateThread(function()
    for zoneId, zone in pairs(Config.Zones) do
        exports.ox_target:addSphereZone({
            coords = zone.coords,
            radius = zone.radius,
            debug = Config.Debug,
            options = {
                {
                    name = 'fishing_start_' .. zoneId,
                    icon = 'fas fa-fish',
                    label = 'Pescar',
                    canInteract = function()
                        return not FishingState.isFishing and not FishingState.isAFK
                    end,
                    onSelect = function()
                        StartFishing()
                    end,
                },
                {
                    name = 'fishing_afk_' .. zoneId,
                    icon = 'fas fa-clock',
                    label = 'Pescar Automaticamente',
                    canInteract = function()
                        return not FishingState.isFishing and not FishingState.isAFK and Config.AFKFishing.enabled
                    end,
                    onSelect = function()
                        StartAFKFishing()
                    end,
                },
                {
                    name = 'fishing_stop_' .. zoneId,
                    icon = 'fas fa-hand',
                    label = 'Guardar Vara',
                    canInteract = function()
                        return FishingState.isFishing or FishingState.isAFK
                    end,
                    onSelect = function()
                        if FishingState.isAFK then
                            StopAFKFishing('Voce guardou a vara')
                        elseif FishingState.isFishing then
                            CancelFishing('Voce guardou a vara')
                        end
                    end,
                },
            },
        })
    end
end)

-- ============================================================================
-- INICIAR PESCA MANUAL
-- ============================================================================

function StartFishing()
    if FishingState.isFishing or FishingState.isAFK then
        lib.notify({ title = 'Pesca', description = 'Voce ja esta pescando', type = 'error' })
        return
    end

    local inZone, zoneId = isPlayerInAnyZone()
    if not inZone then
        lib.notify({ title = 'Pesca', description = 'Voce nao esta na zona de pesca', type = 'error' })
        return
    end
    FishingState.inZone = true
    FishingState.currentZone = zoneId

    local now = GetGameTimer() / 1000
    if now - lastCastTime < Config.Cooldowns.castMin then
        lib.notify({ title = 'Pesca', description = 'Aguarde antes de pescar novamente', type = 'error' })
        return
    end

    local zone = Config.Zones[FishingState.currentZone]
    if not zone then return end

    CreateThread(function()
        lib.notify({ title = 'Pesca', description = 'Verificando equipamento...', type = 'inform', duration = 2000 })
        local equipment = lib.callback.await('fishing:server:validateEquipment', false)
        if not equipment or not equipment.valid then
            lib.notify({ title = 'Pesca', description = equipment and equipment.message or 'Equipamento invalido - precisa de vara e isca', type = 'error', duration = 5000 })
            return
        end

        FishingState.rod = equipment.rod
        FishingState.bait = equipment.bait

        local level = lib.callback.await('fishing:server:getPlayerLevel', false)
        if (level or 1) < zone.minLevel then
            lib.notify({ title = 'Pesca', description = string.format('Nivel %d necessario para esta zona', zone.minLevel), type = 'error' })
            return
        end

        local weather = GetCurrentWeather()
        if Config.WeatherModifiers[weather] and Config.WeatherModifiers[weather].blocked then
            lib.notify({ title = 'Pesca', description = 'Nao e possivel pescar durante tempestade', type = 'error' })
            return
        end

        lastCastTime = GetGameTimer() / 1000
        DoCastSequence()
    end)
end

-- ============================================================================
-- SEQUENCIA DE PESCA MANUAL
-- ============================================================================

function DoCastSequence()
    local ped = PlayerPedId()
    FishingState.isFishing = true

    AttachFishingRod(ped)

    -- FASE 1: Casting
    PlaySound(Config.Sounds.cast)
    lib.requestAnimDict(Config.Anims.cast.dict)
    TaskPlayAnim(ped, Config.Anims.cast.dict, Config.Anims.cast.clip, 8.0, -8.0, 2000, 0, 0, false, false, false)
    Wait(2000)

    if not FishingState.isFishing then SafeCleanup() return end

    -- FASE 2: Idle (esperar peixe)
    ped = PlayerPedId()
    lib.requestAnimDict(Config.Anims.idle.dict)
    TaskPlayAnim(ped, Config.Anims.idle.dict, Config.Anims.idle.clip, 8.0, -8.0, -1, 1, 0, false, false, false)

    local waitTime = math.random(3000, 8000)
    Wait(waitTime)

    if not FishingState.isFishing then SafeCleanup() return end

    -- FASE 3: Bite!
    PlaySound(Config.Sounds.bite)
    lib.notify({ title = 'Pesca', description = 'Um peixe mordeu! Prepare-se!', type = 'success', duration = 2000 })
    Wait(1000)

    if not FishingState.isFishing then SafeCleanup() return end

    -- FASE 4: Determinar peixe
    local fishData = lib.callback.await('fishing:server:determineFish', false, FishingState.currentZone, FishingState.rod, FishingState.bait, GetTimeOfDay(), GetCurrentWeather())

    if not fishData then
        CancelFishing('Nenhum peixe encontrado')
        return
    end

    if not FishingState.isFishing then SafeCleanup() return end

    -- FASE 5: Minigame skillCheck
    ped = PlayerPedId()
    ClearPedTasks(ped)
    lib.requestAnimDict(Config.Anims.reel.dict)
    TaskPlayAnim(ped, Config.Anims.reel.dict, Config.Anims.reel.clip, 8.0, -8.0, -1, 1, 0, false, false, false)

    local rodConfig = Config.Rods[FishingState.rod] or Config.Rods.fishingrod
    local rarityOrder = (Config.Rarity[fishData.rarity] or {}).order or 1
    local levelBonus = (rodConfig.rarityBonus or 0)
    local diffConfig = Config.MinigameDifficulty[fishData.rarity] or Config.MinigameDifficulty.common
    local numInputs = diffConfig.inputs or math.min(1 + rarityOrder, 6)
    local zoneSize = math.max(15, math.floor(60 * (diffConfig.zoneMult or 1.0)) + math.floor(levelBonus * 20))

    local difficulties = {}
    local baseSpeed = 0.3 + ((diffConfig.pullMult or 1.0) * 0.08)
    for i = 1, numInputs do
        local size = math.max(12, zoneSize - ((i - 1) * 3))
        difficulties[i] = { areaSize = size, speedMultiplier = baseSpeed + ((i - 1) * 0.04) }
    end

    lib.notify({
        title = fishData.label,
        description = string.format('%s - Acerte os inputs!', (Config.Rarity[fishData.rarity] or {}).label or 'Comum'),
        type = 'inform',
        duration = 3000,
    })

    Wait(2000)

    if not FishingState.isFishing then SafeCleanup() return end

    local success = lib.skillCheck(difficulties, { '1', '2', '3', '4' })

    if not FishingState.isFishing then SafeCleanup() return end

    if success then
        -- FASE 6: Puxar peixe
        ped = PlayerPedId()
        ClearPedTasks(ped)

        if lib.progressBar({
            duration = 5000,
            label = 'Puxando o peixe...',
            useWhileDead = false,
            canCancel = true,
            disable = { car = true, move = true, combat = true },
            anim = { dict = Config.Anims.reel.dict, clip = Config.Anims.reel.clip, flag = 1 },
        }) then
            if not FishingState.isFishing then SafeCleanup() return end

            local catchResult = lib.callback.await('fishing:server:catchFish', false, fishData, FishingState.currentZone, FishingState.rod, FishingState.bait)

            if catchResult and catchResult.success then
                PlaySound(Config.Sounds.catch)
                lib.notify({ title = 'Pesca', description = string.format('Pescou: %s (%dg)', catchResult.label or 'Peixe', catchResult.weight or 0), type = 'success', duration = 4000 })
                ShowCatchScreen(catchResult)

                if catchResult.wantedLevel and catchResult.wantedLevel > 0 then
                    SetPlayerWantedLevel(PlayerId(), catchResult.wantedLevel, false)
                    SetPlayerWantedLevelNow(PlayerId(), false)
                    lib.notify({ title = 'Zona Proibida', description = 'A policia foi alertada!', type = 'error', duration = 5000 })
                end

                local catchRarityOrder = (Config.Rarity[catchResult.rarity] or {}).order or 1
                if catchRarityOrder >= 3 then
                    Wait(500)
                    ped = PlayerPedId()
                    lib.requestAnimDict(Config.Anims.celebrate.dict)
                    FreezeEntityPosition(ped, true)
                    TaskPlayAnim(ped, Config.Anims.celebrate.dict, Config.Anims.celebrate.clip, 8.0, -8.0, 2000, 1, 0, false, false, false)
                    Wait(2000)
                    FreezeEntityPosition(ped, false)
                end
            else
                lib.notify({ title = 'Pesca', description = catchResult and catchResult.message or 'Erro ao pescar', type = 'error' })
            end
        end

        FishingState.isFishing = false
        SafeCleanup()
    else
        -- Falha no minigame
        PlaySound(Config.Sounds.fail)
        lib.notify({ title = 'Pesca', description = 'O peixe escapou!', type = 'error' })
        FishingState.isFishing = false
        SafeCleanup()

        -- Consumir isca (fire-and-forget)
        local bait = FishingState.bait
        CreateThread(function()
            lib.callback.await('fishing:server:consumeBait', false, bait)
        end)
    end
end

-- ============================================================================
-- CANCELAR PESCA MANUAL
-- ============================================================================

function CancelFishing(reason)
    if not FishingState.isFishing then return end
    FishingState.isFishing = false
    SafeCleanup()
    CloseMinigame()
    if reason then
        lib.notify({ title = 'Pesca', description = reason, type = 'inform' })
    end
end

-- ============================================================================
-- PESCA AFK (VIP)
-- Regras:
--   1. ZERO chamadas bloqueantes dentro do loop
--   2. ZERO FreezeEntityPosition(true) no jogador
--   3. ZERO SetPlayerControl(false)
--   4. Server calls via TriggerServerEvent (fire-and-forget)
--   5. Resultado do server volta via RegisterNetEvent
--   6. Wait maximo de 500ms por ciclo (saida rapida)
-- ============================================================================

-- Resultado pendente do server (preenchido via evento)
local afkPendingCatch = nil
local afkCatchReceived = false

-- Evento: server envia resultado da pesca AFK
RegisterNetEvent('fishing:client:afkCatchResult', function(result)
    afkPendingCatch = result
    afkCatchReceived = true
end)

function StartAFKFishing()
    if FishingState.isFishing or FishingState.isAFK then
        lib.notify({ title = 'Pesca', description = 'Voce ja esta pescando', type = 'error' })
        return
    end

    local inZone, zoneId = isPlayerInAnyZone()
    -- print('^3[PESCA-AFK-DEBUG]^0 isPlayerInAnyZone retornou: ' .. tostring(inZone) .. ' zona: ' .. tostring(zoneId))
    if not inZone then
        lib.notify({ title = 'Pesca', description = 'Voce nao esta na zona de pesca (client)', type = 'error' })
        return
    end
    FishingState.inZone = true
    FishingState.currentZone = zoneId

    CreateThread(function()
        -- Unica chamada bloqueante: validacao inicial (ANTES do loop)
        -- print('^3[PESCA-AFK-DEBUG]^0 Chamando server:startAFK com zona: ' .. tostring(FishingState.currentZone))
        local ok, result = pcall(lib.callback.await, 'fishing:server:startAFK', false, FishingState.currentZone)

        -- print('^3[PESCA-AFK-DEBUG]^0 Server respondeu: ok=' .. tostring(ok) .. ' allowed=' .. tostring(result and result.allowed) .. ' msg=' .. tostring(result and result.message))
        if not ok or not result or not result.allowed then
            lib.notify({ title = 'Pesca', description = (result and result.message) or 'Nao permitido (server)', type = 'error' })
            return
        end

        FishingState.isAFK = true
        FishingState.isFishing = true
        FishingState.rod = result.rod
        FishingState.bait = result.bait

        local intervalMs = result.interval * 1000
        local maxTimeMs = result.maxTime > 0 and (result.maxTime * 60 * 1000) or 0 -- 0 = sem limite
        local startTime = GetGameTimer()
        local fishCaught = 0
        local fishEscaped = 0

        afkMaxTimeMs = maxTimeMs
        afkFishEscaped = 0
        afkLastCatch = nil
        afkNextBiteAt = 0

        -- Labels da vara e isca
        local rodLabel = (Config.Rods[result.rod] and Config.Rods[result.rod].label) or result.rod or 'Vara'
        local baitLabel = (Config.Baits and Config.Baits[result.bait] and Config.Baits[result.bait].label) or result.bait or 'Isca'
        afkRodBait = rodLabel .. ' + ' .. baitLabel

        ShowAFKHud()
        local afkDesc = result.maxTime > 0 and string.format('Pescando automaticamente por ate %d min', result.maxTime) or 'Pescando automaticamente (para quando inventario encher)'
        SendNUIMessage({ action = 'afkNotify', title = 'Pesca AFK', description = afkDesc, type = 'success', duration = 4000 })

        -- Animacao idle
        local ped = PlayerPedId()
        AttachFishingRod(ped)
        ClearPedTasks(ped)
        lib.requestAnimDict(Config.Anims.idle.dict)
        TaskPlayAnim(ped, Config.Anims.idle.dict, Config.Anims.idle.clip, 8.0, -8.0, -1, 1, 0, false, false, false)

        local startCoords = GetEntityCoords(ped)
        local currentStatus = 'Aguardando...'
        local nextBiteAt = GetGameTimer() + intervalMs
        afkNextBiteAt = nextBiteAt

        -- ================================================================
        -- LOOP PRINCIPAL — espera curta (500ms), checa flags, zero bloqueio
        -- ================================================================
        while FishingState.isAFK do
            Wait(500)

            local now = GetGameTimer()
            local elapsed = now - startTime
            local timeRemaining = maxTimeMs > 0 and math.max(0, maxTimeMs - elapsed) or 0

            -- Atualizar HUD
            UpdateAFKHud(fishCaught, timeRemaining, currentStatus, 'idle')

            -- Check: tempo maximo (so se maxTimeMs > 0, senao e ilimitado)
            if maxTimeMs > 0 and elapsed >= maxTimeMs then
                break
            end

            -- Check: saiu do lugar
            local currentCoords = GetEntityCoords(PlayerPedId())
            local moveDist = #(currentCoords - startCoords)
            if moveDist > 5.0 then
                -- print(('[PESCA-AFK] PAROU: jogador moveu %.1fm (max 5m)'):format(moveDist))
                break
            end

            -- Check: saiu da zona (desabilitado — o check de 5m ja cobre isso)
            -- O onExit da zona nao reseta inZone durante AFK

            -- Aguardar intervalo entre mordidas
            if now < nextBiteAt then
                goto continue
            end

            -- ============ MORDIDA ============
            currentStatus = 'Mordida!'
            UpdateAFKHud(fishCaught, math.max(0, maxTimeMs - (GetGameTimer() - startTime)), 'Mordida!', 'bite')
            PlaySound(Config.Sounds.bite)
            SendNUIMessage({ action = 'afkNotify', title = 'Mordida!', description = 'Um peixe mordeu a isca!', type = 'bite', duration = 2500 })

            -- Animacao de puxar (nao bloqueia)
            ped = PlayerPedId()
            if FishingState.isAFK then
                ClearPedTasksImmediately(ped)
                lib.requestAnimDict(Config.Anims.reel.dict)
                TaskPlayAnim(ped, Config.Anims.reel.dict, Config.Anims.reel.clip, 8.0, -8.0, 3000, 1, 0, false, false, false)
            end

            -- Esperar 3s de animacao (em ciclos curtos)
            local animEnd = GetGameTimer() + 3000
            while GetGameTimer() < animEnd and FishingState.isAFK do
                Wait(500)
                UpdateAFKHud(fishCaught, math.max(0, maxTimeMs - (GetGameTimer() - startTime)), 'Puxando o peixe...', 'bite')
            end
            if not FishingState.isAFK then
                -- print('[PESCA-AFK] PAROU: FishingState.isAFK ficou false durante animacao puxar')
                break
            end

            -- ============ RESULTADO ============
            if math.random(1, 100) <= 85 then
                currentStatus = 'Pescou!'
                UpdateAFKHud(fishCaught, math.max(0, maxTimeMs - (GetGameTimer() - startTime)), 'Pescou!', 'caught')

                -- Fire-and-forget: pede resultado ao server
                afkCatchReceived = false
                afkPendingCatch = nil
                TriggerServerEvent('fishing:server:afkCatchRequest',
                    FishingState.currentZone, FishingState.rod, FishingState.bait,
                    GetTimeOfDay(), GetCurrentWeather())

                -- Esperar resposta do server (max 5s, ciclos de 200ms)
                local waitEnd = GetGameTimer() + 5000
                while not afkCatchReceived and FishingState.isAFK and GetGameTimer() < waitEnd do
                    Wait(200)
                end

                if not FishingState.isAFK then
                    -- print('[PESCA-AFK] PAROU: FishingState.isAFK ficou false esperando server')
                    break
                end

                -- print(('[PESCA-AFK] Server respondeu: received=%s success=%s msg=%s'):format(
                --     tostring(afkCatchReceived),
                --     tostring(afkPendingCatch and afkPendingCatch.success),
                --     tostring(afkPendingCatch and afkPendingCatch.message)))

                if afkCatchReceived and afkPendingCatch and afkPendingCatch.success then
                    -- Peixe pego! (ou pulo: label='Nada'/'Limite/hora')
                    local catchWeight = afkPendingCatch.weight or 0
                    local catchLabel = afkPendingCatch.label or 'Peixe'

                    if catchWeight > 0 then
                        fishCaught = fishCaught + 1
                        afkLastCatch = string.format('%s %dg', catchLabel, catchWeight)
                        PlaySound(Config.Sounds.catch)
                        SendNUIMessage({
                            action = 'afkNotify',
                            title = 'Pescou!',
                            description = string.format('%s (%dg)', catchLabel, catchWeight),
                            type = 'success',
                            duration = 3500,
                        })
                        lib.notify({ title = 'Pesca', description = string.format('Pescou: %s (%dg)', catchLabel, catchWeight), type = 'success', duration = 3000 })

                        -- Animacao de celebracao (fixo no lugar)
                        ped = PlayerPedId()
                        if FishingState.isAFK then
                            ClearPedTasksImmediately(ped)
                            FreezeEntityPosition(ped, true)
                            lib.requestAnimDict(Config.Anims.celebrate.dict)
                            TaskPlayAnim(ped, Config.Anims.celebrate.dict, Config.Anims.celebrate.clip, 4.0, -4.0, 2500, 1, 0, false, false, false)
                        end

                        local celebEnd = GetGameTimer() + 2500
                        while GetGameTimer() < celebEnd and FishingState.isAFK do
                            Wait(500)
                        end
                        FreezeEntityPosition(PlayerPedId(), false)
                    end
                    -- Se weight=0 (Nada/Limite), continua sem parar
                elseif afkCatchReceived and afkPendingCatch and not afkPendingCatch.success then
                    -- Server recusou: verificar se e motivo FATAL (parar) ou temporario (continuar)
                    local stopMsg = afkPendingCatch.message or 'Pesca AFK encerrada'
                    local fatalReasons = { 'Inventario cheio', 'Iscas acabaram', 'Limite diario atingido', 'Sessao AFK encerrada' }
                    local isFatal = false
                    for _, reason in ipairs(fatalReasons) do
                        if stopMsg == reason then
                            isFatal = true
                            break
                        end
                    end

                    if isFatal then
                        PlaySound(Config.Sounds.fail)
                        SendNUIMessage({ action = 'afkNotify', title = 'Pesca AFK Parou', description = stopMsg, type = 'error', duration = 5000 })
                        lib.notify({ title = 'Pesca AFK', description = stopMsg, type = 'error', duration = 5000 })
                        break
                    end
                    -- Motivo nao-fatal: continua pescando
                end
                -- Se nao recebeu resposta (timeout): continua sem parar
            else
                -- print('[PESCA-AFK] Peixe escapou — continuando...')
                fishEscaped = fishEscaped + 1
                afkFishEscaped = fishEscaped
                currentStatus = 'Escapou!'
                UpdateAFKHud(fishCaught, math.max(0, maxTimeMs - (GetGameTimer() - startTime)), 'Escapou!', 'escaped')
                PlaySound(Config.Sounds.fail)
                SendNUIMessage({ action = 'afkNotify', title = 'Escapou!', description = 'O peixe fugiu...', type = 'error', duration = 2500 })

                -- Consumir isca (fire-and-forget)
                TriggerServerEvent('fishing:server:consumeBaitEvent', FishingState.bait)

                -- Pequena espera
                local escapeEnd = GetGameTimer() + 1500
                while GetGameTimer() < escapeEnd and FishingState.isAFK do
                    Wait(500)
                end
            end

            if not FishingState.isAFK then
                -- print('[PESCA-AFK] PAROU: FishingState.isAFK ficou false durante resultado')
                break
            end

            -- Voltar pra idle
            currentStatus = 'Aguardando...'
            ped = PlayerPedId()
            if FishingState.isAFK then
                ClearPedTasksImmediately(ped)
                lib.requestAnimDict(Config.Anims.idle.dict)
                TaskPlayAnim(ped, Config.Anims.idle.dict, Config.Anims.idle.clip, 8.0, -8.0, -1, 1, 0, false, false, false)
            end

            -- Proximo intervalo
            nextBiteAt = GetGameTimer() + intervalMs
            afkNextBiteAt = nextBiteAt

            ::continue::
        end

        -- ================================================================
        -- FINALIZACAO — SEMPRE roda, SEMPRE libera o jogador
        -- ================================================================
        -- print(('[PESCA-AFK] === FINALIZOU === Pescados: %d | Escaparam: %d'):format(fishCaught, fishEscaped))
        FishingState.isAFK = false
        FishingState.isFishing = false
        SafeCleanup()
        TriggerServerEvent('fishing:server:stopAFK')

        -- Resumo
        if fishCaught > 0 or fishEscaped > 0 then
            lib.notify({
                title = 'Pesca AFK - Resumo',
                description = string.format('Pescados: %d | Escaparam: %d | Tempo: %s', fishCaught, fishEscaped, formatTime(GetGameTimer() - startTime)),
                type = 'inform',
                duration = 8000,
            })
        end
    end)
end

-- ============================================================================
-- PARAR PESCA AFK (chamado por F5/guardarvara/ox_target)
-- Simples: seta flag false + cleanup imediato. O loop sai sozinho.
-- ============================================================================

function StopAFKFishing(reason)
    if not FishingState.isAFK then return end
    FishingState.isAFK = false
    FishingState.isFishing = false
    SafeCleanup()
    TriggerServerEvent('fishing:server:stopAFK')
    if reason then
        SendNUIMessage({ action = 'afkNotify', title = 'Pesca AFK', description = reason, type = 'info', duration = 3500 })
    end
end

-- ============================================================================
-- EXPORT: Permite outros resources verificar se esta pescando
-- ============================================================================

exports('GetFishingState', function()
    return FishingState
end)

-- ============================================================================
-- CLEANUP DE RESOURCE
-- ============================================================================

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    FishingState.isFishing = false
    FishingState.isAFK = false
    FishingState.inZone = false
    SafeCleanup()
end)

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    SafeCleanup()
end)
