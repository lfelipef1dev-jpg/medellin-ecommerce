-- ============================================================================
-- fishing: Client Nets - Redes e varas plantadas (props, target, blips)
-- ============================================================================

local netProps = {}       -- [netId] = entityHandle
local rodProps = {}       -- [rodId] = entityHandle
local netBlips = {}       -- [netId] = blipHandle
local rodBlips = {}       -- [rodId] = blipHandle
local netTargets = {}     -- [netId] = targetName
local rodTargets = {}     -- [rodId] = targetName

local NET_PROP_MODEL = 'prop_fish_net_01'
local ROD_PROP_MODEL = 'prop_fishing_rod_01'

-- ============================================================================
-- HELPER: Criar prop de rede/vara
-- ============================================================================

local function createNetProp(coords, netId)
    local hash = joaat(NET_PROP_MODEL)
    lib.requestModel(hash)

    local obj = CreateObject(hash, coords.x, coords.y, coords.z - 0.5, false, true, false)
    if obj and obj ~= 0 then
        SetEntityAsMissionEntity(obj, true, true)
        FreezeEntityPosition(obj, true)
        SetEntityCollision(obj, false, false)
        PlaceObjectOnGroundProperly(obj)
        netProps[netId] = obj
    end
    SetModelAsNoLongerNeeded(hash)
    return obj
end

local function createRodProp(coords, rodId)
    local hash = joaat(ROD_PROP_MODEL)
    lib.requestModel(hash)

    local obj = CreateObject(hash, coords.x, coords.y, coords.z - 0.3, false, true, false)
    if obj and obj ~= 0 then
        SetEntityAsMissionEntity(obj, true, true)
        FreezeEntityPosition(obj, true)
        SetEntityCollision(obj, false, false)
        SetEntityRotation(obj, -45.0, 0.0, math.random(0, 360) * 1.0, 2, true)
        rodProps[rodId] = obj
    end
    SetModelAsNoLongerNeeded(hash)
    return obj
end

-- ============================================================================
-- HELPER: Criar blip para rede/vara do jogador
-- ============================================================================

local function createNetBlip(coords, netId, ready)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, 366) -- net icon
    SetBlipScale(blip, 0.6)
    SetBlipColour(blip, ready and 2 or 1) -- verde se pronta, vermelho se nao
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(ready and 'Rede Pronta!' or 'Rede de Pesca')
    EndTextCommandSetBlipName(blip)
    netBlips[netId] = blip
    return blip
end

local function createRodBlip(coords, rodId, fishCount)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, 317) -- fishing icon
    SetBlipScale(blip, 0.6)
    SetBlipColour(blip, fishCount > 0 and 2 or 3) -- verde se tem peixe, azul se vazio
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(string.format('Vara Plantada (%d peixes)', fishCount))
    EndTextCommandSetBlipName(blip)
    rodBlips[rodId] = blip
    return blip
end

-- ============================================================================
-- PLANTAR REDE
-- ============================================================================

function PlaceNet(netItem)
    if not FishingState.inZone or not FishingState.currentZone then
        lib.notify({ title = 'Pesca', description = 'Voce precisa estar em uma zona de pesca', type = 'error' })
        return
    end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    -- Animacao de plantar
    lib.requestAnimDict('anim@heists@narcotics@funding@gang_idle')
    TaskPlayAnim(ped, 'anim@heists@narcotics@funding@gang_idle', 'gang_chatting_idle01', 8.0, -8.0, 3000, 1, 0, false, false, false)

    local success = lib.progressBar({
        duration = 5000,
        label = 'Plantando rede...',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
        anim = {
            dict = 'anim@heists@narcotics@funding@gang_idle',
            clip = 'gang_chatting_idle01',
        },
    })

    ClearPedTasks(ped)

    if not success then
        lib.notify({ title = 'Pesca', description = 'Cancelado', type = 'error' })
        return
    end

    -- Posicao a frente do jogador
    local forward = GetEntityForwardVector(ped)
    local netCoords = coords + forward * 3.0
    netCoords = vector3(netCoords.x, netCoords.y, coords.z - 1.0)

    local result = lib.callback.await('fishing:server:placeNet', false,
        netItem, FishingState.currentZone, netCoords)

    if result and result.success then
        lib.notify({ title = 'Pesca', description = result.message, type = 'success', duration = 5000 })
        PlaySound(Config.Sounds.cast)

        -- Criar prop e blip
        local netId = tostring(result.netId)
        createNetProp(netCoords, netId)
        createNetBlip(netCoords, netId, false)

        -- Adicionar ox_target
        if netProps[netId] and DoesEntityExist(netProps[netId]) then
            local targetName = 'fishing_net_' .. netId
            exports.ox_target:addLocalEntity(netProps[netId], {
                {
                    name = targetName,
                    icon = 'fas fa-fish',
                    label = 'Coletar Rede',
                    distance = 3.0,
                    onSelect = function()
                        CollectNet(tonumber(netId))
                    end,
                },
            })
            netTargets[netId] = targetName
        end
    else
        lib.notify({ title = 'Pesca', description = result and result.message or 'Erro', type = 'error' })
    end
end

-- ============================================================================
-- COLETAR REDE
-- ============================================================================

function CollectNet(netId)
    local ped = PlayerPedId()

    local success = lib.progressBar({
        duration = 3000,
        label = 'Coletando rede...',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
        anim = {
            dict = 'anim@heists@narcotics@funding@gang_idle',
            clip = 'gang_chatting_idle01',
        },
    })

    ClearPedTasks(ped)

    if not success then return end

    local result = lib.callback.await('fishing:server:collectNet', false, netId)

    if result and result.success then
        lib.notify({ title = 'Pesca', description = result.message, type = 'success', duration = 5000 })
        PlaySound(Config.Sounds.catch)

        local netIdStr = tostring(netId)

        if result.broken then
            -- Rede quebrou, remover tudo
            RemoveNetProp(netIdStr)
        else
            -- Rede ainda tem usos, atualizar blip
            if netBlips[netIdStr] and DoesBlipExist(netBlips[netIdStr]) then
                SetBlipColour(netBlips[netIdStr], 1) -- vermelho (cooldown)
            end
        end
    else
        lib.notify({ title = 'Pesca', description = result and result.message or 'Erro', type = 'error' })
    end
end

-- ============================================================================
-- PLANTAR VARA
-- ============================================================================

function PlacePlantedRod()
    if not FishingState.inZone or not FishingState.currentZone then
        lib.notify({ title = 'Pesca', description = 'Voce precisa estar em uma zona de pesca', type = 'error' })
        return
    end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    local success = lib.progressBar({
        duration = 5000,
        label = 'Plantando vara...',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
        anim = {
            dict = 'amb@world_human_stand_fishing@idle_a',
            clip = 'idle_c',
        },
    })

    ClearPedTasks(ped)

    if not success then
        lib.notify({ title = 'Pesca', description = 'Cancelado', type = 'error' })
        return
    end

    local forward = GetEntityForwardVector(ped)
    local rodCoords = coords + forward * 2.0

    local result = lib.callback.await('fishing:server:placeRod', false,
        FishingState.currentZone, rodCoords)

    if result and result.success then
        lib.notify({ title = 'Pesca', description = result.message, type = 'success', duration = 5000 })
        PlaySound(Config.Sounds.cast)

        local rodId = tostring(result.rodId)
        createRodProp(rodCoords, rodId)
        createRodBlip(rodCoords, rodId, 0)

        -- Adicionar ox_target
        if rodProps[rodId] and DoesEntityExist(rodProps[rodId]) then
            local targetName = 'fishing_rod_planted_' .. rodId
            exports.ox_target:addLocalEntity(rodProps[rodId], {
                {
                    name = targetName,
                    icon = 'fas fa-fish',
                    label = 'Coletar Vara Plantada',
                    distance = 3.0,
                    onSelect = function()
                        CollectPlantedRod(tonumber(rodId))
                    end,
                },
            })
            rodTargets[rodId] = targetName
        end
    else
        lib.notify({ title = 'Pesca', description = result and result.message or 'Erro', type = 'error' })
    end
end

-- ============================================================================
-- COLETAR VARA PLANTADA
-- ============================================================================

function CollectPlantedRod(rodId)
    local ped = PlayerPedId()

    local success = lib.progressBar({
        duration = 3000,
        label = 'Coletando vara plantada...',
        useWhileDead = false,
        canCancel = true,
        disable = { move = true, car = true, combat = true },
        anim = {
            dict = 'amb@world_human_stand_fishing@idle_a',
            clip = 'idle_a',
        },
    })

    ClearPedTasks(ped)

    if not success then return end

    local result = lib.callback.await('fishing:server:collectPlantedRod', false, rodId)

    if result and result.success then
        lib.notify({ title = 'Pesca', description = result.message, type = 'success', duration = 5000 })
        PlaySound(Config.Sounds.catch)

        local rodIdStr = tostring(rodId)
        RemoveRodProp(rodIdStr)
    else
        lib.notify({ title = 'Pesca', description = result and result.message or 'Erro', type = 'error' })
    end
end

-- ============================================================================
-- HELPERS: Remover props
-- ============================================================================

function RemoveNetProp(netId)
    if netProps[netId] and DoesEntityExist(netProps[netId]) then
        if netTargets[netId] then
            exports.ox_target:removeLocalEntity(netProps[netId], netTargets[netId])
            netTargets[netId] = nil
        end
        DeleteEntity(netProps[netId])
        netProps[netId] = nil
    end
    if netBlips[netId] and DoesBlipExist(netBlips[netId]) then
        RemoveBlip(netBlips[netId])
        netBlips[netId] = nil
    end
end

function RemoveRodProp(rodId)
    if rodProps[rodId] and DoesEntityExist(rodProps[rodId]) then
        if rodTargets[rodId] then
            exports.ox_target:removeLocalEntity(rodProps[rodId], rodTargets[rodId])
            rodTargets[rodId] = nil
        end
        DeleteEntity(rodProps[rodId])
        rodProps[rodId] = nil
    end
    if rodBlips[rodId] and DoesBlipExist(rodBlips[rodId]) then
        RemoveBlip(rodBlips[rodId])
        rodBlips[rodId] = nil
    end
end

-- ============================================================================
-- CARREGAR REDES/VARAS ATIVAS AO ENTRAR
-- ============================================================================

CreateThread(function()
    Wait(5000)

    local data = lib.callback.await('fishing:server:getAllActiveNetsAndRods', false)
    if not data then return end

    -- Criar props para redes proximas
    if data.nets then
        for _, net in ipairs(data.nets) do
            local netId = tostring(net.id)
            local coords = vector3(net.coords.x, net.coords.y, net.coords.z)
            createNetProp(coords, netId)

            if netProps[netId] and DoesEntityExist(netProps[netId]) then
                exports.ox_target:addLocalEntity(netProps[netId], {
                    {
                        name = 'fishing_net_' .. netId,
                        icon = 'fas fa-fish',
                        label = 'Coletar Rede',
                        distance = 3.0,
                        onSelect = function()
                            CollectNet(net.id)
                        end,
                    },
                })
                netTargets[netId] = 'fishing_net_' .. netId
            end
        end
    end

    -- Criar props para varas plantadas proximas
    if data.rods then
        for _, rod in ipairs(data.rods) do
            local rodId = tostring(rod.id)
            local coords = vector3(rod.coords.x, rod.coords.y, rod.coords.z)
            createRodProp(coords, rodId)

            if rodProps[rodId] and DoesEntityExist(rodProps[rodId]) then
                exports.ox_target:addLocalEntity(rodProps[rodId], {
                    {
                        name = 'fishing_rod_planted_' .. rodId,
                        icon = 'fas fa-fish',
                        label = 'Coletar Vara Plantada',
                        distance = 3.0,
                        onSelect = function()
                            CollectPlantedRod(rod.id)
                        end,
                    },
                })
                rodTargets[rodId] = 'fishing_rod_planted_' .. rodId
            end
        end
    end

    if Config.Debug then
        -- print(string.format('^3[fishing:nets]^0 Props carregados: %d redes, %d varas', #(data.nets or {}), #(data.rods or {})))
    end
end)

-- ============================================================================
-- THREAD: Atualizar blips do jogador (proprias redes/varas)
-- ============================================================================

CreateThread(function()
    Wait(10000)
    while true do
        Wait(60000) -- atualizar a cada 1 min

        local data = lib.callback.await('fishing:server:getPlayerNetsAndRods', false)
        if data then
            -- Atualizar blips de redes
            for _, net in ipairs(data.nets or {}) do
                local netId = tostring(net.id)
                if netBlips[netId] and DoesBlipExist(netBlips[netId]) then
                    SetBlipColour(netBlips[netId], net.ready and 2 or 1)
                else
                    local coords = vector3(net.coords.x, net.coords.y, net.coords.z)
                    createNetBlip(coords, netId, net.ready)
                end
            end

            -- Atualizar blips de varas
            for _, rod in ipairs(data.rods or {}) do
                local rodId = tostring(rod.id)
                if rodBlips[rodId] and DoesBlipExist(rodBlips[rodId]) then
                    SetBlipColour(rodBlips[rodId], rod.fishCount > 0 and 2 or 3)
                else
                    local coords = vector3(rod.coords.x, rod.coords.y, rod.coords.z)
                    createRodBlip(coords, rodId, rod.fishCount)
                end
            end
        end
    end
end)

-- ============================================================================
-- COMANDOS
-- ============================================================================

RegisterCommand('plantarrede', function()
    -- Verificar se tem rede no inventario
    local netItems = { 'fishingnet_legend', 'fishingnet_pro', 'fishingnet' }
    local bestNet = nil

    for _, netItem in ipairs(netItems) do
        local count = exports.ox_inventory:GetItemCount(netItem)
        if count and count > 0 then
            bestNet = netItem
            break
        end
    end

    if not bestNet then
        lib.notify({ title = 'Pesca', description = 'Voce nao tem nenhuma rede de pesca', type = 'error' })
        return
    end

    PlaceNet(bestNet)
end, false)

RegisterCommand('plantarvara', function()
    PlacePlantedRod()
end, false)

RegisterCommand('minhasredes', function()
    local data = lib.callback.await('fishing:server:getPlayerNetsAndRods', false)
    if not data then
        lib.notify({ title = 'Pesca', description = 'Erro ao carregar dados', type = 'error' })
        return
    end

    local options = {}

    -- Redes
    for _, net in ipairs(data.nets or {}) do
        local netConfig = Config.Nets[net.net_item] or {}
        local status = net.ready and '~g~Pronta!' or string.format('~r~%d min restante(s)', net.remainingMinutes)
        options[#options + 1] = {
            title = (netConfig.label or 'Rede') .. ' - ' .. (Config.Zones[net.zone_id] or {}).label or net.zone_id,
            description = string.format('Status: %s | Usos: %d', status, net.usesRemaining),
            icon = 'fas fa-border-all',
            iconColor = net.ready and '#00FF88' or '#e94560',
        }
    end

    -- Varas
    for _, rod in ipairs(data.rods or {}) do
        options[#options + 1] = {
            title = 'Vara Plantada - ' .. ((Config.Zones[rod.zone_id] or {}).label or rod.zone_id),
            description = string.format('Peixes: %d/%d', rod.fishCount, rod.maxBucket),
            icon = 'fas fa-fish',
            iconColor = rod.fishCount > 0 and '#00FF88' or '#48c9b0',
        }
    end

    if #options == 0 then
        lib.notify({ title = 'Pesca', description = 'Nenhuma rede ou vara ativa', type = 'inform' })
        return
    end

    lib.registerContext({
        id = 'fishing_my_nets',
        title = 'Minhas Redes e Varas',
        options = options,
    })
    lib.showContext('fishing_my_nets')
end, false)

-- ============================================================================
-- CLEANUP
-- ============================================================================

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    for netId in pairs(netProps) do
        RemoveNetProp(netId)
    end
    for rodId in pairs(rodProps) do
        RemoveRodProp(rodId)
    end
end)
