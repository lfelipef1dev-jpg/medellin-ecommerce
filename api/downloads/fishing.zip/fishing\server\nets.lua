-- ============================================================================
-- fishing: Server Nets - Redes plantaveis e varas plantadas
-- ============================================================================

-- Cache de redes e varas ativas
local activeNets = {}        -- [netId] = { citizenid, net_item, zone_id, coords, placed_at, collect_after, uses_remaining }
local activePlantedRods = {} -- [rodId] = { citizenid, rod_item, bait_item, zone_id, coords, fish_bucket, last_fish_at }
local playerNetCount = {}    -- [citizenid] = count
local playerRodCount = {}    -- [citizenid] = count (max 1)

-- ============================================================================
-- HELPERS
-- ============================================================================

local function getPlayer(source)
    return exports.qbx_core:GetPlayer(source)
end

local function getCitizenId(source)
    local Player = getPlayer(source)
    return Player and Player.PlayerData and Player.PlayerData.citizenid
end

local function getPlayerVIPTier(source)
    local Player = getPlayer(source)
    if not Player or not Player.PlayerData then return nil end
    local vip = Player.PlayerData.metadata and Player.PlayerData.metadata.vip
    if not vip or vip == false then return nil end
    return tostring(vip):lower()
end

local function isVIP(source)
    return getPlayerVIPTier(source) ~= nil
end

local function isInZone(source, zoneId)
    local Player = getPlayer(source)
    if not Player then return false end
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 then return false end
    local coords = GetEntityCoords(ped)
    local zone = Config.Zones[zoneId]
    if not zone then return false end
    return #(coords - zone.coords) <= zone.radius + (Config.AntiAbuse.maxDistanceFromZone or 15.0)
end

-- Roll fish for net (simplified, capped by rarity)
local function rollFishForNet(zoneId, maxRarity)
    local zone = Config.Zones[zoneId]
    if not zone then return nil end

    local fishList = Config.Fish[zone.waterType]
    if not fishList then return nil end

    local maxOrder = (Config.Rarity[maxRarity] or {}).order or 1

    local pool = {}
    local totalWeight = 0
    for _, fish in ipairs(fishList) do
        local order = (Config.Rarity[fish.rarity] or {}).order or 1
        if order <= maxOrder then
            totalWeight = totalWeight + fish.chance
            pool[#pool + 1] = { fish = fish, cumWeight = totalWeight }
        end
    end

    if #pool == 0 or totalWeight == 0 then return nil end

    local roll = math.random() * totalWeight
    for _, entry in ipairs(pool) do
        if roll <= entry.cumWeight then
            local fish = entry.fish
            return {
                item = fish.item,
                label = fish.label,
                rarity = fish.rarity,
                basePrice = fish.basePrice,
                xp = math.floor(fish.xp * 0.5), -- XP reduzido para pesca passiva
                weight = math.random(fish.weight[1], fish.weight[2]),
                size = math.random(fish.size[1], fish.size[2]),
            }
        end
    end
    return nil
end

-- ============================================================================
-- CARREGAR REDES E VARAS DO BANCO NA INICIALIZACAO
-- ============================================================================

CreateThread(function()
    Wait(3000)

    -- Carregar redes ativas
    local nets = MySQL.query.await('SELECT * FROM fishing_nets WHERE collected = 0')
    if nets then
        for _, net in ipairs(nets) do
            local netId = tostring(net.id)
            activeNets[netId] = {
                id = net.id,
                citizenid = net.citizenid,
                net_item = net.net_item,
                zone_id = net.zone_id,
                coords = vector3(net.coords_x, net.coords_y, net.coords_z),
                placed_at = net.placed_at,
                collect_after = net.collect_after,
                uses_remaining = net.uses_remaining,
            }
            playerNetCount[net.citizenid] = (playerNetCount[net.citizenid] or 0) + 1
        end
    end

    -- Carregar varas plantadas ativas
    local rods = MySQL.query.await('SELECT * FROM fishing_planted_rods WHERE active = 1')
    if rods then
        for _, rod in ipairs(rods) do
            local rodId = tostring(rod.id)
            local bucket = {}
            if rod.fish_bucket and rod.fish_bucket ~= '' then
                bucket = json.decode(rod.fish_bucket) or {}
            end
            activePlantedRods[rodId] = {
                id = rod.id,
                citizenid = rod.citizenid,
                rod_item = rod.rod_item,
                bait_item = rod.bait_item,
                zone_id = rod.zone_id,
                coords = vector3(rod.coords_x, rod.coords_y, rod.coords_z),
                fish_bucket = bucket,
                last_fish_at = rod.last_fish_at,
            }
            playerRodCount[rod.citizenid] = (playerRodCount[rod.citizenid] or 0) + 1
        end
    end

    if Config.Debug then
        local netCount, rodCount = 0, 0
        for _ in pairs(activeNets) do netCount = netCount + 1 end
        for _ in pairs(activePlantedRods) do rodCount = rodCount + 1 end
        -- print(string.format('^3[fishing:nets]^0 Carregadas %d redes e %d varas plantadas', netCount, rodCount))
    end
end)

-- ============================================================================
-- THREAD: Gerar peixes nas varas plantadas
-- ============================================================================

CreateThread(function()
    Wait(5000)
    while true do
        Wait(Config.PlantedRod.fishInterval * 1000)

        for rodId, rod in pairs(activePlantedRods) do
            local maxBucket = Config.PlantedRod.maxBucket
            -- Verificar se o jogador e VIP (via DB, nao via source)
            if #rod.fish_bucket < maxBucket then
                local fish = rollFishForNet(rod.zone_id, Config.PlantedRod.rarityMax)
                if fish then
                    rod.fish_bucket[#rod.fish_bucket + 1] = fish

                    -- Salvar bucket no banco
                    MySQL.update(
                        'UPDATE fishing_planted_rods SET fish_bucket = ?, last_fish_at = NOW() WHERE id = ?',
                        { json.encode(rod.fish_bucket), rod.id }
                    )

                    if Config.Debug then
                        -- print(string.format('^3[fishing:nets]^0 Vara %s: pescou %s (bucket: %d/%d)',
                        --     rodId, fish.label, #rod.fish_bucket, maxBucket))
                    end
                end
            end
        end
    end
end)

-- ============================================================================
-- AUTO-CLEANUP: Remover redes/varas antigas (24h)
-- ============================================================================

CreateThread(function()
    Wait(60000) -- esperar 1 min
    while true do
        Wait(1800000) -- a cada 30 min

        -- Cleanup redes com mais de 2h (degradacao)
        local now = os.time()
        for netId, net in pairs(activeNets) do
            MySQL.query('SELECT TIMESTAMPDIFF(HOUR, placed_at, NOW()) as hours FROM fishing_nets WHERE id = ?',
                { net.id }, function(result)
                    if result and result[1] and result[1].hours >= 2 then
                        -- Rede degradou
                        activeNets[netId] = nil
                        playerNetCount[net.citizenid] = math.max(0, (playerNetCount[net.citizenid] or 1) - 1)
                        MySQL.update('UPDATE fishing_nets SET collected = 1 WHERE id = ?', { net.id })
                        if Config.Debug then
                            -- print(string.format('^3[fishing:nets]^0 Rede %s degradou (>2h)', netId))
                        end
                    end
                end)
        end

        -- Cleanup varas plantadas com mais de 24h
        for rodId, rod in pairs(activePlantedRods) do
            MySQL.query('SELECT TIMESTAMPDIFF(HOUR, placed_at, NOW()) as hours FROM fishing_planted_rods WHERE id = ?',
                { rod.id }, function(result)
                    if result and result[1] and result[1].hours >= Config.PlantedRod.maxIdleHours then
                        activePlantedRods[rodId] = nil
                        playerRodCount[rod.citizenid] = math.max(0, (playerRodCount[rod.citizenid] or 1) - 1)
                        MySQL.update('UPDATE fishing_planted_rods SET active = 0 WHERE id = ?', { rod.id })
                        if Config.Debug then
                            -- print(string.format('^3[fishing:nets]^0 Vara %s expirou (>%dh)', rodId, Config.PlantedRod.maxIdleHours))
                        end
                    end
                end)
        end
    end
end)

-- ============================================================================
-- CALLBACK: Plantar Rede
-- ============================================================================

lib.callback.register('fishing:server:placeNet', function(source, netItem, zoneId, coords)
    if not netItem or not zoneId or not coords then
        return { success = false, message = 'Dados invalidos' }
    end

    local citizenid = getCitizenId(source)
    if not citizenid then
        return { success = false, message = 'Erro interno' }
    end

    -- Validar zona
    if not isInZone(source, zoneId) then
        return { success = false, message = 'Voce nao esta na zona de pesca' }
    end

    -- Verificar config da rede
    local netConfig = Config.Nets[netItem]
    if not netConfig then
        return { success = false, message = 'Rede invalida' }
    end

    -- Verificar nivel
    local level = GetPlayerLevel(source)
    if level < (netConfig.minLevel or 1) then
        return { success = false, message = string.format('Nivel %d necessario para usar %s', netConfig.minLevel, netConfig.label) }
    end

    -- Limite de redes por jogador
    local maxNets = isVIP(source) and 5 or 3
    local currentNets = playerNetCount[citizenid] or 0
    if currentNets >= maxNets then
        return { success = false, message = string.format('Limite de redes atingido (%d/%d)', currentNets, maxNets) }
    end

    -- Verificar inventario
    local count = exports.ox_inventory:GetItemCount(source, netItem)
    if not count or count < 1 then
        return { success = false, message = 'Voce nao tem essa rede' }
    end

    -- Consumir rede
    exports.ox_inventory:RemoveItem(source, netItem, 1)

    -- Calcular tempo de coleta
    local collectMinutes = netConfig.collectTime or 30
    local collectTime = os.time() + (collectMinutes * 60)

    -- Salvar no banco
    local netId = MySQL.insert.await([[
        INSERT INTO fishing_nets (citizenid, net_item, zone_id, coords_x, coords_y, coords_z, collect_after, uses_remaining)
        VALUES (?, ?, ?, ?, ?, ?, FROM_UNIXTIME(?), ?)
    ]], { citizenid, netItem, zoneId, coords.x, coords.y, coords.z, collectTime, netConfig.durability or 5 })

    if not netId then
        exports.ox_inventory:AddItem(source, netItem, 1)
        return { success = false, message = 'Erro ao plantar rede' }
    end

    -- Cache
    local netIdStr = tostring(netId)
    activeNets[netIdStr] = {
        id = netId,
        citizenid = citizenid,
        net_item = netItem,
        zone_id = zoneId,
        coords = vector3(coords.x, coords.y, coords.z),
        placed_at = os.time(),
        collect_after = collectTime,
        uses_remaining = netConfig.durability or 5,
    }
    playerNetCount[citizenid] = (playerNetCount[citizenid] or 0) + 1

    if Config.Debug then
        -- print(string.format('^3[fishing:nets]^0 %s plantou rede %s na zona %s (coleta em %d min)',
            citizenid, netItem, zoneId, collectMinutes))
    end

    return {
        success = true,
        netId = netId,
        collectTime = collectMinutes,
        message = string.format('Rede plantada! Colete em %d minutos', collectMinutes),
    }
end)

-- ============================================================================
-- CALLBACK: Coletar Rede
-- ============================================================================

lib.callback.register('fishing:server:collectNet', function(source, netId)
    if not netId then
        return { success = false, message = 'Dados invalidos' }
    end

    local netIdStr = tostring(netId)
    local net = activeNets[netIdStr]
    if not net then
        return { success = false, message = 'Rede nao encontrada' }
    end

    local citizenid = getCitizenId(source)
    if not citizenid or citizenid ~= net.citizenid then
        return { success = false, message = 'Esta rede nao e sua' }
    end

    -- Verificar tempo
    local now = os.time()
    if now < net.collect_after then
        local remaining = math.ceil((net.collect_after - now) / 60)
        return { success = false, message = string.format('Aguarde mais %d minuto(s)', remaining) }
    end

    -- Roll peixes
    local netConfig = Config.Nets[net.net_item]
    if not netConfig then
        return { success = false, message = 'Erro de configuracao' }
    end

    local maxFish = netConfig.maxFish or 3
    local caughtFish = {}
    local totalXP = 0

    for i = 1, maxFish do
        local fish = rollFishForNet(net.zone_id, netConfig.rarityMax or 'uncommon')
        if fish then
            local added = exports.ox_inventory:AddItem(source, fish.item, 1)
            if added then
                caughtFish[#caughtFish + 1] = fish
                totalXP = totalXP + fish.xp
                UpdatePlayerStats(source, fish)
                LogFishCatch(source, fish, net.zone_id, 'net')
            else
                break -- inventario cheio
            end
        end
    end

    -- XP
    if totalXP > 0 then
        AddPlayerXP(source, totalXP)
    end

    -- Atualizar usos
    net.uses_remaining = net.uses_remaining - 1

    if net.uses_remaining <= 0 then
        -- Rede quebrou
        activeNets[netIdStr] = nil
        playerNetCount[citizenid] = math.max(0, (playerNetCount[citizenid] or 1) - 1)
        MySQL.update('UPDATE fishing_nets SET collected = 1, uses_remaining = 0 WHERE id = ?', { net.id })
    else
        -- Reset timer para proxima coleta
        local collectMinutes = netConfig.collectTime or 30
        net.collect_after = os.time() + (collectMinutes * 60)
        MySQL.update(
            'UPDATE fishing_nets SET uses_remaining = ?, collect_after = FROM_UNIXTIME(?) WHERE id = ?',
            { net.uses_remaining, net.collect_after, net.id }
        )
    end

    -- Conquistas
    CheckStatAchievements(source, nil)

    if Config.Debug then
        -- print(string.format('^3[fishing:nets]^0 %s coletou rede %s: %d peixes, usos restantes: %d',
            citizenid, netIdStr, #caughtFish, net.uses_remaining or 0))
    end

    return {
        success = true,
        fish = caughtFish,
        totalXP = totalXP,
        usesRemaining = net.uses_remaining or 0,
        broken = (net.uses_remaining or 0) <= 0,
        message = string.format('Coletou %d peixes! (+%d XP)', #caughtFish, totalXP),
    }
end)

-- ============================================================================
-- CALLBACK: Plantar Vara
-- ============================================================================

lib.callback.register('fishing:server:placeRod', function(source, zoneId, coords)
    if not Config.PlantedRod.enabled then
        return { success = false, message = 'Varas plantadas desativadas' }
    end

    if not zoneId or not coords then
        return { success = false, message = 'Dados invalidos' }
    end

    local citizenid = getCitizenId(source)
    if not citizenid then
        return { success = false, message = 'Erro interno' }
    end

    -- Validar zona
    if not isInZone(source, zoneId) then
        return { success = false, message = 'Voce nao esta na zona de pesca' }
    end

    -- Limite: 1 vara plantada por jogador
    local currentRods = playerRodCount[citizenid] or 0
    if currentRods >= Config.PlantedRod.maxPerPlayer then
        return { success = false, message = 'Voce ja tem uma vara plantada' }
    end

    -- Encontrar melhor vara e isca
    local rod, bait = nil, nil
    local bestRodTier = 0
    for rodItem, rodConfig in pairs(Config.Rods) do
        local count = exports.ox_inventory:GetItemCount(source, rodItem)
        if count and count > 0 and (rodConfig.tier or 1) > bestRodTier then
            bestRodTier = rodConfig.tier or 1
            rod = rodItem
        end
    end
    if not rod then
        return { success = false, message = 'Voce precisa de uma vara de pesca' }
    end

    local bestBaitTier = 0
    for baitItem, baitConfig in pairs(Config.Baits) do
        local count = exports.ox_inventory:GetItemCount(source, baitItem)
        if count and count > 0 and (baitConfig.tier or 1) > bestBaitTier then
            bestBaitTier = baitConfig.tier or 1
            bait = baitItem
        end
    end
    if not bait then
        return { success = false, message = 'Voce precisa de isca' }
    end

    -- Consumir vara e isca
    exports.ox_inventory:RemoveItem(source, rod, 1)
    exports.ox_inventory:RemoveItem(source, bait, 1)

    -- Salvar no banco
    local rodId = MySQL.insert.await([[
        INSERT INTO fishing_planted_rods (citizenid, rod_item, bait_item, zone_id, coords_x, coords_y, coords_z, fish_bucket)
        VALUES (?, ?, ?, ?, ?, ?, ?, '[]')
    ]], { citizenid, rod, bait, zoneId, coords.x, coords.y, coords.z })

    if not rodId then
        exports.ox_inventory:AddItem(source, rod, 1)
        exports.ox_inventory:AddItem(source, bait, 1)
        return { success = false, message = 'Erro ao plantar vara' }
    end

    -- Cache
    local rodIdStr = tostring(rodId)
    activePlantedRods[rodIdStr] = {
        id = rodId,
        citizenid = citizenid,
        rod_item = rod,
        bait_item = bait,
        zone_id = zoneId,
        coords = vector3(coords.x, coords.y, coords.z),
        fish_bucket = {},
        last_fish_at = os.time(),
    }
    playerRodCount[citizenid] = (playerRodCount[citizenid] or 0) + 1

    if Config.Debug then
        -- print(string.format('^3[fishing:nets]^0 %s plantou vara na zona %s', citizenid, zoneId))
    end

    return {
        success = true,
        rodId = rodId,
        rod = rod,
        bait = bait,
        message = 'Vara plantada! Peixes serao pescados automaticamente.',
    }
end)

-- ============================================================================
-- CALLBACK: Coletar Vara Plantada
-- ============================================================================

lib.callback.register('fishing:server:collectPlantedRod', function(source, rodId)
    if not rodId then
        return { success = false, message = 'Dados invalidos' }
    end

    local rodIdStr = tostring(rodId)
    local rod = activePlantedRods[rodIdStr]
    if not rod then
        return { success = false, message = 'Vara nao encontrada' }
    end

    local citizenid = getCitizenId(source)
    if not citizenid or citizenid ~= rod.citizenid then
        return { success = false, message = 'Esta vara nao e sua' }
    end

    -- Dar peixes do bucket
    local given = 0
    local totalXP = 0
    for _, fish in ipairs(rod.fish_bucket) do
        local added = exports.ox_inventory:AddItem(source, fish.item, 1)
        if added then
            given = given + 1
            totalXP = totalXP + (Config.PlantedRod.xpPerFish or 5)
            UpdatePlayerStats(source, fish)
            LogFishCatch(source, fish, rod.zone_id, 'planted_rod')
        else
            break
        end
    end

    -- XP
    if totalXP > 0 then
        AddPlayerXP(source, totalXP)
    end

    -- Devolver vara ao jogador
    exports.ox_inventory:AddItem(source, rod.rod_item, 1)

    -- Remover do banco e cache
    activePlantedRods[rodIdStr] = nil
    playerRodCount[citizenid] = math.max(0, (playerRodCount[citizenid] or 1) - 1)
    MySQL.update('UPDATE fishing_planted_rods SET active = 0 WHERE id = ?', { rod.id })

    -- Conquistas
    CheckStatAchievements(source, nil)

    if Config.Debug then
        -- print(string.format('^3[fishing:nets]^0 %s coletou vara %s: %d peixes', citizenid, rodIdStr, given))
    end

    return {
        success = true,
        fishCount = given,
        totalXP = totalXP,
        message = string.format('Coletou %d peixes da vara! (+%d XP)', given, totalXP),
    }
end)

-- ============================================================================
-- CALLBACK: Obter redes e varas do jogador
-- ============================================================================

lib.callback.register('fishing:server:getPlayerNetsAndRods', function(source)
    local citizenid = getCitizenId(source)
    if not citizenid then return { nets = {}, rods = {} } end

    local nets = {}
    for netId, net in pairs(activeNets) do
        if net.citizenid == citizenid then
            local now = os.time()
            local ready = now >= net.collect_after
            local remaining = ready and 0 or math.ceil((net.collect_after - now) / 60)
            nets[#nets + 1] = {
                id = net.id,
                net_item = net.net_item,
                zone_id = net.zone_id,
                coords = { x = net.coords.x, y = net.coords.y, z = net.coords.z },
                ready = ready,
                remainingMinutes = remaining,
                usesRemaining = net.uses_remaining,
            }
        end
    end

    local rods = {}
    for rodId, rod in pairs(activePlantedRods) do
        if rod.citizenid == citizenid then
            rods[#rods + 1] = {
                id = rod.id,
                rod_item = rod.rod_item,
                zone_id = rod.zone_id,
                coords = { x = rod.coords.x, y = rod.coords.y, z = rod.coords.z },
                fishCount = #rod.fish_bucket,
                maxBucket = Config.PlantedRod.maxBucket,
            }
        end
    end

    return { nets = nets, rods = rods }
end)

-- ============================================================================
-- CALLBACK: Obter todas redes/varas ativas (para client recriar props)
-- ============================================================================

lib.callback.register('fishing:server:getAllActiveNetsAndRods', function(source)
    local allNets = {}
    for netId, net in pairs(activeNets) do
        allNets[#allNets + 1] = {
            id = net.id,
            coords = { x = net.coords.x, y = net.coords.y, z = net.coords.z },
            net_item = net.net_item,
            citizenid = net.citizenid,
        }
    end

    local allRods = {}
    for rodId, rod in pairs(activePlantedRods) do
        allRods[#allRods + 1] = {
            id = rod.id,
            coords = { x = rod.coords.x, y = rod.coords.y, z = rod.coords.z },
            citizenid = rod.citizenid,
        }
    end

    return { nets = allNets, rods = allRods }
end)
