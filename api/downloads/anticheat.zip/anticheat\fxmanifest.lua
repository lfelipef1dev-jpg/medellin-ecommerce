fx_version 'cerulean'
game 'gta5'

author 'Seu Servidor'
version '1.0.0'
description 'Anti-Cheat: armas proibidas, teleport, godmode, speedhack, resource injection'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}
client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/main.lua',
}
server_script 'server/main.lua'

dependencies {
    'ox_lib',
    'qbx_core'
}

lua54 'yes'
