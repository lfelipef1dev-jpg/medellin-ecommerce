Config = {}

--============================================================================
-- DETECCOES
--============================================================================

-- Armas proibidas: armas pesadas/exploit que NAO existem na loja
Config.EnableWeaponCheck = true
Config.BlacklistedWeapons = {
    "WEAPON_RAILGUN",           -- Railgun (exploit/cheat)
    "WEAPON_MINIGUN",           -- Minigun (exploit/cheat)
    "WEAPON_RPG",               -- RPG (exploit/cheat)
    "WEAPON_GRENADELAUNCHER",   -- Lanca granadas
    "WEAPON_HOMINGLAUNCHER",    -- Missil teleguiado
    "WEAPON_FIREWORK",          -- Fogos de artificio (pode crashar)
    "WEAPON_RAILGUNXM3",        -- Railgun XM3
    "WEAPON_EMPLAUNCHER",       -- EMP Launcher
}

-- Teleport detection: flag se moveu mais de X unidades em 5s sem veiculo
Config.EnableTeleportCheck = true
Config.TeleportMaxDistance = 500.0   -- unidades GTA (metros aprox)
Config.TeleportCheckInterval = 5000  -- ms

-- God mode detection: flag se saude acima do maximo
Config.EnableGodModeCheck = true
Config.GodModeMaxHealth = 200        -- saude normal max = 200 (100 base + 100 armour)
Config.GodModeCheckInterval = 10000  -- ms

-- Speed hack detection: flag se velocidade acima do limite
Config.EnableSpeedCheck = true
Config.SpeedMaxKmh = 350.0           -- km/h maximo permitido para veiculos terrestres
Config.SpeedCheckInterval = 5000     -- ms

--============================================================================
-- ACOES E LOGGING
--============================================================================

Config.KickMessage = "[Anti-Cheat] Violacao detectada. Voce foi removido do servidor."

-- Recurso de loja de armas (opcional): se preenchido, jogadores que compraram
-- armas na loja NAO serao punidos por telas-las. Deixe "" para desativar.
-- Exemplo: Config.WeaponShopResource = 'meu-loja-armas'
-- O recurso precisa exportar: IsLicenseAllowedWeapon(license, weaponHash) -> bool
Config.WeaponShopResource = ""

-- Webhook Discord para logs de anticheat. Deixe "" para nao enviar.
Config.Webhook = ""

-- Strikes: quantas flags antes de kickar (0 = kick imediato, 3 = tolera 3 flags)
-- Arma proibida sempre kicka imediato (bypass strikes)
Config.MaxStrikes = 3

-- Deteccao de resource injection (server-side)
Config.EnableResourceInjectionCheck = true
Config.AllowedResourceCount = GetNumResources and GetNumResources() or 200
