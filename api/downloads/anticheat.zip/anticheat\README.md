# Anti-Cheat para FiveM (QBox / QBCore)

Sistema anti-cheat leve e eficiente, desenvolvido para servidores FiveM com framework **QBox** ou **QBCore**.

## Funcionalidades

| Detecção | Descrição |
|----------|-----------|
| **Armas proibidas** | Detecta armas de exploit/cheat que não existem na loja (Railgun, RPG, Minigun, etc.) |
| **Teleport hack** | Flageia jogadores que se movem mais de X metros em poucos segundos sem estar em veículo |
| **God Mode** | Detecta saúde acima do máximo e invencibilidade ativa |
| **Speed Hack** | Flageia veículos terrestres acima da velocidade configurada |
| **Resource Injection** | Monitora mudança no número de resources ativos (injeção server-side) |

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)
- `ox_inventory` (opcional — melhora detecção de armas legítimas no inventário)

## Instalação

1. Coloque a pasta `anticheat` dentro de `resources/`
2. Adicione ao `server.cfg`:
   ```
   ensure anticheat
   ```
3. Configure o `config.lua` (webhook, limites, lista de armas)

## Configuração (config.lua)

```lua
-- Webhook Discord para logs (deixe "" para desativar)
Config.Webhook = "https://discord.com/api/webhooks/SEU_WEBHOOK"

-- Strikes antes de kickar (0 = kick imediato)
Config.MaxStrikes = 3

-- Mensagem de kick exibida ao jogador
Config.KickMessage = "[Anti-Cheat] Violacao detectada. Voce foi removido do servidor."

-- Recurso de loja de armas (opcional, para evitar falso-positivo em compradores)
-- Config.WeaponShopResource = 'minha-loja-armas'
Config.WeaponShopResource = ""

-- Velocidade máxima permitida para veículos terrestres (km/h)
Config.SpeedMaxKmh = 350.0

-- Distância máxima em 5s sem veículo antes de flagear (metros)
Config.TeleportMaxDistance = 500.0
```

## Adicionar / remover armas proibidas

No `config.lua`, edite a lista `Config.BlacklistedWeapons`:

```lua
Config.BlacklistedWeapons = {
    "WEAPON_RAILGUN",
    "WEAPON_MINIGUN",
    -- adicione mais aqui...
}
```

## Compatibilidade

- QBox (qbx_core) ✅
- QBCore (qb-core via bridge) ✅
- ox_inventory ✅ (opcional)
- ox_lib ✅ (obrigatório para notificações client-side)

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
