-- QBox bridge: exports['qb-core'] funciona via qbx:enablebridge "true"
local QBCore = exports['qb-core']:GetCoreObject()

--============================================================================
-- UTILIDADES
--============================================================================

local function isBlacklisted(weaponHash)
    for _, name in ipairs(Config.BlacklistedWeapons) do
        if weaponHash == GetHashKey(name) then
            return true
        end
    end
    return false
end

local function isAircraftVehicle(vehicle)
    if not DoesEntityExist(vehicle) then return false end
    local class = GetVehicleClass(vehicle)
    -- 15 = helicopteros, 16 = avioes
    return class == 15 or class == 16
end

local function getPlayerAdmin()
    -- QBCore PlayerData: se job.name contem "admin" ou god mode via ace
    local playerData = QBCore.Functions.GetPlayerData()
    if playerData and playerData.job and playerData.job.name == 'admin' then
        return true
    end
    if IsPlayerAceAllowed('command') then
        return true
    end
    -- Verificar se tem permissão "teste" (inauguração - godmode permitido)
    if playerData and playerData.metadata and playerData.metadata['testmode'] then
        return true
    end
    return false
end

--============================================================================
-- EVENTO: Arma removida pelo server
--============================================================================

RegisterNetEvent('anticheat:weaponNotAllowed', function(weapon)
    local ped = PlayerPedId()
    if DoesEntityExist(ped) and weapon then
        RemoveWeaponFromPed(ped, weapon)
        lib.notify({ title = 'Anti-Cheat', description = 'Arma proibida removida.', type = 'error' })
    end
end)

--============================================================================
-- DETECCAO 1: Armas proibidas (a cada 2s)
--============================================================================

CreateThread(function()
    if not Config.EnableWeaponCheck then return end
    while true do
        local ped = PlayerPedId()
        if DoesEntityExist(ped) and not IsEntityDead(ped) then
            local weapon = GetSelectedPedWeapon(ped)
            if weapon and weapon ~= `WEAPON_UNARMED` and isBlacklisted(weapon) then
                TriggerServerEvent('anticheat:flagWeapon', weapon)
            end
        end
        Wait(2000)
    end
end)

--============================================================================
-- DETECCAO 2: Teleport (a cada 5s)
--============================================================================

CreateThread(function()
    if not Config.EnableTeleportCheck then return end

    -- Esperar player spawnar
    while not DoesEntityExist(PlayerPedId()) do Wait(1000) end
    Wait(10000) -- 10s grace period apos spawn (loading, teleport inicial)

    local lastPos = GetEntityCoords(PlayerPedId())

    while true do
        Wait(Config.TeleportCheckInterval)
        local ped = PlayerPedId()
        if DoesEntityExist(ped) and not IsEntityDead(ped) then
            local currentPos = GetEntityCoords(ped)
            local dist = #(currentPos - lastPos)
            local inVehicle = IsPedInAnyVehicle(ped, false)

            -- Flag: moveu muito, nao esta em veiculo, nao caiu (Z delta grande pode ser queda)
            if dist > Config.TeleportMaxDistance and not inVehicle then
                TriggerServerEvent('anticheat:flag', 'teleport', {
                    from = { x = lastPos.x, y = lastPos.y, z = lastPos.z },
                    to = { x = currentPos.x, y = currentPos.y, z = currentPos.z },
                    distance = math.floor(dist),
                })
            end

            lastPos = currentPos
        end
    end
end)

--============================================================================
-- DETECCAO 3: God Mode (a cada 10s)
--============================================================================

CreateThread(function()
    if not Config.EnableGodModeCheck then return end

    -- Esperar player spawnar
    while not DoesEntityExist(PlayerPedId()) do Wait(1000) end
    Wait(15000) -- 15s grace period (spawn pode setar saude temporariamente alta)

    while true do
        Wait(Config.GodModeCheckInterval)
        local ped = PlayerPedId()
        if DoesEntityExist(ped) and not IsEntityDead(ped) then
            local health = GetEntityHealth(ped)
            local maxHealth = GetEntityMaxHealth(ped)
            local armour = GetPedArmour(ped)

            -- Flag: saude acima do max configurado E nao e admin
            if health > Config.GodModeMaxHealth and not getPlayerAdmin() then
                TriggerServerEvent('anticheat:flag', 'godmode', {
                    health = health,
                    maxHealth = maxHealth,
                    armour = armour,
                })
            end

            -- Flag adicional: invencibilidade ativa (GetPlayerInvincible)
            if GetPlayerInvincible(PlayerId()) and not getPlayerAdmin() then
                TriggerServerEvent('anticheat:flag', 'godmode', {
                    health = health,
                    invincible = true,
                })
            end
        end
    end
end)

--============================================================================
-- DETECCAO 4: Speed Hack (a cada 5s)
--============================================================================

CreateThread(function()
    if not Config.EnableSpeedCheck then return end

    while true do
        Wait(Config.SpeedCheckInterval)
        local ped = PlayerPedId()
        if DoesEntityExist(ped) and IsPedInAnyVehicle(ped, false) then
            local vehicle = GetVehiclePedIsIn(ped, false)
            if DoesEntityExist(vehicle) and not isAircraftVehicle(vehicle) then
                -- Velocidade em m/s -> km/h
                local speed = GetEntitySpeed(vehicle) * 3.6
                if speed > Config.SpeedMaxKmh then
                    local model = GetEntityModel(vehicle)
                    TriggerServerEvent('anticheat:flag', 'speedhack', {
                        speed = math.floor(speed),
                        limit = Config.SpeedMaxKmh,
                        vehicleModel = model,
                    })
                end
            end
        end
    end
end)
