--============================================================================
-- UTILIDADES DE LOGGING
--============================================================================

local playerStrikes = {} -- [serverId] = count

local function getPlayerInfo(src)
    local name = GetPlayerName(src) or "desconhecido"
    local identifiers = GetPlayerIdentifiers(src) or {}
    local license = nil
    for _, id in ipairs(identifiers) do
        if id:find('license:', 1, true) == 1 then
            license = id
            break
        end
    end
    return name, identifiers, license
end

local function logToConsole(src, detectionType, details)
    local name = GetPlayerName(src) or "desconhecido"
    local strikes = playerStrikes[src] or 0
    local detailStr = ""
    if type(details) == "table" then
        local parts = {}
        for k, v in pairs(details) do
            parts[#parts + 1] = ("%s=%s"):format(tostring(k), tostring(v))
        end
        detailStr = table.concat(parts, ", ")
    end
    print(("[AC-%s] Player: %s (ID: %s) | Strikes: %d/%d | %s"):format(
        detectionType, name, src, strikes, Config.MaxStrikes, detailStr
    ))
end

local function sendWebhook(src, detectionType, details)
    if not Config.Webhook or Config.Webhook == "" then return end

    local name, identifiers = getPlayerInfo(src)
    local strikes = playerStrikes[src] or 0

    local detailLines = {}
    if type(details) == "table" then
        for k, v in pairs(details) do
            if type(v) == "table" then
                detailLines[#detailLines + 1] = ("**%s:** x=%.1f y=%.1f z=%.1f"):format(k, v.x or 0, v.y or 0, v.z or 0)
            else
                detailLines[#detailLines + 1] = ("**%s:** %s"):format(k, tostring(v))
            end
        end
    end

    local colors = {
        weapon = 15158332,   -- vermelho
        teleport = 15105570, -- laranja
        godmode = 10038562,  -- roxo
        speedhack = 3447003, -- azul
        injection = 16776960,-- amarelo
    }

    local payload = {
        username = "Anti-Cheat",
        embeds = {{
            title = ("[AC] %s"):format(detectionType:upper()),
            color = colors[detectionType] or 16711680,
            fields = {
                { name = "Player", value = ("%s (ID: %s)"):format(name, src), inline = true },
                { name = "Strikes", value = ("%d/%d"):format(strikes, Config.MaxStrikes), inline = true },
                { name = "Detalhes", value = #detailLines > 0 and table.concat(detailLines, "\n") or "N/A", inline = false },
                { name = "IDs", value = table.concat(identifiers, "\n"), inline = false },
            },
            footer = { text = "Anti-Cheat" },
            timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        }},
    }

    PerformHttpRequest(Config.Webhook, function() end, 'POST', json.encode(payload), {
        ['Content-Type'] = 'application/json',
    })
end

local function addStrike(src, detectionType, details)
    playerStrikes[src] = (playerStrikes[src] or 0) + 1
    local strikes = playerStrikes[src]

    logToConsole(src, detectionType, details)
    sendWebhook(src, detectionType, details)

    if strikes >= Config.MaxStrikes then
        local name = GetPlayerName(src) or "desconhecido"
        -- print(("[AC-KICK] Player removido: %s (ID: %s) | Motivo: %s"):format(name, src, detectionType))
        DropPlayer(src, Config.KickMessage)
        playerStrikes[src] = nil
    end
end

--============================================================================
-- EVENTO: Arma proibida (kick imediato, bypass strikes)
--============================================================================

RegisterNetEvent('anticheat:flagWeapon', function(weapon)
    local src = source
    local _, _, license = getPlayerInfo(src)

    -- 1. Verificar se comprou na loja de armas (excecao legitima, opcional via config)
    if license and Config.WeaponShopResource ~= "" and GetResourceState(Config.WeaponShopResource) == 'started' then
        local ok, allowed = pcall(exports[Config.WeaponShopResource].IsLicenseAllowedWeapon, exports[Config.WeaponShopResource], license, weapon)
        if ok and allowed then
            return -- comprou na loja, nao bloquear
        end
    end

    -- 2. Verificar se a arma existe no inventario do jogador (ox_inventory)
    --    Se tem no inventario = recebeu legitimamente (admin, faccao, craft, trade, loja)
    if GetResourceState('ox_inventory') == 'started' then
        for _, weaponName in ipairs(Config.BlacklistedWeapons) do
            if GetHashKey(weaponName) == weapon then
                -- Tentar MAIUSCULO e minusculo (ox_inventory pode usar qualquer um)
                local ok1, count1 = pcall(exports.ox_inventory.GetItemCount, exports.ox_inventory, src, weaponName)
                if ok1 and count1 and count1 > 0 then
                    return -- tem no inventario
                end
                local ok2, count2 = pcall(exports.ox_inventory.GetItemCount, exports.ox_inventory, src, weaponName:lower())
                if ok2 and count2 and count2 > 0 then
                    return -- tem no inventario (minusculo)
                end
                break
            end
        end
    end

    -- 3. Verificar se eh admin via ace permissions do FiveM
    if IsPlayerAceAllowed(tostring(src), 'command') then
        return -- tem permissao de admin, nao bloquear
    end

    -- 4. Nao comprou na loja, nao tem no inventario, nao eh admin = cheater
    TriggerClientEvent('anticheat:weaponNotAllowed', src, weapon)
    logToConsole(src, 'weapon', { weapon = weapon })
    sendWebhook(src, 'weapon', { weapon = weapon })
    DropPlayer(src, Config.KickMessage)
end)

--============================================================================
-- EVENTO: Flag generico (teleport, godmode, speedhack)
--============================================================================

RegisterNetEvent('anticheat:flag', function(detectionType, details)
    local src = source

    -- Rate limit: ignorar se player ja foi flagged recentemente (evita spam)
    -- Usa strike count como rate limiter natural

    addStrike(src, detectionType, details or {})
end)

--============================================================================
-- DETECCAO SERVER-SIDE: Resource injection
--============================================================================

local bootResourceCount = nil

AddEventHandler('onResourceStart', function(resourceName)
    if not Config.EnableResourceInjectionCheck then return end
    if not bootResourceCount then return end

    local currentCount = GetNumResources()
    if currentCount > bootResourceCount + 2 then
        print(("[AC-INJECTION] Resource count changed: boot=%d current=%d new=%s"):format(
            bootResourceCount, currentCount, resourceName
        ))
        sendWebhook(0, 'injection', {
            resource = resourceName,
            bootCount = bootResourceCount,
            currentCount = currentCount,
        })
    end
end)

CreateThread(function()
    Wait(30000) -- 30s para todos os resources carregarem
    bootResourceCount = GetNumResources()
    if Config.EnableResourceInjectionCheck then
        -- print(("[AC] Boot resource count locked: %d"):format(bootResourceCount))
    end
end)

--============================================================================
-- LIMPEZA: Remover strikes quando player desconecta
--============================================================================

AddEventHandler('playerDropped', function()
    playerStrikes[source] = nil
end)
