var maxCheckpoint = 0;
var checkpoint = 0;

function formatTime(ms) {
    var seconds = Math.floor(ms / 1000);
    var minutes = Math.floor(seconds / 60);
    var hours = Math.floor(minutes / 60);
    seconds = seconds % 60;
    minutes = minutes % 60;

    if (hours > 0) return hours + ":" + String(minutes).padStart(2, '0');
    if (minutes > 0) return minutes + ":" + String(seconds).padStart(2, '0');
    return "00:" + String(seconds).padStart(2, '0');
}

window.addEventListener("message", function(event) {
    var data = event.data;
    var runners = document.getElementById("displayRunners");
    var ranking = document.getElementById("displayRanking");

    if (data.show !== undefined) {
        runners.style.display = data.show ? "block" : "none";
        if (data.show) {
            checkpoint = 0;
            maxCheckpoint = data.maxCheckpoint || 0;
        }
    }

    if (data.maxCheckpoint !== undefined) {
        maxCheckpoint = data.maxCheckpoint;
    }

    if (data.upCheckpoint) {
        checkpoint++;
    }

    if (data.ranking !== undefined) {
        if (data.ranking === false) {
            ranking.style.display = "none";
        } else {
            ranking.style.display = "block";
            var items = JSON.parse(data.ranking);
            var html = "<table><tr><th>#</th><th>NOME</th><th>TEMPO</th></tr>";
            for (var i = 0; i < items.length; i++) {
                html += "<tr><td>" + (i + 1) + "</td><td>" + items[i].name + "</td><td>" + formatTime(items[i].time) + "</td></tr>";
            }
            html += "</table>";
            ranking.innerHTML = html;
        }
    }

    if (data.Points !== undefined) {
        var html = '<div class="label">CHECKPOINTS</div><div class="value">' + checkpoint + ' / ' + maxCheckpoint + '</div>';
        html += '<div class="label" style="margin-top:8px">PERCORRIDO</div><div class="value">' + formatTime(data.Points) + '</div>';
        if (data.Explosive > 0) {
            html += '<div class="label" style="margin-top:8px;color:#ff4444">EXPLOSÃO</div><div class="value" style="color:#ff4444">' + formatTime(data.Explosive) + '</div>';
        }
        runners.innerHTML = html;
    }
});
