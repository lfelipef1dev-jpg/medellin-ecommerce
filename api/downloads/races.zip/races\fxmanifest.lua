fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Sistema de Corridas para FiveM (QBox/QBCore)'
version '1.0.0'

shared_scripts { '@ox_lib/init.lua', 'config.lua' }
server_scripts { '@oxmysql/lib/MySQL.lua', 'server/*.lua' }
client_scripts { '@qbx_core/modules/playerdata.lua', 'client/*.lua' }
ui_page 'web/index.html'
files { 'web/**' }
