local QBCore = exports['qb-core']:GetCoreObject()

local Races = {}
local Selected = nil
local Progress = false
local ExplodeRace = false
local raceTyres = {}
local currentCheckpoint = 0
local maxCheckpoints = 0
local raceStartTime = 0
local explosiveTimer = 0
local displayRanking = false

-- Receber tabela de corridas
RegisterNetEvent('races:client:loadTable', function(data)
    Races = data
end)

-- Blip management
local raceBlip = nil

local function MakeBlips(coords)
    if raceBlip then RemoveBlip(raceBlip) end
    raceBlip = AddBlipForCoord(coords[1], coords[2], coords[3])
    SetBlipSprite(raceBlip, 315) -- [FIX] Was sprite 1 (generic), now 315 (flag icon)
    SetBlipColour(raceBlip, 59)
    SetBlipRoute(raceBlip, true)
    SetBlipRouteColour(raceBlip, 59)
end

local function CleanBlips()
    if raceBlip then
        RemoveBlip(raceBlip)
        raceBlip = nil
    end
end

-- Objeto pneus nos checkpoints
local function MakeObjects(checkpoint)
    for _, obj in ipairs(raceTyres) do
        if DoesEntityExist(obj) then DeleteEntity(obj) end
    end
    raceTyres = {}

    if checkpoint and checkpoint[2] then
        local model = GetHashKey('prop_offroad_tyres02')
        RequestModel(model)
        while not HasModelLoaded(model) do Wait(10) end

        local obj1 = CreateObject(model, checkpoint[2][1], checkpoint[2][2], checkpoint[2][3], false, false, false)
        PlaceObjectOnGroundProperly(obj1)
        FreezeEntityPosition(obj1, true)
        raceTyres[#raceTyres + 1] = obj1

        if checkpoint[3] then
            local obj2 = CreateObject(model, checkpoint[3][1], checkpoint[3][2], checkpoint[3][3], false, false, false)
            PlaceObjectOnGroundProperly(obj2)
            FreezeEntityPosition(obj2, true)
            raceTyres[#raceTyres + 1] = obj2
        end
    end
end

local function CleanObjects()
    for _, obj in ipairs(raceTyres) do
        if DoesEntityExist(obj) then DeleteEntity(obj) end
    end
    raceTyres = {}
end

-- Sair da corrida
local function LeaveRace()
    Progress = false
    Selected = nil
    currentCheckpoint = 0
    CleanBlips()
    CleanObjects()
    SendNUIMessage({ show = false })
    TriggerServerEvent('races:server:exitRace')

    if ExplodeRace then
        ExplodeRace = false
        Wait(3000)
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped) then
            local vehicle = GetVehiclePedIsUsing(ped)
            NetworkExplodeVehicle(vehicle, true, true)
        end
    end
end

-- Main race thread
CreateThread(function()
    while true do
        if Progress and Selected and Races[Selected] then
            local ped = PlayerPedId()
            if not IsPedInAnyVehicle(ped) then
                LeaveRace()
            else
                local coords = GetEntityCoords(ped)
                local checkpoint = Races[Selected].coords[currentCheckpoint + 1]

                if checkpoint then
                    local dist = #(coords - vector3(checkpoint[1][1], checkpoint[1][2], checkpoint[1][3]))
                    if dist < 15.0 then
                        currentCheckpoint = currentCheckpoint + 1
                        SendNUIMessage({ upCheckpoint = true })

                        if currentCheckpoint >= maxCheckpoints then
                            -- Corrida finalizada
                            local finishTime = GetGameTimer() - raceStartTime
                            QBCore.Functions.TriggerCallback('races:server:finishRace', function(success)
                                if success then
                                    TriggerEvent('Notify', 'verde', 'Corrida finalizada!', 5000)
                                end
                            end, Selected, finishTime)
                            LeaveRace()
                        else
                            local nextCheckpoint = Races[Selected].coords[currentCheckpoint + 1]
                            if nextCheckpoint then
                                MakeBlips(nextCheckpoint[1])
                                MakeObjects(nextCheckpoint)
                            end
                        end
                    end
                end

                -- Timer HUD
                local elapsed = GetGameTimer() - raceStartTime
                local explosive = ExplodeRace and (explosiveTimer * 1000 - elapsed) or 0
                SendNUIMessage({ Points = elapsed, Explosive = explosive })
            end
            Wait(100)
        else
            Wait(1000)
        end
    end
end)

-- Tire burst system (fora de corridas)
local lastSpeed = 0
CreateThread(function()
    while true do
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped) and not Progress then
            local vehicle = GetVehiclePedIsUsing(ped)
            local speed = GetEntitySpeed(vehicle) * 3.6
            local vehClass = GetVehicleClass(vehicle)
            local model = GetEntityModel(vehicle)

            if vehClass ~= 8 and not Config.ExcludedBikes[model] then
                if lastSpeed - speed > 125 then
                    local wheel = math.random(0, 3)
                    SetVehicleTyreBurst(vehicle, wheel, true, 1000.0)
                end
            end

            lastSpeed = speed
            Wait(500)
        else
            lastSpeed = 0
            Wait(1000)
        end
    end
end)

-- Comando para iniciar corrida
RegisterCommand("corrida", function(_, args)
    local raceId = tonumber(args[1])
    if not raceId or not Races[raceId] then
        TriggerEvent('Notify', 'vermelho', 'Corrida inválida. Use /corrida [id]', 5000)
        return
    end

    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped) then
        TriggerEvent('Notify', 'vermelho', 'Você precisa estar em um veículo.', 5000)
        return
    end

    if Progress then
        TriggerEvent('Notify', 'vermelho', 'Você já está em uma corrida.', 5000)
        return
    end

    if not Races[raceId].coords or #Races[raceId].coords == 0 then
        TriggerEvent('Notify', 'vermelho', 'Esta corrida não tem checkpoints configurados.', 5000)
        return
    end

    QBCore.Functions.TriggerCallback('races:server:checkPermission', function(allowed, isIllegal)
        if not allowed then return end

        Selected = raceId
        Progress = true
        ExplodeRace = isIllegal or false
        currentCheckpoint = 0
        maxCheckpoints = #Races[raceId].coords
        raceStartTime = GetGameTimer()
        explosiveTimer = Races[raceId].explode or 999

        -- Primeiro checkpoint
        local firstCheckpoint = Races[raceId].coords[1]
        if firstCheckpoint then
            MakeBlips(firstCheckpoint[1])
            MakeObjects(firstCheckpoint)
        end

        SendNUIMessage({
            show = true,
            maxCheckpoints = maxCheckpoints,
            raceName = Races[raceId].name,
            explosive = ExplodeRace,
        })

        TriggerEvent('Notify', 'verde', 'Corrida iniciada! Vá até o primeiro checkpoint.', 5000)
    end, raceId)
end, false)

-- Ranking
RegisterCommand("ranking", function(_, args)
    local raceId = tonumber(args[1])
    if not raceId then
        TriggerEvent('Notify', 'vermelho', 'Use /ranking [id]', 5000)
        return
    end

    QBCore.Functions.TriggerCallback('races:server:getRanking', function(ranking)
        if not ranking or #ranking == 0 then
            TriggerEvent('Notify', 'amarelo', 'Sem records para esta corrida.', 5000)
            return
        end
        SendNUIMessage({ action = "showRanking", ranking = ranking, raceName = Races[raceId] and Races[raceId].name or "Corrida " .. raceId })
        SetNuiFocus(true, true)
    end, raceId)
end, false)
