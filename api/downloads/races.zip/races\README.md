# Sistema de Corridas para FiveM (QBox / QBCore)

Sistema completo de corridas com ranking, permissões e UI integrada.

## Funcionalidades

- Corridas com múltiplos checkpoints no mapa
- Ranking por corrida com pontuação
- Corridas legais e ilegais (configurável por permissão)
- Interface web para visualização do placar
- Histórico salvo em banco de dados

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)
- `oxmysql`

## Instalação

1. Coloque a pasta `races` dentro de `resources/`
2. Execute o SQL: `sql/install.sql` no seu banco de dados
3. Adicione ao `server.cfg`:
   ```
   ensure races
   ```
4. Configure as corridas em `config.lua`

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
