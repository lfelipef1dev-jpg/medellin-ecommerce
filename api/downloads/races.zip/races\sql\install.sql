CREATE TABLE IF NOT EXISTS `race_records` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `citizenid` VARCHAR(50) NOT NULL,
    `race_id` INT NOT NULL,
    `best_time` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_record` (`citizenid`, `race_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
