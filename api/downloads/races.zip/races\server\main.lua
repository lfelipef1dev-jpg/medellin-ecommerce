local QBCore = exports['qb-core']:GetCoreObject()

local raceCooldowns = {}
local illegalRaces = {}
local srcToCitizenId = {}

-- Carregar corridas do config
local Races = Config.Races or {}

-- Enviar tabela de corridas ao spawnar (nome correto do evento QBCore)
AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
    local src = Player.PlayerData.source
    srcToCitizenId[src] = Player.PlayerData.citizenid
    TriggerClientEvent('races:client:loadTable', src, Races)
end)

-- Callback: checar permissão para iniciar corrida
QBCore.Functions.CreateCallback('races:server:checkPermission', function(source, cb, raceId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then cb(false) return end

    local citizenid = Player.PlayerData.citizenid

    -- Cooldown check
    if raceCooldowns[citizenid] and os.time() < raceCooldowns[citizenid] then
        TriggerClientEvent('Notify', src, 'vermelho', 'Aguarde antes de iniciar outra corrida.', 5000)
        cb(false)
        return
    end

    raceCooldowns[citizenid] = os.time() + Config.StartCooldown

    -- Checar se tem ticket para corrida ilegal
    local hasTicket = (exports.ox_inventory:Search(src, 'count', 'ticket') or 0) >= (1 or 1)
    if hasTicket then
        exports.ox_inventory:RemoveItem(src, 'ticket', 1)
        illegalRaces[citizenid] = true

        -- Alertar polícia
        local cops = QBCore.Functions.GetQBPlayers()
        for _, cop in pairs(cops) do
            if cop and cop.PlayerData.job.type == 'leo' then
                local ped = GetPlayerPed(src)
                if ped and ped ~= 0 then
                    local coords = GetEntityCoords(ped)
                    TriggerClientEvent('Notify', cop.PlayerData.source, 'police', 'Corrida ilegal detectada na região!', 8000)
                end
            end
        end

        cb(true, true) -- status, isIllegal
    else
        cb(true, false)
    end
end)

-- Callback: finalizar corrida
QBCore.Functions.CreateCallback('races:server:finishRace', function(source, cb, raceId, points)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then cb(false) return end

    local citizenid = Player.PlayerData.citizenid

    -- Reward
    if illegalRaces[citizenid] then
        local reward = math.random(Config.IllegalRewardMin, Config.IllegalRewardMax)
        Player.Functions.AddMoney('cash', reward, 'illegal-race-reward')
        TriggerClientEvent('Notify', src, 'verde', 'Corrida ilegal concluída! Recompensa: $' .. reward, 8000)
        illegalRaces[citizenid] = nil
    end

    -- Salvar record
    local existing = MySQL.query.await('SELECT best_time FROM race_records WHERE citizenid = ? AND race_id = ?', { citizenid, raceId })
    if existing and #existing > 0 then
        if points < existing[1].best_time then
            MySQL.update.await('UPDATE race_records SET best_time = ? WHERE citizenid = ? AND race_id = ?', { points, citizenid, raceId })
        end
    else
        MySQL.insert.await('INSERT INTO race_records (citizenid, race_id, best_time) VALUES (?, ?, ?)', { citizenid, raceId, points })
    end

    cb(true)
end)

-- Callback: ranking
QBCore.Functions.CreateCallback('races:server:getRanking', function(source, cb, raceId)
    local rawRanking = MySQL.query.await('SELECT r.citizenid, r.best_time, p.charinfo FROM race_records r LEFT JOIN players p ON r.citizenid = p.citizenid WHERE r.race_id = ? ORDER BY r.best_time ASC LIMIT 5', { raceId })
    local ranking = {}
    if rawRanking then
        for _, row in ipairs(rawRanking) do
            local charinfo = row.charinfo and json.decode(row.charinfo) or {}
            ranking[#ranking + 1] = {
                name = (charinfo.firstname or 'Desconhecido') .. ' ' .. (charinfo.lastname or ''),
                time = row.best_time,
                citizenid = row.citizenid,
            }
        end
    end
    cb(ranking)
end)

-- Evento: sair da corrida
RegisterNetEvent('races:server:exitRace', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    illegalRaces[Player.PlayerData.citizenid] = nil
end)

-- Cleanup disconnect (GetPlayer não funciona aqui)
AddEventHandler('playerDropped', function()
    local src = source
    local citizenid = srcToCitizenId[src]
    srcToCitizenId[src] = nil
    if citizenid then
        illegalRaces[citizenid] = nil
        raceCooldowns[citizenid] = nil
    end
end)
