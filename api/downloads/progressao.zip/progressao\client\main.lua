-- ============================================================================
-- medellin-progressao – Client
-- ============================================================================

local QBCore = nil

CreateThread(function()
    while GetResourceState('qb-core') ~= 'started' do Wait(100) end
    QBCore = exports['qb-core']:GetCoreObject()
end)

-- Dados locais de progressao
local PlayerData = {
    xp = 0,
    level = 1,
    title = 'Novato',
    nextLevelXp = 500,
    citizenid = nil,
}

local isLoaded = false

-- ============================================================================
-- FUNCOES AUXILIARES
-- ============================================================================

--- Formata numero com separador de milhar (pt-BR style)
---@param n number
---@return string
local function formatNumber(n)
    local formatted = tostring(math.floor(n))
    local k
    while true do
        formatted, k = formatted:gsub('^(-?%d+)(%d%d%d)', '%1.%2')
        if k == 0 then break end
    end
    return formatted
end

--- Calcula percentual de progresso para o proximo nivel
---@return number 0-100
local function getProgressPercent()
    if not PlayerData.nextLevelXp then return 100 end -- nivel maximo

    local currentLevelXp = 0
    for _, lvl in ipairs(Config.Levels) do
        if lvl.level == PlayerData.level then
            currentLevelXp = lvl.xpRequired
            break
        end
    end

    local xpInLevel = PlayerData.xp - currentLevelXp
    local xpNeeded = PlayerData.nextLevelXp - currentLevelXp

    if xpNeeded <= 0 then return 100 end
    return math.floor((xpInLevel / xpNeeded) * 100)
end

-- ============================================================================
-- EVENTOS: SINCRONIZACAO DE DADOS
-- ============================================================================

RegisterNetEvent('medellin-progressao:client:syncData', function(data)
    if not data then return end
    PlayerData.xp = data.xp or 0
    PlayerData.level = data.level or 1
    PlayerData.title = data.title or 'Novato'
    PlayerData.nextLevelXp = data.nextLevelXp
    PlayerData.citizenid = data.citizenid
    isLoaded = true

    if Config.Debug then
        -- print(('[medellin-progressao:client] Sync: XP=%d Level=%d Title=%s'):format(
        --     PlayerData.xp, PlayerData.level, PlayerData.title))
    end
end)

-- ============================================================================
-- EVENTOS: NOTIFICACOES DE XP
-- ============================================================================

RegisterNetEvent('medellin-progressao:client:xpGained', function(data)
    if not data then return end

    -- Atualizar dados locais
    PlayerData.xp = data.totalXp or PlayerData.xp
    PlayerData.level = data.level or PlayerData.level
    PlayerData.title = data.title or PlayerData.title
    PlayerData.nextLevelXp = data.nextLevelXp

    -- Notificacao flutuante de XP ganho
    local vipText = data.isVIP and ' (VIP)' or ''
    local msg = ('+%d XP%s'):format(data.amount, vipText)

    -- Usar ox_lib notify para XP ganho (menos intrusivo)
    if lib and lib.notify then
        lib.notify({
            title = 'Progressao',
            description = msg,
            type = 'success',
            duration = 3000,
            position = 'top-right',
        })
    else
        QBCore.Functions.Notify(msg, 'success', 3000)
    end
end)

-- ============================================================================
-- EVENTOS: LEVEL UP
-- ============================================================================

RegisterNetEvent('medellin-progressao:client:levelUp', function(data)
    if not data then return end

    -- Atualizar dados locais
    PlayerData.level = data.newLevel or PlayerData.level
    PlayerData.title = data.title or PlayerData.title

    -- Notificacao grande de level up
    local rewardText = ''
    if data.rewards then
        if data.rewards.money and data.rewards.money > 0 then
            rewardText = rewardText .. ('$%s'):format(formatNumber(data.rewards.money))
        end
        if data.rewards.item then
            if rewardText ~= '' then rewardText = rewardText .. ' + ' end
            rewardText = rewardText .. ('%dx %s'):format(data.rewards.item.count or 1, data.rewards.item.name)
        end
        if data.rewards.perk and data.rewards.perk.label then
            if rewardText ~= '' then rewardText = rewardText .. ' + ' end
            rewardText = rewardText .. data.rewards.perk.label
        end
    end

    local title = ('NIVEL %d - %s'):format(data.newLevel, data.title)
    local description = 'Voce subiu de nivel!'
    if rewardText ~= '' then
        description = description .. ('\nRecompensa: %s'):format(rewardText)
    end

    -- Usar ox_lib notify para level up (mais visivel)
    if lib and lib.notify then
        lib.notify({
            title = title,
            description = description,
            type = 'info',
            duration = 8000,
            position = 'top',
            icon = 'arrow-up',
        })
    else
        QBCore.Functions.Notify(title .. ' - ' .. description, 'primary', 8000)
    end

    -- Som de level up
    PlaySoundFrontend(-1, 'RANK_UP', 'HUD_AWARDS', false)
end)

-- ============================================================================
-- QUANDO O JOGADOR CARREGA
-- ============================================================================

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    -- Solicitar dados de XP do server via callback
    CreateThread(function()
        Wait(2000) -- aguardar server carregar dados
        local data = lib.callback.await('medellin-progressao:server:getData', false)
        if data then
            PlayerData.xp = data.xp or 0
            PlayerData.level = data.level or 1
            PlayerData.title = data.title or 'Novato'
            PlayerData.nextLevelXp = data.nextLevelXp
            PlayerData.citizenid = data.citizenid
            isLoaded = true
        end
    end)
end)

-- Quando o jogador desloga (multichar)
RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    PlayerData = {
        xp = 0,
        level = 1,
        title = 'Novato',
        nextLevelXp = 500,
        citizenid = nil,
    }
    isLoaded = false
end)

-- ============================================================================
-- COMANDOS
-- ============================================================================

-- /nivel ou /level – Ver progresso atual
RegisterCommand('nivel', function()
    if not isLoaded then
        QBCore.Functions.Notify('Dados de progressao ainda nao carregados.', 'error', 3000)
        return
    end

    local percent = getProgressPercent()
    local progressBar = ''

    -- Barra visual simples com caracteres
    local barLength = 20
    local filled = math.floor(barLength * percent / 100)
    for i = 1, barLength do
        if i <= filled then
            progressBar = progressBar .. '|'
        else
            progressBar = progressBar .. '.'
        end
    end

    local lines = {}
    table.insert(lines, ('~b~=== SUA PROGRESSAO ==='))
    table.insert(lines, ('~w~Nivel: ~y~%d~w~ - ~g~%s'):format(PlayerData.level, PlayerData.title))
    table.insert(lines, ('~w~XP: ~y~%s'):format(formatNumber(PlayerData.xp)))

    if PlayerData.nextLevelXp then
        table.insert(lines, ('~w~Proximo nivel: ~y~%s XP ~w~(%d%%)'):format(
            formatNumber(PlayerData.nextLevelXp), percent))
        table.insert(lines, ('~w~[%s]'):format(progressBar))
        table.insert(lines, ('~w~Faltam: ~r~%s XP'):format(
            formatNumber(PlayerData.nextLevelXp - PlayerData.xp)))
    else
        table.insert(lines, '~g~Nivel maximo alcancado!')
    end

    -- Enviar como mensagens de chat
    for _, line in ipairs(lines) do
        -- Limpar tags de cor para chat
        local cleanLine = line:gsub('~%w~', '')
        TriggerEvent('chat:addMessage', { args = { 'Progressao', cleanLine } })
    end

    -- Notificacao resumida
    local summary
    if PlayerData.nextLevelXp then
        summary = ('Nivel %d (%s) | %s/%s XP (%d%%)'):format(
            PlayerData.level, PlayerData.title,
            formatNumber(PlayerData.xp), formatNumber(PlayerData.nextLevelXp),
            percent)
    else
        summary = ('Nivel %d (%s) | %s XP - NIVEL MAXIMO!'):format(
            PlayerData.level, PlayerData.title,
            formatNumber(PlayerData.xp))
    end

    if lib and lib.notify then
        lib.notify({
            title = 'Sua Progressao',
            description = summary,
            type = 'info',
            duration = 8000,
            position = 'top',
        })
    else
        QBCore.Functions.Notify(summary, 'primary', 8000)
    end
end, false)

-- Alias /level para /nivel
RegisterCommand('level', function()
    ExecuteCommand('nivel')
end, false)

-- ============================================================================
-- EXPORTS PARA OUTROS SCRIPTS CLIENT-SIDE
-- ============================================================================

--- Retorna dados de progressao do jogador local
---@return table {level, xp, title, nextLevelXp, isLoaded}
exports('GetPlayerLevel', function()
    return {
        level = PlayerData.level,
        xp = PlayerData.xp,
        title = PlayerData.title,
        nextLevelXp = PlayerData.nextLevelXp,
        isLoaded = isLoaded,
    }
end)

--- Retorna o nivel numerico do jogador local
---@return number
exports('GetLevel', function()
    return PlayerData.level
end)

--- Retorna o titulo/ranking do jogador local
---@return string
exports('GetTitle', function()
    return PlayerData.title
end)

--- Retorna o percentual de progresso para o proximo nivel
---@return number 0-100
exports('GetProgressPercent', function()
    return getProgressPercent()
end)
