-- ============================================================================
-- medellin-progressao – Sistema de progressao/XP do jogador
-- ============================================================================
--
-- SQL para criar a tabela (execute manualmente ou via migration):
--
-- CREATE TABLE IF NOT EXISTS medellin_progressao (
--     citizenid VARCHAR(50) PRIMARY KEY,
--     xp INT DEFAULT 0,
--     level INT DEFAULT 1,
--     last_online_reward TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
-- );
--
-- ============================================================================

local QBCore = nil

CreateThread(function()
    while GetResourceState('qb-core') ~= 'started' do Wait(100) end
    QBCore = exports['qb-core']:GetCoreObject()
end)

-- Cache de dados de progressao por source (limpo ao desconectar)
local PlayerXPData = {}

-- ============================================================================
-- BANCO DE DADOS – criacao automatica da tabela
-- ============================================================================

MySQL.ready(function()
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS medellin_progressao (
            citizenid VARCHAR(50) PRIMARY KEY,
            xp INT DEFAULT 0,
            level INT DEFAULT 1,
            last_online_reward TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ]])
    -- print('^2[medellin-progressao]^0 Tabela medellin_progressao OK.')
end)

-- ============================================================================
-- FUNCOES AUXILIARES
-- ============================================================================

--- Calcula o nivel baseado no XP total
---@param xp number
---@return table {level, title, xpRequired, nextLevelXp}
local function calculateLevel(xp)
    local currentLevel = Config.Levels[1]
    for i = #Config.Levels, 1, -1 do
        if xp >= Config.Levels[i].xpRequired then
            currentLevel = Config.Levels[i]
            break
        end
    end

    local nextLevelXp = nil
    for _, lvl in ipairs(Config.Levels) do
        if lvl.level == currentLevel.level + 1 then
            nextLevelXp = lvl.xpRequired
            break
        end
    end

    return {
        level = currentLevel.level,
        title = currentLevel.title,
        xpRequired = currentLevel.xpRequired,
        nextLevelXp = nextLevelXp, -- nil se for nivel maximo
    }
end

--- Verifica se o jogador e VIP (via metadata do medellin-vip)
---@param Player table QBCore Player object
---@return boolean
local function isPlayerVIP(Player)
    if not Player or not Player.PlayerData then return false end
    local vip = Player.PlayerData.metadata and Player.PlayerData.metadata.vip
    return vip ~= nil and vip ~= false
end

--- Log de debug
---@param ... any
local function debugLog(...)
    if Config.Debug then
        -- print('^3[medellin-progressao:debug]^0', ...)
    end
end

-- ============================================================================
-- CARREGAR / CRIAR DADOS DO JOGADOR
-- ============================================================================

--- Carrega ou cria os dados de XP do jogador no banco
---@param Player table QBCore Player object
local function loadPlayerXPData(Player)
    if not Player or not Player.PlayerData then return end
    local citizenid = Player.PlayerData.citizenid
    local src = Player.PlayerData.source

    local row = MySQL.single.await(
        'SELECT xp, level, last_online_reward FROM medellin_progressao WHERE citizenid = ?',
        { citizenid }
    )

    if row then
        local levelInfo = calculateLevel(row.xp)
        PlayerXPData[src] = {
            citizenid = citizenid,
            xp = row.xp,
            level = levelInfo.level,
            title = levelInfo.title,
            nextLevelXp = levelInfo.nextLevelXp,
            lastOnlineReward = row.last_online_reward,
        }
        -- Corrige nivel no banco se estiver dessincronizado
        if levelInfo.level ~= row.level then
            MySQL.update('UPDATE medellin_progressao SET level = ? WHERE citizenid = ?',
                { levelInfo.level, citizenid })
        end
    else
        -- Novo jogador: inserir registro
        MySQL.insert.await(
            'INSERT INTO medellin_progressao (citizenid, xp, level) VALUES (?, 0, 1)',
            { citizenid }
        )
        PlayerXPData[src] = {
            citizenid = citizenid,
            xp = 0,
            level = 1,
            title = Config.Levels[1].title,
            nextLevelXp = Config.Levels[2] and Config.Levels[2].xpRequired or nil,
            lastOnlineReward = os.time(),
        }
    end

    -- Sincronizar statebag para acesso por outros resources
    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then
        local state = Entity(ped).state
        state:set('progressao_level', PlayerXPData[src].level, true)
        state:set('progressao_xp', PlayerXPData[src].xp, true)
        state:set('progressao_title', PlayerXPData[src].title, true)
    end

    debugLog(('Jogador %s carregado: XP=%d Level=%d Title=%s'):format(
        citizenid, PlayerXPData[src].xp, PlayerXPData[src].level, PlayerXPData[src].title))

    -- Envia dados para o client
    TriggerClientEvent('medellin-progressao:client:syncData', src, PlayerXPData[src])
end

--- Salva dados do jogador no banco
---@param src number
local function savePlayerData(src)
    local data = PlayerXPData[src]
    if not data then return end
    MySQL.update(
        'UPDATE medellin_progressao SET xp = ?, level = ?, updated_at = CURRENT_TIMESTAMP WHERE citizenid = ?',
        { data.xp, data.level, data.citizenid }
    )
end

-- ============================================================================
-- LOGICA DE XP / LEVEL UP
-- ============================================================================

--- Entrega as recompensas de level up ao jogador
---@param Player table QBCore Player object
---@param level number
local function giveLevelRewards(Player, level)
    local rewards = Config.LevelRewards[level]
    if not rewards then return end

    local src = Player.PlayerData.source

    -- Dinheiro (bank)
    if rewards.money and rewards.money > 0 then
        Player.Functions.AddMoney('bank', rewards.money, 'progressao-level-' .. level)
        debugLog(('Level %d reward: $%d para %s'):format(level, rewards.money, Player.PlayerData.citizenid))
    end

    -- Item
    if rewards.item and rewards.item.name then
        local count = rewards.item.count or 1
        if GetResourceState('ox_inventory') == 'started' then
            exports.ox_inventory:AddItem(src, rewards.item.name, count)
        end
        debugLog(('Level %d reward: %dx %s para %s'):format(level, count, rewards.item.name, Player.PlayerData.citizenid))
    end

    -- Perk (salvo via metadata)
    if rewards.perk and rewards.perk.key then
        Player.Functions.SetMetaData(rewards.perk.key, true)
        debugLog(('Level %d reward: perk %s para %s'):format(level, rewards.perk.key, Player.PlayerData.citizenid))
    end
end

--- Adiciona XP ao jogador
---@param src number source do jogador
---@param activity string nome da atividade (chave de Config.XPRewards)
---@param amountOverride number|nil quantidade de XP override (opcional)
---@return boolean sucesso
---@return string|nil mensagem de erro
local function addXP(src, activity, amountOverride)
    if not src or not PlayerXPData[src] then return false, 'jogador_nao_encontrado' end

    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false, 'jogador_nao_encontrado' end

    -- Determinar quantidade de XP
    local baseAmount = amountOverride or Config.XPRewards[activity]
    if not baseAmount then return false, 'atividade_invalida' end

    -- Multiplicador VIP
    local multiplier = 1.0
    if isPlayerVIP(Player) then
        multiplier = Config.VIPMultiplier or 1.5
    end

    local finalAmount = math.floor(baseAmount * multiplier)
    if finalAmount <= 0 then return false, 'xp_invalido' end

    local data = PlayerXPData[src]
    local oldLevel = data.level

    -- Adicionar XP
    data.xp = data.xp + finalAmount

    -- Recalcular nivel
    local levelInfo = calculateLevel(data.xp)
    data.level = levelInfo.level
    data.title = levelInfo.title
    data.nextLevelXp = levelInfo.nextLevelXp

    -- Salvar no banco
    savePlayerData(src)

    -- Notificar client do XP ganho
    TriggerClientEvent('medellin-progressao:client:xpGained', src, {
        amount = finalAmount,
        activity = activity,
        totalXp = data.xp,
        level = data.level,
        title = data.title,
        nextLevelXp = data.nextLevelXp,
        isVIP = multiplier > 1.0,
    })

    debugLog(('XP: %s ganhou +%d XP (%s) [VIP: x%.1f] | Total: %d | Level: %d'):format(
        data.citizenid, finalAmount, activity or 'manual', multiplier, data.xp, data.level))

    -- Verificar level up (pode ter subido mais de um nivel de uma vez)
    if data.level > oldLevel then
        for lvl = oldLevel + 1, data.level do
            -- Dar recompensas de cada nivel intermediario
            giveLevelRewards(Player, lvl)

            -- Titulo do nivel alcancado
            local lvlTitle = Config.Levels[lvl] and Config.Levels[lvl].title or ('Nivel ' .. lvl)

            -- Notificar client do level up
            TriggerClientEvent('medellin-progressao:client:levelUp', src, {
                newLevel = lvl,
                title = lvlTitle,
                rewards = Config.LevelRewards[lvl],
            })

            -- Evento para outros resources escutarem
            TriggerEvent('medellin-progressao:server:onLevelUp', src, lvl, lvlTitle)

            debugLog(('LEVEL UP: %s subiu para nivel %d (%s)'):format(data.citizenid, lvl, lvlTitle))
        end
    end

    -- Sincronizar statebag
    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then
        local state = Entity(ped).state
        state:set('progressao_level', data.level, true)
        state:set('progressao_xp', data.xp, true)
        state:set('progressao_title', data.title, true)
    end

    -- Sincronizar client
    TriggerClientEvent('medellin-progressao:client:syncData', src, data)

    return true
end

--- Retorna info do nivel do jogador
---@param src number
---@return table|nil {level, xp, title, nextLevelXp}
local function getPlayerLevel(src)
    local data = PlayerXPData[src]
    if not data then return nil end
    return {
        level = data.level,
        xp = data.xp,
        title = data.title,
        nextLevelXp = data.nextLevelXp,
    }
end

-- ============================================================================
-- EXPORTS
-- ============================================================================

exports('AddXP', addXP)
exports('GetPlayerLevel', getPlayerLevel)

-- ============================================================================
-- EVENTOS
-- ============================================================================

-- Quando o jogador carrega o personagem
AddEventHandler('QBCore:Server:PlayerLoaded', function(Player)
    if not Player then return end
    CreateThread(function()
        -- Pequeno delay para garantir que tudo esta pronto
        Wait(1000)
        loadPlayerXPData(Player)
    end)
end)

-- Quando o jogador desconecta: salvar e limpar cache
AddEventHandler('playerDropped', function()
    local src = source
    if PlayerXPData[src] then
        savePlayerData(src)
        PlayerXPData[src] = nil
    end
end)

-- Evento para outros resources adicionarem XP (server-side, interno)
-- Uso: TriggerEvent('medellin-progressao:server:addXP', playerSource, 'roubo_banco')
AddEventHandler('medellin-progressao:server:addXP', function(playerSource, activity)
    addXP(playerSource, activity)
end)

-- Net event para client ou outros resources via TriggerServerEvent
-- Uso: TriggerServerEvent('medellin-progressao:addXP', 'venda_drogas')
RegisterNetEvent('medellin-progressao:addXP', function(activity)
    local src = source
    -- Validacao basica anti-exploit: so aceitar atividades configuradas
    if not Config.XPRewards[activity] then
        debugLog(('Atividade invalida recebida de %d: %s'):format(src, tostring(activity)))
        return
    end
    addXP(src, activity)
end)

-- Callback para o client solicitar seus dados de XP
lib.callback.register('medellin-progressao:server:getData', function(source)
    local data = PlayerXPData[source]
    if not data then
        -- Tentar carregar se ainda nao foi carregado
        local Player = QBCore.Functions.GetPlayer(source)
        if Player then
            loadPlayerXPData(Player)
            data = PlayerXPData[source]
        end
    end
    return data
end)

-- ============================================================================
-- THREAD: RECOMPENSA POR TEMPO ONLINE
-- ============================================================================

CreateThread(function()
    -- Aguardar QBCore inicializar
    while not QBCore do Wait(500) end

    local intervalMs = (Config.OnlineRewardInterval or 30) * 60 * 1000

    while true do
        Wait(intervalMs)

        local players = QBCore.Functions.GetQBPlayers()
        if players then
            for _, Player in pairs(players) do
                if Player and Player.PlayerData then
                    local src = Player.PlayerData.source
                    if PlayerXPData[src] then
                        addXP(src, 'tempo_online')

                        -- Atualizar timestamp no banco
                        MySQL.update(
                            'UPDATE medellin_progressao SET last_online_reward = CURRENT_TIMESTAMP WHERE citizenid = ?',
                            { PlayerXPData[src].citizenid }
                        )

                        debugLog(('Tempo online: +XP para %s'):format(Player.PlayerData.citizenid))
                    end
                end
            end
        end
    end
end)

-- ============================================================================
-- COMANDOS ADMIN
-- ============================================================================

-- /addxp [id] [quantidade] – Dar XP a um jogador
RegisterCommand('addxp', function(source, args)
    -- Apenas console (source == 0) ou admin
    local isConsole = source == 0
    local isAdmin = false
    if not isConsole then
        local Player = QBCore.Functions.GetPlayer(source)
        if Player then
            isAdmin = QBCore.Functions.HasPermission(source, 'admin') or IsPlayerAceAllowed(source, 'command.addxp')
        end
    end

    if not isConsole and not isAdmin then
        if source ~= 0 then
            TriggerClientEvent('QBCore:Notify', source, 'Sem permissao.', 'error')
        end
        return
    end

    local targetId = tonumber(args[1])
    local amount = tonumber(args[2])

    if not targetId or not amount then
        local msg = 'Uso: /addxp [id] [quantidade]'
        if isConsole then
            -- print('^1[medellin-progressao]^0 ' .. msg)
        else
            TriggerClientEvent('QBCore:Notify', source, msg, 'error')
        end
        return
    end

    local ok, err = addXP(targetId, 'roleplay_bonus', amount)
    if ok then
        local msg = ('XP adicionado: +%d XP para jogador %d'):format(amount, targetId)
        if isConsole then
            -- print('^2[medellin-progressao]^0 ' .. msg)
        else
            TriggerClientEvent('QBCore:Notify', source, msg, 'success')
        end
    else
        local msg = ('Erro ao dar XP: %s'):format(tostring(err))
        if isConsole then
            -- print('^1[medellin-progressao]^0 ' .. msg)
        else
            TriggerClientEvent('QBCore:Notify', source, msg, 'error')
        end
    end
end, true) -- restricted = true (ace permissao)

-- /setlevel [id] [nivel] – Setar nivel de um jogador
RegisterCommand('setlevel', function(source, args)
    local isConsole = source == 0
    local isAdmin = false
    if not isConsole then
        local Player = QBCore.Functions.GetPlayer(source)
        if Player then
            isAdmin = QBCore.Functions.HasPermission(source, 'admin') or IsPlayerAceAllowed(source, 'command.setlevel')
        end
    end

    if not isConsole and not isAdmin then
        if source ~= 0 then
            TriggerClientEvent('QBCore:Notify', source, 'Sem permissao.', 'error')
        end
        return
    end

    local targetId = tonumber(args[1])
    local targetLevel = tonumber(args[2])

    if not targetId or not targetLevel then
        local msg = 'Uso: /setlevel [id] [nivel]'
        if isConsole then
            -- print('^1[medellin-progressao]^0 ' .. msg)
        else
            TriggerClientEvent('QBCore:Notify', source, msg, 'error')
        end
        return
    end

    -- Validar nivel
    local targetLevelData = nil
    for _, lvl in ipairs(Config.Levels) do
        if lvl.level == targetLevel then
            targetLevelData = lvl
            break
        end
    end

    if not targetLevelData then
        local msg = ('Nivel %d nao existe. Niveis validos: 1-%d'):format(targetLevel, #Config.Levels)
        if isConsole then
            -- print('^1[medellin-progressao]^0 ' .. msg)
        else
            TriggerClientEvent('QBCore:Notify', source, msg, 'error')
        end
        return
    end

    local data = PlayerXPData[targetId]
    if not data then
        local msg = ('Jogador %d nao encontrado ou nao carregado.'):format(targetId)
        if isConsole then
            -- print('^1[medellin-progressao]^0 ' .. msg)
        else
            TriggerClientEvent('QBCore:Notify', source, msg, 'error')
        end
        return
    end

    -- Setar XP para o minimo do nivel desejado
    data.xp = targetLevelData.xpRequired
    data.level = targetLevelData.level
    data.title = targetLevelData.title

    -- Recalcular nextLevelXp
    local levelInfo = calculateLevel(data.xp)
    data.nextLevelXp = levelInfo.nextLevelXp

    -- Salvar no banco
    savePlayerData(targetId)

    -- Sincronizar com client
    TriggerClientEvent('medellin-progressao:client:syncData', targetId, data)

    -- Sincronizar statebag
    local ped = GetPlayerPed(targetId)
    if ped and ped ~= 0 then
        local state = Entity(ped).state
        state:set('progressao_level', data.level, true)
        state:set('progressao_xp', data.xp, true)
        state:set('progressao_title', data.title, true)
    end

    local msg = ('Nivel de jogador %d setado para %d (%s) | XP: %d'):format(
        targetId, data.level, data.title, data.xp)
    if isConsole then
        -- print('^2[medellin-progressao]^0 ' .. msg)
    else
        TriggerClientEvent('QBCore:Notify', source, msg, 'success')
    end
end, true)

-- /xpstats – Estatisticas de XP do servidor
RegisterCommand('xpstats', function(source)
    local isConsole = source == 0
    local isAdmin = false
    if not isConsole then
        local Player = QBCore.Functions.GetPlayer(source)
        if Player then
            isAdmin = QBCore.Functions.HasPermission(source, 'admin') or IsPlayerAceAllowed(source, 'command.xpstats')
        end
    end

    if not isConsole and not isAdmin then
        if source ~= 0 then
            TriggerClientEvent('QBCore:Notify', source, 'Sem permissao.', 'error')
        end
        return
    end

    -- Estatisticas do banco
    local totalPlayers = MySQL.scalar.await('SELECT COUNT(*) FROM medellin_progressao') or 0
    local avgXP = MySQL.scalar.await('SELECT COALESCE(AVG(xp), 0) FROM medellin_progressao') or 0
    local maxXP = MySQL.scalar.await('SELECT COALESCE(MAX(xp), 0) FROM medellin_progressao') or 0
    local avgLevel = MySQL.scalar.await('SELECT COALESCE(AVG(level), 1) FROM medellin_progressao') or 1

    -- Distribuicao por nivel
    local levelDist = MySQL.query.await(
        'SELECT level, COUNT(*) as count FROM medellin_progressao GROUP BY level ORDER BY level'
    ) or {}

    -- Jogadores online com dados
    local onlineCount = 0
    for _ in pairs(PlayerXPData) do
        onlineCount = onlineCount + 1
    end

    local lines = {
        '^5=== MEDELLIN PROGRESSAO - ESTATISTICAS ===^0',
        ('^3Total jogadores registrados:^0 %d'):format(totalPlayers),
        ('^3Jogadores online com dados:^0 %d'):format(onlineCount),
        ('^3XP medio:^0 %.0f'):format(avgXP),
        ('^3XP maximo:^0 %d'):format(maxXP),
        ('^3Nivel medio:^0 %.1f'):format(avgLevel),
        '^3Distribuicao por nivel:^0',
    }

    for _, row in ipairs(levelDist) do
        local title = 'N/A'
        for _, lvl in ipairs(Config.Levels) do
            if lvl.level == row.level then
                title = lvl.title
                break
            end
        end
        table.insert(lines, ('  Nivel %d (%s): %d jogadores'):format(row.level, title, row.count))
    end

    table.insert(lines, '^5==========================================^0')

    local fullMsg = table.concat(lines, '\n')

    if isConsole then
        -- print(fullMsg)
    else
        -- Para admin in-game: enviar como chat ou notificacoes
        for _, line in ipairs(lines) do
            -- Remover codigos de cor do FiveM para chat
            local cleanLine = line:gsub('%^%d', '')
            TriggerClientEvent('chat:addMessage', source, { args = { 'XP Stats', cleanLine } })
        end
    end
end, true)

-- ============================================================================
-- CLEANUP ao parar o resource
-- ============================================================================

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    -- Salvar todos os jogadores online
    for src, _ in pairs(PlayerXPData) do
        savePlayerData(src)
    end
    -- print('^2[medellin-progressao]^0 Dados salvos ao parar resource.')
end)
