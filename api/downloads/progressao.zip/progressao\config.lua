Config = {}
Config.Debug = false

-- XP por atividade
Config.XPRewards = {
    -- Trabalhos legais (50-200 XP)
    ['coleta_lixo'] = 50,
    ['motorista_bus'] = 50,
    ['entrega_caminhao'] = 75,
    ['mecanica'] = 100,
    ['mergulho'] = 200,
    -- Trabalhos ilegais (100-500 XP)
    ['farm_faccao'] = 100,
    ['venda_drogas'] = 150,
    ['craft_arma'] = 200,
    ['roubo_joalheria'] = 350,
    ['roubo_banco'] = 500,
    -- Geral
    ['tempo_online'] = 100,       -- a cada 60 min online
    ['roleplay_bonus'] = 100,     -- admin pode dar
}

-- ============================================================================
-- 100 Niveis com curva exponencial (interpolacao linear entre ancoras)
-- ============================================================================
-- Ancoras: L1=0, L2=500, L10=5000, L50=50000, L100=200000
-- Incrementos por segmento:
--   L2-10:  ~562/nivel
--   L11-50: ~1125/nivel
--   L51-100: ~3000/nivel
-- ============================================================================

-- Titulos por faixa de nivel
local titleAnchors = {
    { minLevel = 1,   title = 'Novato' },
    { minLevel = 5,   title = 'Morador' },
    { minLevel = 10,  title = 'Conhecido' },
    { minLevel = 15,  title = 'Respeitado' },
    { minLevel = 20,  title = 'Veterano' },
    { minLevel = 30,  title = 'Expert' },
    { minLevel = 40,  title = 'Lenda' },
    { minLevel = 50,  title = 'Imortal' },
    { minLevel = 60,  title = 'Padrinho' },
    { minLevel = 70,  title = 'Magnata' },
    { minLevel = 80,  title = 'Imperador' },
    { minLevel = 90,  title = 'Supremo' },
    { minLevel = 95,  title = 'Rei da Cidade' },
    { minLevel = 100, title = 'Mito' },
}

--- Retorna o titulo para um dado nivel
local function getTitleForLevel(level)
    local title = 'Novato'
    for _, anchor in ipairs(titleAnchors) do
        if level >= anchor.minLevel then
            title = anchor.title
        end
    end
    return title
end

--- Interpola XP entre duas ancoras
local function interpolateXP(level, fromLevel, fromXP, toLevel, toXP)
    local progress = (level - fromLevel) / (toLevel - fromLevel)
    return math.floor(fromXP + progress * (toXP - fromXP))
end

--- Calcula o XP necessario para um nivel
local function getXPForLevel(level)
    if level <= 1 then return 0 end
    if level == 2 then return 500 end
    if level <= 10 then return interpolateXP(level, 2, 500, 10, 5000) end
    if level <= 50 then return interpolateXP(level, 10, 5000, 50, 50000) end
    return interpolateXP(level, 50, 50000, 100, 200000)
end

-- Gerar tabela de 100 niveis programaticamente
Config.Levels = {}
for i = 1, 100 do
    Config.Levels[i] = {
        level = i,
        xpRequired = getXPForLevel(i),
        title = getTitleForLevel(i),
    }
end

-- ============================================================================
-- Recompensas em milestones
-- ============================================================================
Config.LevelRewards = {
    [10]  = { money = 10000 },
    [20]  = { money = 25000,  perk = { key = 'desconto_mecanico', label = 'Desconto Mecanico' } },
    [30]  = { money = 50000,  perk = { key = 'acesso_club_vip',   label = 'Acesso Club VIP' } },
    [50]  = { money = 100000, perk = { key = 'titulo_exclusivo',  label = 'Titulo Exclusivo' } },
    [100] = { money = 500000, perk = { key = 'veiculo_exclusivo', label = 'Veiculo Exclusivo' } },
}

-- Tempo online reward interval (minutos)
Config.OnlineRewardInterval = 60

-- Multiplicador VIP
Config.VIPMultiplier = 1.5
