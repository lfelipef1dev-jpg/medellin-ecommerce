# Minigames para FiveM (QBox / QBCore)

Biblioteca de minigames interativos para usar em roubos, empregos, hackings e qualquer ação do servidor.

## Minigames Inclusos

| Minigame | Descrição |
|----------|-----------|
| **Anagram** | Descubra a palavra embaralhada |
| **Button Mash** | Aperte a tecla correta o mais rápido possível |
| **Chip Hack** | Conecte os circuitos corretamente |
| **Hangman** | Adivinhe a palavra (forca) |
| **Key Drop** | Pressione a tecla no momento certo |
| **Pincode** | Digite o código correto |
| **Safe Crack** | Abra o cofre girando o dial |
| **Skill Bar** | Pare a barra na zona verde |
| **Skill Circle** | Clique no momento certo no círculo |
| **Wire Cut** | Corte o fio correto |

## Como Usar em Outros Recursos

```lua
-- Exemplo: usar o skill_bar em outro resource
local success = exports['minigames']:skillBar({
    duration = 3000,
    keys = 3,
})

if success then
    -- jogador passou no minigame
end
```

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)

## Instalação

1. Coloque a pasta `minigames` dentro de `resources/`
2. Adicione ao `server.cfg`:
   ```
   ensure minigames
   ```
3. Use as exportações nos seus outros recursos conforme exemplos acima

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
