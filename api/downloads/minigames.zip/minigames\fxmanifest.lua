fx_version 'cerulean'
game 'gta5'
lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
}

author 'FiveM RP'
description 'Minigames - Migrado de monkey_minigames'
version '1.0.0'

ui_page 'html/index.html'

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/config.lua',
    'client/main.lua',
    'client/**/*.lua'
}

files {
    'html/**/*'
}
