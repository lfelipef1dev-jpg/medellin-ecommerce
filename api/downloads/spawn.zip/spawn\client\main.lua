local QBCore = exports['qb-core']:GetCoreObject()
local activeCam = nil
local interfaceActive = false
local lastPlayerPosition = nil
local forceVisibleThread = nil
local isSpawning = false -- Flag: evita que ForceVisibleNow descongele o ped durante teleporte

local function normalizeHeading(h)
    local v = tonumber(h) or 0.0
    v = v % 360.0
    if v < 0.0 then v = v + 360.0 end
    return v
end

local function getSpawnHeading(baseHeading, isLastPosition)
    local heading = tonumber(baseHeading) or 0.0
    local offset = tonumber(Config and Config.SpawnHeadingOffset) or 0.0
    local applyLast = (Config and Config.ApplyHeadingOffsetToLastPosition) ~= false
    if isLastPosition and not applyLast then
        return normalizeHeading(heading)
    end
    return normalizeHeading(heading + offset)
end

-- Debug toggle:
-- setr Servidor_debug_spawn 1
local function dbgEnabled()
    return GetConvarInt('Servidor_debug_spawn', 0) == 1 or GetConvarInt('Servidor_debug_multichar', 0) == 1
end

local function dbg(msg)
    if not dbgEnabled() then return end
end

-- Função para forçar fade in e corrigir tela preta
local function ForceFadeIn()
    dbg('ForceFadeIn()')
    
    -- Limpar timecycle/blur imediatamente
    ClearTimecycleModifier()
    SetTimecycleModifier('default')
    SetTimecycleModifierStrength(0.0)
    ClearTimecycleModifier()
    
    -- Desativar qualquer câmera ativa
    if DoesCamExist(activeCam) then
        RenderScriptCams(false, false, 0, false, false)
        SetCamActive(activeCam, false)
        DestroyCam(activeCam, false)
        activeCam = nil
    end
    
    -- Garantir que não está em fade out
    if IsScreenFadingOut() then
        while IsScreenFadingOut() do
            Wait(10)
        end
    end
    
    -- Forçar fade in
    DoScreenFadeIn(0) -- Fade in imediato
    Wait(100)
    
    -- Limpar timecycle novamente após fade in
    ClearTimecycleModifier()
    SetTimecycleModifierStrength(0.0)
    
    -- Se ainda estiver preto, tentar novamente
    if IsScreenFadedOut() then
        DoScreenFadeIn(500)
        Wait(500)
        ClearTimecycleModifier()
        SetTimecycleModifierStrength(0.0)
    end
    
    -- Garantir visibilidade do personagem
    local ped = PlayerPedId()
    SetEntityVisible(ped, true, false)
    SetEntityAlpha(ped, 255, false)
    ResetEntityAlpha(ped)
    SetPlayerControl(PlayerId(), true, 0)
    
end

-- Failsafe: força visibilidade imediata (sem depender do fluxo do spawn)
local function ForceVisibleNow(reason)
    local ped = PlayerPedId()
    dbg(('ForceVisibleNow(%s) ped=%s'):format(tostring(reason), tostring(ped)))
    if ped and ped ~= 0 then
        -- Reset pesado de câmera/tela (muitas "invisibilidades" são câmera travada / tela preta)
        pcall(function()
            RenderScriptCams(false, false, 0, true, true)
            DestroyAllCams(true)
            ClearFocus()
        end)
        if IsScreenFadedOut() or IsScreenFadingOut() then
            DoScreenFadeIn(0)
        end
        ClearTimecycleModifier()
        SetTimecycleModifier('default')
        SetTimecycleModifierStrength(0.0)

        -- Forçar modo de câmera "normal" (evita parecer invisível por estar preso em 1ª pessoa/cinematic)
        pcall(function()
            SetCinematicModeActive(false)
            DisplayRadar(true)
            SetFollowPedCamViewMode(1)
            SetFollowVehicleCamViewMode(1)
        end)

        SetEntityVisible(ped, true, false)
        SetLocalPlayerVisibleLocally(true)
        SetEntityAlpha(ped, 255, false)
        ResetEntityAlpha(ped)
        SetEntityCollision(ped, true, true)
        if not isSpawning then
            FreezeEntityPosition(ped, false)
            SetEntityInvincible(ped, false)
        end
        NetworkSetEntityInvisibleToNetwork(ped, false)
        NetworkSetInSpectatorMode(false, 0)
        SetLocalPlayerAsGhost(false)
        SetPlayerControl(PlayerId(), true, 0)
        ClearPedTasksImmediately(ped)
    end
    -- Limpar statebags que alguns sistemas usam para manter invisível/spectate.
    pcall(function()
        if LocalPlayer and LocalPlayer.state and LocalPlayer.state.set then
            LocalPlayer.state:set('Invisible', false, true)
            LocalPlayer.state:set('Invincible', false, true)
            LocalPlayer.state:set('Spectate', false, true)
        elseif LocalPlayer and LocalPlayer.state then
            -- fallback (read-only em alguns builds, mas não custa tentar)
            LocalPlayer.state.Invisible = false
            LocalPlayer.state.Invincible = false
            LocalPlayer.state.Spectate = false
        end
    end)
    -- Se algum sistema de admin deixou noclip/spectate preso, forçar reset nele também.
    TriggerEvent('Servidor-admin:client:forceResetVisibility', 'spawn ForceVisibleNow')
    TriggerEvent('qb-admin:client:ForceResetVisibility', 'spawn ForceVisibleNow')
    TriggerEvent('qb-admin:client:ForceDisableNoClip', 'spawn ForceVisibleNow')
    TriggerEvent('qb-admin:client:ForceStopSpectate', 'spawn ForceVisibleNow')
    if IsScreenFadedOut() or IsScreenFadingOut() then
        DoScreenFadeIn(0)
    end
    ClearTimecycleModifier()
    SetTimecycleModifier('default')
    SetTimecycleModifierStrength(0.0)
end

-- Se mesmo após ForceVisible o player continuar invisível, forçar reload de skin/aparência
local function RecoverInvisiblePlayer(reason)
    CreateThread(function()
        Wait(300)
        local ped = PlayerPedId()
        if not ped or ped == 0 then return end

        local visible = IsEntityVisible(ped)
        local alpha = GetEntityAlpha(ped)
        dbg(('RecoverInvisiblePlayer(%s): visible=%s alpha=%s'):format(tostring(reason), tostring(visible), tostring(alpha)))

        if visible and alpha >= 200 then
            return
        end

        -- Primeiro, reforçar visibilidade
        ForceVisibleNow('Recover step 1: ' .. tostring(reason))

        -- Segundo, recarregar skin (isso recria/aplica componentes e pode "destravar" ped)
        if GetResourceState('illenium-appearance') == 'started' then
            dbg('RecoverInvisiblePlayer: triggering illenium-appearance reloadSkin')
            pcall(function()
                TriggerEvent('illenium-appearance:client:reloadSkin', true)
            end)
        elseif GetResourceState('qb-clothing') == 'started' then
            dbg('RecoverInvisiblePlayer: triggering qb-clothing reloadSkin')
            pcall(function()
                TriggerEvent('qb-clothing:client:reloadSkin')
            end)
        end

        Wait(800)
        -- Terceiro, resurrect + visibilidade final
        ped = PlayerPedId()
        if ped and ped ~= 0 then
            local c = GetEntityCoords(ped)
            local h = GetEntityHeading(ped)
            pcall(function()
                NetworkResurrectLocalPlayer(c.x, c.y, c.z, h, true, true, false)
            end)
        end
        ForceVisibleNow('Recover step 2 (final): ' .. tostring(reason))
    end)
end

-- Event handler para garantir visibilidade e limpar estado de morte quando QBCore carrega
-- IMPORTANTE: Roda ANTES do qb-ambulancejob (que espera 1s) para evitar spawn morto
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    dbg('QBCore:Client:OnPlayerLoaded recebido')

    -- IMEDIATO (sem Wait): Limpar death state no servidor ANTES do ambulancejob checar (1s delay)
    -- Isso garante que metadata.isdead = false quando o ambulancejob ler os dados
    TriggerServerEvent('hospital:server:SetDeathStatus', false)
    TriggerServerEvent('hospital:server:SetLaststandStatus', false)

    CreateThread(function()
        Wait(500) -- Aguardar um pouco
        ForceVisibleNow('OnPlayerLoaded')

        -- Limpar qualquer blur/timecycle aqui (sem mexer em fade/câmera)
        ClearTimecycleModifier()
        SetTimecycleModifier('default')
        SetTimecycleModifierStrength(0.0)
        ClearTimecycleModifier()

    end)
end)

-- Função para fechar a interface
local function onCloseInterface()
    
    -- Limpar timecycle/blur imediatamente ao fechar
    ClearTimecycleModifier()
    SetTimecycleModifier('default')
    SetTimecycleModifierStrength(0.0)
    ClearTimecycleModifier()
    
    if DoesCamExist(activeCam) then
        RenderScriptCams(false, false, 0, false, false)
        SetCamActive(activeCam, false)
        DestroyCam(activeCam, false)
        activeCam = nil
    end

    interfaceActive = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })

    -- IMPORTANTE:
    -- O menu de spawn esconde o ped ao abrir. Se o jogador fechar o menu (ESC/frontend)
    -- antes de escolher um local, ele podia ficar invisível para sempre.
    -- Sempre restaurar visibilidade/controle ao fechar a interface.
    CreateThread(function()
        Wait(50)
        ForceVisibleNow('onCloseInterface')
        dbg('onCloseInterface: visibilidade restaurada (close sem spawn)')
    end)
    
    -- Limpeza adicional de timecycle em thread separada
    CreateThread(function()
        Wait(100)
        ClearTimecycleModifier()
        SetTimecycleModifier('default')
        SetTimecycleModifierStrength(0.0)
        ClearTimecycleModifier()
        Wait(500)
        ClearTimecycleModifier()
        SetTimecycleModifierStrength(0.0)
    end)
    
end

-- Função para iniciar fade out
local function StartFade()
    DoScreenFadeOut(Config.FadeTime)
    
    -- Aguardar fade out completar com timeout
    local fadeTimeout = 0
    while IsScreenFadingOut() and fadeTimeout < 100 do
        Wait(10)
        fadeTimeout = fadeTimeout + 1
    end
    
    if fadeTimeout >= 100 then
        DoScreenFadeOut(0) -- Forçar fade out imediato
        Wait(100)
    end
    
end

-- Função para iniciar fade in
local function EndFade()
    local ped = PlayerPedId()
    
    -- Garantir que a câmera está desativada
    if DoesCamExist(activeCam) then
        RenderScriptCams(false, false, 0, false, false)
        SetCamActive(activeCam, false)
        DestroyCam(activeCam, false)
        activeCam = nil
    end

    -- Reset pesado extra (garante gameplay cam e remove qualquer câmera perdida)
    pcall(function()
        RenderScriptCams(false, false, 0, true, true)
        DestroyAllCams(true)
        ClearFocus()
    end)
    if IsScreenFadedOut() or IsScreenFadingOut() then
        DoScreenFadeIn(0)
    end
    ClearTimecycleModifier()
    SetTimecycleModifier('default')
    SetTimecycleModifierStrength(0.0)
    
    -- Forçar câmera gameplay (evita ficar sem ver o corpo após spawn)
    pcall(function()
        SetCinematicModeActive(false)
        DisplayRadar(true)
        SetFollowPedCamViewMode(1)
        SetFollowVehicleCamViewMode(1)
    end)

    -- Forçar visibilidade múltiplas vezes para garantir
    SetEntityVisible(ped, true, false)
    SetEntityAlpha(ped, 255, false) -- Garantir alpha máximo
    Wait(50)
    SetEntityVisible(ped, true, false)
    SetEntityAlpha(ped, 255, false)
    
    SetEntityInvincible(ped, false)
    FreezeEntityPosition(ped, false)
    SetPlayerControl(PlayerId(), true, 0)
    
    local isVisible = IsEntityVisible(ped)
    
    -- Garantir que não está em fade out antes de fazer fade in
    if IsScreenFadingOut() then
        while IsScreenFadingOut() do
            Wait(10)
        end
    end
    
    -- Limpar timecycle/blur antes de fazer fade in
    ClearTimecycleModifier()
    SetTimecycleModifier('default')
    SetTimecycleModifierStrength(0.0)
    ClearTimecycleModifier()
    
    -- Fazer fade in
    DoScreenFadeIn(Config.FadeTime)
    
    -- Aguardar fade in completar com timeout
    local fadeTimeout = 0
    while IsScreenFadingIn() and fadeTimeout < 100 do
        Wait(10)
        fadeTimeout = fadeTimeout + 1
    end
    
    if fadeTimeout >= 100 then
        DoScreenFadeIn(0) -- Forçar fade in imediato
    end
    
    -- Verificar novamente após fade
    ped = PlayerPedId()
    SetEntityVisible(ped, true, false)
    SetEntityAlpha(ped, 255, false)
end

-- Função para alternar o menu de spawn
function ToggleSpawnMenu()
    dbg('ToggleSpawnMenu() called')
    
    -- Se já está ativo, não fazer nada (evitar duplicação)
    if interfaceActive then
        return
    end
    
    interfaceActive = true
    local ped = PlayerPedId()
    dbg(('ToggleSpawnMenu: ped=%s fadedOut=%s fadingOut=%s'):format(tostring(ped), tostring(IsScreenFadedOut()), tostring(IsScreenFadingOut())))
    

    -- Importante: qb-multicharacter faz DoScreenFadeOut(10) ao selecionar personagem.
    -- Se ninguém fizer fade in antes de abrir o spawn, a tela fica preta mesmo com a NUI aberta.
    if IsScreenFadingOut() then
        dbg('Tela está em fade out: aguardando finalizar...')
        local t = 0
        while IsScreenFadingOut() and t < 200 do
            Wait(10)
            t = t + 1
        end
    end
    if IsScreenFadedOut() then
        dbg('Tela está faded out: fazendo fade in antes do spawn menu...')
        -- Menu de spawn deve aparecer rápido após salvar personagem
        DoScreenFadeIn(500)
        local t = 0
        while not IsScreenFadedIn() and t < 200 do
            Wait(10)
            t = t + 1
        end
    end

    -- Garantir que não há blur/timecycle herdado do multicharacter
    ClearTimecycleModifier()
    SetTimecycleModifier('default')
    SetTimecycleModifierStrength(0.0)
    ClearTimecycleModifier()
    
    -- Abrir NUI imediatamente (sem esperar playerInfo) -> remove delay após salvar personagem
    TriggerServerEvent("spawn:server:GetLastPosition")
    dbg('ToggleSpawnMenu: pediu last position pro server')

    -- IMPORTANTE:
    -- Não esconder o PlayerPed ao abrir o menu.
    -- Alguns players ficavam "presos invisíveis" após relog/troca de personagem.
    -- A câmera do spawn já controla o que o jogador vê.
    SetEntityVisible(ped, true, false)
    SetEntityAlpha(ped, 255, false)
    ResetEntityAlpha(ped)
    FreezeEntityPosition(ped, true)

    -- Criar câmera inicial primeiro (sem delay)
    activeCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamCoord(activeCam, Config.InitialCamCoords.x, Config.InitialCamCoords.y, Config.InitialCamCoords.z)
    SetCamRot(activeCam, Config.InitialCamRot.x, Config.InitialCamRot.y, Config.InitialCamRot.z, 2)
    SetCamActive(activeCam, true)
    RenderScriptCams(true, true, 0, true, true)

    -- Ativar NUI
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        lastPosition = lastPlayerPosition,
        hasPosition = lastPlayerPosition ~= nil
    })

    -- Thread para manter timecycle limpo enquanto o menu está aberto
    CreateThread(function()
        while interfaceActive do
            Wait(1000)
            ClearTimecycleModifier()
            SetTimecycleModifierStrength(0.0)
        end
    end)

    -- Buscar playerInfo em paralelo (não bloqueia a UI)
    CreateThread(function()
        local ok = pcall(function()
            QBCore.Functions.TriggerCallback('spawn:server:GetPlayerInfo', function(playerInfo)
                if not playerInfo then return end
                dbg('GetPlayerInfo ok (async)')
            end)
        end)
        if not ok then
            -- sem impacto na UI
        end
    end)
end

-- Evento para receber última posição do servidor (spawn)
RegisterNetEvent("spawn:client:ReceiveLastPosition", function(position)
    dbg('ReceiveLastPosition received')
    dbg('ReceiveLastPosition: type=' .. tostring(type(position)))

    if position and position ~= false then
        lastPlayerPosition = position
    else
        lastPlayerPosition = nil
    end

    -- Atualizar botão "Última Localização" na NUI dinamicamente
    SendNUIMessage({
        action = 'updateLastPosition',
        hasPosition = lastPlayerPosition ~= nil
    })
end)

-- Evento para receber última posição do qb-multicharacter (alternativo)
RegisterNetEvent("spawn:client:SetLastPosition", function(position)
    dbg('SetLastPosition received')

    if position and position ~= false then
        lastPlayerPosition = position
    else
        lastPlayerPosition = nil
    end

    -- Atualizar botão "Última Localização" na NUI dinamicamente
    SendNUIMessage({
        action = 'updateLastPosition',
        hasPosition = lastPlayerPosition ~= nil
    })
end)

-- Thread para forçar visibilidade continuamente após spawn (MODO AGRESSIVO)
local function StartForceVisibleThread()
    if forceVisibleThread then
        return -- Já está rodando
    end
    
    forceVisibleThread = CreateThread(function()
        local startTime = GetGameTimer()
        local duration = 15000 -- 15s (failsafe pós-spawn, mais seguro p/ não crashar)
        local ped = PlayerPedId()
        local invisibleCount = 0
        
        
        -- MODO BALANCEADO: força visibilidade periodicamente sem causar crash.
        -- Roda a cada 250ms (4x por segundo) e NÃO reseta câmeras em loop (isso pode crashar alguns clientes).
        -- Se você quiser desabilitar completamente, use:
        -- setr Servidor_force_visible_aggressive 0
        -- Por padrão: OFF. Se precisar, você liga no server.cfg.
        local aggressive = GetConvarInt('Servidor_force_visible_aggressive', 0) == 1

        while (GetGameTimer() - startTime) < duration do
            ped = PlayerPedId()
            
            if ped and ped ~= 0 then
                local visible = IsEntityVisible(ped)
                local alpha = GetEntityAlpha(ped)

                -- Sempre garantir o básico (leve)
                pcall(function()
                    if IsScreenFadedOut() or IsScreenFadingOut() then
                        DoScreenFadeIn(0)
                    end
                    SetEntityVisible(ped, true, false)
                    SetLocalPlayerVisibleLocally(true)
                    SetEntityAlpha(ped, 255, false)
                    ResetEntityAlpha(ped)
                    SetEntityCollision(ped, true, true)
                    if not isSpawning then
                        FreezeEntityPosition(ped, false)
                    end
                    NetworkSetEntityInvisibleToNetwork(ped, false)
                    SetLocalPlayerAsGhost(false)
                    SetPlayerControl(PlayerId(), true, 0)
                end)

                -- Se realmente ficou invisível, aí sim faz um reforço extra
                if (not visible) or (alpha < 250) then
                    invisibleCount = invisibleCount + 1
                    if invisibleCount % 3 == 0 then
                    end

                    -- Limpar statebags problemáticos (com proteção)
                    pcall(function()
                        if LocalPlayer and LocalPlayer.state and LocalPlayer.state.set then
                            LocalPlayer.state:set('Invisible', false, true)
                            LocalPlayer.state:set('Spectate', false, true)
                        end
                    end)

                    -- Modo agressivo opcional: apenas quando necessário (sem reset de câmeras em loop)
                    if aggressive then
                        ForceVisibleNow('forceVisibleThread (aggressive)')
                    end
                end
            end
            
            Wait(250)
        end
        
        -- Verificação final
        ped = PlayerPedId()
        -- No final, um reset leve (evita mexer em câmera global)
        if IsScreenFadedOut() or IsScreenFadingOut() then
            DoScreenFadeIn(0)
        end
        ClearTimecycleModifier()
        SetTimecycleModifier('default')
        SetTimecycleModifierStrength(0.0)
        SetEntityVisible(ped, true, false)
        SetLocalPlayerVisibleLocally(true)
        SetEntityAlpha(ped, 255, false)
        ResetEntityAlpha(ped)
        SetEntityCollision(ped, true, true)
        
        forceVisibleThread = nil
    end)
end

-- Função para validar e ajustar coordenadas antes do spawn (evita crashes)
-- isLastPosition: quando true, NÃO usa GetGroundZFor_3dCoord (pode crashar em interior/área não carregada)
local function ValidateAndAdjustCoords(coords, isLastPosition)
    if not coords then return nil end
    
    local x, y, z = coords.x, coords.y, coords.z
    
    -- Verificar se coordenadas são válidas
    if not x or not y or not z then
        return nil
    end
    
    -- Verificar se não está muito próximo de 0,0,0 (pode causar crash)
    if math.abs(x) < 0.1 and math.abs(y) < 0.1 and math.abs(z) < 0.1 then
        return nil
    end
    
    -- Verificar se Z está muito baixo (debaixo do mapa)
    if z < -50 then
        return nil
    end

    -- Última posição com Z suspeito (embaixo do chão): descarta e usa spawn padrão
    local minZ = (Config and Config.MinSpawnZ) or 15.0
    if isLastPosition and z < minZ then
        return nil
    end
    
    -- Verificar se Z está em range absurdo (evita crash)
    if z > 2500 then
        return nil
    end
    
    -- Para spawn em ponto fixo (não última posição): corrigir Z com chão quando muito diferente
    if not isLastPosition then
        local ok, found, groundZResult = pcall(function()
            local gz = z
            local f, gzr = GetGroundZFor_3dCoord(x, y, math.min(z + 100.0, 2000.0), gz, false)
            return f, gzr
        end)
        if ok and found and groundZResult and math.abs(z - groundZResult) > 10.0 and z < 200 then
            z = groundZResult + 1.0
        end
    elseif z >= minZ and z < 50.0 then
        -- Última posição com Z plausível: confiar no valor salvo pelo servidor
        -- NÃO usar GetGroundZFor_3dCoord aqui (retorna telhado em vez de chão em áreas com estruturas acima)
    elseif isLastPosition and z >= 50.0 then
        -- Última posição com Z >= 50 (possível telhado): tentar ground check
        RequestCollisionAtCoord(x, y, z)
        Wait(500)
        local ok, found, groundZResult = pcall(function()
            local gz = z
            local f, gzr = GetGroundZFor_3dCoord(x, y, z + 5.0, gz, false)
            return f, gzr
        end)
        if ok and found and groundZResult and math.abs(groundZResult - z) > 5.0 then
            z = groundZResult + 1.0
        end
    end
    
    return vector3(x, y, z)
end

-- Callback NUI para cliques de botão
RegisterNUICallback("ButtonClick", function(data, cb)
    dbg('ButtonClick: ' .. tostring(data.callback))
    dbg(('ButtonClick: interfaceActive=%s lastPos=%s'):format(tostring(interfaceActive), tostring(lastPlayerPosition ~= nil)))
    
    local ped = PlayerPedId()
    isSpawning = true -- Impede ForceVisibleNow de descongelar durante teleporte

    -- CRÍTICO: Limpar routing bucket antes do spawn (evita crashes)
    pcall(function()
        SetPlayerRoutingBucket(PlayerId(), 0)
        if ped and ped ~= 0 then
            SetEntityRoutingBucket(ped, 0)
        end
    end)

    -- Guardar destino final para evitar "sumir" após fechar NUI/câmera
    local targetCoords = nil
    local targetHeading = nil

    StartFade()
    
    if data.callback == "last" then
        -- Spawnar na última posição
        if lastPlayerPosition then
            local x = lastPlayerPosition.x or lastPlayerPosition[1] or 0.0
            local y = lastPlayerPosition.y or lastPlayerPosition[2] or 0.0
            local z = lastPlayerPosition.z or lastPlayerPosition[3] or 0.0
            local w = lastPlayerPosition.w or lastPlayerPosition[4] or lastPlayerPosition.h or 0.0
            local spawnHeading = getSpawnHeading(w, true)
            
            
            -- Validar coordenadas SEM usar GetGroundZ (evita crash em interior/área não carregada)
            local validatedCoords = ValidateAndAdjustCoords(vector3(x, y, z), true)
            if not validatedCoords then
                QBCore.Functions.Notify("Última posição inválida! Spawnando em local seguro.", "error")
                -- Usar spawn padrão
                local defaultSpawn = Config.SpawnLocations["Hospital"]
                if defaultSpawn then
                    validatedCoords = vector3(defaultSpawn.coords.x, defaultSpawn.coords.y, defaultSpawn.coords.z)
                    spawnHeading = getSpawnHeading(defaultSpawn.coords.w, false)
                else
                    -- Fallback absoluto
                    validatedCoords = vector3(-1038.03, -2737.89, 13.77) -- Coordenadas seguras do hospital
                    spawnHeading = 0.0
                end
            end
            
            targetCoords = validatedCoords
            targetHeading = spawnHeading
            -- Redirecionar para fallback seguro se última posição estiver na zona crítica (evita crash GTA5_b3258.exe+63288B)
            local center = Config.CriticalZoneCenter
            local radius = (Config.CriticalZoneRadius and Config.CriticalZoneRadius > 0) and Config.CriticalZoneRadius or 0
            if Config.UseSafeFallbackInCriticalZone and center and radius > 0 then
                local dx = validatedCoords.x - center.x
                local dy = validatedCoords.y - center.y
                if (dx * dx + dy * dy) <= (radius * radius) then
                    local safe = Config.SafeFallbackCoords
                    if safe and (safe.x or safe[1]) and (safe.y or safe[2]) and (safe.z or safe[3]) then
                        targetCoords = vector3(safe.x or safe[1], safe.y or safe[2], safe.z or safe[3])
                        targetHeading = getSpawnHeading(safe.w or safe[4] or 0.0, false)
                    end
                end
            end
            
            -- Salvar posição escolhida no servidor
            TriggerServerEvent("spawn:server:SpawnPlayer", "last")
        else
            QBCore.Functions.Notify("Última posição não encontrada! Escolha outro local de spawn.", "error")
            -- Spawnar em local padrão se não tiver última posição
            local defaultSpawn = Config.SpawnLocations["Hospital"]
            if defaultSpawn then
                local spawnHeading = getSpawnHeading(defaultSpawn.coords.w, false)
                targetCoords = vector3(defaultSpawn.coords.x, defaultSpawn.coords.y, defaultSpawn.coords.z)
                targetHeading = spawnHeading
            end
        end
    elseif data.callback == "faction" then
        -- Spawnar em local de facção (implementar conforme necessário)
        QBCore.Functions.Notify("Spawn de facção em desenvolvimento", "info")
    else
        -- Spawnar em local específico
        local spawnName = data.callback
        if Config.SpawnLocations[spawnName] then
            local spawnData = Config.SpawnLocations[spawnName]
            local spawnHeading = getSpawnHeading(spawnData.coords.w, false)
            targetCoords = vector3(spawnData.coords.x, spawnData.coords.y, spawnData.coords.z)
            targetHeading = spawnHeading
            
            TriggerServerEvent("spawn:server:SpawnPlayer", spawnName)
        end
    end

    -- Se não temos coordenadas válidas, usar fallback
    if not targetCoords then
        local defaultSpawn = Config.SpawnLocations["Hospital"]
        if defaultSpawn then
            targetCoords = vector3(defaultSpawn.coords.x, defaultSpawn.coords.y, defaultSpawn.coords.z)
            targetHeading = getSpawnHeading(defaultSpawn.coords.w, false)
        else
            targetCoords = vector3(-1038.03, -2737.89, 13.77)
            targetHeading = 0.0
        end
    end

    -- Fechar interface PRIMEIRO (desativa câmera)
    onCloseInterface()
    
    -- CRÍTICO para "última localização": pedir colisão na posição alvo ANTES de teleportar,
    -- para o jogo carregar a célula e evitar crash (five-sweet-north / GameSkeleton).
    if data.callback == "last" and targetCoords then
        RequestCollisionAtCoord(targetCoords.x, targetCoords.y, targetCoords.z)
        Wait(Config.LastPositionCollisionWaitMs or 800)
    end
    
    -- IMPORTANTE: Aguardar um pouco para garantir que tudo está limpo
    Wait(200)
    
    -- IMPORTANTE: Tornar visível ANTES de qualquer outra coisa
    ped = PlayerPedId() -- Atualizar referência
    
    -- CRÍTICO: Validar coordenadas finais (isLastPosition = true quando veio de "last")
    local finalCoords = ValidateAndAdjustCoords(targetCoords, data.callback == "last")
    if not finalCoords then
        finalCoords = vector3(-1038.03, -2737.89, 13.77)
        targetHeading = 0.0
    end
    
    -- Limpar apenas veículos vazios MUITO próximos (evita crash: loop pesado no spawn)
    pcall(function()
        if not finalCoords then return end
        local pool = GetGamePool('CVehicle')
        local count = 0
        for _, veh in ipairs(pool) do
            if count >= 3 then break end -- Máximo 3 para não travar/crashar
            if DoesEntityExist(veh) then
                local vehCoords = GetEntityCoords(veh)
                local dist = #(vehCoords - finalCoords)
                if dist < 3.0 and GetPedInVehicleSeat(veh, -1) == 0 then
                    DeleteEntity(veh)
                    count = count + 1
                end
            end
        end
    end)
    
    -- Usar NetworkResurrectLocalPlayer APENAS UMA VEZ com coordenadas validadas
    pcall(function()
        NetworkResurrectLocalPlayer(finalCoords.x, finalCoords.y, finalCoords.z, targetHeading, true, true, false)
    end)

    -- CRÍTICO: Limpar death state no servidor e disparar revive no client
    -- Garante que o jogador NÃO fica preso no estado de morte após spawn
    TriggerServerEvent('hospital:server:SetDeathStatus', false)
    TriggerServerEvent('hospital:server:SetLaststandStatus', false)
    TriggerEvent('hospital:client:Revive')

    Wait(100)

    ped = PlayerPedId()

    -- CRÍTICO: Congelar ped ANTES de teleportar (evita queda enquanto colisão carrega)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)

    SetEntityCoordsNoOffset(ped, finalCoords.x, finalCoords.y, finalCoords.z, false, false, false)
    SetEntityHeading(ped, targetHeading)

    -- CRÍTICO: Esperar colisão carregar no destino (sem isso o chão não existe e o ped cai)
    RequestCollisionAtCoord(finalCoords.x, finalCoords.y, finalCoords.z)
    NewLoadSceneStartSphere(finalCoords.x, finalCoords.y, finalCoords.z, 50.0, 0)
    local colTimeout = 0
    while not HasCollisionLoadedAroundEntity(ped) and colTimeout < 50 do
        RequestCollisionAtCoord(finalCoords.x, finalCoords.y, finalCoords.z)
        Wait(100)
        colTimeout = colTimeout + 1
    end
    NewLoadSceneStop()

    -- Reposicionar após colisão (garante que não caiu durante o carregamento)
    SetEntityCoordsNoOffset(ped, finalCoords.x, finalCoords.y, finalCoords.z, false, false, false)
    SetEntityHeading(ped, targetHeading)

    -- CRÍTICO: Setar health IMEDIATAMENTE (não após 10s)
    SetEntityHealth(ped, GetEntityMaxHealth(ped))

    -- CRÍTICO: Garantir routing bucket correto após spawn
    pcall(function()
        SetPlayerRoutingBucket(PlayerId(), 0)
        if ped and ped ~= 0 then
            SetEntityRoutingBucket(ped, 0)
        end
    end)

    -- Forçar visibilidade múltiplas vezes
    SetEntityVisible(ped, true, false)
    SetEntityAlpha(ped, 255, false) -- Garantir alpha máximo
    SetEntityInvincible(ped, false)
    FreezeEntityPosition(ped, false)
    SetPlayerControl(PlayerId(), true, 0)

    -- Verificar se ficou visível
    Wait(100)
    local isVisible = IsEntityVisible(ped)

    if not isVisible then
        ForceVisibleNow('ButtonClick still invisible')
    end

    -- Aguardar um pouco para garantir que tudo está aplicado
    Wait(400)

    -- Chamar EndFade que vai fazer o fade in e garantir câmera desativada
    EndFade()
    
    -- Garantir novamente após o fade (segurança extra)
    Wait(500)
    ped = PlayerPedId()
    
    -- CRÍTICO: Garantir routing bucket novamente após fade
    pcall(function()
        SetPlayerRoutingBucket(PlayerId(), 0)
        if ped and ped ~= 0 then
            SetEntityRoutingBucket(ped, 0)
        end
    end)
    
    SetEntityVisible(ped, true, false)
    SetEntityAlpha(ped, 255, false)
    SetPlayerControl(PlayerId(), true, 0)
    FreezeEntityPosition(ped, false)

    isSpawning = false -- Spawn completo, liberar ForceVisibleNow

    -- Não usar SetFocusEntity no pós-spawn (pode contribuir para crash em alguns clientes)
    pcall(function() ClearFocus() end)

    -- Iniciar thread de força visibilidade
    StartForceVisibleThread()
    -- Auto-recover caso ainda fique invisível (admin/noclip/skin bug)
    RecoverInvisiblePlayer('after spawn ButtonClick=' .. tostring(data.callback))
    

    -- Recarregar skin/aparencia apos spawn (garante que roupas custom carregam)
    if GetResourceState('illenium-appearance') == 'started' then
        dbg('Recarregando skin apos spawn')
        TriggerEvent('illenium-appearance:client:reloadSkin', true)
    end

    -- Sair da sessão tutorial (torna o jogador visível para outros)
    if NetworkIsInTutorialSession() then
        NetworkEndTutorialSession()
    end

    -- Reativar HUD (java-hud é desligada pelo multichar do qbx_core)
    DisplayHud(true)
    DisplayRadar(true)
    TriggerEvent('java_hud:toggleHud', true)

    -- Avisar outros scripts (ex: Servidor-starter-car) que o player concluiu o spawn
    dbg('SpawnCompleted emit')
    TriggerEvent('spawn:client:SpawnCompleted', data.callback)

    -- (REMOVIDO) Auto abrir garagem após spawn: com carro inicial ativo, o fluxo é:
    -- spawn -> escolher carro -> salvar na garage
    
    -- Restaurar saúde reforço (1s após spawn, caso algo tenha resetado)
    SetTimeout(1000, function()
        local ped = PlayerPedId()
        SetEntityHealth(ped, GetEntityMaxHealth(ped))
    end)
    
    cb('ok')
end)

-- Callback NUI para fechar menu (ex: tecla ESC no frontend)
-- Importante: se o frontend só esconder o HTML sem chamar isso,
-- o foco NUI pode ficar preso e quebrar HUDs que dependem de IsNuiFocused().
RegisterNUICallback("Close", function(_, cb)
    dbg('Close callback')
    if interfaceActive then
        onCloseInterface()
    else
        -- Garantir que não ficou foco preso mesmo se interfaceActive estiver falso
        SetNuiFocus(false, false)
        -- Failsafe: também restaurar visibilidade caso algum close aconteça fora de ordem.
        ForceVisibleNow('NUI Close (not interfaceActive)')
    end
    cb('ok')
end)

-- Callback NUI para mudar câmera
RegisterNUICallback("SetCam", function(data, cb)
    local spawnName = data.spawn and data.spawn.name
    
    if spawnName and Config.SpawnLocations[spawnName] then
        local spawnData = Config.SpawnLocations[spawnName]
        
        if DoesCamExist(activeCam) then
            local camZ = spawnData.camCoords.z
            if spawnName == "Hospital" then
                camZ = camZ + 2.5
            else
                camZ = camZ + 2
            end
            
            SetCamCoord(activeCam, spawnData.camCoords.x, spawnData.camCoords.y, camZ)
            SetCamRot(activeCam, 0.0, 0.0, spawnData.camHeading, 2)
            SetCamActive(activeCam, true)
            RenderScriptCams(true, true, 0, true, true)
            
            -- Mover ped para visualização
            local ped = PlayerPedId()
            SetEntityCoords(ped, spawnData.coords.x, spawnData.coords.y, spawnData.coords.z - 1)
            SetEntityHeading(ped, getSpawnHeading(spawnData.coords.w, false))
        end
    end
    
    cb('ok')
end)

-- Export para alternar o menu
exports("ToggleSpawnMenu", ToggleSpawnMenu)

-- Comando de teste (remover em produção)
RegisterCommand('testspawn', function()
    ToggleSpawnMenu()
end, false)

-- Comando para forçar visibilidade (caso algum recurso deixe invisível)
RegisterCommand('fixvis', function()
    ForceVisibleNow('fixvis')
    ForceFadeIn()
    RecoverInvisiblePlayer('fixvis')
    if QBCore and QBCore.Functions and QBCore.Functions.Notify then
        QBCore.Functions.Notify("Visibilidade forçada.", "success")
    end
end, false)

-- Diagnóstico: imprime o estado atual de visibilidade/invisibilidade no console
RegisterCommand('visstatus', function()
    local ped = PlayerPedId()
    local visible = (ped and ped ~= 0) and IsEntityVisible(ped) or false
    local alpha = (ped and ped ~= 0) and GetEntityAlpha(ped) or -1
    local coords = (ped and ped ~= 0) and GetEntityCoords(ped) or vector3(0.0, 0.0, 0.0)
    local stInvisible = (LocalPlayer and LocalPlayer.state and LocalPlayer.state.Invisible) and true or false
    local stSpectate = (LocalPlayer and LocalPlayer.state and LocalPlayer.state.Spectate) and true or false
    local stInvincible = (LocalPlayer and LocalPlayer.state and LocalPlayer.state.Invincible) and true or false
--         tostring(ped), tostring(visible), tostring(alpha),
--         coords.x, coords.y, coords.z,
--         tostring(stInvisible), tostring(stSpectate), tostring(stInvincible)
--     ))
end, false)

-- Comando para forçar fade in e corrigir tela preta
RegisterCommand('fixscreen', function()
    ForceFadeIn()
    QBCore.Functions.Notify("Tela corrigida! Se ainda estiver preta, reinicie o recurso.", "success")
end, false)

-- /roupa removido daqui: Servidor-clothing-ui ja registra este comando

-- Emergência: receber comando do server pra sair da tutorial session
RegisterNetEvent('Servidor:emergency:endTutorial', function()
    if NetworkIsInTutorialSession() then
        NetworkEndTutorialSession()
    end
end)
