const config = {
  url: `https://${(typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'medellin-spawn'}`,
  spawns: [
    {
      name: "Policia",
      callback: "dp",
      image: "./assets/images/dp.webp",
      description: "Um dos locais mais movimentados de nossa cidade, muitas pessoas circulando por ai, você terá facilidade em fazer contatos aqui, vamos lá?",
      position: { left: 30.1, top: 90.5 }
    },
    {
      name: "Paleto",
      callback: "paleto",
      image: "./assets/images/paleto.webp",
      description: "Um dos locais mais movimentados de nossa cidade, muitas pessoas circulando por ai, você terá facilidade em fazer contatos aqui, vamos lá?",
      position: { left: 46.5, top: 23.5 }
    },
    {
      name: "Hospital",
      callback: "hp",
      image: "./assets/images/hp.webp",
      description: "Um dos locais mais movimentados de nossa cidade, muitas pessoas circulando por ai, você terá facilidade em fazer contatos aqui, vamos lá?",
      position: { left: 53, top: 97.5 }
    },
    {
      name: "Pier",
      callback: "pier",
      image: "./assets/images/pier.webp",
      description: "Um dos locais mais movimentados de nossa cidade, muitas pessoas circulando por ai, você terá facilidade em fazer contatos aqui, vamos lá?",
      position: { left: 55.5, top: 103.5 }
    },
    {
      name: "Praça",
      callback: "praca",
      image: "./assets/images/praca.webp",
      description: "Um dos locais mais movimentados de nossa cidade, muitas pessoas circulando por ai, você terá facilidade em fazer contatos aqui, vamos lá?",
      position: { left: 65, top: 102.5 }
    }
  ]
}
