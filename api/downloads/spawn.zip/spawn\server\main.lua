local QBCore = exports['qb-core']:GetCoreObject()

-- ============================================
-- Servidor-SPAWN SERVER
-- Sistema de busca e salvamento de última posição
-- ============================================

-- Evento para buscar a última posição do jogador
RegisterNetEvent('spawn:server:GetLastPosition', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then
        TriggerClientEvent('spawn:client:ReceiveLastPosition', src, nil)
        return
    end
    
    local citizenid = Player.PlayerData.citizenid
    local position = nil
    
    -- Primeiro, tentar obter a posição do PlayerData (em memória)
    if Player.PlayerData.position then
        local pos = Player.PlayerData.position
        if pos.x and pos.y and pos.z then
            position = {
                x = pos.x,
                y = pos.y,
                z = pos.z,
                w = pos.w or pos.h or 0.0
            }
        end
    end
    
    -- Se não encontrou no PlayerData, buscar no banco de dados
    if not position then
        local result = MySQL.query.await('SELECT position FROM players WHERE citizenid = ?', { citizenid })
        if result and result[1] and result[1].position then
            local success, posData = pcall(function()
                return json.decode(result[1].position)
            end)
            
            if success and posData then
                -- Posição pode estar em formato array [x, y, z, w] ou objeto {x, y, z, w}
                if posData.x and posData.y and posData.z then
                    position = {
                        x = posData.x,
                        y = posData.y,
                        z = posData.z,
                        w = posData.w or posData.h or 0.0
                    }
                elseif posData[1] and posData[2] and posData[3] then
                    position = {
                        x = posData[1],
                        y = posData[2],
                        z = posData[3],
                        w = posData[4] or 0.0
                    }
                end
                
                if position then
                end
            else
            end
        else
        end
    end
    
    -- Validar posição antes de enviar (evitar coordenadas que causam crash no cliente)
    if position then
        if math.abs(position.x) < 1 and math.abs(position.y) < 1 and math.abs(position.z) < 1 then
            position = nil
        end
        if position and position.z < -200 then
            position = nil
        end
        if position and position.z > 2500 then
            position = nil
        end
    end
    
    -- Enviar posição para o cliente
    if position then
    else
    end
    
    TriggerClientEvent('spawn:client:ReceiveLastPosition', src, position)
end)

-- Evento quando o jogador spawna em um local
RegisterNetEvent('spawn:server:SpawnPlayer', function(spawnLocation)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then
        return
    end
    
    local citizenid = Player.PlayerData.citizenid
    
    -- Log para registro (opcional - pode usar qb-log se disponível)
    if GetResourceState('qb-log') == 'started' then
        TriggerEvent('qb-log:server:CreateLog', 'spawn', 'Player Spawn', 'green', 
            '**' .. GetPlayerName(src) .. '** (' .. citizenid .. ') spawnou em: ' .. tostring(spawnLocation))
    end
end)

-- Callback para obter informações do jogador (usado pelo cliente)
QBCore.Functions.CreateCallback('spawn:server:GetPlayerInfo', function(source, cb)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then
        cb(nil)
        return
    end
    
    local playerInfo = {
        citizenid = Player.PlayerData.citizenid,
        name = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname,
        job = Player.PlayerData.job.name,
        gang = Player.PlayerData.gang and Player.PlayerData.gang.name or nil,
        money = {
            cash = Player.PlayerData.money.cash or 0,
            bank = Player.PlayerData.money.bank or 0
        }
    }
    
    cb(playerInfo)
end)

-- Evento para salvar posição manualmente (pode ser chamado por outros recursos)
RegisterNetEvent('spawn:server:SavePosition', function(coords)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    local citizenid = Player.PlayerData.citizenid
    
    if coords and coords.x and coords.y and coords.z then
        local position = json.encode({
            x = coords.x,
            y = coords.y,
            z = coords.z,
            w = coords.w or coords.h or 0.0
        })
        
        MySQL.update('UPDATE players SET position = ? WHERE citizenid = ?', { position, citizenid })
    end
end)

-- Comando de emergência: libera TODOS jogadores da tutorial session (invisibilidade)
RegisterCommand('fixtutorial', function(source)
    TriggerClientEvent('Servidor:emergency:endTutorial', -1)
    -- print('^2[FIX] NetworkEndTutorialSession enviado para TODOS os jogadores^0')
end, true)

