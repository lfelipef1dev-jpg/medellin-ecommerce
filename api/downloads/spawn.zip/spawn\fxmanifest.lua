fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Servidor Roleplay'
description 'Sistema de spawn moderno para Servidor Roleplay'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client/main.lua',
    'client/fix-darkness.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/assets/css/main.css',
    'web/assets/js/config.js',
    'web/assets/js/main.js',
    -- NÃO usar wildcard aqui (pode impedir o recurso de iniciar em alguns builds)
    'web/assets/images/map.svg',
    'web/assets/images/box.svg',
    -- Assets do layout Portal (base_portal2/dm_spawn)
    'web/assets/images/title.png',
    'web/assets/images/hexagon.png',
    'web/assets/images/dp.webp',
    'web/assets/images/paleto.webp',
    'web/assets/images/hp.webp',
    'web/assets/images/pier.webp',
    'web/assets/images/praca.webp',
    'web/assets/images/background.webp',
    'web/assets/images/border.png',
    'web/assets/images/map.webp',
    'web/assets/images/objects.png',
    'web/assets/images/vermelho.webp',
}

dependencies {
    'ox_lib',
    'qbx_core'
}
