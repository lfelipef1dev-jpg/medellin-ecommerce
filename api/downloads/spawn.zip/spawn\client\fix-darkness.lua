-- Fix para ambiente escuro/timecycle preso
local QBCore = exports['qb-core']:GetCoreObject()

local function FixDarkness()
    
    -- 1. Limpar timecycle/blur
    ClearTimecycleModifier()
    SetTimecycleModifier('default')
    SetTimecycleModifierStrength(0.0)
    ClearTimecycleModifier()
    
    -- 2. Limpar efeitos visuais presos
    ClearExtraTimecycleModifier()
    SetTransitionTimecycleModifier('default', 0.0)
    
    -- 3. Forçar clima ensolarado
    SetWeatherTypePersist('EXTRASUNNY')
    SetWeatherTypeNow('EXTRASUNNY')
    SetWeatherTypeNowPersist('EXTRASUNNY')
    
    -- 4. Forçar hora do dia (meio-dia)
    NetworkOverrideClockTime(12, 0, 0)
    
    -- 5. Limpar blackscreen effects
    SetBlackout(false)
    
    -- 6. Resetar exposure/gamma
    SetArtificialLightsState(false)
    
    -- 7. Limpar night vision / thermal
    SetNightvision(false)
    SetSeethrough(false)
    
    -- 8. Reabilitar weathersync (se tiver qb-weathersync)
    TriggerEvent('qb-weathersync:client:EnableSync')
    
    
    if QBCore and QBCore.Functions and QBCore.Functions.Notify then
        QBCore.Functions.Notify("Ambiente corrigido (clima + hora + timecycle)", "success")
    end
end

RegisterCommand('fixdark', function()
    FixDarkness()
end, false)

RegisterCommand('fixclima', function()
    FixDarkness()
end, false)

-- Auto-fix ao spawnar (se estiver muito escuro)
AddEventHandler('spawn:client:SpawnCompleted', function()
    CreateThread(function()
        Wait(2000)
        -- Se o timecycle não for 'default', corrigir
        local currentTimecycle = GetTimecycleModifierIndex()
        if currentTimecycle ~= -1 then
            FixDarkness()
        end
    end)
end)

