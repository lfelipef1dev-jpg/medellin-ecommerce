# Sistema de Spawn para FiveM (QBox / QBCore)

Tela de spawn moderna com seleção de local, UI customizada e correção de escuridão ao spawnar.

## Funcionalidades

- UI bonita com mapa e seleção de local de spawn
- Múltiplos pontos de spawn configuráveis com foto/preview
- Correção automática de escuridão (black screen ao spawnar)
- Compatível com multi-personagem (qbx-multicharacter)
- Integração com `ox_lib` para transições

## Pontos de Spawn Inclusos (exemplos)

- Downtown
- Pier
- Paleto Bay
- Hospital
- Praça central

*(Todos configuráveis em `config.lua`)*

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)

## Instalação

1. Coloque a pasta `spawn` dentro de `resources/`
2. Adicione ao `server.cfg`:
   ```
   ensure spawn
   ```
3. Configure os locais em `config.lua` e substitua as imagens em `web/assets/images/`

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
