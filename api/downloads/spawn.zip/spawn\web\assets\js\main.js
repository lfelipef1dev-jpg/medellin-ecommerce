// Spawn NUI (Portal) - alinhado ao index.html atual (.locales)
function post(endpoint, payload) {
  const url = (typeof config === 'object' && config.url) ? config.url : null;
  if (!url) return Promise.reject(new Error('config.url missing'));
  return fetch(`${url}/${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload ?? {}),
  });
}

class App {
  constructor(rootElement, config) {
    this._config = config;
    this._rootElement = rootElement;
    this._spawnSelected = config.spawns[0];
    this._containerCards = rootElement.querySelector(".locales");
    this._init();
  }

  _init() {
    this._config.spawns.forEach((spawn) => this._createCard(spawn));

    window.addEventListener("message", (event) => this._handleVisibilityMessage(event));

    // botão "última localização"
    const lastBtn = this._rootElement.querySelector(".last_local");
    if (lastBtn) lastBtn.addEventListener("click", () => this._sendPostRequest("last"));

    // relógio/data
    const dateEl = document.querySelector('.date p');
    if (dateEl) {
      dateEl.textContent = new Date()
        .toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' })
        .split('/')
        .join('.');
    }
    const clockEl = document.querySelector('.clock p');
    if (clockEl) {
      const update = () => {
        const el = document.querySelector('.clock p');
        if (el) el.textContent = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      };
      update();
      setInterval(update, 1000);
    }

    // ESC fecha (libera foco no client)
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        post('Close', {}).catch(() => {});
        this._setDisplay(false);
      }
    });
  }

  _createCard(item) {
    const cardElement = document.createElement("div");
    cardElement.classList.add("spawn");
    cardElement.innerHTML = `
      <div class="local"></div>
      <div class="name">
        <p>${item.name}</p>
      </div>
      <button type="button">SELECIONAR</button>
    `;

    const localEl = cardElement.querySelector('.local');
    if (localEl) {
      localEl.style.background = `url(${item.image})`;
    }

    // Clique no card: seleciona + atualiza cam
    cardElement.addEventListener("click", () => this._setCam(item, cardElement));

    // Clique no botão: confirma spawn (com balões antes)
    const btn = cardElement.querySelector('button');
    if (btn) {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        // Portal (base_portal2/dm_spawn): envia o NOME do spawn (não o callback abreviado)
        this._sendPostRequest(item.name);
      });
    }

    this._containerCards.appendChild(cardElement);

    // primeira seleção default
    if (this._containerCards.children.length === 1) {
      this._setCam(item, cardElement);
    }
  }

  _setCam(spawn, cardElement) {
    // destacar a opção selecionada (CSS usa .local.selected)
    this._containerCards.querySelectorAll('.local.selected').forEach((el) => el.classList.remove('selected'));
    const localEl = cardElement.querySelector('.local');
    if (localEl) localEl.classList.add('selected');

    this._spawnSelected = spawn;
    post('SetCam', { spawn }).catch(() => {});
  }

  _sendPostRequest(callback) {
    // Portal: confirma spawn imediatamente (sem balões)
    post('ButtonClick', { callback })
      .then(() => this._setDisplay(false))
      .catch(() => {});
  }

  _handleVisibilityMessage({ data }) {
    if (!data || !data.action) return;

    if (data.action === 'open') {
      this._setDisplay(true, data.inFaction);
      // Esconder botão "Última Localização" se jogador não tem posição salva
      this._toggleLastLocalButton(!!data.hasPosition);
    } else if (data.action === 'updateLastPosition') {
      // Atualização dinâmica após servidor responder
      this._toggleLastLocalButton(!!data.hasPosition);
    } else {
      this._setDisplay(false, data.inFaction);
    }
  }

  _toggleLastLocalButton(hasPosition) {
    const lastBtn = this._rootElement.querySelector(".last_local");
    if (lastBtn) {
      lastBtn.style.display = hasPosition ? "" : "none";
    }
  }

  _setDisplay(visible, inFaction) {
    // o CSS do Portal usa body{display:none} então aqui é o "show" real
    this._rootElement.style.display = visible ? "flex" : "none";

    // Se tiver facção no futuro
    const special = document.querySelector(".special_spawn");
    const specialSvg = document.querySelector(".special_spawn svg");
    if (special) {
      special.style.opacity = inFaction ? 1 : 0.2;
      special.style.pointerEvents = inFaction ? "all" : "none";
    }
    if (specialSvg) {
      specialSvg.style.display = inFaction ? "none" : "block";
    }
  }
}

new App(document.querySelector("body"), config);
