Config = {}

-- Coordenadas de spawn disponíveis
Config.SpawnLocations = {
    ["Policia"] = {
        coords = vector4(-830.84, -1216.97, 6.94, 220.0),
        camCoords = vector3(-881.38, -1161.52, 5.14),
        camHeading = 220.0,
        image = "./assets/images/map.svg",
        description = "Departamento de Polícia de Los Santos. Um dos locais mais movimentados da cidade.",
        position = { left = 30.1, top = 90.5 }
    },
    ["Paleto"] = {
        coords = vector4(-783.05, 5559.7, 33.6, 290.0),
        camCoords = vector3(-782.78, 5559.6, 33.59),
        camHeading = 290.0,
        image = "./assets/images/map.svg",
        description = "Pequena cidade costeira ao norte de Los Santos. Ambiente tranquilo e acolhedor.",
        position = { left = 46.5, top = 23.5 }
    },
    ["Hospital"] = {
        coords = vector4(-1197.35, -128.45, 40.86, 160.21),
        camCoords = vector3(-1176.99, -104.93, 40.11),
        camHeading = 160.21,
        image = "./assets/images/map.svg",
        description = "Hospital Central de Pillbox Hill. Centro médico principal da cidade.",
        position = { left = 53, top = 97.5 }
    },
    ["Pier"] = {
        coords = vector4(-1636.93, -984.85, 13.01, 137.62),
        camCoords = vector3(-1636.95, -984.35, 13.01),
        camHeading = 137.62,
        image = "./assets/images/map.svg",
        description = "Píer de Del Perro. Área costeira com vista para o oceano.",
        position = { left = 55.5, top = 103.5 }
    },
    ["Praça"] = {
        coords = vector4(165.77, -1004.86, 29.36, 10.0),
        camCoords = vector3(165.94, -1002.11, 29.35),
        camHeading = 10.0,
        image = "./assets/images/map.svg",
        description = "Praça Central de Los Santos. Coração da cidade, sempre movimentado.",
        position = { left = 65, top = 102.5 }
    },
    ["Aeroporto"] = {
        coords = vector4(-1038.03, -2737.89, 13.77, 305.95),
        camCoords = vector3(-1035.0, -2735.0, 14.77),
        camHeading = 333.0,
        image = "./assets/images/map.svg",
        description = "Aeroporto Internacional de Los Santos. Onde tudo começa.",
        position = { left = 48, top = 113 }
    }
}

-- Heading padrão do spawn:
-- 0.0 = usar exatamente o coords.w de cada ponto.
-- Se quiser inverter (trocar frente/costas) globalmente, use 180.0.
Config.SpawnHeadingOffset = 0.0
Config.ApplyHeadingOffsetToLastPosition = true

-- Coordenadas da câmera inicial
Config.InitialCamCoords = vector3(-1082.17, -59.63, 101.49)
Config.InitialCamRot = vector3(0.0, 0.0, 30.0)

-- Configurações de fade
Config.FadeTime = 500

-- =============================================================================
-- Zona crítica (crash GTA5_b3258.exe+63288B / chicken-fourteen-michigan)
-- Quando a "última posição" cai dentro desta região (Vespucci/píer), o cliente
-- pode crashar ao carregar colisão/streaming. Use fallback para evitar crash.
-- =============================================================================
-- Centro da região problemática (x=-1616.545, y=-1063.780, z=13.019)
Config.CriticalZoneCenter = vector3(-1616.545, -1063.780, 13.019)
Config.CriticalZoneRadius = 80.0
-- true = redireciona spawn "última posição" para SafeFallbackCoords quando na zona crítica (recomendado até validar mapas).
-- false = spawn normal na última posição (use após corrigir .ybn/overlap dos mapas do píer).
Config.UseSafeFallbackInCriticalZone = true
-- Fallback seguro (ex.: Praça / Legion Square)
Config.SafeFallbackCoords = vector4(165.77, -1004.86, 29.36, 10.0)
-- Tempo extra de espera após RequestCollisionAtCoord em última posição (ms); pode reduzir crash em tiles lentos.
Config.LastPositionCollisionWaitMs = 800

-- Z mínimo aceitável para "última posição" (evita nascer embaixo do mapa).
-- 15.0 bloqueava jogadores em áreas baixas da cidade (praia, aeroporto, zonas planas = Z 3~13m).
-- -10.0 descarta só quem realmente está subterrado; ruas normais passam.
Config.MinSpawnZ = -10.0
