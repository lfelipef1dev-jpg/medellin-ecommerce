-- Script de verificação para garantir que tudo está funcionando
-- Execute este código no console F8 do jogo para testar


-- Verificar se o recurso está iniciado
local spawnState = GetResourceState('spawn')

if spawnState == 'started' then
    
    -- Verificar se o export existe
    local success, result = pcall(function()
        return exports['spawn']:ToggleSpawnMenu()
    end)
    
    if success then
    else
    end
else
end

-- Verificar dependências
local qbCoreState = GetResourceState('qb-core')
local appearanceState = GetResourceState('illenium-appearance')


if qbCoreState == 'started' and appearanceState == 'started' then
else
end

