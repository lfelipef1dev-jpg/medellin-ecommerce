# Sistema de Eventos para FiveM (QBox / QBCore)

Sistema completo de eventos sazonais e semanais ativados por admins ou agendados automaticamente.

## Tipos de Evento Inclusos

| Evento | Descrição |
|--------|-----------|
| **XP em Dobro** | Todos os ganhos de XP são dobrados por X minutos |
| **Dinheiro Bônus** | Empregos pagam % a mais durante o evento |
| **Happy Hour** | Itens de shop com desconto |
| **Corrida Maluca** | Corrida entre jogadores com prêmio ao primeiro |
| **Caça ao Tesouro** | Encontre baús escondidos pela cidade |
| **Invasão Zumbi** | Sobreviva e mate zumbis para ganhar recompensas |

## Funcionalidades

- Admins ativam eventos via comando no chat (`/evento iniciar xp_dobrado`)
- Agendamento automático por dia/hora configurável
- Notificação broadcast para todos os jogadores ao iniciar/encerrar
- Duração configurável por evento
- Recompensas em dinheiro e XP

## Requisitos

- `ox_lib`
- `qbx_core` (ou `qb-core` via bridge)

## Instalação

1. Coloque a pasta `eventos` dentro de `resources/`
2. Adicione ao `server.cfg`:
   ```
   ensure eventos
   ```
3. Configure os eventos e agendamentos em `config.lua`

## Comandos de Admin

```
/evento iniciar <nome>     — inicia um evento manualmente
/evento parar              — encerra o evento ativo
/evento listar             — lista todos os eventos disponíveis
```

## Criar Novos Eventos (config.lua)

```lua
Config.Events['meu_evento'] = {
    label = 'Meu Evento',
    description = 'Descrição do evento.',
    duration = 60,  -- minutos
    icon = '🎉',
    effects = { xpMultiplier = 2.0 },
    reward = { money = 10000 },
}
```

## Suporte

Dúvidas? Entre em contato pelo nosso Discord ou abra um ticket no site.
