Config = {}
Config.Debug = false

-- Eventos disponveis (admins ativam via comando)
Config.Events = {
    ['xp_dobrado'] = {
        label = 'XP em Dobro',
        description = 'Todos os ganhos de XP sao dobrados!',
        duration = 120, -- minutos
        icon = '⭐',
        effects = { xpMultiplier = 2.0 },
    },
    ['dinheiro_bonus'] = {
        label = 'Dinheiro Bonus',
        description = 'Todos os trabalhos pagam 50% a mais!',
        duration = 120,
        icon = '💰',
        effects = { moneyMultiplier = 1.5 },
    },
    ['happy_hour'] = {
        label = 'Happy Hour',
        description = 'Bebidas e comidas custam metade do preco!',
        duration = 60,
        icon = '🍺',
        effects = { shopDiscount = 0.5 },
    },
    ['corrida_maluca'] = {
        label = 'Corrida Maluca',
        description = 'Corrida entre jogadores! Primeiro a chegar no checkpoint ganha premio!',
        duration = 30,
        icon = '🏎️',
        effects = { type = 'race' },
        reward = { money = 50000 },
        minPlayers = 3,
    },
    ['caca_tesouro'] = {
        label = 'Caca ao Tesouro',
        description = 'Encontre os 5 baus escondidos pela cidade!',
        duration = 45,
        icon = '🏴‍☠️',
        effects = { type = 'treasure' },
        reward = { money = 25000, xp = 500 },
        treasureLocations = {
            vector3(195.0, -933.0, 30.7),
            vector3(-1037.0, -2736.0, 20.2),
            vector3(1692.0, 4923.0, 42.1),
            vector3(-74.0, 6218.0, 31.1),
            vector3(2564.0, 2577.0, 108.0),
        },
    },
    ['invasao_zumbi'] = {
        label = 'Invasao Zumbi',
        description = 'Sobreviva a horda de zumbis! Mate para ganhar recompensas!',
        duration = 30,
        icon = '🧟',
        effects = { type = 'zombie' },
        reward = { moneyPerKill = 1000, xp = 200 },
    },
    ['corrida_rua'] = {
        label = 'Corrida de Rua',
        description = 'Corridas com bonus! Use /corrida para participar!',
        duration = 120,
        icon = '🏁',
        effects = { type = 'passive', raceMultiplier = 1.5 },
    },
    ['guerra_faccoes'] = {
        label = 'Guerra de Faccoes',
        description = 'Guerras entre faccoes com recompensas bonus!',
        duration = 120,
        icon = '⚔️',
        effects = { type = 'passive', warMultiplier = 1.5 },
    },
}

-- Calendario mensal de eventos
-- Semana calculada: math.ceil(dia_do_mes / 7), cap em 4
Config.Schedule = {
    -- Semana 1 (dias 1-7): xp_dobrado
    { week = 1, day = 'friday',   hour = 20, event = 'xp_dobrado' },
    { week = 1, day = 'saturday', hour = 15, event = 'xp_dobrado' },
    -- Semana 2 (dias 8-14): corrida_rua
    { week = 2, day = 'friday',   hour = 20, event = 'corrida_rua' },
    { week = 2, day = 'saturday', hour = 15, event = 'corrida_rua' },
    -- Semana 3 (dias 15-21): caca_tesouro
    { week = 3, day = 'friday',   hour = 20, event = 'caca_tesouro' },
    { week = 3, day = 'saturday', hour = 15, event = 'caca_tesouro' },
    -- Semana 4 (dias 22-31): guerra_faccoes
    { week = 4, day = 'friday',   hour = 20, event = 'guerra_faccoes' },
    { week = 4, day = 'saturday', hour = 15, event = 'guerra_faccoes' },
}

-- Notificacao global quando evento comeca/termina
Config.GlobalNotification = true
