local QBCore = exports['qb-core']:GetCoreObject()

-- ============================================================
-- Estado dos eventos ativos
-- ============================================================
local activeEvent = nil       -- evento ativo no momento (tabela com dados)
local eventTimer = nil        -- referência do timer para cancelar
local raceParticipants = {}   -- jogadores participando da corrida
local raceCheckpoint = nil    -- coordenada do checkpoint atual
local raceWinner = nil        -- se já houve vencedor
local treasuresFound = {}     -- baús encontrados por cada jogador {[source] = {indexes}}
local zombieKills = {}        -- kills de zumbi por jogador {[source] = count}

-- ============================================================
-- Funções auxiliares
-- ============================================================

--- Retorna o nome do dia da semana em ingles (lowercase)
local function GetDayName()
    local days = { 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday' }
    return days[tonumber(os.date('%w')) + 1]
end

--- Retorna a semana do mes (1-4) baseado no dia
local function GetWeekOfMonth()
    local day = tonumber(os.date('%d'))
    local week = math.ceil(day / 7)
    if week > 4 then week = 4 end
    return week
end

--- Verifica se o jogador é admin (QBCore god/admin)
local function IsAdmin(source)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end
    -- QBCore/QBox: verificar se tem permissão admin ou god
    return QBCore.Functions.HasPermission(source, 'admin') or QBCore.Functions.HasPermission(source, 'god')
end

--- Notifica todos os jogadores conectados
local function NotifyAll(title, message, type)
    if not Config.GlobalNotification then return end
    local players = QBCore.Functions.GetPlayers()
    for _, playerId in ipairs(players) do
        TriggerClientEvent('eventos:client:notify', playerId, title, message, type or 'info')
    end
end

--- Loga informações no console do servidor
local function DebugLog(msg)
    if Config.Debug then
        -- print('[eventos] ' .. msg)
    end
end

-- ============================================================
-- Iniciar evento
-- ============================================================
function StartEvent(eventName, triggeredBy)
    -- Verificar se já existe evento ativo
    if activeEvent then
        return false, 'Ja existe um evento ativo: ' .. activeEvent.label
    end

    -- Verificar se o evento existe na config
    local eventConfig = Config.Events[eventName]
    if not eventConfig then
        return false, 'Evento nao encontrado: ' .. eventName
    end

    -- Para corrida, verificar minimo de jogadores
    if eventConfig.minPlayers then
        local playerCount = #QBCore.Functions.GetPlayers()
        if playerCount < eventConfig.minPlayers then
            return false, 'Minimo de ' .. eventConfig.minPlayers .. ' jogadores necessarios. Online: ' .. playerCount
        end
    end

    -- Montar dados do evento ativo
    activeEvent = {
        name = eventName,
        label = eventConfig.label,
        description = eventConfig.description,
        icon = eventConfig.icon,
        effects = eventConfig.effects,
        reward = eventConfig.reward,
        duration = eventConfig.duration,
        startTime = os.time(),
        endTime = os.time() + (eventConfig.duration * 60),
        triggeredBy = triggeredBy or 'sistema',
    }

    -- Resetar dados de mini-eventos
    raceParticipants = {}
    raceCheckpoint = nil
    raceWinner = nil
    treasuresFound = {}
    zombieKills = {}

    -- Configurar dados especificos por tipo de evento
    local effectType = eventConfig.effects and eventConfig.effects.type

    if effectType == 'race' then
        -- Gerar checkpoint aleatorio para a corrida
        local raceCoords = {
            vector3(117.2, -1955.4, 20.8),
            vector3(-1609.3, -1075.0, 13.0),
            vector3(1198.0, -1501.0, 35.2),
            vector3(-537.0, -210.0, 37.6),
            vector3(247.0, -370.0, 44.7),
        }
        raceCheckpoint = raceCoords[math.random(#raceCoords)]
        activeEvent.checkpoint = raceCheckpoint
        DebugLog('Corrida iniciada - checkpoint: ' .. tostring(raceCheckpoint))

    elseif effectType == 'treasure' then
        -- As localizacoes ja estao na config
        activeEvent.treasureLocations = eventConfig.treasureLocations
        DebugLog('Caca ao tesouro iniciada - ' .. #eventConfig.treasureLocations .. ' baus')

    elseif effectType == 'zombie' then
        DebugLog('Invasao zumbi iniciada')
    end

    -- Setar GlobalState para sincronizar com todos os clients
    GlobalState.activeEvent = activeEvent

    -- Notificar todos os jogadores (BigNotify se notify disponivel)
    local startMsg = eventConfig.description .. ' (Duracao: ' .. eventConfig.duration .. ' min)'
    if GetResourceState('notify') == 'started' then
        TriggerClientEvent('BigNotify', -1, 'amarelo', startMsg, 10000, 'EVENTO: ' .. eventConfig.label)
    else
        NotifyAll(
            eventConfig.icon .. ' EVENTO: ' .. eventConfig.label,
            startMsg,
            'success'
        )
    end

    -- Disparar evento para os clients configurarem visuals
    TriggerClientEvent('eventos:client:eventStarted', -1, activeEvent)

    DebugLog('Evento iniciado: ' .. eventName .. ' por ' .. (triggeredBy or 'sistema'))
    -- print('[eventos] ^2Evento iniciado: ' .. eventConfig.label .. ' (' .. eventConfig.duration .. ' min)^0')

    -- Iniciar timer para encerrar automaticamente
    if eventTimer then
        clearTimeout(eventTimer)
    end

    eventTimer = SetTimeout(eventConfig.duration * 60 * 1000, function()
        StopEvent('tempo_esgotado')
    end)

    return true, 'Evento ' .. eventConfig.label .. ' iniciado com sucesso!'
end

-- ============================================================
-- Parar evento
-- ============================================================
function StopEvent(reason)
    if not activeEvent then
        return false, 'Nenhum evento ativo no momento.'
    end

    local eventName = activeEvent.name
    local eventLabel = activeEvent.label
    local effectType = activeEvent.effects and activeEvent.effects.type
    reason = reason or 'encerrado_manualmente'

    -- Processar resultados finais de mini-eventos
    if effectType == 'race' and not raceWinner then
        NotifyAll('🏎️ Corrida Maluca', 'Ninguem chegou ao checkpoint a tempo! Sem vencedor.', 'error')

    elseif effectType == 'treasure' then
        -- Dar recompensa para quem encontrou baus
        local eventConfig = Config.Events[eventName]
        for src, found in pairs(treasuresFound) do
            local Player = QBCore.Functions.GetPlayer(src)
            if Player then
                local count = #found
                if count > 0 then
                    local moneyReward = math.floor((eventConfig.reward.money or 0) * (count / #eventConfig.treasureLocations))
                    local xpReward = math.floor((eventConfig.reward.xp or 0) * (count / #eventConfig.treasureLocations))
                    if moneyReward > 0 then
                        Player.Functions.AddMoney('bank', moneyReward, 'evento-caca-tesouro')
                    end
                    TriggerClientEvent('eventos:client:notify', src,
                        'Caca ao Tesouro - Fim!',
                        'Voce encontrou ' .. count .. ' bau(s) e ganhou $' .. moneyReward,
                        'success'
                    )
                end
            end
        end

    elseif effectType == 'zombie' then
        -- Dar recompensas de kills
        local eventConfig = Config.Events[eventName]
        for src, kills in pairs(zombieKills) do
            local Player = QBCore.Functions.GetPlayer(src)
            if Player then
                if kills > 0 then
                    local moneyReward = kills * (eventConfig.reward.moneyPerKill or 0)
                    if moneyReward > 0 then
                        Player.Functions.AddMoney('bank', moneyReward, 'evento-zumbi-kills')
                    end
                    TriggerClientEvent('eventos:client:notify', src,
                        'Invasao Zumbi - Fim!',
                        'Voce matou ' .. kills .. ' zumbi(s) e ganhou $' .. moneyReward,
                        'success'
                    )
                end
            end
        end
    end

    -- Cancelar timer
    if eventTimer then
        clearTimeout(eventTimer)
        eventTimer = nil
    end

    -- Limpar GlobalState
    GlobalState.activeEvent = nil

    -- Notificar todos (BigNotify se notify disponivel)
    local stopMsg = eventLabel .. ' foi encerrado! (' .. reason .. ')'
    if GetResourceState('notify') == 'started' then
        TriggerClientEvent('BigNotify', -1, 'vermelho', stopMsg, 8000, 'EVENTO ENCERRADO')
    else
        NotifyAll('Evento Encerrado', stopMsg, 'error')
    end

    -- Disparar evento para clients limparem visuals
    TriggerClientEvent('eventos:client:eventStopped', -1, eventName)

    -- print('[eventos] ^1Evento encerrado: ' .. eventLabel .. ' - Motivo: ' .. reason .. '^0')

    -- Limpar estado
    activeEvent = nil
    raceParticipants = {}
    raceCheckpoint = nil
    raceWinner = nil
    treasuresFound = {}
    zombieKills = {}

    return true, 'Evento ' .. eventLabel .. ' encerrado.'
end

-- ============================================================
-- Comandos de admin
-- ============================================================

-- /evento [nome] - Iniciar um evento manualmente
QBCore.Commands.Add('evento', 'Iniciar um evento (admin)', {
    { name = 'nome', help = 'Nome do evento (ex: xp_dobrado, happy_hour)' },
}, false, function(source, args)
    if not IsAdmin(source) then
        TriggerClientEvent('eventos:client:notify', source, 'Erro', 'Sem permissao.', 'error')
        return
    end

    local eventName = args[1]
    if not eventName then
        -- Mostrar lista de eventos disponíveis
        local msg = 'Eventos disponiveis: '
        for name, event in pairs(Config.Events) do
            msg = msg .. '\n' .. event.icon .. ' ' .. name .. ' - ' .. event.label
        end
        TriggerClientEvent('eventos:client:notify', source, 'Eventos', msg, 'info')
        return
    end

    local success, message = StartEvent(eventName, tostring(source))
    local type = success and 'success' or 'error'
    TriggerClientEvent('eventos:client:notify', source, 'Eventos', message, type)
end)

-- /pararevento - Parar o evento ativo
QBCore.Commands.Add('pararevento', 'Parar o evento ativo (admin)', {}, false, function(source, args)
    if not IsAdmin(source) then
        TriggerClientEvent('eventos:client:notify', source, 'Erro', 'Sem permissao.', 'error')
        return
    end

    local success, message = StopEvent('admin_' .. tostring(source))
    local type = success and 'success' or 'error'
    TriggerClientEvent('eventos:client:notify', source, 'Eventos', message, type)
end)

-- /eventos - Listar eventos disponíveis
QBCore.Commands.Add('eventos', 'Listar eventos disponiveis (admin)', {}, false, function(source, args)
    if not IsAdmin(source) then
        TriggerClientEvent('eventos:client:notify', source, 'Erro', 'Sem permissao.', 'error')
        return
    end

    local msg = ''
    for name, event in pairs(Config.Events) do
        msg = msg .. event.icon .. ' ' .. name .. ' - ' .. event.label .. ' (' .. event.duration .. 'min)\n'
    end

    if activeEvent then
        local remaining = math.max(0, activeEvent.endTime - os.time())
        local mins = math.floor(remaining / 60)
        msg = msg .. '\n--- EVENTO ATIVO ---\n'
        msg = msg .. activeEvent.icon .. ' ' .. activeEvent.label .. ' (resta: ' .. mins .. 'min)'
    else
        msg = msg .. '\nNenhum evento ativo no momento.'
    end

    TriggerClientEvent('eventos:client:notify', source, 'Lista de Eventos', msg, 'info')
end)

-- ============================================================
-- Exports para outros resources
-- ============================================================

--- Retorna o evento ativo ou nil
local function GetActiveEvent()
    return activeEvent
end

--- Retorna o multiplicador de acordo com o tipo (xp, money, shop)
local function GetEventMultiplier(type)
    if not activeEvent or not activeEvent.effects then
        return 1.0
    end

    if type == 'xp' and activeEvent.effects.xpMultiplier then
        return activeEvent.effects.xpMultiplier
    elseif type == 'money' and activeEvent.effects.moneyMultiplier then
        return activeEvent.effects.moneyMultiplier
    elseif type == 'shop' and activeEvent.effects.shopDiscount then
        return activeEvent.effects.shopDiscount
    elseif type == 'race' and activeEvent.effects.raceMultiplier then
        return activeEvent.effects.raceMultiplier
    elseif type == 'war' and activeEvent.effects.warMultiplier then
        return activeEvent.effects.warMultiplier
    end

    return 1.0
end

--- Verifica se um evento especifico esta ativo
local function IsEventActive(eventName)
    if not activeEvent then return false end
    return activeEvent.name == eventName
end

exports('GetActiveEvent', GetActiveEvent)
exports('GetEventMultiplier', GetEventMultiplier)
exports('IsEventActive', IsEventActive)

-- ============================================================
-- Eventos de corrida - jogador chegou no checkpoint
-- ============================================================
RegisterNetEvent('eventos:server:raceCheckpointReached', function()
    local src = source
    if not activeEvent or activeEvent.name ~= 'corrida_maluca' then return end
    if raceWinner then return end -- ja tem vencedor

    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    raceWinner = src
    local playerName = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname

    -- Dar premio ao vencedor
    local eventConfig = Config.Events['corrida_maluca']
    if eventConfig.reward and eventConfig.reward.money then
        Player.Functions.AddMoney('bank', eventConfig.reward.money, 'evento-corrida-premio')
    end

    -- Anunciar vencedor
    NotifyAll(
        '🏎️ Corrida Maluca - Vencedor!',
        playerName .. ' chegou primeiro e ganhou $' .. (eventConfig.reward.money or 0) .. '!',
        'success'
    )

    -- Encerrar corrida apos 10 segundos
    SetTimeout(10000, function()
        if activeEvent and activeEvent.name == 'corrida_maluca' then
            StopEvent('vencedor_encontrado')
        end
    end)
end)

-- ============================================================
-- Eventos de caca ao tesouro - jogador encontrou um bau
-- ============================================================
RegisterNetEvent('eventos:server:treasureFound', function(treasureIndex)
    local src = source
    if not activeEvent or activeEvent.name ~= 'caca_tesouro' then return end

    local eventConfig = Config.Events['caca_tesouro']
    if not eventConfig.treasureLocations[treasureIndex] then return end

    -- Inicializar tabela do jogador
    if not treasuresFound[src] then
        treasuresFound[src] = {}
    end

    -- Verificar se o jogador ja encontrou esse bau
    for _, idx in ipairs(treasuresFound[src]) do
        if idx == treasureIndex then
            return -- ja encontrou
        end
    end

    table.insert(treasuresFound[src], treasureIndex)

    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local playerName = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
    local found = #treasuresFound[src]
    local total = #eventConfig.treasureLocations

    TriggerClientEvent('eventos:client:notify', src,
        'Bau Encontrado!',
        'Voce encontrou ' .. found .. '/' .. total .. ' baus!',
        'success'
    )

    -- Notificar todos que alguem encontrou um bau
    NotifyAll(
        '🏴‍☠️ Caca ao Tesouro',
        playerName .. ' encontrou um bau! (' .. found .. '/' .. total .. ')',
        'info'
    )

    -- Se encontrou todos, bonus especial
    if found >= total then
        local bonusMoney = eventConfig.reward.money or 0
        Player.Functions.AddMoney('bank', bonusMoney, 'evento-tesouro-todos')
        NotifyAll(
            '🏴‍☠️ INCRIVEL!',
            playerName .. ' encontrou TODOS os baus e ganhou bonus de $' .. bonusMoney .. '!',
            'success'
        )
    end
end)

-- ============================================================
-- Eventos de zumbi - jogador matou um zumbi
-- ============================================================
RegisterNetEvent('eventos:server:zombieKill', function()
    local src = source
    if not activeEvent or activeEvent.name ~= 'invasao_zumbi' then return end

    if not zombieKills[src] then
        zombieKills[src] = 0
    end

    zombieKills[src] = zombieKills[src] + 1

    -- Recompensa instantanea por kill
    local eventConfig = Config.Events['invasao_zumbi']
    local Player = QBCore.Functions.GetPlayer(src)
    if Player and eventConfig.reward and eventConfig.reward.moneyPerKill then
        Player.Functions.AddMoney('cash', eventConfig.reward.moneyPerKill, 'evento-zumbi-kill')
    end

    DebugLog('Jogador ' .. src .. ' matou zumbi. Total: ' .. zombieKills[src])
end)

-- ============================================================
-- Agendamento automatico de eventos
-- ============================================================
CreateThread(function()
    -- Esperar servidor estabilizar
    Wait(30000)

    local lastScheduleCheck = ''

    while true do
        Wait(60000) -- Verificar a cada 1 minuto

        -- Nao agendar se ja tem evento ativo
        if not activeEvent then
            local currentDay = GetDayName()
            local currentHour = tonumber(os.date('%H'))
            local currentWeek = GetWeekOfMonth()
            local checkKey = currentWeek .. '_' .. currentDay .. '_' .. currentHour

            -- Evitar disparar o mesmo agendamento mais de uma vez
            if checkKey ~= lastScheduleCheck then
                lastScheduleCheck = checkKey

                for _, schedule in ipairs(Config.Schedule) do
                    if schedule.week == currentWeek and schedule.day == currentDay and schedule.hour == currentHour then
                        DebugLog('Agendamento encontrado: ' .. schedule.event .. ' (semana ' .. currentWeek .. ', ' .. currentDay .. ' ' .. currentHour .. 'h)')
                        local success, msg = StartEvent(schedule.event, 'agendamento')
                        if success then
                            -- print('[eventos] ^3Evento agendado iniciado: ' .. schedule.event .. '^0')
                        else
                            DebugLog('Falha ao iniciar evento agendado: ' .. msg)
                        end
                        break
                    end
                end
            end
        end
    end
end)

-- ============================================================
-- Sincronizar evento ativo quando jogador conecta
-- ============================================================
RegisterNetEvent('eventos:server:requestSync', function()
    local src = source
    if activeEvent then
        TriggerClientEvent('eventos:client:eventStarted', src, activeEvent)
    end
end)

-- ============================================================
-- Limpar dados quando jogador desconecta
-- ============================================================
AddEventHandler('playerDropped', function()
    local src = source
    treasuresFound[src] = nil
    zombieKills[src] = nil
end)

-- ============================================================
-- Log de inicializacao
-- ============================================================
CreateThread(function()
    local count = 0
    for _ in pairs(Config.Events) do count = count + 1 end
    -- print('[eventos] ^2Sistema de eventos carregado!^0')
    -- print('[eventos] ^2' .. count .. ' eventos disponiveis.^0')
    -- print('[eventos] ^2' .. #Config.Schedule .. ' agendamentos configurados.^0')
end)
