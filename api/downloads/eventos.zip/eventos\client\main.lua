local QBCore = exports['qb-core']:GetCoreObject()

-- ============================================================
-- Estado local do client
-- ============================================================
local currentEvent = nil          -- dados do evento ativo
local eventEndTime = 0            -- timestamp de quando o evento termina
local showTimer = false           -- se esta mostrando o timer na tela
local raceBlip = nil              -- blip do checkpoint da corrida
local treasureBlips = {}          -- blips dos tesouros (dicas)
local zombiePeds = {}             -- peds de zumbi spawnados
local zombieSpawnThread = false   -- se a thread de spawn de zumbis esta ativa
local foundTreasures = {}         -- indices de baus ja encontrados pelo jogador

-- ============================================================
-- Funcoes auxiliares
-- ============================================================

--- Exibe notificacao para o jogador (usa ox_lib se disponivel, senao QBCore)
local function Notify(title, message, type)
    -- Tentar usar ox_lib
    local success = pcall(function()
        lib.notify({
            title = title,
            description = message,
            type = type or 'info',
            duration = 7000,
        })
    end)

    if not success then
        -- Fallback para QBCore notification
        QBCore.Functions.Notify(title .. ': ' .. message, type or 'primary', 7000)
    end
end

--- Remove um blip com seguranca
local function SafeRemoveBlip(blip)
    if blip and DoesBlipExist(blip) then
        RemoveBlip(blip)
    end
end

--- Limpa todos os blips de evento
local function ClearEventBlips()
    SafeRemoveBlip(raceBlip)
    raceBlip = nil

    for _, blip in ipairs(treasureBlips) do
        SafeRemoveBlip(blip)
    end
    treasureBlips = {}
end

--- Remove todos os peds zumbi spawnados
local function ClearZombiePeds()
    for _, ped in ipairs(zombiePeds) do
        if DoesEntityExist(ped) then
            DeleteEntity(ped)
        end
    end
    zombiePeds = {}
    zombieSpawnThread = false
end

--- Formata segundos em MM:SS
local function FormatTime(seconds)
    if seconds < 0 then seconds = 0 end
    local mins = math.floor(seconds / 60)
    local secs = seconds % 60
    return string.format('%02d:%02d', mins, secs)
end

-- ============================================================
-- Receber notificacao do servidor
-- ============================================================
RegisterNetEvent('eventos:client:notify', function(title, message, type)
    Notify(title, message, type)
end)

-- ============================================================
-- Evento iniciou
-- ============================================================
RegisterNetEvent('eventos:client:eventStarted', function(eventData)
    currentEvent = eventData
    eventEndTime = eventData.endTime
    showTimer = true
    foundTreasures = {}

    local effectType = eventData.effects and eventData.effects.type

    -- Configurar visuais por tipo de evento
    if effectType == 'race' and eventData.checkpoint then
        -- Criar blip no checkpoint da corrida
        raceBlip = AddBlipForCoord(eventData.checkpoint.x, eventData.checkpoint.y, eventData.checkpoint.z)
        SetBlipSprite(raceBlip, 315) -- icone de bandeira
        SetBlipColour(raceBlip, 5)   -- amarelo
        SetBlipScale(raceBlip, 1.5)
        SetBlipRoute(raceBlip, true)
        SetBlipRouteColour(raceBlip, 5)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName('Checkpoint - Corrida Maluca')
        EndTextCommandSetBlipName(raceBlip)

        Notify('🏎️ Corrida Maluca', 'Siga o GPS ate o checkpoint! Primeiro a chegar ganha!', 'info')

        -- Thread para verificar distancia e chegada (lógica, loop lento)
        CreateThread(function()
            while currentEvent and currentEvent.name == 'corrida_maluca' do
                Wait(500)
                local playerCoords = GetEntityCoords(PlayerPedId())
                local dist = #(playerCoords - eventData.checkpoint)
                if dist < 5.0 then
                    TriggerServerEvent('eventos:server:raceCheckpointReached')
                    Notify('🏎️ Checkpoint!', 'Voce chegou ao checkpoint!', 'success')
                    break
                end
            end
        end)

        -- Thread para desenhar marcador (render, loop rápido Wait(0))
        CreateThread(function()
            while currentEvent and currentEvent.name == 'corrida_maluca' do
                local playerCoords = GetEntityCoords(PlayerPedId())
                local dist = #(playerCoords - eventData.checkpoint)
                if dist < 30.0 then
                    DrawMarker(1, eventData.checkpoint.x, eventData.checkpoint.y, eventData.checkpoint.z - 1.0,
                        0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 255, 255, 0, 100, false, false, 2, false, nil, nil, false)
                    Wait(0)
                else
                    Wait(500)
                end
            end
        end)

    elseif effectType == 'treasure' and eventData.treasureLocations then
        -- Nao mostrar localizacoes exatas, apenas dicas de proximidade
        Notify('🏴‍☠️ Caca ao Tesouro', 'Explore a cidade para encontrar os baus! Fique atento as dicas!', 'info')

        -- Variavel compartilhada para o marcador do tesouro
        local treasureMarkerData = { active = false, coords = nil }

        -- Thread para dar dicas de quente/frio (lógica, loop lento)
        CreateThread(function()
            while currentEvent and currentEvent.name == 'caca_tesouro' do
                Wait(2000)
                local playerCoords = GetEntityCoords(PlayerPedId())
                local closestDist = 99999.0
                local closestIndex = nil

                for i, loc in ipairs(eventData.treasureLocations) do
                    local alreadyFound = false
                    for _, fi in ipairs(foundTreasures) do
                        if fi == i then
                            alreadyFound = true
                            break
                        end
                    end

                    if not alreadyFound then
                        local dist = #(playerCoords - loc)
                        if dist < closestDist then
                            closestDist = dist
                            closestIndex = i
                        end
                    end
                end

                if closestIndex then
                    if closestDist < 5.0 then
                        local loc = eventData.treasureLocations[closestIndex]
                        treasureMarkerData = { active = true, coords = loc }

                        if closestDist < 2.0 then
                            table.insert(foundTreasures, closestIndex)
                            TriggerServerEvent('eventos:server:treasureFound', closestIndex)
                            PlaySoundFrontend(-1, 'PICK_UP', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
                            treasureMarkerData.active = false
                        end
                    else
                        treasureMarkerData.active = false
                        if closestDist < 30.0 then
                            ShowHint('~r~MUITO QUENTE! O bau esta muito perto!')
                        elseif closestDist < 80.0 then
                            ShowHint('~o~QUENTE! Voce esta se aproximando de um bau!')
                        elseif closestDist < 200.0 then
                            ShowHint('~y~Morno... Um bau nao esta muito longe.')
                        end
                    end
                end
            end
        end)

        -- Thread de render para marcador do tesouro (Wait(0) só quando perto)
        CreateThread(function()
            while currentEvent and currentEvent.name == 'caca_tesouro' do
                if treasureMarkerData.active and treasureMarkerData.coords then
                    local c = treasureMarkerData.coords
                    DrawMarker(2, c.x, c.y, c.z, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 255, 215, 0, 200, true, false, 2, false, nil, nil, false)
                    Wait(0)
                else
                    Wait(500)
                end
            end
        end)

    elseif effectType == 'zombie' then
        Notify('🧟 Invasao Zumbi', 'Zumbis estao aparecendo! Mate-os para ganhar recompensas!', 'error')
        StartZombieSpawner()

    elseif effectType == 'passive' then
        Notify(eventData.icon .. ' ' .. eventData.label, eventData.description, 'info')
    end

    -- Tocar som de inicio de evento
    PlaySoundFrontend(-1, 'FLIGHT_SCHOOL_LESSON_PASSED', 'HUD_AWARDS', true)
end)

-- ============================================================
-- Evento terminou
-- ============================================================
RegisterNetEvent('eventos:client:eventStopped', function(eventName)
    currentEvent = nil
    showTimer = false
    eventEndTime = 0

    -- Limpar todos os visuais
    ClearEventBlips()
    ClearZombiePeds()

    -- Tocar som de fim de evento
    PlaySoundFrontend(-1, 'FLIGHT_SCHOOL_LESSON_FAILED', 'HUD_AWARDS', true)
end)

-- ============================================================
-- Timer na tela (canto superior direito)
-- ============================================================
CreateThread(function()
    while true do
        if showTimer and currentEvent then
            local remaining = eventEndTime - os.time()
            if remaining <= 0 then
                showTimer = false
            else
                local timeText = FormatTime(remaining)
                local eventText = (currentEvent.icon or '') .. ' ' .. (currentEvent.label or 'Evento')

                -- Fundo semi-transparente
                DrawRect(0.92, 0.04, 0.16, 0.05, 0, 0, 0, 150)

                -- Texto do evento
                SetTextFont(4)
                SetTextScale(0.0, 0.35)
                SetTextColour(255, 255, 255, 255)
                SetTextCentre(true)
                SetTextDropshadow(1, 0, 0, 0, 255)
                SetTextEntry('STRING')
                AddTextComponentSubstringPlayerName(eventText)
                DrawText(0.92, 0.02)

                -- Tempo restante
                SetTextFont(4)
                SetTextScale(0.0, 0.40)
                SetTextColour(255, 200, 50, 255)
                SetTextCentre(true)
                SetTextDropshadow(1, 0, 0, 0, 255)
                SetTextEntry('STRING')
                AddTextComponentSubstringPlayerName(timeText)
                DrawText(0.92, 0.045)
            end
            Wait(0) -- DrawRect/DrawText sao ThisFrame
        else
            Wait(1000)
        end
    end
end)

-- ============================================================
-- Mostrar dica na tela (temporaria)
-- ============================================================
local hintText = nil
local hintEndTime = 0

function ShowHint(text, duration)
    hintText = text
    hintEndTime = GetGameTimer() + (duration or 3000)
end

CreateThread(function()
    while true do
        if hintText and GetGameTimer() < hintEndTime then
            SetTextFont(4)
            SetTextScale(0.0, 0.38)
            SetTextColour(255, 255, 255, 255)
            SetTextCentre(true)
            SetTextDropshadow(1, 0, 0, 0, 255)
            SetTextOutline()
            SetTextEntry('STRING')
            AddTextComponentSubstringPlayerName(hintText)
            DrawText(0.5, 0.85)
            Wait(0) -- DrawText e ThisFrame
        else
            if hintText then hintText = nil end
            Wait(500)
        end
    end
end)

-- ============================================================
-- Spawner de zumbis
-- ============================================================
function StartZombieSpawner()
    if zombieSpawnThread then return end
    zombieSpawnThread = true

    -- Modelos de peds para usar como "zumbis"
    local zombieModels = {
        'a_m_m_tramp_01',
        'a_m_o_tramp_01',
        'a_f_m_tramp_01',
        'u_m_y_zombie_01', -- modelo de zumbi do GTA
    }

    CreateThread(function()
        while zombieSpawnThread and currentEvent and currentEvent.name == 'invasao_zumbi' do
            Wait(8000) -- Spawn a cada 8 segundos

            -- Limitar quantidade de zumbis simultaneos (mortos sao removidos pela thread de monitoramento)
            local alive = {}
            for _, ped in ipairs(zombiePeds) do
                if DoesEntityExist(ped) and not IsEntityDead(ped) then
                    table.insert(alive, ped)
                end
            end
            zombiePeds = alive

            if #zombiePeds >= 8 then
                goto continue
            end

            -- Spawnar zumbi em posicao aleatoria perto do jogador
            local playerCoords = GetEntityCoords(PlayerPedId())
            local angle = math.random() * 2 * math.pi
            local distance = 30.0 + math.random() * 30.0
            local spawnX = playerCoords.x + math.cos(angle) * distance
            local spawnY = playerCoords.y + math.sin(angle) * distance
            local spawnZ = playerCoords.z

            -- Encontrar Z correto no chao
            local found, groundZ = GetGroundZFor_3dCoord(spawnX, spawnY, spawnZ + 50.0, false)
            if found then
                spawnZ = groundZ
            end

            -- Escolher modelo aleatorio
            local model = zombieModels[math.random(#zombieModels)]
            local hash = GetHashKey(model)

            RequestModel(hash)
            local timeout = 0
            while not HasModelLoaded(hash) and timeout < 50 do
                Wait(100)
                timeout = timeout + 1
            end

            if HasModelLoaded(hash) then
                local zombie = CreatePed(4, hash, spawnX, spawnY, spawnZ, math.random(0, 360) + 0.0, true, true)

                if DoesEntityExist(zombie) then
                    -- Configurar comportamento agressivo
                    SetPedFleeAttributes(zombie, 0, false)
                    SetPedCombatAttributes(zombie, 46, true) -- sempre lutar
                    SetPedCombatAttributes(zombie, 5, true)  -- pode lutar com armas
                    SetBlockingOfNonTemporaryEvents(zombie, true)

                    -- Fazer o zumbi atacar o jogador
                    TaskCombatPed(zombie, PlayerPedId(), 0, 16)

                    -- Configurar para andar como zumbi (lento e cambaleante)
                    SetPedMoveRateOverride(zombie, 0.6)
                    SetPedSuffersCriticalHits(zombie, true)

                    -- Nao dar drop de itens
                    SetPedDropsWeaponsWhenDead(zombie, false)

                    -- Resistencia reduzida - morre facil
                    SetEntityHealth(zombie, 150)
                    SetPedArmour(zombie, 0)

                    -- Marcar como missao para nao despawnar
                    SetEntityAsMissionEntity(zombie, true, true)

                    table.insert(zombiePeds, zombie)
                end

                SetModelAsNoLongerNeeded(hash)
            end

            ::continue::
        end

        -- Quando o loop terminar, limpar zumbis restantes
        ClearZombiePeds()
    end)
end

-- ============================================================
-- Monitorar morte de zumbis (thread separada para precisao)
-- ============================================================
CreateThread(function()
    while true do
        Wait(1000)
        if currentEvent and currentEvent.name == 'invasao_zumbi' then
            local newAlive = {}
            for _, ped in ipairs(zombiePeds) do
                if DoesEntityExist(ped) then
                    if IsEntityDead(ped) then
                        TriggerServerEvent('eventos:server:zombieKill')
                        SetTimeout(15000, function()
                            if DoesEntityExist(ped) then
                                DeleteEntity(ped)
                            end
                        end)
                    else
                        -- Redirecionar para o jogador se ficou parado
                        local pedCoords = GetEntityCoords(ped)
                        local playerCoords = GetEntityCoords(PlayerPedId())
                        local dist = #(pedCoords - playerCoords)

                        if dist > 100.0 then
                            -- Muito longe, deletar
                            DeleteEntity(ped)
                        else
                            TaskCombatPed(ped, PlayerPedId(), 0, 16)
                            table.insert(newAlive, ped)
                        end
                    end
                end
            end
            zombiePeds = newAlive
        end
    end
end)

-- ============================================================
-- Comando /evento - ver evento ativo (para qualquer jogador)
-- ============================================================
RegisterCommand('eventoinfo', function()
    local event = GlobalState.activeEvent
    if event then
        local remaining = event.endTime - os.time()
        if remaining < 0 then remaining = 0 end
        local mins = math.floor(remaining / 60)

        Notify(
            (event.icon or '') .. ' ' .. event.label,
            event.description .. '\nTempo restante: ' .. mins .. ' minuto(s)',
            'info'
        )
    else
        Notify('Eventos', 'Nenhum evento ativo no momento.', 'info')
    end
end, false)

-- ============================================================
-- Sincronizar ao conectar
-- ============================================================
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    -- Pedir sincronizacao do servidor
    TriggerServerEvent('eventos:server:requestSync')
end)

-- ============================================================
-- Monitorar mudancas no GlobalState (backup de sincronizacao)
-- ============================================================
AddStateBagChangeHandler('activeEvent', 'global', function(bagName, key, value)
    if value then
        -- Evento ficou ativo via GlobalState
        if not currentEvent or currentEvent.name ~= value.name then
            -- O evento client:eventStarted ja deveria ter sido disparado
            -- Isto serve como fallback
        end
    else
        -- Evento foi removido
        if currentEvent then
            local eventName = currentEvent.name
            currentEvent = nil
            showTimer = false
            eventEndTime = 0
            ClearEventBlips()
            ClearZombiePeds()
        end
    end
end)

-- ============================================================
-- Limpeza ao sair do resource
-- ============================================================
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end

    -- Limpar tudo
    ClearEventBlips()
    ClearZombiePeds()
    currentEvent = nil
    showTimer = false
end)
