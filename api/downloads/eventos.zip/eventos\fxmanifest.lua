fx_version 'cerulean'
game 'gta5'

description 'Sistema de Eventos para FiveM (QBox/QBCore)'
author 'Seu Servidor'
version '1.0.0'

lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',
}

client_scripts {
    'client/main.lua',
}

dependencies {
    'ox_lib',
    'oxmysql',
    'qb-core',
}
