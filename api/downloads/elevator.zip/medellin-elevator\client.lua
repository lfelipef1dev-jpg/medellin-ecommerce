-- Robust load of cfg.lua (avoids require path issues)
local cfg = (function()
    local raw = LoadResourceFile(GetCurrentResourceName(), "cfg.lua")
    if raw then
        local fn, err = load(raw, "cfg", "t")
        if fn then
            local ok, res = pcall(fn)
            if ok and type(res) == "table" then
                return res
            end
        end
    end
    -- fallback (older require style)
    local ok, res = pcall(require, "cfg")
    if ok and type(res) == "table" then
        return res
    end
    return { elevator = {} }
end)()


----------------------------------------------------------------------------------------------------------------------------------
-- GLOBAIS
----------------------------------------------------------------------------------------------------------------------------------
local function showHelpNotification(msg)
    BeginTextCommandDisplayHelp("STRING")
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandDisplayHelp(0, false, true, 1)
end

-----------------------------------------------------------------------------------------------------------------
-- ELEVATOR (ox_lib context menu — substitui NUI)
-----------------------------------------------------------------------------------------------------------------
local nearestElevator = {}
local elevatorType = nil

local function openElevatorMenu()
    if not elevatorType or not cfg.elevator[elevatorType] then return end

    local options = {}
    for _, v in pairs(cfg.elevator[elevatorType].andares) do
        options[#options + 1] = {
            title = 'Andar ' .. v.name,
            onSelect = function()
                local ped = PlayerPedId()
                DoScreenFadeOut(1000)
                SetTimeout(1400, function()
                    SetEntityCoords(ped, v.coords, 0, 0, 0, 0)
                    SetEntityHeading(ped, v.h)
                    DoScreenFadeIn(1000)
                end)
            end,
        }
    end

    lib.registerContext({
        id = 'elevator_menu',
        title = 'Elevador',
        options = options,
    })
    lib.showContext('elevator_menu')
end

-- ATUALIZA OS ELEVADORES PROXIMOS
CreateThread(function()
    while true do
        local playercoords = GetEntityCoords(PlayerPedId())
        for k in pairs(cfg.elevator) do
            for k2 in pairs(cfg.elevator[k].blips) do
                local distance = #(playercoords - cfg.elevator[k].blips[k2].coords)
                if distance < 3 then
                    nearestElevator[k .. "-" .. k2] = cfg.elevator[k].blips[k2]
                    elevatorType = k
                elseif nearestElevator[k .. "-" .. k2] then
                    nearestElevator[k .. "-" .. k2] = nil
                    elevatorType = nil
                end
            end
        end
        Citizen.Wait(1000)
    end
end)

-- THREAD DOS MARKERS E ATIVADORA DO MENU
Citizen.CreateThread(function()
    while true do
        local delay = 1000
        if next(nearestElevator) then
            local playercoords = GetEntityCoords(PlayerPedId())
            for i in pairs(nearestElevator) do
                if nearestElevator[i] then
                    delay = 4
                    local coords = nearestElevator[i].coords
                    local distance = #(playercoords - coords)
                    if distance < 2 then
                        showHelpNotification("Pressione ~INPUT_PICKUP~ (E) para usar o elevador")
                    end
                    if distance < 2 and IsControlJustPressed(0, 38) then
                        openElevatorMenu()
                    end
                end
            end
        end
        Citizen.Wait(delay)
    end
end)
