fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Medellin - Elevador simples (portado para QBCore/standalone)'
version '1.0.0'

-- ui_page removida Fase3.2 — substituída por lib.showContext

shared_scripts {
    '@ox_lib/init.lua',
    'cfg.lua',
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
	'client.lua',
}