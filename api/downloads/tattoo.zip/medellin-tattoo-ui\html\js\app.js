// ============================================
// MEDELLIN TATTOO UI - JavaScript v3.0
// Grid com IMAGENS de tatuagem + painel ampliado
// ============================================

const categoryConfig = {
    head:     { name: 'Cabeca',         zone: 'ZONE_HEAD' },
    torso:    { name: 'Torso',          zone: 'ZONE_TORSO' },
    leftArm:  { name: 'Braco Esquerdo', zone: 'ZONE_LEFT_ARM' },
    rightArm: { name: 'Braco Direito',  zone: 'ZONE_RIGHT_ARM' },
    leftLeg:  { name: 'Perna Esquerda', zone: 'ZONE_LEFT_LEG' },
    rightLeg: { name: 'Perna Direita',  zone: 'ZONE_RIGHT_LEG' }
};

// URL base das imagens (resource medellin-assets-appearance, raiz)
const IMG_BASE = 'nui://medellin-assets-appearance/';

const state = {
    isOpen: false,
    isMale: true,
    currentCategory: null,
    currentIndex: -1,
    tattoos: {},
    appliedTattoos: []
};

const elements = {};

// ============================================
// INIT
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    cacheElements();
    setupEventListeners();
    setupNuiCallbacks();
});

function cacheElements() {
    elements.app            = document.getElementById('app');
    elements.contentTitle   = document.getElementById('content-title');
    elements.contentCounter = document.getElementById('content-counter');
    elements.placeholder    = document.getElementById('placeholder');
    elements.tattooGrid     = document.getElementById('tattoo-grid');
    elements.contentActions = document.getElementById('content-actions');
    elements.selectedInfo   = document.getElementById('selected-info');
    elements.selectedNumber = document.getElementById('selected-number');
    elements.selectedLabel  = document.getElementById('selected-label');
    elements.btnApply       = document.getElementById('btn-apply');
    elements.btnRemove      = document.getElementById('btn-remove');
    elements.btnClearAll    = document.getElementById('btn-clear-all');
    elements.btnCancel      = document.getElementById('btn-cancel');
    elements.btnSave        = document.getElementById('btn-save');
    elements.sidebarTabs    = document.querySelectorAll('.sidebar-tabs .sidebar-tab');
}

function setupEventListeners() {
    elements.sidebarTabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            openCategory(tab.dataset.category);
        });
    });

    elements.btnClearAll.addEventListener('click', clearAllTattoos);
    elements.btnApply.addEventListener('click', applyTattoo);
    elements.btnRemove.addEventListener('click', removeTattoo);
    elements.btnCancel.addEventListener('click', cancel);
    elements.btnSave.addEventListener('click', save);
}

function setupNuiCallbacks() {
    window.addEventListener('message', function(event) {
        var data = event.data;
        switch (data.action) {
            case 'open':
                openUI(data);
                break;
            case 'close':
                closeUI();
                break;
        }
    });
}

// ============================================
// UI
// ============================================

function openUI(data) {
    state.isOpen = true;
    state.isMale = data.isMale !== false;
    state.tattoos = data.tattoos || {};
    state.appliedTattoos = data.appliedTattoos || [];
    elements.app.classList.remove('hidden');
    resetView();

    // Auto-abrir primeira categoria com tattoos (mesma tecnica da barbearia)
    var firstCategory = null;
    var priorities = ['torso', 'leftArm', 'rightArm', 'head', 'leftLeg', 'rightLeg'];
    for (var i = 0; i < priorities.length; i++) {
        if (state.tattoos[priorities[i]] && state.tattoos[priorities[i]].length > 0) {
            firstCategory = priorities[i];
            break;
        }
    }
    if (firstCategory) {
        openCategory(firstCategory);
    }
}

function closeUI() {
    state.isOpen = false;
    elements.app.classList.add('hidden');
    state.currentCategory = null;
    state.currentIndex = -1;
}

function resetView() {
    state.currentCategory = null;
    state.currentIndex = -1;
    elements.sidebarTabs.forEach(function(t) { t.classList.remove('active'); });
    elements.placeholder.classList.remove('hidden');
    elements.tattooGrid.classList.add('hidden');
    elements.contentActions.classList.add('hidden');
    elements.selectedInfo.classList.add('hidden');
    elements.contentTitle.textContent = 'Selecione uma zona';
    elements.contentCounter.textContent = '';
    elements.tattooGrid.innerHTML = '';
}

function openCategory(category) {
    var config = categoryConfig[category];
    if (!config) return;

    state.currentCategory = category;
    state.currentIndex = -1;

    elements.sidebarTabs.forEach(function(tab) {
        tab.classList.toggle('active', tab.dataset.category === category);
    });

    var tattooList = state.tattoos[category] || [];
    elements.contentTitle.textContent = config.name;
    elements.contentCounter.textContent = tattooList.length + ' tattoos';

    elements.placeholder.classList.add('hidden');
    elements.tattooGrid.classList.remove('hidden');
    elements.contentActions.classList.remove('hidden');
    elements.selectedInfo.classList.remove('hidden');
    elements.selectedNumber.textContent = '--';
    elements.selectedLabel.textContent = 'Selecione uma tatuagem';

    buildGrid(tattooList);

    // Notificar client.lua para mover camera
    fetch('https://medellin-tattoo-ui/changeZone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category: category })
    });
}

// ============================================
// GRID — IMAGENS DE TATUAGEM
// ============================================

function getImageUrl(tattoo, ext) {
    // O hash da tattoo (ex: MP_Airraces_Tattoo_000_M) = nome do arquivo .jpg ou .png
    var hash = tattoo.name || '';
    if (!hash) return null;
    return IMG_BASE + hash + (ext || '.jpg');
}

function buildGrid(tattooList) {
    elements.tattooGrid.innerHTML = '';

    if (tattooList.length === 0) {
        var empty = document.createElement('div');
        empty.style.cssText = 'grid-column:1/-1; text-align:center; color:rgba(255,255,255,0.3); font-size:12px; padding:30px;';
        empty.textContent = 'Nenhuma tatuagem disponivel';
        elements.tattooGrid.appendChild(empty);
        return;
    }

    for (var i = 0; i < tattooList.length; i++) {
        var btn = document.createElement('button');
        btn.className = 'grid-btn';
        btn.dataset.index = i;

        var inner = document.createElement('span');
        inner.className = 'grid-btn-inner';

        // Tentar carregar imagem
        var imgUrl = getImageUrl(tattooList[i]);
        var label = tattooList[i].label || 'Tattoo';
        var maxLabel = 16;

        if (imgUrl) {
            var img = document.createElement('img');
            img.className = 'grid-img';
            img.src = imgUrl;
            img.alt = label;
            img.loading = 'lazy';
            // Se .jpg falhar, tentar .png, depois .webp. Se todos falharem, fallback texto
            img.onerror = (function(innerEl, idx, lbl, tattoo) {
                var triedPng = false;
                var triedWebp = false;
                return function() {
                    if (!triedPng) {
                        triedPng = true;
                        this.src = getImageUrl(tattoo, '.png');
                        return;
                    }
                    if (!triedWebp) {
                        triedWebp = true;
                        this.src = getImageUrl(tattoo, '.webp');
                        return;
                    }
                    this.remove();
                    innerEl.classList.add('grid-btn-fallback');
                    var numSpan = document.createElement('span');
                    numSpan.className = 'grid-num';
                    numSpan.textContent = idx + 1;
                    var labelSpan = document.createElement('span');
                    labelSpan.className = 'grid-label';
                    labelSpan.textContent = lbl.length > maxLabel ? lbl.substring(0, maxLabel - 1) + '…' : lbl;
                    innerEl.appendChild(numSpan);
                    innerEl.appendChild(labelSpan);
                };
            })(inner, i, label, tattooList[i]);

            inner.appendChild(img);
        } else {
            // Sem hash — fallback texto
            inner.classList.add('grid-btn-fallback');
            var numSpan = document.createElement('span');
            numSpan.className = 'grid-num';
            numSpan.textContent = i + 1;
            var labelSpan = document.createElement('span');
            labelSpan.className = 'grid-label';
            labelSpan.textContent = label.length > maxLabel ? label.substring(0, maxLabel - 1) + '…' : label;
            inner.appendChild(numSpan);
            inner.appendChild(labelSpan);
        }

        btn.appendChild(inner);

        if (tattooList[i].label) {
            btn.title = (i + 1) + ' - ' + tattooList[i].label;
        }

        btn.addEventListener('click', onGridClick);
        elements.tattooGrid.appendChild(btn);
    }
}

function onGridClick(e) {
    var btn = e.currentTarget;
    var index = parseInt(btn.dataset.index);
    state.currentIndex = index;

    var buttons = elements.tattooGrid.querySelectorAll('.grid-btn');
    for (var i = 0; i < buttons.length; i++) {
        buttons[i].classList.toggle('active', parseInt(buttons[i].dataset.index) === index);
    }

    var tattooList = state.tattoos[state.currentCategory] || [];
    if (index >= 0 && index < tattooList.length) {
        elements.selectedNumber.textContent = '#' + (index + 1);
        elements.selectedLabel.textContent = tattooList[index].label || 'Tatuagem ' + (index + 1);
    }

    previewTattoo();
}

// ============================================
// ACOES
// ============================================

function previewTattoo() {
    var tattooList = state.tattoos[state.currentCategory] || [];
    if (state.currentIndex < 0 || state.currentIndex >= tattooList.length) return;
    var tattoo = tattooList[state.currentIndex];

    fetch('https://medellin-tattoo-ui/previewTattoo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            collection: tattoo.collection,
            name: tattoo.name,
            category: state.currentCategory
        })
    });
}

function applyTattoo() {
    var tattooList = state.tattoos[state.currentCategory] || [];
    if (state.currentIndex < 0 || state.currentIndex >= tattooList.length) return;
    var tattoo = tattooList[state.currentIndex];

    fetch('https://medellin-tattoo-ui/applyTattoo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            collection: tattoo.collection,
            name:       tattoo.name,
            tatName:    tattoo.tatName || tattoo.name,
            hashMale:   tattoo.hashMale || '',
            hashFemale: tattoo.hashFemale || '',
            zone:       tattoo.zone || '',
            category:   state.currentCategory,
            label:      tattoo.label
        })
    });
}

function removeTattoo() {
    fetch('https://medellin-tattoo-ui/removeTattoo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category: state.currentCategory })
    });
}

function clearAllTattoos() {
    fetch('https://medellin-tattoo-ui/clearAllTattoos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
}

function cancel() {
    fetch('https://medellin-tattoo-ui/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
}

function save() {
    fetch('https://medellin-tattoo-ui/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
}
