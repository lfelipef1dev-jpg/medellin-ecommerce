--[[
    MEDELLIN TATTOO UI v1.0
    Sistema de Tatuagem Visual Personalizado
    
    Cores: Verde/Azul/Preto (Paleta Medellin)
]]

fx_version 'cerulean'
lua54 'yes'
game 'gta5'

name 'medellin-tattoo-ui'
description 'Sistema de Tatuagem Visual - Medellin Roleplay'
author 'Medellin Dev Team'
version '1.0.0'

ui_page 'html/index.html'

shared_scripts {
    '@ox_lib/init.lua',
    '@illenium-appearance/shared/config.lua',
    '@illenium-appearance/shared/tattoos.lua',
}

client_scripts {
    '@qbx_core/modules/playerdata.lua',
    'client.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua',
}

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/app.js',
}

dependencies {
    'ox_lib',
}
