--[[
    MEDELLIN TATTOO UI - Client v2.0
    Sistema de Tatuagem Visual — Corrigido

    Fixes:
    - Camera por zona do corpo (head, torso, bracos, pernas)
    - Rotacao A/D funcional (DisableControlAction + IsDisabledControlPressed)
    - Salva tatuagens via illenium-appearance (persiste no banco)
    - Grid com labels ao inves de so numeros
]]

local QBCore = exports['qb-core']:GetCoreObject()
local isOpen = false
local appliedTattoos = {}      -- Tatuagens aplicadas nesta sessao
local savedTattoos = {}        -- Tatuagens salvas no banco (carregadas ao abrir)
local previewTattoo = nil
local blockEscUntil = 0

-- ============================================
-- VERIFICAR CONFIG
-- ============================================

CreateThread(function()
    Wait(1000)
    if Config and Config.Tattoos then
        local total = 0
        for _, list in pairs(Config.Tattoos) do
            total = total + #list
        end
    else
    end
end)

-- ============================================
-- MAPEAMENTO DE ZONAS
-- ============================================

local TattooZones = {
    head     = "ZONE_HEAD",
    torso    = "ZONE_TORSO",
    leftArm  = "ZONE_LEFT_ARM",
    rightArm = "ZONE_RIGHT_ARM",
    leftLeg  = "ZONE_LEFT_LEG",
    rightLeg = "ZONE_RIGHT_LEG"
}

local ZoneToCategory = {}
for cat, zone in pairs(TattooZones) do
    ZoneToCategory[zone] = cat
end

-- ============================================
-- FUNCOES AUXILIARES
-- ============================================

local function IsMale()
    return GetEntityModel(PlayerPedId()) == GetHashKey("mp_m_freemode_01")
end

local function GetTattoosByZone()
    local isMale = IsMale()
    local tattoos = {
        head = {}, torso = {},
        leftArm = {}, rightArm = {},
        leftLeg = {}, rightLeg = {}
    }

    local configTattoos = Config and Config.Tattoos
    if not configTattoos then
        local ok, result = pcall(exports['illenium-appearance'].getTattooList, exports['illenium-appearance'])
        if ok then configTattoos = result end
    end

    if not configTattoos then
        return tattoos
    end

    for zoneName, tattooList in pairs(configTattoos) do
        local category = ZoneToCategory[zoneName]
        if category and tattooList then
            for _, tattoo in ipairs(tattooList) do
                local hash = isMale and tattoo.hashMale or tattoo.hashFemale
                if hash and hash ~= "" then
                    table.insert(tattoos[category], {
                        collection = tattoo.collection,
                        name       = hash,
                        label      = tattoo.label or tattoo.name or "Tatuagem",
                        tatName    = tattoo.name,           -- ID original (ex: TAT_AR_000)
                        hashMale   = tattoo.hashMale,
                        hashFemale = tattoo.hashFemale,
                        zone       = zoneName,
                    })
                end
            end
        end
    end

    return tattoos
end

-- ============================================
-- CARREGAR TATUAGENS SALVAS DO ILLENIUM
-- ============================================

local function LoadSavedTattoos()
    savedTattoos = {}
    local ok, result = pcall(function()
        return exports['illenium-appearance']:getPedTattoos()
    end)
    if ok and result then
        for zoneName, list in pairs(result) do
            local cat = ZoneToCategory[zoneName]
            if cat then
                for _, t in ipairs(list) do
                    table.insert(savedTattoos, {
                        collection = t.collection,
                        name       = IsMale() and t.hashMale or t.hashFemale,
                        tatName    = t.name,
                        hashMale   = t.hashMale,
                        hashFemale = t.hashFemale,
                        zone       = zoneName,
                        category   = cat,
                        label      = t.label or t.name,
                        opacity    = t.opacity or 0.1,
                    })
                end
            end
        end
    end
    -- Iniciar appliedTattoos com as salvas
    appliedTattoos = {}
    for _, t in ipairs(savedTattoos) do
        table.insert(appliedTattoos, {
            collection = t.collection,
            name       = t.name,
            tatName    = t.tatName,
            hashMale   = t.hashMale,
            hashFemale = t.hashFemale,
            zone       = t.zone,
            category   = t.category,
            label      = t.label,
            opacity    = t.opacity,
        })
    end
end

-- ============================================
-- ROUPA (cueca para visualizar tattoos)
-- ============================================

local originalClothes = {}

local function SaveCurrentClothes()
    local ped = PlayerPedId()
    originalClothes = {}
    for i = 0, 11 do
        originalClothes[i] = {
            drawable = GetPedDrawableVariation(ped, i),
            texture  = GetPedTextureVariation(ped, i)
        }
    end
end

local function SetUnderwear()
    local ped = PlayerPedId()
    if IsMale() then
        SetPedComponentVariation(ped, 3, 15, 0, 0)
        SetPedComponentVariation(ped, 4, 61, 0, 0)
        SetPedComponentVariation(ped, 6, 34, 0, 0)
        SetPedComponentVariation(ped, 8, 15, 0, 0)
        SetPedComponentVariation(ped, 11, 15, 0, 0)
    else
        SetPedComponentVariation(ped, 3, 15, 0, 0)
        SetPedComponentVariation(ped, 4, 17, 0, 0)
        SetPedComponentVariation(ped, 6, 35, 0, 0)
        SetPedComponentVariation(ped, 8, 15, 0, 0)
        SetPedComponentVariation(ped, 11, 15, 0, 0)
    end
end

local function RestoreClothes()
    local ped = PlayerPedId()
    for i, cloth in pairs(originalClothes) do
        SetPedComponentVariation(ped, i, cloth.drawable, cloth.texture, 0)
    end
end

-- ============================================
-- APLICAR DECORATIONS NO PED
-- ============================================

local function ApplyAllDecorations()
    local ped = PlayerPedId()
    ClearPedDecorations(ped)
    for _, t in ipairs(appliedTattoos) do
        SetPedDecoration(ped, GetHashKey(t.collection), GetHashKey(t.name))
    end
end

-- ============================================
-- CAMERA POR ZONA DO CORPO
-- ============================================

local tattooCam = nil
local originalHeading = 0.0
local currentRotation = 0.0

-- Offsets: { forward, right, up, fov, lookAtOffsetZ }
local CameraPresets = {
    default  = { fwd = 2.5,  right = 0.0,  up = 0.3,  fov = 48.0, lookZ = -0.1 },
    head     = { fwd = 1.0,  right = 0.0,  up = 0.65, fov = 30.0, lookZ =  0.6 },
    torso    = { fwd = 1.5,  right = 0.0,  up = 0.2,  fov = 40.0, lookZ =  0.0 },
    leftArm  = { fwd = 1.3,  right = -0.5, up = 0.15, fov = 38.0, lookZ =  0.0 },
    rightArm = { fwd = 1.3,  right = 0.5,  up = 0.15, fov = 38.0, lookZ =  0.0 },
    leftLeg  = { fwd = 1.8,  right = -0.3, up = -0.3, fov = 40.0, lookZ = -0.6 },
    rightLeg = { fwd = 1.8,  right = 0.3,  up = -0.3, fov = 40.0, lookZ = -0.6 },
}

local function SetCameraForZone(zone)
    local preset = CameraPresets[zone] or CameraPresets.default
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    if tattooCam then
        DestroyCam(tattooCam, false)
    end

    tattooCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    local camPos = GetOffsetFromEntityInWorldCoords(ped, preset.right, preset.fwd, preset.up)
    SetCamCoord(tattooCam, camPos.x, camPos.y, camPos.z)
    PointCamAtCoord(tattooCam, coords.x, coords.y, coords.z + preset.lookZ)
    SetCamFov(tattooCam, preset.fov)
    SetCamActive(tattooCam, true)
    RenderScriptCams(true, true, 300, true, true)
end

local function StartTattooPose()
    local ped = PlayerPedId()
    originalHeading = GetEntityHeading(ped)
    currentRotation = originalHeading
    FreezeEntityPosition(ped, true)
    SetCameraForZone("default")
end

local function RotateCharacter(direction)
    local ped = PlayerPedId()
    currentRotation = currentRotation + (direction * 3.0)
    SetEntityHeading(ped, currentRotation)
end

local function StopTattooPose()
    local ped = PlayerPedId()
    ClearPedTasks(ped)
    FreezeEntityPosition(ped, false)

    if tattooCam then
        RenderScriptCams(false, true, 500, true, true)
        DestroyCam(tattooCam, false)
        tattooCam = nil
    end

    SetEntityHeading(ped, originalHeading)
end

-- ============================================
-- SALVAR NO ILLENIUM-APPEARANCE (PERSISTENCIA)
-- ============================================

local function SaveToIllenium()
    -- Montar estrutura esperada: { ZONE_HEAD = { {name, label, hashMale, hashFemale, collection, zone, opacity} }, ... }
    local tattoosByZone = {}
    for _, zone in pairs(TattooZones) do
        tattoosByZone[zone] = {}
    end

    for _, t in ipairs(appliedTattoos) do
        local zone = t.zone or TattooZones[t.category] or "ZONE_TORSO"
        if not tattoosByZone[zone] then tattoosByZone[zone] = {} end
        table.insert(tattoosByZone[zone], {
            name       = t.tatName or t.name,
            label      = t.label,
            hashMale   = t.hashMale or (IsMale() and t.name or ""),
            hashFemale = t.hashFemale or (not IsMale() and t.name or ""),
            collection = t.collection,
            zone       = zone,
            opacity    = t.opacity or 0.1,
        })
    end

    -- Atualizar no illenium-appearance client-side
    local ok, _ = pcall(function()
        exports['illenium-appearance']:setPedTattoos(PlayerPedId(), tattoosByZone)
    end)

    if ok then
        -- Pegar appearance completa e enviar pro server salvar
        local appearance = nil
        local ok2, result = pcall(function()
            return exports['illenium-appearance']:getPedAppearance(PlayerPedId())
        end)
        if ok2 and result then
            appearance = result
            appearance.tattoos = tattoosByZone
        end

        if appearance then
            TriggerServerEvent("illenium-appearance:server:saveAppearance", appearance)
        else
            -- Fallback: salvar so tattoos via evento custom
            TriggerServerEvent("medellin-tattoo-ui:server:saveTattoos", tattoosByZone)
        end
    else
        -- Fallback se illenium-appearance nao tiver export
        TriggerServerEvent("medellin-tattoo-ui:server:saveTattoos", tattoosByZone)
    end
end

-- ============================================
-- ABRIR / FECHAR UI
-- ============================================

local function OpenTattooUI()
    if isOpen then return end

    -- Verificar se outro menu esta aberto
    if GetResourceState('medellin-utils') == 'started' then
        local ok, isNuiOpen = pcall(exports['medellin-utils'].IsAppearanceNuiOpen, exports['medellin-utils'])
        if ok and isNuiOpen then
            QBCore.Functions.Notify('Feche o outro menu primeiro.', 'error', 3000)
            return
        end
    end

    isOpen = true

    if GetResourceState('medellin-utils') == 'started' then
        pcall(exports['medellin-utils'].SetAppearanceNuiOpen, exports['medellin-utils'], true)
    end

    SaveCurrentClothes()
    LoadSavedTattoos()
    SetUnderwear()

    local tattoos = GetTattoosByZone()

    SendNUIMessage({
        action         = "open",
        isMale         = IsMale(),
        tattoos        = tattoos,
        appliedTattoos = appliedTattoos
    })

    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(true)
    Wait(100)
    StartTattooPose()
end

local function CloseTattooUI(save)
    if not isOpen then return end

    if GetResourceState('medellin-utils') == 'started' then
        pcall(exports['medellin-utils'].SetAppearanceNuiOpen, exports['medellin-utils'], false)
    end

    blockEscUntil = GetGameTimer() + 1000
    isOpen = false

    SetNuiFocusKeepInput(false)
    SetNuiFocus(false, false)
    StopTattooPose()
    RestoreClothes()

    if save then
        -- Aplicar decorations finais e salvar no banco
        ApplyAllDecorations()
        SaveToIllenium()
    else
        -- Restaurar tatuagens originais (do banco)
        local ped = PlayerPedId()
        ClearPedDecorations(ped)
        for _, t in ipairs(savedTattoos) do
            SetPedDecoration(ped, GetHashKey(t.collection), GetHashKey(t.name))
        end
    end

    SendNUIMessage({ action = "close" })
end

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    if GetResourceState('medellin-utils') == 'started' then
        pcall(exports['medellin-utils'].SetAppearanceNuiOpen, exports['medellin-utils'], false)
    end
    if isOpen then
        SetNuiFocus(false, false)
        SetNuiFocusKeepInput(false)
        isOpen = false
        StopTattooPose()
        RestoreClothes()
    end
end)

-- ============================================
-- NUI CALLBACKS
-- ============================================

RegisterNUICallback('previewTattoo', function(data, cb)
    local ped = PlayerPedId()
    ClearPedDecorations(ped)

    -- Reaplicar todas as aplicadas
    for _, t in ipairs(appliedTattoos) do
        SetPedDecoration(ped, GetHashKey(t.collection), GetHashKey(t.name))
    end

    -- Adicionar preview
    if data.collection and data.name then
        SetPedDecoration(ped, GetHashKey(data.collection), GetHashKey(data.name))
        previewTattoo = data
    end

    cb('ok')
end)

RegisterNUICallback('changeZone', function(data, cb)
    if data.category then
        SetCameraForZone(data.category)
    end
    cb('ok')
end)

RegisterNUICallback('applyTattoo', function(data, cb)
    table.insert(appliedTattoos, {
        collection = data.collection,
        name       = data.name,
        tatName    = data.tatName,
        hashMale   = data.hashMale,
        hashFemale = data.hashFemale,
        zone       = data.zone,
        category   = data.category,
        label      = data.label,
        opacity    = 0.1,
    })

    ApplyAllDecorations()
    previewTattoo = nil

    lib.notify({ title = 'Tatuagem', description = 'Tatuagem aplicada!', type = 'success' })
    cb('ok')
end)

RegisterNUICallback('removeTattoo', function(data, cb)
    local newList = {}
    for _, t in ipairs(appliedTattoos) do
        if t.category ~= data.category then
            table.insert(newList, t)
        end
    end
    appliedTattoos = newList
    ApplyAllDecorations()

    lib.notify({ title = 'Tatuagem', description = 'Tatuagens da zona removidas!', type = 'error' })
    cb('ok')
end)

RegisterNUICallback('clearAllTattoos', function(_, cb)
    ClearPedDecorations(PlayerPedId())
    appliedTattoos = {}
    previewTattoo = nil

    lib.notify({ title = 'Tatuagem', description = 'Todas removidas!', type = 'error' })
    cb('ok')
end)

RegisterNUICallback('cancel', function(_, cb)
    CloseTattooUI(false)
    cb('ok')
end)

RegisterNUICallback('save', function(_, cb)
    CloseTattooUI(true)
    lib.notify({ title = 'Tatuagem', description = 'Tatuagens salvas!', type = 'success' })
    cb('ok')
end)

-- ============================================
-- EXPORTS & COMANDOS
-- ============================================

exports('OpenTattooUI', OpenTattooUI)
exports('CloseTattooUI', CloseTattooUI)

RegisterCommand('tattoo', function()
    OpenTattooUI()
end, false)

-- ============================================
-- TECLAS: ESC, A (34), D (35)
-- ============================================

CreateThread(function()
    while true do
        if isOpen then
            Wait(0) -- Per-frame para rotacao suave

            -- Desabilitar controles que conflitam
            DisableControlAction(0, 1, true)    -- Mouse LR
            DisableControlAction(0, 2, true)    -- Mouse UD
            DisableControlAction(0, 24, true)   -- Attack
            DisableControlAction(0, 25, true)   -- Aim
            DisableControlAction(0, 34, true)   -- Move Left (A)
            DisableControlAction(0, 35, true)   -- Move Right (D)
            DisableControlAction(0, 30, true)   -- Move LR
            DisableControlAction(0, 31, true)   -- Move UD
            DisableControlAction(0, 47, true)   -- Weapon
            DisableControlAction(0, 58, true)   -- Enter Vehicle
            DisableControlAction(0, 140, true)  -- Melee
            DisableControlAction(0, 141, true)  -- Melee
            DisableControlAction(0, 142, true)  -- Melee
            DisableControlAction(0, 143, true)  -- Melee
            DisableControlAction(0, 199, true)  -- Pause
            DisableControlAction(0, 200, true)  -- ESC/Map

            SetPauseMenuActive(false)

            -- ESC para fechar
            if IsDisabledControlJustPressed(0, 200) then
                CloseTattooUI(false)
            end

            -- A = rotacionar esquerda
            if IsDisabledControlPressed(0, 34) then
                RotateCharacter(-1)
            end

            -- D = rotacionar direita
            if IsDisabledControlPressed(0, 35) then
                RotateCharacter(1)
            end
        else
            -- Idle: bloquear ESC por 1s apos fechar (evita abrir pause menu)
            if GetGameTimer() < blockEscUntil then
                DisableControlAction(0, 200, true)
                SetPauseMenuActive(false)
                Wait(0)
            else
                Wait(500)
            end
        end
    end
end)

-- ============================================
-- LOJAS DE TATUAGEM (markers + interacao)
-- ============================================

local TattooShops = {
    { x = 1322.92,  y = -1652.27, z = 52.27 },
    { x = -1154.42, y = -1425.89, z = 4.94  },
    { x = 322.83,   y = 180.16,   z = 103.58 },
    { x = -3169.61, y = 1075.80,  z = 20.82 },
    { x = 1864.07,  y = 3748.09,  z = 33.03 },
    { x = -293.57,  y = 6199.85,  z = 31.48 },
    { x = -1612.08, y = -1075.58, z = 13.08 },
}

local function Draw3DText(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
        local factor = (string.len(text)) / 370
        DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 0, 0, 0, 75)
    end
end

CreateThread(function()
    while true do
        local sleep = 1000
        local playerCoords = GetEntityCoords(PlayerPedId())

        for _, shop in ipairs(TattooShops) do
            local shopCoords = vector3(shop.x, shop.y, shop.z)
            local dist = #(playerCoords - shopCoords)

            if dist < 20.0 then
                sleep = 0
                DrawMarker(27, shop.x, shop.y, shop.z - 0.98, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    1.2, 1.2, 0.15, 0, 255, 136, 200, false, true, 2, false, nil, nil, false)
                if not isOpen then
                    Draw3DText(shop.x, shop.y, shop.z + 0.3, "~g~[E]~w~ Tatuagem")
                end
                if dist < 3.0 and IsControlJustPressed(0, 38) and not isOpen then
                    OpenTattooUI()
                end
            end
        end

        Wait(sleep)
    end
end)

