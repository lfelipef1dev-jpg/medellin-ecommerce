--[[
    MEDELLIN TATTOO UI - Server v2.0
    Salva tatuagens via illenium-appearance
]]

local QBCore = exports['qb-core']:GetCoreObject()

-- Fallback: salvar tatuagens diretamente se illenium-appearance nao responder
RegisterNetEvent('medellin-tattoo-ui:server:saveTattoos', function(tattoosByZone)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local citizenid = Player.PlayerData.citizenid
    if not citizenid then return end

    -- Tentar salvar via illenium-appearance framework
    local ok, _ = pcall(function()
        local appearance = MySQL.single.await(
            'SELECT skin FROM playerskins WHERE citizenid = ?',
            { citizenid }
        )
        if appearance and appearance.skin then
            local skinData = json.decode(appearance.skin)
            if skinData then
                skinData.tattoos = tattoosByZone
                MySQL.update.await(
                    'UPDATE playerskins SET skin = ? WHERE citizenid = ?',
                    { json.encode(skinData), citizenid }
                )
            end
        end
    end)

    if not ok then
    end
end)

